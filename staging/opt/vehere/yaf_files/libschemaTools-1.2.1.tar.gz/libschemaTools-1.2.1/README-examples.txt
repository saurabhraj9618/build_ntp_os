Examples of how to use schemaTools can be found in the sub directories
schemaBuilders and schemaTesters.

schemaBuiders show how to build schemas in a number of different ways:

rawIPFIXschema.c uses no apriori knowledge and builds any number of schemas
    based on the IPFIX templates it recieves.  As of now it is hardcoded to 
    listen for IPFIX messages from "localhost" on port 18000.  This will be 
    rectified by an eventual connection mechanism built into schemaTools.

silkSchemaForPipe.c is an attempt to fully describe SiLK records, it is not
    finished yet, just most of the way there.

baseballSchemaForPipe.c and testSchemaForSample.c build similar schemas
    but are set up to provide information for different applications.
    They each define an input schema containing baseball statistics, which
    is just an excuse to mix strings and different integer values.

baseballSchemaForPipe.c provides just an input schema for Analysis Pipeline
    to use.  The notable difference is that it contains a 32bit timestamp.

testSchemaForSample.c provides that same baseball input schema, just without
    the timestamp.  It also provides an output schema which combines some of
    the fields in the input schema.

    The input schema contains 'runs' and 'rbis' fields.  The sum of these
    is the 'runsCreated' field in the output schema.
    The input schema contains 'hits' and 'atBats' fields.  The output schema
    contains a FLOAT_64 called 'AVERAGE' which is 'hits' / 'atBats'.
    All other fields in the input schema are to be copied into the output
    schema.

    This schema builder shows how to make a copy of an existing schema, and
    how to mold it into a new schema by removing, adding, and reordering
    information elements that fill it.

schemaTesters are modules that recieve schemas and use the data records
    described by them.  There is also an exporter included that does not
    use the schema tools, but is connected to one of the modules and could
    be used with any other module accepting IPFIX traffic.

exporters/ipfixSchemaTester.c sends IPFIX traffic to hardcoded 'localhost' and
    port 18000.  It uses 3 different templates, with some overlapping
    information elements, and 2 custom information elements.  It sends 1
    record of each type.  Within the framework of these examples, it is to be 
    used with the sampleIPFIX module, which uses the rawIPFIXschema builder.

modules/rawIpfixModule/sampleIPFIX.c uses the exporter ipfixSchemaTester.c
    and prints the values for the information elements.  It also looks for
    DPORT in each record and prints its value if it's there, or prints that
    there's no DPORT value in the record.  It uses the fast lookup, asking
    for the DPORT IE regardless of the schema.  

modules/baseball/sampleBaseball.c is a module that uses testSchemaForSample.c
    that converts the runs and rbis fields to runsCreated, and hits and
    atBats into average.  It utilizes copyBetweenSchemas and illustrates
    the .setVal functionality with IEs.  TestSchemaForSample.c provides the 
    data records so it doesn't need an exporter.
