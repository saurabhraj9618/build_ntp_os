Once SchemaTools is properly built and installed, there are unit tests to run 
to make sure it's performing properly. 

cd into the "test" directory (cd test)

run the script "theTester.sh" with the first parameter to the script being
the full path to the prefix used with -DCMAKE_INSTALL_PREFIX, when installing
schemaTools.

There will be a lot of compiler output at first, followed by 4 test results.

Everything worked if the output is:
Schema Details Passed
ports passed
baseball passed
rawipfix passed

email netsa-help@cert.org if any tests failed. Please include the full output,
as it contains the deviations from expected results.
