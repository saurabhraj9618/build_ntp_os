#ifndef _SCHEMATOOLS_H
#define _SCHEMATOOLS_H

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>
#include <inttypes.h>
#include <fixbuf/public.h>
#include <schemaTools/scpolldir.h>


/** @file schemaTools.h
 * This library is used for constructing and accessing schemas to describe
 * the components of data. This file contains all publically available
 * functions and data. See the main page for general descriptions.
 */

/** struct to make it easier to manipulate variable length fields in a buffer,
 * Variable lengthed fields in records will be handled by the functions
 * attached to each information element
 */
typedef struct scVarfield_st {
    size_t      len; /*!< Length of the data contained in the varfield */
    uint8_t    *dataPtr; /*!< Pointer to the data contained in the varfield */
} scVarfield_t;

extern scVarfield_t     globalVarFieldForRetPtr;

/**
 * Maximum length of the error string
 */
#define SC_ERROR_MAX_LEN    200

/**
 * Error codes that can be returned from schemaTools library calls
 */
typedef enum scErrorCode_en {
    SC_ERROR_OK = 1, /*!< No error */
    SC_ERROR_NOT_FOUND, /*!< Input is fine, but element not found */
    SC_ERROR_NULL_PARAM, /*!< One of the parameters to the function was NULL */
    SC_ERROR_INVALID_INPUT, /*!< One of the inputs isn't allowed */
    SC_ERROR_WARNING /*!< Things are OK, but not perfect, things can continue */
} scErrorCode_t;

/**
 * Contains more detailed error reporting from functions.
 */
typedef struct scError_st {
    /** Error code defined above */
    scErrorCode_t   code;
    /** Buffer containing a more detailed error message */
    char            msg[SC_ERROR_MAX_LEN];
} scError_t;

/* typedefs allowing builders and users to get pointers to structures */

/**
 * Pairs an integer with a string.
 * Used to translate text that a user puts in a configuration file
 * or command line option into a number.
 * Prime example: TCP flags.  F-->1 A-->2, etc
 * Also, SiLK sensor names
 */
typedef struct scInfoStringVal_st scInfoStringVal_t;

/**
 * Mirrored structure for code readability
 */
typedef struct scInfoStringVal_st scInfoStringValList_t;

/**
 * Info Element type
 */
typedef struct scInfoElement_st scInfoElement_t;

/**
 * Opaque structure used by dataInfo for fast lookups
 */
typedef struct scUniqueIE_st scUniqueIE_t;


/**
 * scNestedIE_t
 * Structure to hold an IE in a group.
 */
typedef struct scNestedIE_st scNestedIE_t;

/**
 * scGroupedElements_t
 * Used to hold a sub list of information elements that have a common
 * user-access string.
 * Prime example: Source IP and Destination IP in a group labled "IP"
 */
typedef struct scGroupedElements_st scGroupedElements_t;

/**
 * scSchema_t
 * Opaque structure holder that holds the schema
 */
typedef struct scSchema_st scSchema_t;

/** scBasicList_t
 * Just a typedef for fbBasicList_t (for now)
 */
typedef fbBasicList_t scBasicList_t;

/**
 * Holds the schema, and record level functions
 */
typedef struct scDataInfo_st scDataInfo_t;

/**
 * Error codes for the get next record function.
 * The values are copied from SiLK skStream.
 * It is unlikely all values will be used
 * SiLK specific ones have been removed
 */
typedef enum {
    /** The last command was completed successfully. */
    SCGETNEXT_OK = 0,

    /* The following often represent programmer errors */

    SCGETNEXT_ERR_ALLOC = -64,
    /* Memory could not be allocated. */

    SCGETNEXT_ERR_CLOSED = -65,
    /* Attempt to operate on a file that is already closed.  Once
     * closed, a stream can only be destroyed; re-opening is not (yet)
     * supported. */

    SCGETNEXT_ERR_NOT_BOUND = -67,
    /* Attempt to open a stream that is not bound to a pathname. */

    SCGETNEXT_ERR_NOT_OPEN = -68,
    /* Attempt to read or write from a stream that has not yet been
     * opened. */

    SCGETNEXT_ERR_NULL_ARGUMENT = -69,
    /* An argument to the function is NULL or empty */

    SCGETNEXT_ERR_PREV_BOUND = -70,
    /* The stream is already bound to a pathname. */

    SCGETNEXT_ERR_UNSUPPORT_CONTENT = -73,
    /* The file's content type does not support the action */

    /* Errors due to missing or outdated libraries */

    /* User errors when creating a new stream */
    SCGETNEXT_ERR_RLOCK = -20,
    /* Could not get a read lock on the stream. */

    SCGETNEXT_ERR_SYS_LSEEK = -22,
    /* The call to lseek() failed. */

    /* Errors that may occur while processing the stream that
     * typically indicate a fatal condition. */

    SCGETNEXT_ERR_IO = -1,
    /* Value returned read() when an error has occured. */

    SCGETNEXT_ERR_IOBUF = -2,
    /* Error with internal buffering. */

    SCGETNEXT_ERR_READ = -4,
    /* There was an error reading from the stream. */

    /** Value returned when the input is exhausted.  Note that reaching
     * the end of a file is not really an "error". */
    SCGETNEXT_ERR_EOF = -5,
    /**
     * Value returned when there is a user-specified interrupt in the
     * processing and there are still records
     */
    SCGETNEXT_ERR_USER_BREAK = -6,

    SCGETNEXT_ERR_READ_SHORT = -7,
    /* The read returned fewer bytes than required for a complete
     * record. */

    SCGETNEXT_ERR_NOT_SEEKABLE = -8,
    /* The operation requires the stream to be bound to a seekable
     * file, and the stream is not. */

    SCGETNEXT_ERR_LONG_LINE = 96
    /* Returned when an input line is longer than
     * the specified buffer size. */

} scDataInfoGetRecErr_t;

typedef enum scIEDiffReason_en {
    IE_DR_EQUAL = 0,
    IE_DR_NULL_PTR,
    IE_DR_ENT,
    IE_DR_DATA_LEVEL,
    IE_DR_LEN,
    IE_DR_ID,
    IE_DR_TYPE,
    IE_DR_SEMANTIC,
    IE_DR_UNITS,
    IE_DR_RANGE_MIN,
    IE_DR_RANGE_MAX,
    IE_DR_NAME
} scIEDiffReason_t;


/*************** Function Signatures ***********/

/* These will be included in structures that define the schema
 * They will be called indirectly by the client program
 */

/**
 * @brief Copies the value of the information element from the raw data record.
 * If the information element is variable lengthed, the contents of the
 * scVarfield_t (length and pointer) will be copied, NOT the field data itself.
 * The same goes for lists.  The list structure will be copied rather than the
 * contents of the list.
 * @param   ie      Pointer to the information element
 * @param   rec     Pointer to the data record to copy FROM
 * @param   outBuf  Pointer to the buffer to copy the element value INTO
 * @return  the number of bytes copied is returned on success
 *          0 is returned on error or if there is no value to be copied
 */
typedef int         (*scInfoElementCopyVal_fn)(
                                                scInfoElement_t    *ie,
                                                const uint8_t      *rec,
                                                uint8_t            *outBuf);

/**
 * @brief Returns a pointer to the value for the information element in the
 * data record. If the information element is variable lengthed it will be a
 * pointer to the scVarfield_t that contains the field rather than the pointer
 * to the variably lengthed data. The same goes for lists. A pointer to the
 * list structure will be returned rather than the list contents.
 * The pointer to the data value is only good until the next call to retPtr.
 * There is no way to guarantee that the memory referenced by the pointer still
 * contains the original data after subsequent calls.
 * @param   ie   Pointer to the information element
 * @param   rec  Pointer to the data record
 * @return  A pointer to the value on success
 *          NULL on failure or if there is no pointer to be returned
 */
typedef uint8_t*    (*scInfoElementRetPtr_fn)(
                                                scInfoElement_t    *ie,
                                                const uint8_t      *rec);

/*
 * Both of these functions:
 * *iteration should be set to 0 for the first one. The function will set
 * it and it is to be reused for future calls.
 * It will set it back to 0 when it is not to be called anymore.
 * int iter = 0;
 *  do {
 *      ie->copyValIter(ie, rec, outBuf, &iter);
 *  } while (*iter);
 */

typedef int         (*scInfoElementCopyValIter_fn)(
                                                scInfoElement_t    *ie,
                                                const uint8_t      *rec,
                                                uint8_t            *outBuf,
                                                int                *iteration);

typedef uint8_t*    (*scInfoElementRetPtrIter_fn)(
                                                scInfoElement_t    *ie,
                                                const uint8_t      *rec,
                                                int                *iteration);
/**
 * Copies the value into a record.  To set the value of a variable lengthed
 * field, a buffer containing an fbVarfield_t or a list structure is passed
 * as the contents of inBuf, not the data for the field itself..
 * @param ie    Pointer to the information element
 * @param rec   Pointer to the record where the value is to written
 * @param inBuf Pointer to the buffer containing the value to be written
 * @return      0 is returned on success
 *              Not 0 is returned on failure
 */
typedef int         (*scInfoElementSetVal_fn) (
                                                scInfoElement_t    *ie,
                                                uint8_t            *rec,
                                                uint8_t            *inBuf);

/**
 * Converts the value for a given information element to a human readable
 * format.  Basically an snprintf() for the element type. IPv4 addresses are
 * printed in hexadecimal notation.
 * @param ie    Pointer to the information element
 * @param buf   Pointer to buffer where the printed value is to be written
 * @param maxlen number of bytes available in the buffer for writing
 * @param val   Pointer to the buffer containing the value to be printed
 * @return      number of bytes written to the buffer
 */
typedef int (*scInfoElementPrint_fn)(
                                                scInfoElement_t    *ie,
                                                char               *buf,
                                                int                 maxlen,
                                                const uint8_t      *val);

/**
 * Merges two values of the same IE into one.  e.g. sum of two byte count fields
 * Parameters:
 * @param ie    Pointer to the information element describing the data
 * @param outBuf Pointer to the buffer where the merged value is to be written
 * @param buf1  Pointer to the buffer with one of the values to merge
 * @param buf2  Pointer to the buffer with the other value to merge
 * @return      The number of bytes written into the merge buffer
 */
typedef uint32_t (*scInfoElementMerge_fn)(
                                                scInfoElement_t    *ie,
                                                uint8_t            *outBuf,
                                                uint8_t            *buf1,
                                                uint8_t            *buf2);

/**************** End of info element based functions *****************/

/**************** DataInfo/Record level functions ***********************/
/**
 * Modeled after skStreamOpenSilkFLow
 * Tells the data reader to more to the next input,
 * most likely, the next file.  The details of which are hidded from the
 * program.
 * It fills the stream blob double pointer with the new stream pointer,
 * which holds enough information for the getNextRecord function to get the data
 * @param streamBlobDP  double pointer to be filled in
 * @return
 *      0 when where are no more streams (probably time to exit)
 *      1 if the stream successfully opened and there is data to read
 *      2 if there is no error, but the check timed out (directory polling?)
 */
typedef uint32_t (*scDataInfoNextInput_fn)(
                                                void          **streamBlobDP);

/**
 * Copies the next record from the opened stream into buf
 * The copy of the record is now owned by the caller
 * @param someStreamBlob Pointer to the stream created by NextInput
 * @param buf            Pointer to the buffer where the record is copied
 * @return SCGETNEXT_ERR_OK if successful
 *         SCGETNEXT_ERR_EOF if no more records and nextInput should be called
 */
typedef scDataInfoGetRecErr_t (*scDataInfoGetNextRecCopy_fn)(
                                                void           *someStreamBlob,
                                                uint8_t        *buf,
                                                scSchema_t    **schemaUsed);

/**
 * Returns a pointer to the next record.  Access to the record contents is
 * only valid until the next call to GetNextPtr.
 * Any memory allocated internally by GetNextRecPtr must be freed by
 * subsequent calls to getNextRecord.  Nothing will be done by the caller.
 * @param someStreamBlob Pointer to the stream created by NextInput
 * @return NULL if there are no more records and nextInput should be called
 *         A pointer to the record (not NULL) on success
 */
typedef void* (*scDataInfoGetNextRecPtr_fn)(
                                                void           *someStreamBlob,
                                                scSchema_t    **schemaUsed);

/**
 * A function to write out a record at the data info level using the stream
 * blob created by nextInput
 * @param someStreamBlob    Pointer to the writing stream structure
 * @param schema            Pointer to the schema describing the record
 * @param buf               Pointer to the buffer containing the record
 * @param length            Length of the buffer to write
 * @return                  Number of bytes written
 */
typedef uint32_t (*scDataInfoWriteRecord_fn)(
                                                void           *someStreamBlob,
                                                scSchema_t     *schema,
                                                const uint8_t  *buf,
                                                uint32_t        length);

/*
 * A function that returns the schema that will be used for the next record
 * @param someStreamBlob    Pointer to teh writing stream structure
 * @return                  Pointer to the schema
 */
typedef scSchema_t* (*scDataInfoGetNextSchema_fn) (
                                                void           *someStreamBlob);

/**
 * Function template for the 2 functions that free records.
 * One completely frees a record, one just frees the variable lengthed fields
 * @param schema    Pointer to the schema describing the record
 * @param rec       Pointer to the record to be freed
 */
typedef void (*scSchemaFreeRecord_fn)(
                                                scSchema_t     *schema,
                                                uint8_t        *rec);

/**
 * Executes a deep copy of the reord from src to dst.
 * If there are variable lengthed fields, or nested schemas,
 * new memory is allocated and the strings or arrays are copied as well.
 * For a first-level-only copy, just memcpy and the schema length,
 * or the macro: SC_SCHEMA_SHALLOW_COPY (defined below)
 * @param schema    Pointer to the schema describing the data
 * @param dst       Pointer to the buffer where the data will be copied
 * @param src       Pointer to the buffer containing the record to be copied
 * @return          The number of bytes copied for the top level
 */
typedef uint32_t (*scSchemaDeepCopyRecord_fn)(
                                                scSchema_t     *schema,
                                                uint8_t        *dst,
                                                const uint8_t  *src);

typedef void* (*scSchemaBuilderMemAllocAndCopy_fn)(scSchema_t  *schema);
typedef void  (*scSchemaBuilderMemFree_fn)(void    *builderMem);

typedef void* (*scInfoElementCtxAllocAndCopy_fn)(scInfoElement_t  *ie);
typedef void  (*scInfoElementCtxFree_fn)(void    *builderMem);

/**
 * @brief Shallow copy of records according to a schema.
 *        No second level fields will be copied
 * @param _schema_ pointer to the schema defining the records
 * @param _dst_ pointer to the destination buffer
 * @param _src_ pointer to the source buffer
 */
#define SC_SCHEMA_SHALLOW_COPY(_schema_, _dst_, _src_)          \
    memcpy((_dst_), (_src_), scSchemaGetRecordLength((_schema_)))

/************************ End of function signatures **/


/**
 * Top level structure for defining the schema and functions used for
 * retrieving data
 */
struct scDataInfo_st {
    /** Pointer to the first schema in the list (Do not edit) */
    scSchema_t                 *firstSchema;
    /** Pointer to the last schema in the list (Do not edit) */
    scSchema_t                 *lastSchema;
    /** Number of schemas added */
    uint32_t                    numSchemas;
    /** Function to move the reader onto the next Input */
    scDataInfoNextInput_fn      nextInput;
    /** Function to get a copy of the next record from the stream */
    scDataInfoGetNextRecCopy_fn getNextRecordCopy;
    /** Function to get a pointer to the next record from the stream */
    scDataInfoGetNextRecPtr_fn  getNextRecordPtr;
    /** Function to write a record to an output stream */
    scDataInfoWriteRecord_fn    writeRecord;
    /** Function to return the schema for the next data record,
     ** without retrieving the next data record */
    scDataInfoGetNextSchema_fn  getNextSchema;
    /** Largest record size from the added schemas */
    uint32_t                    maxRecordLength;
    /** Set to 1 if this DataInfo is to be used for input (0 for output) */
    uint8_t                     isInputDataInfo;
    /** info model / list of available possible elements. Do not free this,
        just a reference */
    fbInfoModel_t              *infoModel;
};

/**
 * @brief signifies a variable length field
 */
#define SC_VAR_LEN  sizeof(scVarfield_t)

/**
 * Specific types of IEs, according to RFC 5610
 */
typedef enum scInfoType_en {
    OCTET_ARRAY, /*!< Generic byte array */
    UNSIGNED_8,  /*!< 8-bit unsigned integer */
    UNSIGNED_16, /*!< 16-bit unsigned integer */
    UNSIGNED_32, /*!< 32-bit unsigned integer */
    UNSIGNED_64, /*!< 64bit unsigned integer */
    SIGNED_8,    /*!< 8-bit signed integer */
    SIGNED_16,   /*!< 16-bit signed integer */
    SIGNED_32,   /*!< 32-bit signed integer */
    SIGNED_64,   /*!< 64-bit signed integer */
    FLOAT_32,    /*!< 32-bit floating point number */
    FLOAT_64,    /*!< 64-bit floating point number */
    BOOLEAN,     /*!< Boolean value, 0 FALSE, not-zero TRUE */
    MAC_ADDRESS, /*!< 6 byte MAC address */
    STRING,      /*!< Array of printable characters */
    DATETIME_SECONDS, /*!< Date/Time stored in Seconds */
    DATETIME_MILLISECONDS, /*!< Date/Time stored in Milliseconds */
    DATETIME_MICROSECONDS, /*!< Date/Time stored in Microseconds */
    DATETIME_NANOSECONDS, /*!< Date/Time stored in nanoseconds */
    IPV4_ADDRESS, /*!< IPv4 Address */
    IPV6_ADDRESS, /*!< IPv6 Address */
    BASIC_LIST, /*!< IPFIX Basic List */
    SUB_TEMPLATE_LIST, /*!< IPFIX Sub Template List */
    SUB_TEMPLATE_MULTI_LIST /*!< IPFIX Sub Template Multi List */
} scInfoType_t;

/**
 * Descriptions for more generally classifiying IEs
 */
typedef enum scGeneralType_en {
    FIXED, /*!< The field has fixed size.  Numbers, IPs, floats, times */
    VARLEN_DATA, /*!< OCTET_ARRAY or STRING */
    LIST_TYPE /*!< basic list, sub template list, or sub template multi list */
} scGeneralType_t;

/**
 * Values for the semantic field of an IE, according to RFC 5610
 */
typedef enum scInfoSemantic_en {
    DEFAULT, /*!< Type field implies all that's needed (string) */
    QUANTITY, /*!< The value is a quantity eligible for math done on the value*/
    TOTAL_COUNTER, /*!< A summary counter */
    DELTA_COUNTER, /*!< A change in a given counter */
    IDENTIFIER,    /*!< A number, but no math done.  e.g. source ports */
    FLAGS,         /*!< The value is a combination of sub values */
    LIST,          /*!< The field is one of the list structures */
    CUSTOM_NUM_REP = 200 /*!< A numeric field, an identifier, where
                          * info string vals are required, e.g. sensor name */
} scInfoSemantic_t;


/**
 * Values for the units field of an IE, according to RFC 5610
 */
typedef enum scInfoUnits_en {
    NONE, /*!< No Units */
    BITS, /*!< Bits */
    OCTETS, /*!< Octets */
    PACKETS, /*!< Packets */
    FLOWS, /*!< Flows */
    SECONDS, /*!< Seconds */
    MILLISECONDS, /*!< Milliseconds */
    MICROSECONDS, /*!< Microseconds */
    NANOSECONDS, /*!< NanoSeconds */
    FOUR_OCTET_WORDS, /*!< Four Octet Words */
    MESSAGES, /*!< Messages */
    HOPS, /*!< Hops */
    ENTRIES /*!< Entries */
} scInfoUnits_t;

/**
 * Designates whether this information element is a raw field (PRIMARY),
 * or a derived from one or more raw field (SECONDARY)
 */
typedef enum scDataLevel_en {
    PRIMARY, /*!< This IE's value takes up memory in the record */
    VIRTUAL /*!< This IE's value is derived from other values, such as a sum.
                 This IE does not take up memory in the record */
} scDataLevel_t;

typedef struct scIE_IDs_st {
    uint32_t            ent;
    uint32_t            id;
    scInfoElement_t    *ie;
} scIE_IDs_t;

typedef struct scIELastBL_st {
    scInfoElement_t    *lastBL_IE;
    uint32_t            lastEnt;
    uint32_t            lastNum;
} scIELastBL_t;

/**
 * Details made visible to users for simplicity.
 * Contains full definition of information element
 */
struct scInfoElement_st {
    scInfoElement_t        *next;      /*!< next IE */
    scInfoElement_t        *prev;      /*!< prev IE */
    uint32_t                ent;       /*!< enterprise number */
    uint32_t                id;        /*!< field ID */
    uint16_t                lenOverride;/* over-ridden length */
    uint16_t                len;
    scInfoType_t            type;      /*!< field type */
    scInfoSemantic_t        semantic;  /*!< semantic */
    scInfoUnits_t           units;     /*!< units */
    uint64_t                rangeMin;  /*!< minimum range */
    uint64_t                rangeMax;  /*!< maximum range */
    char                   *description; /*!< description, not user string*/
    char                   *name;      /*!< how user refers to element */
    scDataLevel_t           dataLevel; /*!< PRIMARY (raw data) or VIRTUAL */
    scInfoStringVal_t      *firstStringVal; /*!< head of linked list of isv's*/
    uint32_t                offset;    /*!< offset of this field in record */
    void                   *ctx;
    scInfoElementCtxAllocAndCopy_fn ctxAllocAndCopy;
    scInfoElementCtxFree_fn ctxFree;
    scInfoElementCopyVal_fn copyVal;   /*!< function to copy IE val from rec */
    scInfoElementRetPtr_fn  retPtr;  /*!< function to return pointer to field */
    scInfoElementCopyValIter_fn copyValIter;/*!<copyVal that iterates */
    scInfoElementRetPtrIter_fn  retPtrIter; /*!<retPtr that iterates */
    scInfoElementSetVal_fn  setFunc;   /*!< function to set this IE in rec */
    scInfoElementPrint_fn   printFunc; /*!< function to print this IE */
    scInfoElementMerge_fn   mergeFunc; /*!< function to merge two values */
    void                   *valPtr;
    scInfoElement_t        *higherLevelIE;
    scInfoElement_t        *nextIdenticalIE;
};

#define IE_COULD_HAVE_MULTIPLE_VALS(__ie__)                                 \
    __ie__->copyValIter | __ie__->retPtrIter

#define ID_IS_IE(__ID__, __ie__)                                            \
    ((__ID__.ent == __ie__->ent) && (__ID__.id == __ie__->id))

/*
 * When getting input from files, you can tell a schemabuilder to assume that
 * the schema(s) read from the first file, will apply to all of them
 */
typedef enum scRedoOrSameSchemas_en {
    SC_CS_REDO_SCHEMAS, /* recreate schemas for each file's templates */
    SC_CS_SAME_SCHEMAS  /* use existing schemas, assume same from first file */
} scRedoOrSameSchemas_t;
/**
 * The different ways in inputs and outputs can be specified by a program
 */
typedef enum scConnSpecType_en {
    SC_CS_NONE, /*!< No connection details set */
    SC_CS_TCP, /*!< TCP connection */
    SC_CS_UDP, /*!< UDP connection */
    SC_CS_DIRECTORY, /*!< Read all files from this directory, does not poll */
    SC_CS_POLL_DIR, /*!< Poll a directory for input */
    SC_CS_FILELIST_INPUT, /*! Read input from files in this list */
    SC_CS_STANDARD_IN, /* read data straight from standard in */
    SC_CS_FILE_OUTPUT /*!< Write output to this file */
} scConnSpecType_t;

typedef struct scConnSpec_st scConnSpec_t;

/**
 * Structure to hold socket information
 */
typedef struct scSocket_st {
    /** Port number in string form (what FIXBUF uses) */
    char   *portStr;
    /** Hostname to connect to (what FIXBUF uses) */
    char   *hostname;
    /** Integer port number **/
    uint16_t    portInt;
    /** Integer IP address **/
    uint32_t    ipAddr;

} scSocket_t;

/**
 * Structure to hold file list information
 */
typedef struct scFileList_st {
    /** An array of filename pointers */
    char      **filenames;
    /** The number of elements in the filename list */
    uint32_t    numFiles;
    uint32_t    currentFile;
} scFileList_t;

typedef struct scDirPoll_t {
    char            currentFile[200];
    skPollDir_t    *pollDir;
    char           *directory;
    uint32_t        timeoutSeconds;
    char           *archiveDir;
    uint32_t        pollingInterval;
    uint32_t        pollingTimeout;
} scDirPoll_t;
/**
 * Structure to specify all of the details needed to make a connection
 */
struct scConnSpec_st {
    /** The overall type of specification, which dictates the union var to use*/
    scConnSpecType_t        type;
    /** Type specific information to use */
    union {
        /** If the type is TCP or UDP, it's a socket */
        scSocket_t      socket;
        /** If the type is DIRECTORY */
        scDirPoll_t     pollDir;
        /** If the type is FILELIST_INPUT or FILE_OUTPUT */
        scFileList_t    fileList;
    } connInfo;
    scRedoOrSameSchemas_t   redoOrSame;
};

/******************** Accessing Schema Functions */

/**
 * @brief allocated a new information element and fills it with information
 * from the passed in infoModel using {ent,id} to identify the element
 * @param       infoModel   Pointer to the information model to pull data from
 * @param       ent         The enterprise ID of the element
 * @param       id          The element ID of the element
 * @return An allocated and filled information element on success, NULL if the
 * element does not exist in the info model
 */
scInfoElement_t* scInfoElementAllocAndFill(
    fbInfoModel_t  *infoModel,
    uint32_t        ent,
    uint32_t        id);

/********************** Data Information functions */

/**
 * @brief Frees the data info pointer and EVERYTHING encapsulated in it
 * @param   dataInfo:   pointer to the data info struct to be freed
 */
void scDataInfoFree(scDataInfo_t           *dataInfo);

/**
 * @brief Frees the contents of a DataInfo, but not the dataInfo pointer itself
 * @param dataInfo  Pointer to the dataInfo
 */
void scDataInfoFreeContents(scDataInfo_t   *dataInfo);

/** @brief Retrieve the first schema in the data info
 * @param dataInfo Pointer to the data info
 * @return A pointer to the first schema which can be used to start a loop
 */
scSchema_t* scDataInfoGetFirstSchema(
    scDataInfo_t   *dataInfo);

/**
 * @brief Iterate to the next schema from data info based on the last one
 * @param dataInfo Pointer to the dataInfo
 * @param lastSchema Pointer to the last schema processed, used as an iterator.
 *                  A NULL pointer here returns the first schema.
 * @return  A pointer to the next schema based on the one provided.
 *          NULL if there are no more schemas
 */
scSchema_t* scDataInfoGetNextSchema(
    scDataInfo_t   *dataInfo,
    scSchema_t     *lastSchema);

/** @brief Gets the length of the longest schema in the scDataInfo.
 * Used to allocated a record buffer big enough to handle all schemas.
 * @param dataInfo Pointer to the data info
 * @return the length of the longest schema in the data info
 */
uint32_t scDataInfoGetMaxRecordLength(
    scDataInfo_t   *dataInfo);

/** @brief Retrieve the NextInput_fn from the data info
 * @param dataInfo Pointer to the data info
 * @return The function pointer that moves on to the next high level input
 */
scDataInfoNextInput_fn scDataInfoGetNextInputFunc(
    scDataInfo_t    *dataInfo);

/** @brief Retrieve the GetNextRecCopy_fn from the data info
 * @param dataInfo Pointer to the data info
 * @return The function pointer that gets a copy of the next data record
 */
scDataInfoGetNextRecCopy_fn scDataInfoGetRecordCopyFunc(
    scDataInfo_t   *dataInfo);

/** @brief Retrieve the GetNextRecPtr_fn from the data info
 * @param dataInfo Pointer to the data info
 * @return The function pointer that gets a pointer to the next data record
 */
scDataInfoGetNextRecPtr_fn scDataInfoGetRecordPtrFunc(
    scDataInfo_t    *dataInfo);

/** @brief Retrieve the WriteRecord_fn from the data info
 * @param dataInfo Pointer to the data info
 * @return The function pointer that writes a record
 */

scDataInfoWriteRecord_fn scDataInfoGetWriteRecordFunc(
    scDataInfo_t       *dataInfo);


/** @brief Retrieve the GetNextSchema_fn from the data info. This function
 * returns the schema pointer for the next record without reading the record
 * @param dataInfo  Pointer to the data info
 * @return The function pointer that returns the next schema to be used
 */
scDataInfoGetNextSchema_fn scDataInfoGetNextSchemaFunc(
    scDataInfo_t       *dataInfo);

/** @brief Validates a data info struct
 *
 * Validates the values and parameters nexted in a dataInfo struct.
 * This can be called by the schema builder and / or schema accessor.
 *
 * @param dataInfo  Pointer to the data info to be validated
 * @param error     Pointer to an error struct for better error reporting
 * @return 0 if the data info is valid, 1 if the data is invalid
 */
uint8_t scDataInfoValidate(scDataInfo_t    *dataInfo,
                           scError_t       *error);

/********************** End of Data Information Functions */

/********************** Schema functions */
/* most of these are standard schema accessor functions */
/**
 * @brief Get the name of the schema
 * @param schema    Pointer to the schema to get the name from
 * @return          Pointer to the name of the schema, doesn't need freed
 */
char* scSchemaGetName(
    scSchema_t *schema);

/**
 * @brief Get the ID for the schema
 * @param schema    Pointer to the schema
 * @return          The ID for this schema
 */
uint16_t scSchemaGetId(
    scSchema_t *schema);

/** @brief Get the length needed to hold a record described by this schema
 * @param schema Pointer to the schema
 * @return The length of the record described by this schema
 */
uint32_t scSchemaGetRecordLength(
    scSchema_t *schema);

/*
 * Force the storage size for the record to be larger than the calculated value
 * This can only be set after all elements are added, and also
 * must be larger than the calculated length
 * returns 0 on success, non-zero on failure
 */
int scSchemaForceRecordLength(
    scSchema_t *schema,
    uint32_t    forcedLength,
    scError_t  *error);

/**
 * @brief Get the schema associated with this one
 * @param schema    Pointer to the schema
 * @return          Pointer to the schema associated with this one
 */
scSchema_t* scSchemaGetAssociatedSchema(
    scSchema_t *schema);

/**
 * @brief Get the number of information elements in the schema
 * @param schema    Pointer to the schema
 * @return          The number of IEs in the schema
 */
uint32_t scSchemaGetNumInfoElements(
    scSchema_t *schema);

/**
 * @brief Return whether the schema has variable lengthed IEs
 * @param schema    Pointer to the schema
 * @return          1 if there are variable lengthed fields, 0 if only fixed
 */
uint8_t scSchemaHasVarLenFields(
    scSchema_t *schema);

/**
 * @brief Get the number of element groups in a schema
 * @param schema    Pointer to the schema
 * @return          The number of groups of elements in the schema
 */
uint32_t scSchemaGetNumOfElementGroups(
    scSchema_t *schema);

/**
 * @brief Returns the first grouped elements in the schema.
 * @param schema Pointer to the schema containing groups
 * @return Pointer to the first group in the list
 */
scGroupedElements_t* scSchemaGetFirstGroupOfElements(
    scSchema_t *schema);

/**
 * @brief Iterates to the next group based on the current group.
 * @param schema Pointer to the schema containing groups
 * @param lastGroup Pointer to the last group retrieved by this function
 *                  if this pointer is NULL, the first group is returned
 * @return Pointer to the next group in the list. NULL if no more groups.
 */
scGroupedElements_t* scSchemaGetNextGroupOfElements(
    scSchema_t             *schema,
    scGroupedElements_t    *lastGroup);

/**
 * @brief Look for a set of GroupedElements by user string
 * @param schema    Pointer to the schema containing the groups
 * @param userString    User string to look up among the group names
 * @return A pointer to the group, or NULL if not found
 */
scGroupedElements_t* scSchemaGetGroupedElementsByUserString(
    scSchema_t *schema,
    char       *userString);
 /**
 * @brief Iterates to the next info element based on the current one
 * @param schema    Pointer to the schema
 * @param previousIE Pointer to the current IE to iterate from
 * @return The next IE based on the current info element, NULL if no more IEs
 */
scInfoElement_t* scSchemaGetNextInfoElement(
    scSchema_t         *schema,
    scInfoElement_t    *previousIE);

/**
 * Get the copy record function for this schema
 * @param schema    Pointer to the schema to get copy record function from
 * @return          Function used to copy records described by this schema
 */
scSchemaDeepCopyRecord_fn scSchemaGetCopyRecordFunc(
    scSchema_t *schema);

/**
 * Get the function that completely frees a record including the buffer.
 * @param schema    Pointer to the schema to get the free record function from
 * @return          Function to completely free a record, undoing the Copy
 */
scSchemaFreeRecord_fn scSchemaGetFreeRecordFunc(
    scSchema_t *schema);

/**
 * Get the function that frees the second level values of the record, but
 * leaves the original buffer intact to be reused
 * @param schema    Pointer to the schema to get the 2nd level free from
 * @return          Function that frees the second level fields
 */
scSchemaFreeRecord_fn scSchemaGetSecondLevelFreeFunc(
    scSchema_t *schema);

/**
 * @brief Return a pointer to the information element in the given schema with
 *              enterprise and element id equal to the inputs
 * @param schema  Pointer to the schema containing IEs
 * @param ent     Enterprise ID value for the IE
 * @param id      Element ID value for the IE
 * @return   Pointer to the IE referred in the schema referred to by {ent, id}.
 *      NULL if there is no such IE
 */
scInfoElement_t* scSchemaGetIEByID(
    scSchema_t *schema,
    uint32_t    ent,
    uint32_t    id);

/**
 * @brief Returns a pointer to the next IE with a given ID, but it must come
 * after the given IE in the schema.  This allows the user to find more than one
 * IE with the same ID tuple in a schema.
 * @param schema    Pointer to the schema
 * @param ent       Enterprise ID for the IE
 * @param id        Element ID for the IE
 * @param baseIE    The IE to start after to find another IE with the ID tuple
 * @return          A pointer to the found IE, or NULL if not present
 */
scInfoElement_t* scSchemaGetNextRepeatedIEByID(
    scSchema_t         *schema,
    uint32_t            ent,
    uint32_t            id,
    scInfoElement_t    *baseIE);

/**
 * @brief Returns a pointer to the IE with a gieven name in a schema
 * @param schema    Pointer to the schema to get the IE from
 * @param name      String name to use to look for an IE
 * @return          Pointer to the element with the provided name if found.
 *      NULL on error or if it's not found
 */
scInfoElement_t* scSchemaGetIEByName(
    scSchema_t *schema,
    char       *name);

/**
 * @brief Returns a pointer to the next IE with a given name, but it must come
 * after the given IE in the schema.  This allows the user to find more than one
 * IE with the same name in a schema.
 * @param schema    Pointer to the schema
 * @param name      Name of the IE to find
 * @param baseIE    The IE to start after to find another IE with the name
 * @return          A pointer to the found IE, or NULL if not present
 */
scInfoElement_t* scSchemaGetNextRepeatedIEByName(
    scSchema_t         *schema,
    char               *name,
    scInfoElement_t    *baseIE);

/**
 * @brief Check to see if the given IE pointer is in the schema
 * @param schema    Pointer to the schema
 * @param ie        Pointer to the IE to check the inclusion of
 * @return          1 if the IE is in the schema, 0 otherwise.
 */
int scSchemaIEInSchema(
    scSchema_t         *schema,
    scInfoElement_t    *ie);

/**
 * @brief Iterate to the next schema based on the current schema
 * @param schema    Pointer to the schema to iterate from, can't be NULL
 * @return A pointer to the next schema.  NULL if there are no more schemas
 */
scSchema_t* scSchemaGetNextSchema(
    scSchema_t *schema);

/**
 * @brief Removes any groups of elements that are empty
 * @param schema    Pointer to the schema to remove empty groups
 * @return none
 */
void scSchemaRemoveEmptyGroups(
    scSchema_t *schema);

/**
 * @brief Get the builder memory for the schema
 * @param schema    Pointer to the schema
 * @return Pointer to the builder memory created by the schema builder
 */
void* scSchemaGetBuilderMem(
    scSchema_t *schema);

/**
 * @brief Set the builder memory for the schema, will be freed by schemaTools
 * @param schema        Pointer to the schema
 * @param builderMem    Pointer to the builder mem to be attached to the schema
 */
void scSchemaSetBuilderMem(
    scSchema_t                         *schema,
    void                               *builderMem,
    scSchemaBuilderMemAllocAndCopy_fn   builderMemCopy,
    scSchemaBuilderMemFree_fn           builderMemFree);

/* define the function signature for the function to free user context pointers
 */
typedef void (*scSchemaCtxFree_fn) (
        void   *ptr);

/**
 * @brief Get the user defined context pointer for a given schema
 * @param schema    Pointer to the schema to get the context pointer from
 * @return          The user supplied context pointer for the schema
 */
void* scSchemaGetCtx(
    scSchema_t *schema);

/**
 * @brief Set the user defined context pointer for the given schema
 * @param schema    The pointer to the schema to set
 * @param ctx       Pointer to the user allocated memory to set for the schema
 * @param freeFunction The function to call(can be NULL) to free the context
 *                      The context pointer is only freed if a function is
 *                      provided here.
 */
void scSchemaSetCtx(
    scSchema_t *schema,
    void       *ctx,
    scSchemaCtxFree_fn freeFunction);

/**
 * @brief Returns the pointer allocated by the schema to hold a record. This is
 * used to make it more convenient to return the user a pointer to a record
 * copied somewhere, without having to allocate memory with every new record.
 * This is allocated when the schema is allocated, and is free when the schema
 * is freed.
 * @param schema    Pointer to the schema to get the rec pointer from
 * @return      Pointer to memory allocated to hold one record of this schema
 */
uint8_t* scSchemaGetRecPtr(
    scSchema_t *schema);

/**
 * @brief Returns the pointer to the IE designated by the schema builder as
 * a timing source.
 * Do not free this pointer as it is part of the schema and will be freed
 * automatically by the builder
 * @param schema    Pointer to the schema to get the timing IE from
 * @return      Pointer to the IE on success, NULL on failure
 */
scInfoElement_t* scSchemaGetTimingSource(
    scSchema_t *schema);

/**
 * @brief Sets the timing source to be a given IE already inserted into the
 * schema.
 * @param schema    Pointer to the schema to set the timing source
 * @param IE        Pointer to existing IE in the schema to be timing source
 * @return          0 on success, non-zero if IE is null or not in schema
 */
int scSchemaSetTimingSource(
    scSchema_t         *schema,
    scInfoElement_t    *ie);

/**
 * Returns 1 if the schemas have the same IEs, in the same order, with the same
 * offsets. Returns 0 if there's any variation
 */
int scSchemaEqual(
    scSchema_t *schema1,
    scSchema_t *schema2);

/**
 * @brief This is a wrapper function to call the DeepCopyRecord function
 * for a given schema
 * @param schema    Pointer to the schema whose DeepCopyRecord function to call
 * @param dst       Pointer to the destination buffer for the copied record
 * @param src       Pointer to the source record to be copied into dst
 * @return          The number of bytes copied into dst
 */
uint32_t callSchemaDeepCopyRecord(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src);

/**
 * @brief This is a wrapper function to call the freeRecordCopy of a schema
 * @param schema    Pointer to the schema whose freeRecordCopy is to be called
 * @param rec       The record pointer to free
 */
void callSchemaFreeRecord(
    scSchema_t *schema,
    uint8_t    *rec);

/**
 * @brief This is a wrapper function to call the freeSecondLevelFields func
 * @param schema    Pointer to the schema whose freeSecondLevelFields is called
 * @param rec       Pointer to the record to free second level fields
 */
void callSchemaFreeSecondLevel(
    scSchema_t *schema,
    uint8_t    *rec);

/************************ End of schema functions */

/************************ Grouped Elements functions */
/**
 * @brief Iterates to the next groupedElements based on the current one
 * @param group Pointer to the current group
 * @return The next group after the current one, NULL if no more groups
 */
scGroupedElements_t* scGroupedElementsGetNextGroup(
    scGroupedElements_t    *group);

/**
 * Get the user string from a group of elements
 * @param group Pointer to the groupedElements to get the userString from
 * @return      Pointer to the userString for the group, doesn't need freed
 */
char* scGroupedElementsGetUserString(
    scGroupedElements_t    *group);

/**
 * @brief get the number of elements in a GroupedElements
 * @param group     Pointer to the group
 * @return          The number of elements in the group
 */
uint32_t scGroupedElementsGetNumElements(
    scGroupedElements_t    *group);

/**
 * @brief Get the first nestedIE from a group
 * @param group Pointer to the group
 * @return The first nestedIE in the group
 */
scNestedIE_t* scGroupedElementsGetFirstNestedIE(
    scGroupedElements_t    *group);

/**
 * @brief Iterate to the next nestedIE from the group based on the current one.
 * @param   group       Pointer to the group
 * @param   nestedIE    Pointer to the current nestedIE.  NULL yields first one.
 * @return              A pointer to the next nested IE after the current one.
 *                      NULL if there are no more nestedIEs
 */
scNestedIE_t* scGroupedElementsGetNextNestedIE(
    scGroupedElements_t    *group,
    scNestedIE_t           *nestedIE);

/*********************** end of grouped elements functions */

/*********************** Nested IE functions ********/
/**
 * @brief Iterate to the next nested IE based on the current one.
 * @param nestedIE  Pointer to the current nested IE. NULL yields first one.
 * @return          Pointer to the nested IE after the current one.
 *                  NULL if there are no more nestedIEs
 */
scNestedIE_t* scNestedIEGetNextNestedIE(
    scNestedIE_t           *nestedIE);

/**
 * @brief Retrieve the enterprise ID and element ID from the nested IE
 * @param   nestedIE    Pointer to the nested IE to retrieve the ids from
 * @param   entIdPtr    Pointer to be filled in by the enterprise ID
 * @param   idPtr       Pointer to be filled in by the element ID
 */
void scNestedIEGetIds(
    scNestedIE_t           *nestedIE,
    uint32_t               *entIdPtr,
    uint32_t               *idPtr);

/**
 * @brief Return the information element embedded in the nestedIE
 * @param   nestedIE    Pointer to the nexted IE to retrieve the IE from
 * @return  Pointer to the information element
 */
scInfoElement_t* scNestedIEGetIE(
    scNestedIE_t           *nestedIE);


/************************ End of Nested IE functions */

/************************ Info Element functions ***/
/**
 * Get the enterprise number for an IE
 * @param _ie_  Pointer to the IE to get the description from
 * @return      The enterprise number for the IE
 */
#define scInfoElementGetEnterpriseNum(_ie_)                                 \
    (_ie_)->ent

/**
 * Get the context pointer for an IE
 * @param _ie_  Pointer to the IE to get the context pointer from
 * @return      The context pointer for the IE
 */
#define scInfoElementGetCtx(_ie_)                                           \
    (_ie_)->ctx

/**
 * Get the element ID for an IE
 * @param _ie_  Pointer to the IE to get the description from
 * @return      The element ID for the IE
 */
#define scInfoElementGetId(_ie_)                                            \
    (_ie_)->id

/**
 * Get the info typefor an IE
 * @param _ie_  Pointer to the IE to get the description from
 * @return      The type info for the IE
 */
#define scInfoElementGetType(_ie_)                                          \
    (_ie_)->type

/**
 * Get the description for an IE
 * @param _ie_  Pointer to the IE to get the description from
 * @return      Pointer to the string description, doesn't need freed
 */
#define scInfoElementGetDescription(_ie_)                                   \
    (_ie_)->description

/**
 * Get the name of the IE
 * @param _ie_  Pointer to the IE to get the name from
 * @return      Pointer to the string name, doesn't need freed
 */
#define scInfoElementGetName(_ie_)                                          \
    (_ie_)->name

/**
 * Get the Range Min value from the IE
 * @param _ie_  Pointer to the IE
 * @return      The range min field for this IE
 */
#define scInfoElementGetRangeMin(_ie_)                                      \
    (_ie_)->rangeMin

/**
 * Get the Range Max value from the IE
 * @param _ie_  Pointer to the IE
 * @return      The range max field for this IE
 */
#define scInfoElementGetRangeMax(_ie_)                                      \
    (_ie_)->rangeMax

/**
 * Get the Semantic value from the IE
 * @param _ie_  Pointer to the IE
 * @return      The semantic field for this IE
 */
#define scInfoElementGetSemantic(_ie_)                                      \
    (_ie_)->semantic

/**
 * @brief Return the first info string value from the IE to begin iteration
 * @param _ie_  Pointer to the ie to retrieve the first info string val
 * @return      Pointer to the first info string val
 */
#define scInfoElementsGetFirstStringVal(_ie_)                               \
    (_ie_)->firstStringVal

/**
 * @brief Iterate to the next string val based on the current isv
 * @param ie    Pointer to the IE
 * @param isv   Pointer to the current isv, NULL returns first element
 * @return      The next ISV in the list, NULL if not more ISV's
 */
scInfoStringVal_t* scInfoElementGetNextStringVal(
    scInfoElement_t    *ie,
    scInfoStringVal_t  *isv);

#define scInfoElementGetLength(_ie_)                                        \
    (_ie_)->len

/**
 * Get the Units value from the IE
 * @param _ie_  Pointer to the IE
 * @return      The units field for this IE
 */
#define scInfoElementGetUnits(_ie_)                                         \
    (_ie_)->units

/**
 * @brief Get function that copies the value for this IE from a record
 * @param _ie_  Pointer to the IE
 * @return      Copy Val function for the IE
 */
#define scInfoElementGetCopyValFunction(_ie_)                               \
    (_ie_)->copyVal

/**
 * @brief Get function that returns a pointer to the value for this IE
 * @param _ie_  Pointer to the IE
 * @return      GetPtr function for the IE
 */
#define scInfoElementGetReturnPointerFunction(_ie_)                         \
    (_ie_)->retPtr

/**
 * @brief Get function that sets the value for this IE in a rec
 * @param _ie_  Pointer to the IE
 * @return      Set Value function for the IE
 */
#define scInfoElementGetSetValFunction(_ie_)                                \
    (_ie_)->setFunc

/**
 * @brief Get the data level of the IE, PRIMARY or VIRTUAL
 * @param _ie_  Pointer to the IE
 * @return      The data level of the IE, PRIMARY or VIRTUAL
 */
#define scInfoElementGetDataLevel(_ie_)                                     \
    (_ie_)->dataLevel

/**
 * @brief Returns whether or not the information element is variable lengthed
 * @param   ie  Pointer to the IE to check if varlen
 * @return  1 if it is variable lengthed
 *          0 if it is NOT variabled lengthed
 */
uint8_t scInfoElementIsVarlen(const scInfoElement_t  *ie);

/**
 * @brief Returns 1 if the info elements are equivalent, 0 if different
 * @param ie1 - pointer to one of the IEs to be compared
 * @param ie2 - pointer to the other IE to be compared
 * @return 0 if the IEs are equivalent, positive reason if not
 */
scIEDiffReason_t scInfoElementCompare(scInfoElement_t *ie1,
                       scInfoElement_t *ie2);

char* getIEDiffReasonString(
    scIEDiffReason_t    dr);

char* getIEDataLevelString(
    scDataLevel_t   level);

/**
 * scInfoElementGetGeneralType
 * Returns the general type description: fixed, (string or array), or list,
 * of the IE.  This is a more detailed version of isVarlen.
 * Parameters:
 *      ie:     pointer to the IE to get general type
 * Returns:
 *      FIXED       (0): If the IE is a fixed field
 *      VARLEN_DATA (1): If the IE is a string or octet array
 *      LIST        (2): If the IE is a list
 */
scGeneralType_t scInfoElementGetGeneralType(scInfoElement_t   *ie);

/***************** Info String Val functions **/
/**
 * @brief Iterate to the next ISV based on the current one.
 * @param isv   Current ISV, what the "next" is based on, NULL yields first one
 * @return      The next ISV after the current one
 */
scInfoStringVal_t* scInfoStringValGetNextISV(
    scInfoStringVal_t  *isv);

/**
 * Get the integer value from an ISV
 * @param isv   Pointer to the ISV to get the integer from
 * @return      The integer value from the ISV
 */

uint64_t scInfoStringValGetVal(
    scInfoStringVal_t  *isv);

/**
 * Get the string value from an ISV
 * @param isv   Pointer to the ISV to get the string from
 * @return      Pointer to the string in the ISV, doesn't need freed
 */
char* scInfoStringValGetString(
    scInfoStringVal_t  *isv);

/**
 * Copies the values of the fields in the src schema into the appropriate
 * field locations in the destination schema.
 * This is NOT a deep copy.  Variable lengthed fields will contain the
 * same pointers.  Use deepCopyBetweenSchemas if needed
 * @param dstSchema Pointer to the schema describing the destination buffer
 * @param dstBuf    Pointer to the buffer to where the data should be copied
 * @param srcSchema Pointer to the schema describing the source buffer
 * @param srcBuf    Pointer to the buffer containing the record to be copied
 * @return The number of bytes copied into the destination buffer/schema
 */
uint32_t copyBetweenSchemas(
    scSchema_t *dstSchema,
    uint8_t    *dstBuf,
    scSchema_t *srcSchema,
    uint8_t    *srcBuf);

/**
 * deepCopyBetweenSchemas
 * This is a standard function, meaning it requires the standard ordering
 * functions as it needs the offsets.  Custom ordering, means custom
 * copying functions.
 * Copies the values of the fields in the src schema into the appropriate
 * field locations in the destination schema.  All variable lengthed fields
 * are given new buffers and pointers, full deep copy.
 * Parameters:
 *      dstSchema:  pointer to the schema describing the destination buffer
 *      dstBuf:     pointer to the buffer to where the data should be copied
 *      srcSchema:  pointer to the schema describing the source buffer
 *      srcBuf:     pointer to the buffer containing the record to be copied
 */
uint32_t deepCopyBetweenSchemas(
    scSchema_t *dstSchema,
    uint8_t    *dstBuf,
    scSchema_t *srcSchema,
    const uint8_t    *srcBuf);


/******************* End of schema accessing functions ******/

/******************* Schema building functions **************/

/**
 * @brief Allocate an empty scDataInfo
 * @return A newly allocated DataInfo pointer
 */
scDataInfo_t* scDataInfoAlloc(
    void);

/**
 * scDataInfoFillAsInput
 * Fills a previously allocated data info struct with function pointers
 * Parameters:
 *      dataInfo            pointer to the data info struct to fill in
 *      nextInput           function the clinet program will use to move to
 *                                                          next input function
 *      getNextRecordCopy   function the client program will use to get copies
 *      getNextRecordPtr    function the clinet program will use to get rec ptr
 * Returns:
 *      0 on success
 *      1 on failure
 */
int scDataInfoFillAsInput(
    scDataInfo_t                   *dataInfo,
    scDataInfoNextInput_fn          nextInput,
    scDataInfoGetNextRecCopy_fn     getNextRecordCopy,
    scDataInfoGetNextRecPtr_fn      getNextRecordPtr,
    scDataInfoGetNextSchema_fn      getNextSchema,
    scError_t                      *error);

/**
 * scDataInfoFillAsOutput
 * Fills a previously allocated data info struct with function pointers
 * Parameters:
 *      dataInfo            pointer to the data info struct to fill in
 *      writeRecord         function that writes out a given record
 * Returns:
 *      0 on success;
 *      1 on failure
 */
int scDataInfoFillAsOutput(
    scDataInfo_t                   *dataInfo,
    scDataInfoWriteRecord_fn        writeRecord,
    scError_t                      *error);

/**
 * Free an InfoElement and all underlying structures
 * @param ie    Pointer to the IE to free
 */
void scInfoElementFree(scInfoElement_t    *ie);

/** @brief Adds a schema to the data info.
 * If the schema ID exists, the existing schema is freed, and replaced
 * Parameters:
 *      dataInfo        pointer to the data info struct to add the schema to
 *      schema          pointer to the schema to add to the data info
 * Returns:
 *      0 on success
 *      not 0 on failure (null pointers)
 */
int scDataInfoAddSchema(
    scDataInfo_t   *dataInfo,
    scSchema_t     *schema,
    scError_t      *error);

int scDataInfoAddSchemaForce(
    scDataInfo_t   *dataInfo,
    scSchema_t     *schema,
    scError_t      *error);


int scDataInfoRemoveSchema(
    scDataInfo_t   *dataInfo,
    scSchema_t     *schema,
    scError_t      *error);

/**
 * scSchemaAlloc
 * Allocates a new schema object, and initializes it properly.
 * The builderMem is a context pointer for the builder to use to store
 * required information for what to do with the schema. The builder is
 * responsible for allocating and managing the memory, it will be freed by
 * scSchemaAlloc()
 * Parameters:
 *      schemaName:     Identifying name for the schema
 *      schemaId:       Identifying ID for the schema
 *      freeRecordCopy: function to be used to free copies of records
 *      freeSecondLevelFields:
 *                      function to free 2nd level fields but not the buffer,
 *                      used after copy record when the buffer will be reused
 *      copyRecord:     function that copies records defined by the schema
 * Returns:
 *      Pointer to the newly allocted schema structure
 */
scSchema_t* scSchemaAlloc(
    char                       *schemaName,
    uint32_t                    schemaId,
    scSchemaFreeRecord_fn       freeRecordCopy,
    scSchemaFreeRecord_fn       freeSecondLevelFields,
    scSchemaDeepCopyRecord_fn   copyRecord,
    scError_t                  *error);

/**
 * Free a schema and all underlying structures
 * @param schema    Pointer to the schema to free
 */
void scSchemaFree(scSchema_t *schema);

/**
 * scSchemaValidate
 * Validates the schema
 * Parameters:
 *      schema:     pointer to the schema to validate
 * Returns:
 *      0 on success, valid schema
 *      non zero if the schema is invalid
 */
uint8_t scSchemaValidate(scSchema_t    *schema,
                         scError_t     *error);

/**
 * scSchemaNewRecord
 * Returns an empty record for the given schema type
 * Parameters:
 *      schema:     pointer to the schema used to describe the new record
 * Returns:
 *      pointer to newly allocated record on success
 *      NULL on failure
 */
uint8_t* scSchemaNewRecord(
    scSchema_t *schema);

/**
 * Associate two schemas.  Used in cases where one used as an input schema
 * means that the program should use the other as the output schema.
 * While the parameters are labeled inSchema and outSchema, the order doesn't
 * matter as the association is reflexive.
 * @param inSchema  Pointer to the schema to associate with outSchema
 * @param outSchema Pointer to the schema to associate
 * @param error     Pointer to an error struct for better error reporting
 * @return          0 on success, non-zero on failure
 */
int scSchemaAssociate(
    scSchema_t *inSchema,
    scSchema_t *outSchema,
    scError_t  *error);


/**
 * scSchemaDuplicate
 * Dupicates the contents of the one schema into a newly allocated schema.
 * The schema ID and name will be identical, as will the functions for copying
 * and freeing. Adding the duplicated schema to the same DataInfo structure
 * as the original will result in an error, as the IDs have to be different.
 * If you want the IE contents copied, but want to pass in new functions and IDs
 * so the new schema can be added to the same DataInfo as the original, use
 * scSchemaCopy() below
 * @param   schema      Pointer to the schema to be duplicated
 * @return  A pointer to the newly allocated schema on success, NULL on failure
 */
scSchema_t* scSchemaDuplicate(
    scSchema_t                 *schema,
    scError_t                  *error);

/**
 * scSchemaCopy
 * Copies the contents of one schema into a newly created one.
 * The new schema gets its own copies of the IEs, so they can be removed and
 * freed, and the original schema is untouched.
 * New schema data functions must be provided, though they can be the same
 * as the original.
 * The context and builderMem pointers are NOT copied into the new schema.
 * Neither is the forced fixed length of the original. It will have to be reset
 * for the newly created copied schema.
 * If what you want to copy everything from the original schema, including ID,
 * name, and functions, use scSchemaDuplicate() above.
 * Parameters:
 *      schema:     pointer to the schema to be copied
 *      newSchemaID:Id for the newly copied schema.
 *      newSchemaName: Name for the newly copied schema. Must be different.
 * Returns:
 *      a new schema with all of the features of the original schema
 */
scSchema_t* scSchemaCopy(
    scSchema_t                 *schema,
    uint32_t                    newSchemaID,
    char                       *newSchemaName,
    scSchemaFreeRecord_fn       freeRecordCopy,
    scSchemaFreeRecord_fn       freeSecondLevelFields,
    scSchemaDeepCopyRecord_fn   copyRecord,
    scError_t                  *error);

/**
 * @brief Set the user defined context pointer for the given IE
 * @param ie    The pointer to the IE to set
 * @param ctx       Pointer to the user allocated memory to set for the IE
 * @param freeFunction The function to call(can be NULL) to free the context
 *                      The context pointer is only freed if a function is
 *                      provided here.
 */
void scInfoElementSetCtx(
    scInfoElement_t    *ie,
    void               *ctx,
    scInfoElementCtxAllocAndCopy_fn     ctxCopy,
    scInfoElementCtxFree_fn             freeFunction);


/**
 * scInfoElementCopy
 * Copies the contents of an information element and allocates a new one
 * A length override of the original is copied to the new one.
 * Parameters:
 *      ie      pointer to the information element to copy
 * Returns:
 *      pointer to newly allocated and filled information element
 */
scInfoElement_t* scInfoElementCopy(
    scInfoElement_t    *ie,
    scError_t          *error);

/**
 * scInfoStringValListCopy
 * Copies the contents of an info string list
 * Parameters:
 *      isvList     pointer to the list of info string vals to copy
 * Returns:
 *      pointer to the newly allocated and filled ISV list
 */
scInfoStringValList_t* scInfoStringValListCopy(
    scInfoStringValList_t  *isvList,
    scError_t              *error);


/****************** Functions that add elements to a schema **********/
/*
 * This function overrides the length field of an IE that has ALREADY been
 * added to a schema. This can only be done for OCTET_ARRAY and STRING
 * (potentially the rest later)
 * it returns the pointer the IE on success, NULL on failure
 */
scInfoElement_t* scSchemaOverrideLengthOfExistingIE(
    scSchema_t         *schema,
    scInfoElement_t    *ie,
    uint16_t            len,
    scError_t          *error);

/*
 * There are 2 different aspects of information elements that can be
 * customized:
 *  1) Values such as type, semantic, range, etc
 *          These standard values are pulled from a global table by IDs
 *  2) Functions used for copying, returning a pointer, setting, etc
 *          These standard function are part of the tools, and are used when
 *          no replacements are provided.
 * There are 7 functions that add IEs to a schema:
 *  scSchemaAddStandardIEByID:    standard values and standard functions
 *          (PRIMARY elements only)     extra parameter for custom info model
 *  scSchemaAddStandardIEByName:  standard values and functions
 *  scSchemaAddIEByIDCustomFuncs: standard value and custom functions
 *          (any element)               extra parameter for custom info model
 *  scSchemaAddIEByNameCustomFuncs: standardValues and custom functions
 *  scSchemaAddCustomIEStandardFuncs: custom values, but standard functions
 *          (PRIMARY elements only)
 *  scSchemaAddCustIE:                 custom values and custom functions
 *          (any element)
 *  scSchemaAddExistingIE:         copies IE values into schema
 *          (any element)          used for copying IEs to new schema 1 by 1
 */

/**
 * scSchemaAddStandardIEByID
 * Adds a PRIMARY IE with standard values and standard functions
 * It accept a custom info model from fixbuf for element lookups
 * Parameters:
 *      schema          pointer to the schema to add the IE to
 *      ent             enterprise ID of the element to add
 *      id              element ID of the element to add
 *      firstStringVal  pointer to the list of info string vals for this element
 *      infoModel       pointer to a created fixbuf info model. If NULL,
 *                      if uses the standard fixbuf info model.
 * Returns:
 *      a pointer to the successfully created IE that was added
 *      NULL if an error occured
 */
scInfoElement_t* scSchemaAddStandardIEByID(
    scSchema_t         *schema,
    uint32_t            ent,
    uint32_t            id,
    char               *userStringOveride,
    scInfoStringVal_t  *firstStringVal,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

/**
 * scSchemaAddStandardIEByName
 * Adds a PRIMARY IE with standard values and standard functions
 * It accept a custom info model from fixbuf for element lookups
 * Parameters:
 *      schema          pointer to the schema to add the IE to
 *      name            name of IE to add. IPFIX standard names only.
 *      firstStringVal  pointer to the list of info string vals for this element
 *      infoModel       pointer to a created fixbuf info model. If NULL,
 *                      if uses the standard fixbuf info model.
 * Returns:
 *      a pointer to the successfully created IE that was added
 *      NULL if an error occured
 */
scInfoElement_t* scSchemaAddStandardIEByName(
    scSchema_t         *schema,
    char               *name,
    char               *userStringOveride,
    scInfoStringVal_t  *firstStringVal,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

/**
 * scSchemaAddIEByIECustomFuncs
 * Adds an IE with standard values and custom functions to the schema
 * IE can be primary or secondary
 * Accept a created fixbuf info model for element lookups
 * Parameters:
 *      schema          pointer to the schema to add the IE to
 *      ent             enterprise ID of the element to add
 *      id              element ID of the element to add
 *      firstStringVal  pointer to the list of info string vals for this element
 *      dataLevel       PRIMARY or SECONDARY
 *      copyVal         function used to copy this value from record into buffer
 *      retPtr          function used to return a pointer to this value from rec
 *      setFunc         function used to set this value into a record
 *      lenFunc         function used to return the length of this IE val
 *      printFunc       function used to print the value for this IE
 *      infoModel       pointer to a created fixbuf info model. If this is NULL,
                        the default fixbuf info model will be used
 * Returns:
 *      a pointer to the successfully created IE that was added
 *      NULL if an error occured
 */
scInfoElement_t* scSchemaAddIEByIDCustomFuncs(
    scSchema_t             *schema,
    uint32_t                ent,
    uint32_t                id,
    char                   *userStringOveride,
    scInfoStringValList_t  *firstStringVal,
    scDataLevel_t           dataLevel,
    scInfoElementCopyVal_fn copyVal,
    scInfoElementRetPtr_fn  retPtr,
    scInfoElementSetVal_fn  setFunc,
    scInfoElementPrint_fn   printFunc,
    scInfoElementMerge_fn   mergeFunc,
    fbInfoModel_t          *infoModel,
    scError_t              *error);

/**
 * scSchemaAddIEByNameCustomFuncs
 * Adds an IE with standard values and custom functions to the schema
 * IE can be primary or secondary
 * Accept a created fixbuf info model for element lookups
 * Parameters:
 *      schema          pointer to the schema to add the IE to
 *      name            name of IE to add. IPFIX standard names only.
 *      firstStringVal  pointer to the list of info string vals for this element
 *      dataLevel       PRIMARY or SECONDARY
 *      copyVal         function used to copy this value from record into buffer
 *      retPtr          function used to return a pointer to this value from rec
 *      setFunc         function used to set this value into a record
 *      lenFunc         function used to return the length of this IE val
 *      printFunc       function used to print the value for this IE
 *      infoModel       pointer to a created fixbuf info model. If this is NULL,
                        the default fixbuf info model will be used
 * Returns:
 *      a pointer to the successfully created IE that was added
 *      NULL if an error occured
 */
scInfoElement_t* scSchemaAddIEByNameCustomFuncs(
    scSchema_t             *schema,
    char                   *name,
    char                   *userStringOveride,
    scInfoStringValList_t  *firstStringVal,
    scDataLevel_t           dataLevel,
    scInfoElementCopyVal_fn copyVal,
    scInfoElementRetPtr_fn  retPtr,
    scInfoElementSetVal_fn  setFunc,
    scInfoElementPrint_fn   printFunc,
    scInfoElementMerge_fn   mergeFunc,
    fbInfoModel_t          *infoModel,
    scError_t              *error);



/**
 * scSchemaAddCustomIEStandardFuncs
 * Adds an IE with custom values and standard functions.
 * IE must be primary
 * Parameters:
 *      schema          pointer to the schema to add the IE to
 *      ent             enterprise ID of the element to add
 *      id              element ID of the element to add
 *      type            type field for IE
 *      description     string description of the IE
 *      name            symbolic string name of the IE
 *      rangeMin        minimum accepted value for this IE
 *      rangeMax        maximum accepted value for this IE
 *      semantic        semantic field for the IE
 *      firstStringVal  pointer to the list of info string vals for this element
 *      units           units field for the IE
 */
scInfoElement_t* scSchemaAddCustomIEStandardFuncs(
    scSchema_t             *schema,
    uint32_t                ent,
    uint32_t                id,
    scInfoType_t            type,
    char                   *description,
    char                   *name,
    uint64_t                rangeMin,
    uint64_t                rangeMax,
    scInfoSemantic_t        semantic,
    scInfoStringValList_t  *firstStringVal,
    scInfoUnits_t           units,
    scError_t              *error);

/**
 * scSchemaAddCustomIE
 * Adds an IE with custom values and custom funcitons.
 * IE can be either primary or secondary
 * Parameters:
 *      schema          pointer to the schema to add the IE to
 *      ent             enterprise ID of the element to add
 *      id              element ID of the element to add
 *      type            type field for IE
 *      description     string description of the IE
 *      name            symbolic string name of the IE
 *      rangeMin        minimum accepted value for this IE
 *      rangeMax        maximum accepted value for this IE
 *      semantic        semantic field for the IE
 *      firstStringVal  pointer to the list of info string vals for this element
 *      units           units field for the IE
 *      dataLevel       PRIMARY or SECONDARY
 *      copyVal         function used to copy this value from record into buffer
 *      retPtr          function used to return a pointer to this value from rec
 *      setFunc         function used to set this value into a record
 *      lenFunc         function used to return the length of this IE val
 *      printFunc       function used to print the value for this IE
 * Returns:
 *      a pointer to the successfully created IE that was added
 *      NULL if an error occured
 */
scInfoElement_t* scSchemaAddCustomIE(
    scSchema_t             *schema,
    uint32_t                ent,
    uint32_t                id,
    scInfoType_t            type,
    char                   *description,
    char                   *name,
    uint64_t                rangeMin,
    uint64_t                rangeMax,
    scInfoSemantic_t        semantic,
    scInfoStringValList_t  *firstStringVal,
    scInfoUnits_t           units,
    scDataLevel_t           dataLevel,
    scInfoElementCopyVal_fn copyVal,
    scInfoElementRetPtr_fn  retPtr,
    scInfoElementSetVal_fn  setFunc,
    scInfoElementPrint_fn   printFunc,
    scInfoElementMerge_fn   mergeFunc,
    scError_t              *error);

/**
 * scSchemaAddExistingIE
 * Adds an IE with custom values and custom funcitons.
 * IE can be either primary or secondary
 * Parameters:
 *      schema          pointer to the schema to add the IE to
 *      existingIE      pointer to existing IE from another schema
 *      error           pointer to error reporting structure
 * Returns:
 *      a pointer ot the successfully created IE that was added
 *      NULL if an error occured
 */
scInfoElement_t* scSchemaAddExistingIE(
    scSchema_t         *schema,
    scInfoElement_t    *existingIE,
    scError_t          *error);

/**
 * scSchemaMoveIEBeforeAnother
 * Move the first IE to before the other paramter
 * If beforeHere is set to NULL, the IE is set as the first element
 * Parameters:
 *      schema:     pointer to the schema to edit
 *      ieToMove:   pointer to the IE to move before the other one
 *      beforeHere: pointer to the IE to move ieToMove before, NULL means start
 * Returns:
 *      pointer to the IE that was moved on success
 *      NULL on failure
 */
scInfoElement_t* scSchemaMoveIEBeforeAnother(
    scSchema_t         *schema,
    scInfoElement_t    *ieToMove,
    scInfoElement_t    *beforeHere,
    scError_t          *error);

/**
 * scSchemaMoveIEBeforeAnotherByName
 * Move the first IE to before the other paramter referenced by name
 * If beforeHere is set to NULL, the IE is set as the first element
 * Parameters:
 *      schema:     pointer to the schema to edit
 *      ieToMove:   name of the IE to move
 *      beforeHere: name of the IE to move ieToMove before, NULL means start
 * Returns:
 *      pointer to the IE that was moved on success
 *      NULL on failure
 */
scInfoElement_t* scSchemaMoveIEBeforeAnotherByName(
    scSchema_t *schema,
    char       *ieToMove,
    char       *beforeHere,
    scError_t  *error);

/**
 * scSchemaMoveIEAfterAnother
 * Move the first IE to after the other paramter
 * Parameters:
 *      schema:     pointer to the schema to edit
 *      ieToMove:   pointer to the IE to move before the other one
 *      afterHere:  pointer to the IE to move ieToMove after it
 * Returns:
 *      pointer to the IE that was moved on success
 *      NULL on failure
 */
scInfoElement_t* scSchemaMoveIEAfterAnother(
    scSchema_t         *schema,
    scInfoElement_t    *ieToMove,
    scInfoElement_t    *afterHere,
    scError_t          *error);

/**
 * scSchemaMoveIEAfterAnotherByName
 * Move the first IE to before the other paramter referenced by name
 * Parameters:
 *      schema:     pointer to the schema to edit
 *      ieToMove:   name of the IE to move
 *      afterHere:  name of the IE to move ieToMove after it
 * Returns:
 *      pointer to the IE that was moved on success
 *      NULL on failure
 */
scInfoElement_t* scSchemaMoveIEAfterAnotherByName(
    scSchema_t *schema,
    char       *ieToMove,
    char       *afterHere,
    scError_t  *error);

/**
 * scSchemaMoveIEToBeginning
 * Moves the IE to the beginning of the schema (offset 0)
 * Parameters:
 *      schema:     pointer to the schema to edit
 *      ieToMove:   pointer to the IE to move to the beginning of the schema
 * Returns:
 *      pointer to the moved IE on success
 *      NULL on failure
 */
scInfoElement_t* scSchemaMoveIEToBeginning(
    scSchema_t         *schema,
    scInfoElement_t    *ieToMove,
    scError_t          *error);

/**
 * scSchemaMoveIEToBeginningByName
 * Moves the IE to the beginning of the schema (offset 0)
 * Parameters:
 *      schema:     pointer to the schema to edit
 *      ieToMove:   name of the IE to move to the beginning of the schema
 * Returns:
 *      pointer to the moved IE on success
 *      NULL on failure
 */
scInfoElement_t* scSchemaMoveIEToBeginningByName(
    scSchema_t *schema,
    char       *ieToMove,
    scError_t  *error);

/**
 * scSchemaMoveIEToEnd
 * Moves the IE to the end of the schema (offset 0)
 * Parameters:
 *      schema:     pointer to the schema to edit
 *      ieToMove:   pointer to the IE to move to the end of the schema
 * Returns:
 *      pointer to the moved IE on success
 *      NULL on failure
 */
scInfoElement_t* scSchemaMoveIEToEnd(
    scSchema_t         *schema,
    scInfoElement_t    *ieToMove,
    scError_t          *error);

/**
 * scSchemaMoveIEToEndByName
 * Moves the IE to the end of the schema (offset 0)
 * Parameters:
 *      schema:     pointer to the schema to edit
 *      ieToMove:   name of the IE to move to the end of the schema
 * Returns:
 *      pointer to the moved IE on success
 *      NULL on failure
 */
scInfoElement_t* scSchemaMoveIEToEndByName(
    scSchema_t *schema,
    char       *ieToMove,
    scError_t  *error);



/**
 * scSchemaRemoveIE
 * Removes the specified IE from the schema.  The IE pointer must be one
 * from the schema, not just one with the same IDs
 * This function will remove the IE from any sets of grouped elements
 * This function will free the IE
 * Parameters:
 *      schema      pointer to the schema containing the IE to be removed
 *      ie          pointer to the IE to be removed.
 * Returns:
 *      0 on success
 *      not 0 on failure, mainly a null pointer or IE not in schema
 */
int scSchemaRemoveIE(
    scSchema_t         *schema,
    scInfoElement_t    *ie,
    scError_t          *error);

/**
 * scSchemaRemoveIE
 * Removes the IE specified by enterprise ID and element ID from the schema.
 * This function will remove the IE from any sets of grouped elements
 * This function will free the IE
 * Parameters:
 *      schema      pointer to the schema containing the IE to be removed
 *      ent         enterprise ID of the IE to remove
 *      id          element ID of the IE to remove
 * Returns:
 *      0 on success
 *      not 0 on failure, mainly IE not in schema
 */
int scSchemaRemoveIEByID(
    scSchema_t         *schema,
    uint32_t            ent,
    uint32_t            id,
    scError_t          *error);

/**** Functions for allocating, freeing, filling, and emptying grouped IEs */
/**
 * Allocate a new group of elements attached to the given schema that uses
 * the string name to identify this group
 * @param schema    Pointer to the schema to attach the group to
 * @param string    UserString to identify the group
 * @param error     Pointer to an error struct for better error reporting
 * @return          Pointer to the allocted GroupedElements_t
 */
scGroupedElements_t* scGroupedElementsAlloc(
    scSchema_t *schema,
    char       *string,
    scError_t  *error);

/**
 * Free a grouped elements and all underlying structures, but not the IEs in
 * group, those really live in the schema which will free them.
 * @param ge    Pointer to the group to free
 */
void scGroupedElementsFree(scGroupedElements_t    *ge);

/**
 * Add an information element to a group of elements
 * @param ge    Pointer to the group to add the IE to
 * @param ie    Pointer to the IE to add to the group
 * @param error Pointer to an error struct for better error reporting
 * @return      0 on success, non-zero on failure
 */
int scGroupedElementsAddIE(
    scGroupedElements_t    *ge,
    scInfoElement_t        *ie,
    scError_t              *error);

/**
 * Remove an IE from a group of elements
 * @param ge    Pointer to the group of the elements to remove the IE from
 * @param ie    Pointer to the IE to remove from group
 * @param error Pointer to an error struct for better error reporting
 * @return      0 on success, non-zero on failure, or if the IE isn't found.
 *              If not found, the group is still OK, and you can continue.
 */
int scGroupedElementsRemoveIE(
    scGroupedElements_t    *ge,
    scInfoElement_t        *ie,
    scError_t              *error);
/******** done with grouped elements */

/**
 * scInfoStringValListInit
 * Initializes the list to be ready to accept the first upcoming ISV
 * Parameters:
 *      list        double pointer to the head of the list (&(list pointer))
 */
void scInfoStringValListInit(
    scInfoStringValList_t **list);

/**
 * scInfoStringValAddToList
 * Adds a new pair {val, userString} to previously initialized list
 * Parameters:
 *      list        double pointer to head of list (same param as init)
 *      val         numberic value for the tuple
 *      userString  string value for the tuple
 */
scInfoStringVal_t* scInfoStringValAddToList(
    scInfoStringValList_t **list,
    uint32_t                val,
    char                   *userString,
    scError_t              *error);

/**
 * Free an infoStringVal, though probably not needed by a user, as ISV's
 * get freed with an InfoElement gets freed
 * @param isv   Pointer to the ISV to free
 */
void scInfoStringValFree(scInfoStringVal_t *isv);

/**
 * Used for debugging purposes to print the contents of a schema
 * @param schema Pointer to the schema to debug
 */
void scSchemaPrintIEs(
    scSchema_t *schema);

/******************* End of schema building functions */

/**
 * Allocates an error structure
 * @return A pointer to the newly allocated error structure
 */
scError_t* scErrorAlloc(
    void);

/**
 * Frees an error structure that was created with scErrorAlloc()
 * @param error Pointer to the error to free
 */
void scErrorFree(
    scError_t  *error);

/**
 * Clears an error structure, more for convenience, not required to do
 * @param error Pointer to the error to clear
 */
void scErrorClear(
    scError_t  *error);

/* allocate a new scConnSpec based on the type */
scConnSpec_t* scConnSpecAlloc(
    scConnSpecType_t    type);

/* allocate a new scConnSpec based on the type, setting it to reuse any
 * existing schemas already found in previous files. This is to be used if
 * you assume/know that schemas will not change from file to file */
scConnSpec_t* scConnSpecAllocUseSameSchemas(
    scConnSpecType_t    type);

/* set an exisitng conn spec to use same schemas from file to file */
void scConnSpecUseSameSchemas(
    scConnSpec_t   *connSpec);

/* hostname and poststring get strdup'ed */
int scConnSpecConfigureFixbufSocket(
    scConnSpec_t   *connSpec,
    char           *hostname,
    char           *portString);

/**
 * configure a socket conn spec with an integer point and IP address
 * rather than strings as above
 */
int scConnSpecConfigureSocketWithInts(
    scConnSpec_t   *connSpec,
    uint32_t        ip,
    uint16_t        port);

/* filename gets strdup'ed */
int scConnSpecAddFile(
    scConnSpec_t   *connSpec,
    const char     *filename);

/* do not include the trailing slash */
int scConnSpecAddDirectory(
    scConnSpec_t   *connSpec,
    const char     *directory,
    uint32_t        timeoutSeconds,
    uint32_t        pollingInterval,
    uint32_t        pollingTimeout);

int scConnSpecAddArchiveDirectory(
    scConnSpec_t   *connSpec,
    const char     *archiveDir);

void scConnSpecFree(
    scConnSpec_t   *connSpec);

scConnSpec_t* scConnSpecCopy(
    scConnSpec_t   *connSpec);


uint32_t getFixbufConnObservationDomain(
    void   *schemaState);

struct sockaddr* getFixbufConnPeerSocket(
    void   *schemaState);

int getFixbufConnCurrentInputName(
    void   *schemaState,
    char   *buf,
    size_t  len);

/************************ fixbuf <--> schemaTools functions */

/*
 * Make an ipfix connection to a socket, a list of files, everything in a
 * directory, or poll a directory, based on the fields set in connSpec.
 * This function creates a DataInfo structure, and creates the state pointer
 * to be passed to subsequent calls to get data (nextInput, and
 * getNextRecordCopy/Ptr). It returns 0 on success, and non-zero (usually 1)
 * upon failure. This state pointer must be freed by passing it to:
 *  freeAnyIncomingFixbufConnection()
 * The assocated incoming DataInfo structure will be free by this function.
 *
 * This function is to be called once per connection. The only time I can see
 * it being called more than once is to reconnect to a socket.
 * For ALL file related connections, this is to be called once
 *
 * This function calls other "get" functions below depending on the connSpec
 *
 * A copy of the incoming scConnSpec is made and will be freed.
 * The user is responsible for freeing their version of the connSpec.
 * Any changes to that connspec, once the data info and potential state are
 * created will have no effect.
 *
 * This function accepts a created fixbuf info model.
 * the info model will be freed by the schema builder if freedByConnection is
 * non-zero.
 *
 * If the infoModel pointer is NULL, an info model will be allocated, and then
 * freed by freeAnyIncomingFixbufConnection.
 */
int getAnyFixbufConnection(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             freedByConnection,
    scError_t      *error);

/*
 * Gets a connection to a socket specified by connSpec. Other than reconnecting
 * to a socket, and starting over, this function should be called only once
 * This function accepts a created fixbuf info model
 * the info model will be freed by the schema builder if freedByConnection is
 * non-zero. If infoModel is NULL, the standard fixbuf info model will be
 * used and allocated.
 */
int getSocketFixbufConnection(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *scError);

/** free all of the state associated with the incoming connection
 */
void freeAnyIncomingFixbufConnection(
    void  **schemaStateBlob);

void freeAnyOutgoingFixbufConnection(
    void  **outStateBlob);

/* interrupt a connected socket for shutdown */
void fixbufSocketConnectionInterrupt(
    void  **schemaStateBlob);

void fixbufPollDirConnectionInterrupt(
    void  **schemaStateBlob);

/* interrupt any blocking connection (socket or pollDir) */
void fixbufAnyConnectionInterrupt(
    void  **schemaStateBlob);

/*
 * get a connection to read all of the files in a directory.
 * This function is to be called once, with each file being a new input.
 * Set the conn spec to use the same schemas if you know that all of the files
 * in the directory use the same templates */
/* same function as above, except is accepts a fixbuf info model
 * the info model will be freed by the schema builder, NOT the user */
int getPollFileDirFixbufConnection(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *error);

/* same function as above, except is accepts a fixbuf info model
 * the info model will be freed by the schema builder, NOT the user */
int getPollFileDirFixbufConnectionSameSchemas(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *error);

/* get a connection to read all of the files specified in the connSpec.
 * This function is to be called once, with each file being a new input.
 * Set the conn spec to use the same schemas if you know that all of the files
 * in the list use the same templates */
/* same function as above, except is accepts a fixbuf info model
 * the info model will be freed by the schema builder, NOT the user */
int getFileListFixbufConnection(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *scError);

/* same function as above, except is accepts a fixbuf info model
 * the info model will be freed by the schema builder, NOT the user */
int getFileListFixbufConnectionSameSchemas(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *scError);

#define getFileDirFixbufConnection getFileListFixbufConnection
#define getFileDirFixbufConnectionSameSchemas getFileListFixbufConnectionSameSchemas

/* Not implemented */
int getMultiThreadedAnyConnection(
    scConnSpec_t   *connSpec);

/* Not implemented */
int getMultiThreadedSocketConnection(
    scConnSpec_t   *connSpec);

/* not implemented */
int getMultiThreadedFileDirConnection(
    scConnSpec_t   *connSpec);

/********* These functions create outgoing DataInfo's based on either incoming
 DataInfo's, or a list of schemas *****************************/

/**
 * Upon receiving an incoming data info from the schemaBuilder, or one of the
 * functions above, an outgoing ipfix/fixbuf connection can be derived from
 * those schemas. The functions below create outgoing dataInfo, based on an
 * allocated and filled scConnSpec, and uses an existing set of schemas
 * to build associated templates to use with ipfix/fixbuf.
 * Functions below with the prefix "derive" take an incoming data info as input
 * Functions below with the prefix "make", take a list of schemas that do not
 * need to be attached to a data info
 *
 * The connection state pointer that is allocated and passed back to these
 * functions is freed by calling: freeAnyOutgoingFixbufConnection()
 */
/* same function as above, except that it accepts a user created info model.
 * This info model will NOT be freed by freeAnyOutgoingFixbufConnection.
 * If this parameter is null, a new info model will be created, and freed.
 */
int deriveOutgoingFixbufConnection(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    const scDataInfo_t *inDataInfo,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

/* Same as the pair of functions above except that they take a list of schemas
 * instead of an existing data info struct
 */
int makeOutgoingFixbufConnection(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    scSchema_t         *firstSchema,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

int getAnyOutgoingFixbufConnectionWithoutSchemas(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

scSchema_t* addSchemaToOutgoingFixbufConnection(
    scDataInfo_t       *outDataInfo,
    void               *potentialState,
    scSchema_t         *schema,
    scError_t          *error);

scSchema_t* addSchemaToOutgoingFixbufConnectionAutoId(
    scDataInfo_t       *outDataInfo,
    void               *potentialState,
    scSchema_t         *schema,
    scError_t          *error);

/**
 * Converts a Fixbuf template to a schema.
 * In addition to the session (which contains an info model) and the template,
 * a schema ID and name are required
 * This function allocates a new schema, but does not add it to a DataInfo
 * @param session   A pointer to the session that contains the template
 * @param tmpl      A pointer to the template to convert
 * @param schemaID  An ID for the newly created schema
 * @param schemaName    A string name for the schema
 * @param error     A pointer to an error reporting structure
 * @return A pointer to the newly allocated and filled schema. Null on failure
 */
scSchema_t* scFixbufTemplateToSchema(
    fbSession_t    *session,
    fbTemplate_t   *tmpl,
    uint16_t        schemaId,
    char           *schemaName,
    scError_t      *error);

/*
 * Takes a schema, and returns a template. A new template is allocated and
 * filled with IEs from the schema. It uses the info model from the session.
 * It does NOT add the template to the session.
 * @param session   A pointer to the session
 * @param schema    The schema to convert to a template
 * @return A newly allocated and filled template pointer. Null on error.
 */
fbTemplate_t* scSchemaToFixbufTemplate(
    fbSession_t    *session,
    scSchema_t     *schema);

/*
 * This structure is likely to be used in some sort of connection state with
 * fixbuf as it keeps track of {schema, tid} pairs to convert to/and from
 * fixbuf and schemaTools. Is uses a template ID versus a template pointer
 * because a pointer can be used to create and internal and external template
 * ID, and this difference can matter.
 */
typedef struct scSchemaTemplateMgmt_st scSchemaTemplateMgmt_t;

/*
 * Allocates and initialized a TemplateMgmt pointer
 */
scSchemaTemplateMgmt_t* scSchemaTemplateMgmtInit(int isInput);

void printMgmt(
    scSchemaTemplateMgmt_t *mgmt);

/*
 * Adds the {schema, tid} pair to the template management.
 * @param   mgmt    Pointer to an allocated and initialized mgmt variable
 * @param   schema  Pointer to the schema to add
 * @param   tid     Template ID to pair with the schema
 * @return  0 on succes, 1 on failure
 */
int scSchemaTemplateMgmtAdd(
    scSchemaTemplateMgmt_t *mgmt,
    scSchema_t             *schema,
    uint16_t                tid);

/*
 * Delete a {schema, tid} pair based on the tid
 * @param mgmt  A pointer to the schema management struct
 * @param tid   The template ID to use as the key to remove the pair
 */
void scSchemaTemplateMgmtRemoveByTid(
    scSchemaTemplateMgmt_t *mgmt,
    uint16_t                tid);

/*
 * Delete a {schema, tid} pair based on the schema
 * @param mgmt      Pointer to the schema management struct
 * @param schema    Pointer to the schema to use as the key to remove the pair
 */
void scSchemaTemplateMgmtRemoveBySchema(
    scSchemaTemplateMgmt_t *mgmt,
    scSchema_t             *schema);

/*
 * Lookup a TID in the template management and return the associated schema
 * @param   mgmt    Pointer to the template management structure
 * @param   tid     Template ID to use as the key to find the right pair
 * @return Pointer to the schema on success, NULL if not found
 */
scSchema_t* scSchemaTemplateMgmtGetSchemaForTid(
    scSchemaTemplateMgmt_t *mgmt,
    uint16_t                tid);

/*
 * Lookup a schema in the template management and return the associated TID
 * It uses the schema ID as the key, not the pointer to the schema.
 * @param   mgmt    Pointer to the template management structure
 * @param   schema  Pointer to the schema to use to find the right TID
 * @return 0 if not found, non-zero on success
 */
uint16_t scSchemaTemplateMgmtGetTidForSchema(
    scSchemaTemplateMgmt_t *mgmt,
    scSchema_t             *schema);

/*
 * free and cleanup the template management structure. This does not free the
 * schema pointers is saves, nor does it do anything to the template
 */
void scSchemaTemplateMgmtFree(scSchemaTemplateMgmt_t *mgmt);

/************************ helper functions *****************/
/**
 * Returns a string with the name of the type value for logging.
 * @param type Value to get the string for
 * @return Pointer to a string with the name.  Does not need freed.
 */
char* getIETypeString(      scInfoType_t        type);
/**
 * Returns a string with the name of the semantic value for logging.
 * @param semantic Value to get the string for
 * @return Pointer to a string with the name.  Does not need freed.
 */
char* getIESemanticString(  scInfoSemantic_t    semantic);
/**
 * Returns a string with the name of the units value for logging.
 * @param units Value to get the string for
 * @return Pointer to a string with the name.  Does not need freed.
 */
char* getIEUnitsString(     scInfoUnits_t       units);


/* fixbuf helper functions and structures */
typedef struct scSchemaBuilderMem_st {
    void               *schemaStateContext;
    uint32_t            numVarfields;
    uint32_t            varfieldOffsets[100];
    uint32_t            numLists;
    uint32_t            numBasicLists;
    uint32_t            basicListOffsets[100];
    scInfoElement_t    *basicListIEs[100];
    uint32_t            numSTLs;
    uint32_t            STLoffsets[100];
    scInfoElement_t    *STLies[100];
    uint32_t            numSTMLs;
    uint32_t            STMLoffsets[100];
    scInfoElement_t    *STMLies[100];
} scSchemaBuilderMem_t;

typedef struct scFBufSessionAndState_st {
    fbSession_t        *fBufSession;
    void               *schemaState;
} scFBufSessionAndState_t;

void fixbufSchemaBuilderMemFree(
    void   *builderMem);

void* fixbufSchemaBuilderMemAllocAndCopy(
    scSchema_t *schema);

void scFBufSessionAndStateAdd(
    fbSession_t    *session,
    void           *state);

void scFBufSessionAndStateRemove(
    fbSession_t    *session);

typedef struct scSchemaTemplate_st {
    scSchema_t *schema;
    uint16_t    tid;
} scSchemaTemplate_t;

struct scSchemaTemplateMgmt_st {
    uint16_t            numSchemas;
    int                 isInput;
    scSchemaTemplate_t *head;
};

void* scGetSchemaStateForFBufSession(
    fbSession_t    *session);

/* IE is the BL, pass in full rec */
uint8_t* scBasicListGetDataPtrFromRec(
    scInfoElement_t    *ie,
    uint8_t            *rec);

/* if IE is the BL, pass in full rec
 */
uint16_t scBasicListGetNumElementsFromRec(
    scInfoElement_t    *ie,
    uint8_t            *rec);

uint8_t* scBasicListGetDataPtr(
    scBasicList_t  *basicList);

uint16_t scBasicListGetNumElements(
    scBasicList_t  *basicList);

scInfoElement_t* scDataInfoGetElementFromModelByName(
    scDataInfo_t   *dataInfo,
    char           *name);

scInfoElement_t* scDataInfoGetElementFromModelByID(
    scDataInfo_t   *dataInfo,
    uint32_t        ent,
    uint32_t        id);

void scInfoElementSetStandardFuncs(
    scInfoElement_t    *ie);


#define scBasicListGetIndexedDataPtr fbBasicListGetIndexedDataPtr
#define scBasicListGetNextPtr        fbBasicListGetNextPtr

#endif
