#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <schemaTools/schemaTools.h>
#include <fixbuf/public.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <signal.h>
#include <time.h>
#include <libgen.h>
#include <unistd.h>
#include <errno.h>
#include <glib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <assert.h>

/*
 * This function loops through the elements of a data record
 * and calls the print function for each IE and data value
 */
void myPrintAllElements(
    scSchema_t *schema,
    uint8_t    *rec)
{
    char                stringBuf[300];
    scInfoElement_t    *ie = NULL;
    uint8_t             dataBuf[100];
    int                 printedSoFar = 0;
    
    memset(stringBuf, 0, 300);
    memset(dataBuf, 0, 100);

    printf("IE names: ");
    while((ie = scSchemaGetNextInfoElement(schema, ie))) {
        if (ie->type == BASIC_LIST) {
            printf("%s", ie->name);
        } else {
            printf("%s ", ie->name);
        }
                
        ie->copyVal(ie, rec, dataBuf);
        printedSoFar += ie->printFunc(ie, 
                                      (stringBuf + printedSoFar), 
                                      300 - printedSoFar, 
                                      dataBuf);
        snprintf(stringBuf + printedSoFar, 300 - printedSoFar, " ");
        printedSoFar++;    
    
        memset(dataBuf, 0, 100);
    }

    printf("\n");

    printf("Data values: %s\n", stringBuf);
}

int main(int argc, char **argv)
{
    scDataInfo_t               *inDataInfo  = NULL;
    int                         rv;
    uint8_t                    *inRec;
    scSchema_t                 *schemaUsed;
    scSchemaFreeRecord_fn       secFreeInRec;
    scSchemaDeepCopyRecord_fn   copyRecord;
    scSchemaFreeRecord_fn       secondLevelFree;
    void                       *schemaState = NULL;
    scSchema_t                 *lastSchema = NULL;
    scError_t                  *error;
    scConnSpec_t               *myConnSpec;
    fbInfoModel_t              *infoModel;
    int                         connMax = 1;
    int                         connCount = 0;
    char                        fileBuf[200];
    scInfoElement_t            *currentBasicList;
    scBasicList_t               basicList;
    
    

    memset(fileBuf, 0, 200);

    infoModel = fbInfoModelAlloc();

    if (argc != 3) {
        printf("SOCK, FILELISTSAME, FILELISTREDO, FILEDIRSAME, FILEDIRREDO, POLLDIRSAME, POLLDIRREDO dummy\n");
        return 0;
    }

    if (strcmp(argv[1], "SOCK") == 0) {
        myConnSpec = scConnSpecAlloc(SC_CS_TCP);
        scConnSpecConfigureFixbufSocket(myConnSpec, "localhost", argv[2]);
        connMax = 1;
    } else if (strcmp(argv[1], "FILEDIRSAME") == 0) {
        myConnSpec = scConnSpecAllocUseSameSchemas(SC_CS_DIRECTORY);
        snprintf(fileBuf, 200, "%s", argv[2]);
        scConnSpecAddDirectory(myConnSpec, fileBuf, 0, 0, 0);
    } else if (strcmp(argv[1], "FILEDIRREDO") == 0) {
        myConnSpec = scConnSpecAlloc(SC_CS_DIRECTORY);
        snprintf(fileBuf, 200, "%s", argv[2]);
        scConnSpecAddDirectory(myConnSpec, fileBuf, 0, 0, 0);
    } else if (strcmp(argv[1], "FILELISTSAME") == 0) {
        myConnSpec = scConnSpecAllocUseSameSchemas(SC_CS_FILELIST_INPUT);
        snprintf(fileBuf, 200, "%s", argv[2]);
        scConnSpecAddFile(myConnSpec, fileBuf);
    } else if (strcmp(argv[1], "FILELISTREDO") == 0) {
        myConnSpec = scConnSpecAlloc(SC_CS_FILELIST_INPUT);
        snprintf(fileBuf, 200, "%s", argv[2]);
        scConnSpecAddFile(myConnSpec, fileBuf);
/*    } else if (strcmp(argv[1], "POLLDIRSAME") == 0) {
        myConnSpec = scConnSpecAllocUseSameSchemas(SC_CS_POLL_DIR);
        scConnSpecAddDirectory(myConnSpec, "/afs/cert.org/usr/druef/hg/schemaTools/schemaTesters/exporters/outputFiles/", 0);
    } else if (strcmp(argv[1], "POLLDIRREDO") == 0) {
        myConnSpec = scConnSpecAlloc(SC_CS_POLL_DIR);
        scConnSpecAddDirectory(myConnSpec, "/afs/cert.org/usr/druef/hg/schemaTools/schemaTesters/exporters/outputFiles/", 0);*/
    } else {
        printf("%s dummy\n", argv[1]);
    }
        

    error = scErrorAlloc();

    /* Retrieve the data info */
    while(connCount < connMax) {
        connCount++;
    
    if (getAnyFixbufConnection(myConnSpec, &inDataInfo,
                                  &schemaState, infoModel, 1, error)) {
        printf("getting connection failed %s\n", error->msg);
        return 0;
    }

    /* allocate a record big enough to hold the largest record */
    inRec           = calloc(1, scDataInfoGetMaxRecordLength(inDataInfo));

    /* loop through all of the inputs */
    while ((rv = inDataInfo->nextInput(&schemaState)) != 0) {
        /* loop through all of the records in a given input */
        while((inDataInfo->getNextRecordCopy(schemaState, inRec, &schemaUsed) == SCGETNEXT_OK))
        {
            /* set up the function pointers and lookups if this schema
             * is different than the last one */
            if (schemaUsed != lastSchema || 
                scSchemaGetCtx(schemaUsed) != (void*)11) 
            { 
                scSchemaSetCtx(schemaUsed, (void*)11, NULL);
                /* get the function to make copies of these records */
                copyRecord      = scSchemaGetCopyRecordFunc(schemaUsed);
                /* get the function to free the copied records */
                secFreeInRec    = scSchemaGetFreeRecordFunc(schemaUsed);
                /* get function to free the original record, but not buf */
                secondLevelFree = scSchemaGetSecondLevelFreeFunc(schemaUsed);
                /* find the dport in this schema */
                lastSchema = schemaUsed;

            }

            currentBasicList = scSchemaGetIEByName(schemaUsed, "basicList");

            while (currentBasicList) {
                uint16_t    i;
                void       *theVal = NULL;
                void       *iterVal = NULL;
                char        valBuf[100];
                char        iterBuf[100];
                const fbInfoElement_t    *fbIE;
                scInfoElement_t    *underIE;
                currentBasicList->copyVal(currentBasicList, inRec, (uint8_t*)&basicList);
                fbIE = basicList.infoElement;
                underIE = scInfoElementAllocAndFill(infoModel, fbIE->ent, fbIE->num);
                scInfoElementSetStandardFuncs(underIE);
                for (i = 0; i < scBasicListGetNumElements(&basicList); i++) {
                    memset(valBuf, 0, 100);
                    memset(iterBuf, 0, 100);
                    theVal = scBasicListGetIndexedDataPtr(&basicList, i);
                    iterVal = scBasicListGetNextPtr(&basicList, iterVal);
                    underIE->printFunc(underIE, valBuf, 100, theVal);
                    underIE->printFunc(underIE, iterBuf, 100, iterVal);
                    printf("please be equal: (%s)(%s)\n", valBuf, iterBuf);
                }
                scInfoElementFree(underIE);
                currentBasicList = currentBasicList->nextIdenticalIE;
            }

/*            myPrintAllElements(schemaUsed, inRec);*/
            
            /* free the extra elements of the buffer, but not the inRec buf */
            secondLevelFree(schemaUsed, inRec);
            /* free the record copy */
            printf("\n");
        }
    }
    }

    /*freeAnyIncomingFixbufConnection(&schemaState);*/

    free(inRec);

    scErrorFree(error);

    /* to be updated...*/
    scConnSpecFree(myConnSpec);
    return 0;
}
