/**
 * @OPENSOURCE_HEADER_START@
 * Use of this (and related) source code is subject to the terms
 * of the following licenses:
 *
 * GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 *
 * NO WARRANTY
 *
 * ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 * PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 * PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 * "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 * LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 * MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 * OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 * SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 * TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 * WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 * LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 * CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 * CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 * DELIVERABLES UNDER THIS LICENSE.
 *
 * Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 * Mellon University, its trustees, officers, employees, and agents from
 * all claims or demands made against them (and any related losses,
 * expenses, or attorney's fees) arising out of, or relating to Licensee's
 * and/or its sub licensees' negligent use or willful misuse of or
 * negligent conduct or willful misconduct regarding the Software,
 * facilities, or other rights or assistance granted by Carnegie Mellon
 * University under this License, including, but not limited to, any
 * claims of product liability, personal injury, death, damage to
 * property, or violation of any laws or regulations.
 *
 * Carnegie Mellon University Software Engineering Institute authored
 * documents are sponsored by the U.S. Department of Defense under
 * Contract F19628-00-C-0003. Carnegie Mellon University retains
 * copyrights in all material produced under this contract. The U.S.
 * Government retains a non-exclusive, royalty-free license to publish or
 * reproduce these documents, or allow others to do so, for U.S.
 * Government purposes only pursuant to the copyright license under the
 * contract clause at 252.227.7013.
 *
 * @OPENSOURCE_HEADER_END@
 * -----------------------------------------------------------
 */


#include <fixbuf/public.h>

static char * md_iport = "21000";
static char * md_ihost = "localhost";

static fbInfoElementSpec_t  dummyPortsTemplate[] = {
    {"sourceTransportPort",                 0, 0 },
    {"destinationTransportPort",            0, 0 },
    {"flowActiveTimeout",                   0, 0 },
/*    {"tunnelTechnology",                    0, 0 },
    {"encryptedTechnology",                 0, 0 },*/
    FB_IESPEC_NULL
};

typedef struct portsStruct_st {
    uint16_t        sport;
    uint16_t        dport;
    uint16_t        portSum;
/*    fbVarfield_t    sportDesc;
    fbVarfield_t    dportDesc;*/
} portsStruct_t;

#define FLUSHCOUNT 64
#define FILEFLUSH  10000
#define FLUSH_TIMEOUT 18000 /* 5 mins */
#define MAX_EXPORT 256

fbListener_t   *collectorListener;
fbInfoModel_t  *infoModel;
fbTemplate_t   *portsTemplate;

/**
 * main
 *
 *
 */
int
main (int argc, char *argv[])
{
    fbSession_t            *collectorSession;
    struct fbConnSpec_st    socketDef;

    GError                 *error   = NULL;
    gboolean                rc;
    size_t                  length;
    uint16_t                portsTemplateID;

    portsStruct_t           thePorts;

    memset(&thePorts, 0, sizeof(portsStruct_t));

    /**
       this program runs forever, until interrupted, handle
       the interrupt gracefully and exit by installing these
       handlers
    */

    infoModel = fbInfoModelAlloc();

    /**
       template creation
       =================
       with the info model created, it is time to create the templates.
    */
    /* create a template for the collector (ingress) PDU's to us */

    portsTemplate = fbTemplateAlloc(infoModel);
    rc = fbTemplateAppendSpecArray(portsTemplate, dummyPortsTemplate,
                                   0xffffffff, &error);
    if (FALSE == rc)
    {
        fprintf(stderr, "fatal: error building collector template\n");
        fprintf(stderr, "\t%s\n", error->message);
        exit (-20);
    }

    socketDef.transport = FB_TCP;
    socketDef.host = md_ihost;
    socketDef.svc = md_iport;

    socketDef.ssl_ca_file = NULL;
    socketDef.ssl_cert_file = NULL;
    socketDef.ssl_key_file = NULL;
    socketDef.ssl_key_pass = NULL;
    socketDef.vai = NULL;
    socketDef.vssl_ctx = NULL;


    /**
       create a collector to read from an ipfix file
       =============================================
       create a session (fbSession_t) and attach it to the info model via
       fbSessionAlloc create a collector session and then pass that session
       to the listener to finish building the collector

    */

    collectorSession = fbSessionAlloc(infoModel);
    portsTemplateID = fbSessionAddTemplate(collectorSession,
                            TRUE, 300,
                            portsTemplate,
                            &error);
    if (0 == portsTemplateID)
    {
        fprintf(stderr, "fatal: couldn't associate collector template\n");
        fprintf(stderr, "\t%s\n", error->message);
        exit(-40);
    }

    collectorListener = fbListenerAlloc(&socketDef,
                              collectorSession,
                              NULL, NULL, &error);
    /* some variables needed to run the loop of getting buffers
       and exporting buffers
    */

    /** wait for connections*/
        if (error != NULL){
            g_clear_error(&error);
        }
        /** wait for the collector to get a connection from a sensor */
        
        fBuf_t *collectorBuf = fbListenerWait(collectorListener, &error);

        /** can only set the template for the buffer after you have the buffer
        and that gets created by the listener on demand when a connection
        happens - we have it now set the template on it */

        rc = fBufSetInternalTemplate(collectorBuf, portsTemplateID, &error);
        if (FALSE == rc)
        {
            fprintf(stderr, "fatal: couldn't set internal template\n");
            fprintf(stderr, "\t%s\n", error->message);
            exit(-41);
        }

        /**  consume buffers as long as the buffers keep arriving */
        while (1)
        {

            memset(&thePorts, 0, sizeof(portsStruct_t));
            length = sizeof(portsStruct_t);
            rc = fBufNext(collectorBuf, (uint8_t *)&thePorts, &length,
              &error);

            if (FALSE == rc) {
                if (!strncmp(error->message, "End of file",
                     strlen("End of file")))
                {
                    fBufFree(collectorBuf);
                    break;
                }
                printf("error: %s\n", error->message);
                g_clear_error(&error);
                break;
            }
            if (thePorts.sport || thePorts.dport) {
                printf("sport: %d dport:%d sum %d\n", thePorts.sport,
                                               thePorts.dport, thePorts.portSum);
/*                printf("sport len: %d dport len: %d\n", thePorts.sportDesc.len,
                                                        thePorts.dportDesc.len);*/
            } else {
                printf("no port\n");
            }
        }
        printf("Connection Reset\n");

    g_error_free(error);
    fbSessionFree(collectorSession);
    fbListenerFree(collectorListener);
    fbInfoModelFree(infoModel);
    /** finished with no problems */
    return 0;
}

/**
 * sigHandler
 *
 * this gets called from various system signal handlers.  It is used to
 * provide a way to exit this program cleanly when the user wants to
 * kill this program
 *
 * @param signalNumber the number of the signal that this handler is
 *        getting called for
 *
 */
void
sigHandler (int signalNumber)
{
    fprintf(stderr, "Received signal %d, time to die...\n", signalNumber);

    fbTemplateFreeUnused(portsTemplate);
    fbListenerFree(collectorListener);
    fbInfoModelFree(infoModel);

    /** exit the system cleanly */
    exit(-1*signalNumber);
}
