/**
 * @OPENSOURCE_HEADER_START@
 * Use of this (and related) source code is subject to the terms
 * of the following licenses:
 *
 * GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 *
 * NO WARRANTY
 *
 * ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 * PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 * PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 * "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 * LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 * MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 * OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 * SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 * TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 * WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 * LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 * CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 * CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 * DELIVERABLES UNDER THIS LICENSE.
 *
 * Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 * Mellon University, its trustees, officers, employees, and agents from
 * all claims or demands made against them (and any related losses,
 * expenses, or attorney's fees) arising out of, or relating to Licensee's
 * and/or its sub licensees' negligent use or willful misuse of or
 * negligent conduct or willful misconduct regarding the Software,
 * facilities, or other rights or assistance granted by Carnegie Mellon
 * University under this License, including, but not limited to, any
 * claims of product liability, personal injury, death, damage to
 * property, or violation of any laws or regulations.
 *
 * Carnegie Mellon University Software Engineering Institute authored
 * documents are sponsored by the U.S. Department of Defense under
 * Contract F19628-00-C-0003. Carnegie Mellon University retains
 * copyrights in all material produced under this contract. The U.S.
 * Government retains a non-exclusive, royalty-free license to publish or
 * reproduce these documents, or allow others to do so, for U.S.
 * Government purposes only pursuant to the copyright license under the
 * contract clause at 252.227.7013.
 *
 * @OPENSOURCE_HEADER_END@
 * -----------------------------------------------------------
 */

#include <fixbuf/public.h>

static char * md_ehost = "localhost";

/* A template with sip, dip, sport and dport */
static fbInfoElementSpec_t  allTemplate[] = {
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"basicList",                           0, 0 },
    {"interfaceName",                       0, 0 },
    {"postMCastPacketDeltaCount",           0, 0 },
    {"sourceIPv4Address",                   0, 0 },
    {"sourceTransportPort",                 0, 0 },
    {"igmpType",                            0, 0 },
    {"flowStartSeconds",                    0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for allTemplate */
typedef struct allVar_st {
    fbBasicList_t   u8BL;
    fbBasicList_t   u16BL;
    fbBasicList_t   u32BL;
    fbBasicList_t   u64BL;
    fbBasicList_t   stringBL;
    fbBasicList_t   octetArrayBL;
    fbBasicList_t   f64BL;
    fbBasicList_t   secBL;
    fbBasicList_t   micSecBL;
    fbBasicList_t   milSecBL;
    fbBasicList_t   nanoSecBL;
    fbBasicList_t   ipv4BL;
    fbBasicList_t   ipv6BL;
    fbVarfield_t    interfaceName;
    uint64_t        dfc;
    uint32_t        sip;
    uint16_t        sport;
    uint8_t         igmp;
    uint32_t        timestamp;
} allVar_t;

#define FLUSHCOUNT 64
#define FILEFLUSH  10000
#define FLUSH_TIMEOUT 18000 /* 5 mins */
#define MAX_EXPORT 256

/**
 * prototypes
 */

GTimer * timer;

typedef enum sockOrFiles_en {
    SOCKET = 1,
    ONE_FILE,
    MULTIPLE_FILES
} sockOrFiles_t;

/**
 * main
 *
 *
 */
int
main (int argc, char *argv[])
{
    fbSession_t            *exporterSession;
    fbInfoModel_t          *infoModel;
    struct fbConnSpec_st    eSocketDef;
    fBuf_t                 *exporterBuf;
    fbExporter_t           *exporter;

    GError                 *error   = NULL;
    gboolean                rc;
    size_t                  length;
    fbTemplate_t           *allTmpl;
    uint16_t                allID;
    allVar_t                all;
    int                     i;
    int                     loopNum = 1;
    sockOrFiles_t           socketOrFiles;
    char                    fileName[100];
    char                    first[6];
    char                    second[9];
    char                   *portOrDirString;
    char                    testString[10];

    /* basic list pointer vars */
    uint8_t                *protoPtr = NULL;
    uint16_t               *sectionPtr = NULL;
    uint32_t               *samplingPtr = NULL;
    uint64_t               *octetPtr = NULL;
    fbVarfield_t           *stringPtr = NULL;
    fbVarfield_t           *octetArrayPtr = NULL;
    double                 *f64Ptr = NULL;
    uint32_t               *dtSecPtr = NULL;
    uint64_t               *dtMicSecPtr = NULL;
    uint64_t               *dtMilSecPtr = NULL;
    uint64_t               *dtNanoSecPtr = NULL;
    uint32_t               *dipPtr = NULL;
    uint64_t               *ipv6Ptr = NULL;

    memset(&all, 0, sizeof(allVar_t));

    strncpy(testString, "testString", 10);

    if (argc != 4) {
        printf("./basic... SOCKET/FILES loopNum portNumber/dir\n");
        return 1;
    }


    portOrDirString = argv[3];
    loopNum = atoi(argv[2]);
    if (strcmp(argv[1], "SOCKET") == 0) {
        socketOrFiles = SOCKET;
    } else if (strcmp(argv[1], "FILES") == 0) {
        socketOrFiles = MULTIPLE_FILES;
    } else if (strcmp(argv[1], "ONE_FILE") == 0) {
        socketOrFiles = ONE_FILE;
    } else {
        printf("Invalid arg 1\n");
        return 1;
    }

    infoModel = fbInfoModelAlloc();
    if (socketOrFiles != MULTIPLE_FILES) {
        /* allocate an info model which everything is built from */

        /* create a session to add eventual templates to */
        exporterSession = fbSessionAlloc(infoModel);
        allTmpl = fbTemplateAlloc(infoModel);
        fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);

        /* Create a template for each defined above (all, ips, and ports)
           Add each template as external templates to the session to get IDs */
        allID = fbSessionAddTemplate(exporterSession, TRUE, 1982,
                                 allTmpl, &error);

        /* add the data templates as internal templates to the session */
        fbSessionAddTemplate(exporterSession, FALSE, allID, allTmpl, &error);
    }
    if (socketOrFiles == SOCKET) {
        /* set up hardcoded connection to localhost 18000 */
        eSocketDef.transport = FB_TCP;
        eSocketDef.host = md_ehost;
        eSocketDef.svc = portOrDirString;
        eSocketDef.ssl_ca_file = NULL;
        eSocketDef.ssl_cert_file = NULL;
        eSocketDef.ssl_key_file = NULL;
        eSocketDef.ssl_key_pass = NULL;
        eSocketDef.vai = NULL;
        eSocketDef.vssl_ctx = NULL;

        exporter = fbExporterAllocNet(&eSocketDef);
        exporterBuf = fBufAllocForExport(exporterSession, exporter);
        fbSessionExportTemplates(exporterSession, &error);
    } else if (socketOrFiles == ONE_FILE) {
        memset(fileName, 0, 100);
        snprintf(fileName, 100, "%s/ONE.ipfix", portOrDirString);
        exporter = fbExporterAllocFile(fileName);
        exporterBuf = fBufAllocForExport(exporterSession, exporter);
        if (!exporterBuf) {
            printf("Couldn't alloc fbuf for ONE_FILE\n");
            return 1;
        }
        fbSessionExportTemplates(exporterSession, &error);
    }

    /* set the internal and external templates to the all template
       to send data in that format */

    /* set the initial values */

    all.interfaceName.len = strlen("testString");
    all.interfaceName.buf = (uint8_t*)testString;
    all.dfc   = 5000;
    all.igmp  = 100;
    all.timestamp = 100;

    protoPtr = fbBasicListInit(&(all.u8BL), 0,
              fbInfoModelGetElementByName(infoModel, "protocolIdentifier"), 2);
    *protoPtr = 1;
    protoPtr++;
    *protoPtr = 2;

    sectionPtr = (uint16_t*)fbBasicListInit(&(all.u16BL), 0,
        fbInfoModelGetElementByName(infoModel, "sectionOffset"), 2);
    *sectionPtr = 100;
    sectionPtr++;
    *sectionPtr = 101;

    samplingPtr = (uint32_t*)fbBasicListInit(&(all.u32BL), 0,
        fbInfoModelGetElementByName(infoModel, "samplingInterval"), 2);
    *samplingPtr = 500;
    samplingPtr++;
    *samplingPtr = 1000;

    octetPtr = (uint64_t*)fbBasicListInit(&(all.u64BL), 0,
        fbInfoModelGetElementByName(infoModel, "octetDeltaCount"), 2);
    *octetPtr = 25;
    octetPtr++;
    *octetPtr = 35;

    stringPtr = (fbVarfield_t*)fbBasicListInit(&(all.stringBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "wlanSSID"),
                                         2);
    strcpy(first, "first");
    stringPtr->len = strlen("first");
    stringPtr->buf = (uint8_t*)first;

    stringPtr++;
    strcpy(second, "secndOne");
    stringPtr->len = 8;
    stringPtr->buf = (uint8_t*)second;

    octetArrayPtr = (fbVarfield_t*)fbBasicListInit(&(all.octetArrayBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "mplsTopLabelStackSection"),
                                         2);
    strcpy(first, "first");
    octetArrayPtr->len = strlen("first");
    octetArrayPtr->buf = (uint8_t*)first;

    octetArrayPtr++;
    strcpy(second, "secndOne");
    octetArrayPtr->len = 8;
    octetArrayPtr->buf = (uint8_t*)second;

    f64Ptr = (double*)fbBasicListInit(&(all.f64BL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "absoluteError"), 2);

    *f64Ptr = 10.75;
    f64Ptr++;
    *f64Ptr = 75.10;

    dtSecPtr = (uint32_t*)fbBasicListInit(&(all.secBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartSeconds"), 2);

    *dtSecPtr = 7;
    dtSecPtr++;
    *dtSecPtr = 8;

    dtMilSecPtr = (uint64_t*)fbBasicListInit(&(all.milSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartMilliseconds"), 2);

    *dtMilSecPtr = 7000;
    dtMilSecPtr++;
    *dtMilSecPtr = 8000;

    dtMicSecPtr = (uint64_t*)fbBasicListInit(&(all.micSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartMicroseconds"), 2);

    *dtMicSecPtr = 7000000;
    dtMicSecPtr++;
    *dtMicSecPtr = 8000000;

    dtNanoSecPtr = (uint64_t*)fbBasicListInit(&(all.nanoSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartNanoseconds"), 2);

    *dtNanoSecPtr = 7000000000;
    dtNanoSecPtr++;
    *dtNanoSecPtr = 8000000000;

    dipPtr = (uint32_t*)fbBasicListInit(&(all.ipv4BL), 0,
                                          fbInfoModelGetElementByName(infoModel,
                                               "destinationIPv4Address"), 2);
    *dipPtr = 0x01020304;
    dipPtr++;
    *dipPtr = 0x02030405;

    ipv6Ptr = (uint64_t*)fbBasicListInit(&(all.ipv6BL), 0,
                                          fbInfoModelGetElementByName(infoModel,
                                            "destinationIPv6Address"), 2);
    *ipv6Ptr = 0x01234567;
    ipv6Ptr++;
    *ipv6Ptr = 0x89abcdef;
    ipv6Ptr++;
    /* 2nd one */
    *ipv6Ptr = 0xfedcba98;
    ipv6Ptr++;
    *ipv6Ptr = 0x76543210;


    for (i = 0; i < loopNum; i ++) {
        sleep(2);
        if (socketOrFiles == MULTIPLE_FILES) {
            exporterSession = fbSessionAlloc(infoModel);

            allTmpl = fbTemplateAlloc(infoModel);
            fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);
            /* Create a template for each defined above (all, ips, and ports)
            Add each template as external templates to the session to get IDs */
            allID = fbSessionAddTemplate(exporterSession, TRUE, 1982,
                                 allTmpl, &error);

            /* add the data templates as internal templates to the session */
            fbSessionAddTemplate(exporterSession, FALSE, allID, allTmpl, &error);

            memset(fileName, 0, 100);
            snprintf(fileName, 100, "%s/%02d.ipfix", portOrDirString, i);
            exporter = fbExporterAllocFile(fileName);
            exporterBuf = fBufAllocForExport(exporterSession, exporter);
            if (!exporterBuf) {
                printf("no exporter buf\n");
                return 1;
            }
            fbSessionExportTemplates(exporterSession, &error);
        }

        fBufSetInternalTemplate(exporterBuf, allID, &error);
        fBufSetExportTemplate(exporterBuf, allID, &error);

        /* fill the data structure and send the record */
        all.timestamp++;
        length = sizeof(allVar_t);
        rc = fBufAppend(exporterBuf, (uint8_t *)&all, length,
        &error);

        fbBasicListClear(&all.u8BL);
        fbBasicListClear(&all.u16BL);
        fbBasicListClear(&all.u32BL);
        fbBasicListClear(&all.u64BL);
        fbBasicListClear(&all.stringBL);
        fbBasicListClear(&all.octetArrayBL);
        fbBasicListClear(&all.f64BL);
        fbBasicListClear(&all.ipv4BL);
        fbBasicListClear(&all.ipv6BL);
        all.sip++;
        all.sport++;
        all.dfc++;
        all.igmp++;

    protoPtr = fbBasicListInit(&(all.u8BL), 0,
              fbInfoModelGetElementByName(infoModel, "protocolIdentifier"), 2);
    *protoPtr = 11;
    protoPtr++;
    *protoPtr = 12;

    sectionPtr = (uint16_t*)fbBasicListInit(&(all.u16BL), 0,
        fbInfoModelGetElementByName(infoModel, "sectionOffset"), 2);
    *sectionPtr = 200;
    sectionPtr++;
    *sectionPtr = 201;

    samplingPtr = (uint32_t*)fbBasicListInit(&(all.u32BL), 0,
        fbInfoModelGetElementByName(infoModel, "samplingInterval"), 2);
    *samplingPtr = 1500;
    samplingPtr++;
    *samplingPtr = 2000;

    octetPtr = (uint64_t*)fbBasicListInit(&(all.u64BL), 0,
        fbInfoModelGetElementByName(infoModel, "octetDeltaCount"), 2);
    *octetPtr = 125;
    octetPtr++;
    *octetPtr = 135;

    stringPtr = (fbVarfield_t*)fbBasicListInit(&(all.stringBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "wlanSSID"),
                                         2);
    strcpy(second, "thirdOne");
    stringPtr->len = 8;
    stringPtr->buf = (uint8_t*)second;

    stringPtr++;
    strcpy(first, "forth");
    stringPtr->len = 5;
    stringPtr->buf = (uint8_t*)first;

    octetArrayPtr = (fbVarfield_t*)fbBasicListInit(&(all.octetArrayBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "mplsTopLabelStackSection"),
                                         2);
    strcpy(second, "thirdOne");
    octetArrayPtr->len = 8;
    octetArrayPtr->buf = (uint8_t*)second;

    octetArrayPtr++;
    strcpy(first, "forth");
    octetArrayPtr->len = 5;
    octetArrayPtr->buf = (uint8_t*)first;

    f64Ptr = (double*)fbBasicListInit(&(all.f64BL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "absoluteError"), 2);

    *f64Ptr = 12.34;
    f64Ptr++;
    *f64Ptr = 56.78;

    dtSecPtr = (uint32_t*)fbBasicListInit(&(all.secBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartSeconds"), 2);

    *dtSecPtr = 17;
    dtSecPtr++;
    *dtSecPtr = 18;

    dtMilSecPtr = (uint64_t*)fbBasicListInit(&(all.milSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartMilliseconds"), 2);

    *dtMilSecPtr = 17000;
    dtMilSecPtr++;
    *dtMilSecPtr = 18000;

    dtMicSecPtr = (uint64_t*)fbBasicListInit(&(all.micSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartMicroseconds"), 2);

    *dtMicSecPtr = 17000000;
    dtMicSecPtr++;
    *dtMicSecPtr = 18000000;

    dtNanoSecPtr = (uint64_t*)fbBasicListInit(&(all.nanoSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartNanoseconds"), 2);

    *dtNanoSecPtr = 17000000000;
    dtNanoSecPtr++;
    *dtNanoSecPtr = 18000000000;

    dipPtr = (uint32_t*)fbBasicListInit(&(all.ipv4BL), 0,
                                          fbInfoModelGetElementByName(infoModel,
                                               "destinationIPv4Address"), 2);
    *dipPtr = 0x0F0F0F0F;
    dipPtr++;
    *dipPtr = 0x12121212;

    ipv6Ptr = (uint64_t*)fbBasicListInit(&(all.ipv6BL), 0,
                                          fbInfoModelGetElementByName(infoModel,
                                            "destinationIPv6Address"), 2);
    *ipv6Ptr = 0x11111111;
    ipv6Ptr++;
    *ipv6Ptr = 0x22222222;
    ipv6Ptr++;
    /* 2nd one */
    *ipv6Ptr = 0x33333333;
    ipv6Ptr++;
    *ipv6Ptr = 0x44444444;


    all.timestamp++;
    length = sizeof(allVar_t);
    rc = fBufAppend(exporterBuf, (uint8_t *)&all, length,
    &error);

    fbBasicListClear(&all.u8BL);
    fbBasicListClear(&all.u16BL);
    fbBasicListClear(&all.u32BL);
    fbBasicListClear(&all.u64BL);
    fbBasicListClear(&all.stringBL);
    fbBasicListClear(&all.octetArrayBL);
    fbBasicListClear(&all.f64BL);
    fbBasicListClear(&all.ipv4BL);
    fbBasicListClear(&all.ipv6BL);

    all.sip++;
    all.sport++;
    all.dfc++;
    all.igmp++;

    protoPtr = fbBasicListInit(&(all.u8BL), 0,
              fbInfoModelGetElementByName(infoModel, "protocolIdentifier"), 2);
    *protoPtr = 21;
    protoPtr++;
    *protoPtr = 22;

    sectionPtr = (uint16_t*)fbBasicListInit(&(all.u16BL), 0,
        fbInfoModelGetElementByName(infoModel, "sectionOffset"), 2);
    *sectionPtr = 300;
    sectionPtr++;
    *sectionPtr = 301;

    samplingPtr = (uint32_t*)fbBasicListInit(&(all.u32BL), 0,
        fbInfoModelGetElementByName(infoModel, "samplingInterval"), 2);
    *samplingPtr = 2500;
    samplingPtr++;
    *samplingPtr = 3000;

    octetPtr = (uint64_t*)fbBasicListInit(&(all.u64BL), 0,
        fbInfoModelGetElementByName(infoModel, "octetDeltaCount"), 2);
    *octetPtr = 225;
    octetPtr++;
    *octetPtr = 235;

    stringPtr = (fbVarfield_t*)fbBasicListInit(&(all.stringBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "wlanSSID"),
                                         2);
    strcpy(first, "fifth");
    stringPtr->len = 5;
    stringPtr->buf = (uint8_t*)first;

    stringPtr++;
    strcpy(second, "sixthOne");
    stringPtr->len = 8;
    stringPtr->buf = (uint8_t*)second;

    octetArrayPtr = (fbVarfield_t*)fbBasicListInit(&(all.octetArrayBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "mplsTopLabelStackSection"),
                                         2);
    strcpy(first, "fifth");
    octetArrayPtr->len = 5;
    octetArrayPtr->buf = (uint8_t*)first;

    octetArrayPtr++;
    strcpy(second, "sixthOne");
    octetArrayPtr->len = 8;
    octetArrayPtr->buf = (uint8_t*)second;

    f64Ptr = (double*)fbBasicListInit(&(all.f64BL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "absoluteError"), 2);

    *f64Ptr = 1500;
    f64Ptr++;
    *f64Ptr = .15;

    dtSecPtr = (uint32_t*)fbBasicListInit(&(all.secBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartSeconds"), 2);

    *dtSecPtr = 27;
    dtSecPtr++;
    *dtSecPtr = 28;

    dtMilSecPtr = (uint64_t*)fbBasicListInit(&(all.milSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartMilliseconds"), 2);

    *dtMilSecPtr = 27000;
    dtMilSecPtr++;
    *dtMilSecPtr = 28000;

    dtMicSecPtr = (uint64_t*)fbBasicListInit(&(all.micSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartMicroseconds"), 2);

    *dtMicSecPtr = 27000000;
    dtMicSecPtr++;
    *dtMicSecPtr = 28000000;

    dtNanoSecPtr = (uint64_t*)fbBasicListInit(&(all.nanoSecBL), 0,
                                         fbInfoModelGetElementByName(infoModel,
                                                        "flowStartNanoseconds"), 2);

    *dtNanoSecPtr = 27000000000;
    dtNanoSecPtr++;
    *dtNanoSecPtr = 28000000000;

    dipPtr = (uint32_t*)fbBasicListInit(&(all.ipv4BL), 0,
                                          fbInfoModelGetElementByName(infoModel,
                                               "destinationIPv4Address"), 2);
    *dipPtr = 0x0a0a0a0a;
    dipPtr++;
    *dipPtr = 0x08080808;

    ipv6Ptr = (uint64_t*)fbBasicListInit(&(all.ipv6BL), 0,
                                          fbInfoModelGetElementByName(infoModel,
                                            "destinationIPv6Address"), 2);
    *ipv6Ptr = 0x55555555;
    ipv6Ptr++;
    *ipv6Ptr = 0x66666666;
    ipv6Ptr++;
    /* 2nd one */
    *ipv6Ptr = 0x77777777;
    ipv6Ptr++;
    *ipv6Ptr = 0x88888888;


    /* send the data records */
    if (rc) {
        fBufEmit(exporterBuf, &error);
        if (FALSE == rc) {
           fprintf(stderr,"err with sending record to exporter, %s\n",
           error->message);
           fBufFree(exporterBuf);
        }
    } else {
        printf("didn't send the second...%s\n", error->message);
    }

    if (socketOrFiles == MULTIPLE_FILES) {
        fBufFree(exporterBuf);
    }
}

    /* cleanup */
    if (socketOrFiles != MULTIPLE_FILES) {
        fbTemplateFreeUnused(allTmpl);
        fBufFree(exporterBuf);
    }
    fbInfoModelFree(infoModel);

    fbBasicListClear(&all.u8BL);
    fbBasicListClear(&all.u16BL);
    fbBasicListClear(&all.u32BL);
    fbBasicListClear(&all.u64BL);
    fbBasicListClear(&all.stringBL);
    fbBasicListClear(&all.octetArrayBL);
    fbBasicListClear(&all.f64BL);
    fbBasicListClear(&all.ipv4BL);
    fbBasicListClear(&all.ipv6BL);

    /** finished with no problems */
    return 0;
}
