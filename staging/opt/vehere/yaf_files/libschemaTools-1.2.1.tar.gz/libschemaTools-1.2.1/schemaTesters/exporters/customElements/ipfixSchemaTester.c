/**
 * @OPENSOURCE_HEADER_START@
 * Use of this (and related) source code is subject to the terms
 * of the following licenses:
 *
 * GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 *
 * NO WARRANTY
 *
 * ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 * PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 * PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 * "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 * LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 * MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 * OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 * SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 * TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 * WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 * LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 * CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 * CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 * DELIVERABLES UNDER THIS LICENSE.
 *
 * Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 * Mellon University, its trustees, officers, employees, and agents from
 * all claims or demands made against them (and any related losses,
 * expenses, or attorney's fees) arising out of, or relating to Licensee's
 * and/or its sub licensees' negligent use or willful misuse of or
 * negligent conduct or willful misconduct regarding the Software,
 * facilities, or other rights or assistance granted by Carnegie Mellon
 * University under this License, including, but not limited to, any
 * claims of product liability, personal injury, death, damage to
 * property, or violation of any laws or regulations.
 *
 * Carnegie Mellon University Software Engineering Institute authored
 * documents are sponsored by the U.S. Department of Defense under
 * Contract F19628-00-C-0003. Carnegie Mellon University retains
 * copyrights in all material produced under this contract. The U.S.
 * Government retains a non-exclusive, royalty-free license to publish or
 * reproduce these documents, or allow others to do so, for U.S.
 * Government purposes only pursuant to the copyright license under the
 * contract clause at 252.227.7013.
 *
 * @OPENSOURCE_HEADER_END@
 * -----------------------------------------------------------
 */

#include <fixbuf/public.h>

static char * md_eport = "18000";
static char * md_ehost = "localhost";

/* A template with sip, dip, sport and dport */
static fbInfoElementSpec_t  allTemplate[] = {
    {"sourceIPv4Address",                   0, 0 },
    {"destinationIPv4Address",              0, 0 },
    {"sourceTransportPort",                 0, 0 },
    {"destinationTransportPort",            0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for allTemplate */
typedef struct allVar_st {
    uint32_t        sip;
    uint32_t        dip;
    uint16_t        sport;
    uint16_t        dport;
} allVar_t;

/* template with sip, dip, and a custom string */
static fbInfoElementSpec_t  ipsTemplate[] = {
    {"sourceIPv4Address",                   0, 0 },
    {"destinationIPv4Address",              0, 0 },
    {"customUint64",                        0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for ipsTemplate */
typedef struct ipsVar_st {
    uint32_t        sip;
    uint32_t        dip;
    uint64_t        my64;
} ipsVar_t;

/* template with sport, dport, and a custom uint64 */
static fbInfoElementSpec_t  ptsTemplate[] = {
    {"sourceTransportPort",                 0, 0 },
    {"destinationTransportPort",            0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for ptsTemplate */
typedef struct ptsVar_st {
    uint16_t        sport;
    uint16_t        dport;
} ptsVar_t;

static fbInfoElement_t customElements[] = {
    FB_IE_INIT_FULL("customUint64", 9, 15, 8,
                    FB_IE_F_REVERSIBLE | FB_UNITS_FLOWS | FB_IE_DELTACOUNTER, 0, 8888888, FB_UINT_64, "A custom uint64 just to show we can handle it."),
    FB_IE_INIT_FULL("customString", 11, 22, FB_IE_VARLEN, FB_IE_F_NONE, 0, 0, FB_STRING, "A custom string just to show we can handle it"),
    FB_IE_NULL
};



#define FLUSHCOUNT 64
#define FILEFLUSH  10000
#define FLUSH_TIMEOUT 18000 /* 5 mins */
#define MAX_EXPORT 256

/**
 * prototypes
 */

GTimer * timer;

/**
 * main
 *
 *
 */
int
main (int argc, char *argv[])
{
    fbSession_t            *exporterSession;
    fbInfoModel_t          *infoModel;
    uint16_t                otid;
    struct fbConnSpec_st    eSocketDef;
    fBuf_t                 *exporterBuf;
    fbExporter_t           *exporter;
    /*fbExporter_t           *fileExporter;
    fBuf_t                 *fileFBuf;*/

    GError                 *error   = NULL;
    gboolean                rc;
    size_t                  length;
    fbTemplate_t           *otmpl;

    fbTemplate_t           *allTmpl;
    fbTemplate_t           *ipsTmpl;
    fbTemplate_t           *ptsTmpl;
    uint16_t                allID;
    uint16_t                ipsID;
    uint16_t                ptsID;
    allVar_t                all;
    ipsVar_t                ips;
    ptsVar_t                pts;
    int i;

    memset(&all, 0, sizeof(allVar_t));
    memset(&ips, 0, sizeof(ipsVar_t));
    memset(&pts, 0, sizeof(ptsVar_t));

    /* set up hardcoded connection to localhost 18000 */
    eSocketDef.transport = FB_TCP;
    eSocketDef.host = md_ehost;
    eSocketDef.svc = md_eport;
    eSocketDef.ssl_ca_file = NULL;
    eSocketDef.ssl_cert_file = NULL;
    eSocketDef.ssl_key_file = NULL;
    eSocketDef.ssl_key_pass = NULL;
    eSocketDef.vai = NULL;
    eSocketDef.vssl_ctx = NULL;

    /* allocate an info model which everything is built from */
    infoModel = fbInfoModelAlloc();

    /* create a session to add eventual templates to */
    exporterSession = fbSessionAlloc(infoModel);

    /* add the custom elements to the info model */
    fbInfoModelAddElementArray(infoModel, customElements);

    /* allocate template to export custom types (customString, customUint64) */
    otmpl = fbInfoElementAllocTypeTemplate(infoModel, &error);

    /* add template to session to receive a template ID for the types */
    otid = fbSessionAddTemplate(exporterSession, TRUE, FB_TID_AUTO,
                                otmpl, &error);

    /* Create a template for each defined above (all, ips, and ports)
       Add each template as external templates to the session to get IDs */ 
    allTmpl = fbTemplateAlloc(infoModel);
    fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);
    allID = fbSessionAddTemplate(exporterSession, TRUE, FB_TID_AUTO,
                                 allTmpl, &error);

    ipsTmpl = fbTemplateAlloc(infoModel);
    fbTemplateAppendSpecArray(ipsTmpl, ipsTemplate, 0xffffffff, &error);
    ipsID = fbSessionAddTemplate(exporterSession, TRUE, FB_TID_AUTO,
                                 ipsTmpl, &error);

    ptsTmpl = fbTemplateAlloc(infoModel);
    fbTemplateAppendSpecArray(ptsTmpl, ptsTemplate, 0xffffffff, &error);
    ptsID = fbSessionAddTemplate(exporterSession, TRUE, FB_TID_AUTO,
                                 ptsTmpl, &error);

    /* build an exporter and associated fbuf */
    exporter = fbExporterAllocNet(&eSocketDef);
    exporterBuf = fBufAllocForExport(exporterSession, exporter);

    /* add the custom type template as an internal template */
    fbSessionAddTemplate(exporterSession, FALSE, otid, otmpl, &error);

    /* set the custom type tempate as both internal and external templates */
    rc = fBufSetInternalTemplate(exporterBuf, otid, &error);
    rc = fBufSetExportTemplate(exporterBuf, otid, &error);

    /* export the custom types so the collecter understands them */
    fbInfoElementWriteOptionsRecord(exporterBuf, 
                        fbInfoModelGetElementByName(infoModel, "customUint64"), 
                        otid, &error);

    fbInfoElementWriteOptionsRecord(exporterBuf, 
                        fbInfoModelGetElementByName(infoModel, "customString"),
                        otid, &error);

    /* add the data templates as internal templates to the session */
    fbSessionAddTemplate(exporterSession, FALSE, allID, allTmpl, &error);
    fbSessionAddTemplate(exporterSession, FALSE, ipsID, ipsTmpl, &error);
    fbSessionAddTemplate(exporterSession, FALSE, ptsID, ptsTmpl, &error);

    /* set the internal and external templates to the all template
       to send data in that format */
    fBufSetInternalTemplate(exporterBuf, allID, &error);
    fBufSetExportTemplate(exporterBuf, allID, &error);

    for (i = 0; i < 10; i ++) {
    /* fill the data structure and send the record */
    all.sip   = 0x12345678;
    all.dip   = 0x567890ab;
    all.sport = 22;
    all.dport = 14;

    length = sizeof(allVar_t);
    rc = fBufAppend(exporterBuf, (uint8_t *)&all, length,
    &error);

    /* set the internal and external templates to the ips template
       to send data in that format */
    fBufSetInternalTemplate(exporterBuf, ipsID, &error);
    fBufSetExportTemplate(exporterBuf, ipsID, &error);

    /* fill the data structure and send the record */
    ips.sip   = 0x33334444;
    ips.dip   = 0x55556666;
    ips.my64 = 12345678;
/**/
    length = sizeof(ipsVar_t);
    rc = fBufAppend(exporterBuf, (uint8_t *)&ips, length,
    &error);

    /* set the internal and external templates to the pts template
       to send data in that format */
    fBufSetInternalTemplate(exporterBuf, ptsID, &error);
    fBufSetExportTemplate(exporterBuf, ptsID, &error);

    /* fill the data structure and send the record */
    pts.sport       = 2430;
    pts.dport       = 24;

    length = sizeof(ptsVar_t);
    rc = fBufAppend(exporterBuf, (uint8_t *)&pts, length,
    &error);

    /* send the data records */
    if (rc) {
        fBufEmit(exporterBuf, &error);
        if (FALSE == rc) {
           fprintf(stderr,"err with sending record to exporter, %s\n",
           error->message);
           fBufFree(exporterBuf);
        }
    } else {
        printf("didn't send the second...%s\n", error->message);
    }

    }

    /* cleanup */
    fbTemplateFreeUnused(allTmpl);
    fbTemplateFreeUnused(ipsTmpl);
    fbTemplateFreeUnused(ptsTmpl);
    fBufFree(exporterBuf);
    fbInfoModelFree(infoModel);

    /** finished with no problems */
    return 0;
}

/**
 * sigHandler
 *
 * this gets called from various system signal handlers.  It is used to
 * provide a way to exit this program cleanly when the user wants to
 * kill this program
 *
 * @param signalNumber the number of the signal that this handler is
 *        getting called for
 *
 */
void
sigHandler (int signalNumber)
{
    fprintf(stderr, "Received signal %d, time to die...\n", signalNumber);

    /** exit the system cleanly */
    exit(-1*signalNumber);
}
