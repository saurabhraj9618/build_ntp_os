/**
 * @OPENSOURCE_HEADER_START@
 * Use of this (and related) source code is subject to the terms
 * of the following licenses:
 *
 * GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 *
 * NO WARRANTY
 *
 * ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 * PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 * PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 * "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 * LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 * MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 * OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 * SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 * TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 * WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 * LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 * CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 * CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 * DELIVERABLES UNDER THIS LICENSE.
 *
 * Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 * Mellon University, its trustees, officers, employees, and agents from
 * all claims or demands made against them (and any related losses,
 * expenses, or attorney's fees) arising out of, or relating to Licensee's
 * and/or its sub licensees' negligent use or willful misuse of or
 * negligent conduct or willful misconduct regarding the Software,
 * facilities, or other rights or assistance granted by Carnegie Mellon
 * University under this License, including, but not limited to, any
 * claims of product liability, personal injury, death, damage to
 * property, or violation of any laws or regulations.
 *
 * Carnegie Mellon University Software Engineering Institute authored
 * documents are sponsored by the U.S. Department of Defense under
 * Contract F19628-00-C-0003. Carnegie Mellon University retains
 * copyrights in all material produced under this contract. The U.S.
 * Government retains a non-exclusive, royalty-free license to publish or
 * reproduce these documents, or allow others to do so, for U.S.
 * Government purposes only pursuant to the copyright license under the
 * contract clause at 252.227.7013.
 *
 * @OPENSOURCE_HEADER_END@
 * -----------------------------------------------------------
 */

#include <fixbuf/public.h>
#include "CERT_IE.h"

static char * md_ehost = "localhost";

/* A template with sip, dip, sport and dport */
static fbInfoElementSpec_t  allTemplate[] = {
    {"dnsQName",                            0, 0 },
    {"sourceIPv4Address",                   0, 0 },
    {"flowStartSeconds",                    0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for allTemplate */
typedef struct allVar_st {
    fbVarfield_t    dnsName;
    uint32_t        sip;
    uint32_t        timestamp;
} allVar_t;

#define FLUSHCOUNT 64
#define FILEFLUSH  10000
#define FLUSH_TIMEOUT 18000 /* 5 mins */
#define MAX_EXPORT 256

/**
 * prototypes
 */

GTimer * timer;

typedef enum sockOrFiles_en {
    SOCKET = 1,
    ONE_FILE,
    MULTIPLE_FILES
} sockOrFiles_t;

/**
 * main
 *
 *
 */
fBuf_t                 *exporterBuf;
fbExporter_t           *exporter;

GError                 *error   = NULL;

size_t                  length;
allVar_t                all;
char                   *stringBuf;

static int addTuple(
    uint32_t    ip,
    char       *dns)
{
    int rc;
    all.sip   = ip;
    memset(stringBuf, 0, 100);
    all.dnsName.len = snprintf(stringBuf, 100, "%s", dns);
    all.dnsName.buf = (uint8_t*)stringBuf;
    all.timestamp += 3600;

    length = sizeof(allVar_t);
    rc = fBufAppend(exporterBuf, (uint8_t *)&all, length, &error);
    return rc;
}
     
int main (int argc, char *argv[])
{
    fbSession_t            *exporterSession;
    fbInfoModel_t          *infoModel;
    struct fbConnSpec_st    eSocketDef;
    gboolean                rc;
    fbTemplate_t           *allTmpl;
    uint16_t                allID;
    int                     loopNum = 1;
    sockOrFiles_t           socketOrFiles;
    char                   *portOrDirString = NULL;

    stringBuf = calloc(1, 100);

    memset(&all, 0, sizeof(allVar_t));

    all.timestamp = 1234396800;
    if (argc != 4) {
        printf("./one... SOCKET loopNum portNumber/dir\n");
        return 1;
    }

    portOrDirString = argv[3];
    loopNum = atoi(argv[2]);
    if (strcmp(argv[1], "SOCKET") == 0) {
        socketOrFiles = SOCKET;
    } else {
        printf("Invalid arg 1\n");
        return 1;
    }

    infoModel = fbInfoModelAlloc();
    fbInfoModelAddElementArray(infoModel, yaf_info_elements);
    fbInfoModelAddElementArray(infoModel, yaf_dpi_info_elements);
    fbInfoModelAddElementArray(infoModel, yaf_dhcp_info_elements);

    /* add template to session to receive a template ID for the types */
    

    exporterSession = fbSessionAlloc(infoModel);

    allTmpl = fbTemplateAlloc(infoModel);
    fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);

        /* Create a template for each defined above (all, ips, and ports)
           Add each template as external templates to the session to get IDs */ 
    allID = fbSessionAddTemplate(exporterSession, TRUE, 2000,
                                 allTmpl, &error);

        /* add the data templates as internal templates to the session */
    fbSessionAddTemplate(exporterSession, FALSE, allID, allTmpl, &error);

    /* set up hardcoded connection to localhost 18000 */
    eSocketDef.transport = FB_TCP;
    eSocketDef.host = md_ehost;
    eSocketDef.svc = portOrDirString;
    eSocketDef.ssl_ca_file = NULL;
    eSocketDef.ssl_cert_file = NULL;
    eSocketDef.ssl_key_file = NULL;
    eSocketDef.ssl_key_pass = NULL;
    eSocketDef.vai = NULL;
    eSocketDef.vssl_ctx = NULL;

    exporter = fbExporterAllocNet(&eSocketDef);

    /*exporter = fbExporterAllocFile(portOrDirString);*/
    exporterBuf = fBufAllocForExport(exporterSession, exporter);
    

    fbSessionExportTemplates(exporterSession, &error);
    /* set the internal and external templates to the all template
       to send data in that format */

    fBufSetInternalTemplate(exporterBuf, allID, &error);
    fBufSetExportTemplate(exporterBuf, allID, &error);

    /*
     *  ! = www.google.com
     *  & = a.b.lebo.k12.pa.us
     *  # = .www.google.com
     *  $ = www.google.com.
     *  ^ = com
     *  * = .org
     *  - = sld.notASuffix.
     *  ( = pirates.com
     */
    rc = addTuple(1, "www.google.com");
    rc = addTuple(3, "a.b.lebo.k12.pa.us");
    rc = addTuple(4, ".www.google.com");
    rc = addTuple(4, "www.google.com");
    rc = addTuple(5, "www.g\\.oogle.com.");
    rc = addTuple(6, "com");
    rc = addTuple(7, "com");
    rc = addTuple(7, ".org");
    rc = addTuple(1, "sld.notASuffix.");
    rc = addTuple(11, "pirates.com");
    rc = addTuple(11, "sld.notASuffix.");
    rc = addTuple(2, ".org");

        /* send the data records */
    if (rc) {
        fBufEmit(exporterBuf, &error);
        if (FALSE == rc) {
           fprintf(stderr,"err with sending record to exporter, %s\n",
           error->message);
           fBufFree(exporterBuf);
        }
    } else {
        printf("didn't send the second...%s\n", error->message);
    }

    /* cleanup */
    fbTemplateFreeUnused(allTmpl);
    fBufFree(exporterBuf);
    fbInfoModelFree(infoModel);

    /** finished with no problems */
    return 0;
}
