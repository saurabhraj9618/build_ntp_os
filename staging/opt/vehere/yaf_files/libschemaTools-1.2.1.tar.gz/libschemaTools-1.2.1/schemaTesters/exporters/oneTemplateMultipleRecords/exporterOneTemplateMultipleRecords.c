/**
 * @OPENSOURCE_HEADER_START@
 * Use of this (and related) source code is subject to the terms
 * of the following licenses:
 *
 * GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 *
 * NO WARRANTY
 *
 * ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 * PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 * PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 * "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 * LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 * MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 * OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 * SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 * TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 * WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 * LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 * CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 * CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 * DELIVERABLES UNDER THIS LICENSE.
 *
 * Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 * Mellon University, its trustees, officers, employees, and agents from
 * all claims or demands made against them (and any related losses,
 * expenses, or attorney's fees) arising out of, or relating to Licensee's
 * and/or its sub licensees' negligent use or willful misuse of or
 * negligent conduct or willful misconduct regarding the Software,
 * facilities, or other rights or assistance granted by Carnegie Mellon
 * University under this License, including, but not limited to, any
 * claims of product liability, personal injury, death, damage to
 * property, or violation of any laws or regulations.
 *
 * Carnegie Mellon University Software Engineering Institute authored
 * documents are sponsored by the U.S. Department of Defense under
 * Contract F19628-00-C-0003. Carnegie Mellon University retains
 * copyrights in all material produced under this contract. The U.S.
 * Government retains a non-exclusive, royalty-free license to publish or
 * reproduce these documents, or allow others to do so, for U.S.
 * Government purposes only pursuant to the copyright license under the
 * contract clause at 252.227.7013.
 *
 * @OPENSOURCE_HEADER_END@
 * -----------------------------------------------------------
 */

#include <fixbuf/public.h>

static char * md_ehost = "localhost";

/* A template with sip, dip, sport and dport */
static fbInfoElementSpec_t  allTemplate[] = {
    {"interfaceName",                       0, 0 },
    {"sourceIPv4Address",                   0, 0 },
    {"destinationIPv4Address",              0, 0 },
    {"sourceTransportPort",                 0, 0 },
/*    {"destinationTransportPort",            0, 0 },*/
    {"flowActiveTimeout",                   0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for allTemplate */
typedef struct allVar_st {
    fbVarfield_t    varfield;
    uint32_t        sip;
    uint32_t        dip;
    uint16_t        sport;
    uint16_t        dport;
} allVar_t;

#define FLUSHCOUNT 64
#define FILEFLUSH  10000
#define FLUSH_TIMEOUT 18000 /* 5 mins */
#define MAX_EXPORT 256

/**
 * prototypes
 */

GTimer * timer;

typedef enum sockOrFiles_en {
    SOCKET = 1,
    ONE_FILE,
    MULTIPLE_FILES
} sockOrFiles_t;

/**
 * main
 *
 *
 */
int
main (int argc, char *argv[])
{
    fbSession_t            *exporterSession;
    fbInfoModel_t          *infoModel;
    struct fbConnSpec_st    eSocketDef;
    fBuf_t                 *exporterBuf;
    fbExporter_t           *exporter;

    GError                 *error   = NULL;
    gboolean                rc;
    size_t                  length;
    fbTemplate_t           *allTmpl;
    uint16_t                allID;
    allVar_t                all;
    int                     i;
    int                     loopNum = 1;
    sockOrFiles_t           socketOrFiles;
    char                    fileName[100];
    char                   *portOrDirString = NULL;
    char                   *stringBuf;

    stringBuf = calloc(1, 100);

    memset(&all, 0, sizeof(allVar_t));

    if (argc != 4) {
        printf("./one... SOCKET/FILES loopNum [port number]\n");
        return 1;
    }

    portOrDirString = argv[3];
    loopNum = atoi(argv[2]);
    if (strcmp(argv[1], "SOCKET") == 0) {
        socketOrFiles = SOCKET;
    } else if (strcmp(argv[1], "FILES") == 0) {
        socketOrFiles = MULTIPLE_FILES;
    } else if (strcmp(argv[1], "ONE_FILE") == 0) {
        socketOrFiles = ONE_FILE;
    } else {
        printf("Invalid arg 1\n");
        return 1;
    }

    infoModel = fbInfoModelAlloc();
    if (socketOrFiles != MULTIPLE_FILES) {
        /* allocate an info model which everything is built from */

        /* create a session to add eventual templates to */
        exporterSession = fbSessionAlloc(infoModel);
        allTmpl = fbTemplateAlloc(infoModel);
        fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);

        /* Create a template for each defined above (all, ips, and ports)
           Add each template as external templates to the session to get IDs */ 
        allID = fbSessionAddTemplate(exporterSession, TRUE, 1982,
                                 allTmpl, &error);

        /* add the data templates as internal templates to the session */
        fbSessionAddTemplate(exporterSession, FALSE, allID, allTmpl, &error);
    }
    if (socketOrFiles == SOCKET) {
        /* set up hardcoded connection to localhost 18000 */
        eSocketDef.transport = FB_TCP;
        eSocketDef.host = md_ehost;
        eSocketDef.svc = portOrDirString;
        eSocketDef.ssl_ca_file = NULL;
        eSocketDef.ssl_cert_file = NULL;
        eSocketDef.ssl_key_file = NULL;
        eSocketDef.ssl_key_pass = NULL;
        eSocketDef.vai = NULL;
        eSocketDef.vssl_ctx = NULL;

        exporter = fbExporterAllocNet(&eSocketDef);
        exporterBuf = fBufAllocForExport(exporterSession, exporter);
        fbSessionExportTemplates(exporterSession, &error);
    } else if (socketOrFiles == ONE_FILE) {
        memset(fileName, 0, 100);
        snprintf(fileName, 100, "%s/ONE.ipfix", portOrDirString);
        exporter = fbExporterAllocFile(fileName);
        exporterBuf = fBufAllocForExport(exporterSession, exporter);
        if (!exporterBuf) {
            printf("Couldn't alloc fbuf for ONE_FILE\n");
            return 1;
        }
        fbSessionExportTemplates(exporterSession, &error);
    }

    /* set the internal and external templates to the all template
       to send data in that format */

    all.sip   = 0x12340000;
    all.dip   = 0x56780000;
    all.sport = 10;
    all.dport = 100;

    memset(stringBuf, 0, 100);
    all.varfield.len = snprintf(stringBuf, 100, "myString%02d", 0);
    all.varfield.buf = (uint8_t*)stringBuf;

    for (i = 0; i < loopNum; i ++) {
        if (socketOrFiles == MULTIPLE_FILES) {
            exporterSession = fbSessionAlloc(infoModel); 

            allTmpl = fbTemplateAlloc(infoModel);
            fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);
            /* Create a template for each defined above (all, ips, and ports)
            Add each template as external templates to the session to get IDs */
            allID = fbSessionAddTemplate(exporterSession, TRUE, 1982,
                                 allTmpl, &error);

            /* add the data templates as internal templates to the session */
            fbSessionAddTemplate(exporterSession, FALSE, allID, allTmpl, &error);

            memset(fileName, 0, 100);
            snprintf(fileName, 100, "%s/ONE%02d.ipfix", portOrDirString, i);
            exporter = fbExporterAllocFile(fileName);
            exporterBuf = fBufAllocForExport(exporterSession, exporter);
            if (!exporterBuf) {
                printf("no exporter buf\n");
                return 1;
            }
            fbSessionExportTemplates(exporterSession, &error);     
        }

        fBufSetInternalTemplate(exporterBuf, allID, &error);
        fBufSetExportTemplate(exporterBuf, allID, &error);

        /* fill the data structure and send the record */
        length = sizeof(allVar_t);
        rc = fBufAppend(exporterBuf, (uint8_t *)&all, length,
        &error);

        all.sip++;
        all.dip++;
        all.sport++;
        all.dport++;
        
        memset(stringBuf, 0, 100);
        all.varfield.len = snprintf(stringBuf, 100, "myString%02d", i);
        all.varfield.buf = (uint8_t*)stringBuf;

        length = sizeof(allVar_t);
        rc = fBufAppend(exporterBuf, (uint8_t *)&all, length,
        &error);

        all.sip++;
        all.dip++;
        all.sport++;
        all.dport++;

        /* send the data records */
        if (rc) {
            fBufEmit(exporterBuf, &error);
            if (FALSE == rc) {
               fprintf(stderr,"err with sending record to exporter, %s\n",
               error->message);
               fBufFree(exporterBuf);
            }
        } else {
            printf("didn't send the second...%s\n", error->message);
        }

        if (socketOrFiles == MULTIPLE_FILES) {
            fBufFree(exporterBuf);
        }
    }

    /* cleanup */
    if (socketOrFiles != MULTIPLE_FILES) {
        fbTemplateFreeUnused(allTmpl);
        fBufFree(exporterBuf);
    }
    fbInfoModelFree(infoModel);

    /** finished with no problems */
    return 0;
}
