/**
 * @OPENSOURCE_HEADER_START@
 * Use of this (and related) source code is subject to the terms
 * of the following licenses:
 *
 * GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 *
 * NO WARRANTY
 *
 * ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 * PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 * PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 * "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 * LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 * MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 * OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 * SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 * TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 * WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 * LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 * CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 * CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 * DELIVERABLES UNDER THIS LICENSE.
 *
 * Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 * Mellon University, its trustees, officers, employees, and agents from
 * all claims or demands made against them (and any related losses,
 * expenses, or attorney's fees) arising out of, or relating to Licensee's
 * and/or its sub licensees' negligent use or willful misuse of or
 * negligent conduct or willful misconduct regarding the Software,
 * facilities, or other rights or assistance granted by Carnegie Mellon
 * University under this License, including, but not limited to, any
 * claims of product liability, personal injury, death, damage to
 * property, or violation of any laws or regulations.
 *
 * Carnegie Mellon University Software Engineering Institute authored
 * documents are sponsored by the U.S. Department of Defense under
 * Contract F19628-00-C-0003. Carnegie Mellon University retains
 * copyrights in all material produced under this contract. The U.S.
 * Government retains a non-exclusive, royalty-free license to publish or
 * reproduce these documents, or allow others to do so, for U.S.
 * Government purposes only pursuant to the copyright license under the
 * contract clause at 252.227.7013.
 *
 * @OPENSOURCE_HEADER_END@
 * -----------------------------------------------------------
 */

#include <fixbuf/public.h>

static char * md_ehost = "localhost";

static fbInfoElementSpec_t  allTemplate[] = {
    {"mplsTopLabelStackSection",        0, 0 }, /* OCTET_ARRAY  0, 70 */
    {"mplsTopLabelStackSection",        0, 0 }, /* OCTET_ARRAY  0, 70 */
    {"interfaceName",                   0, 0 }, /* STRING:      0, 82 */
    {"interfaceName",                   0, 0 }, /* STRING:      0, 82 */
    {"interfaceDescription",            0, 0 }, /* TUPLE STRING */
    {"octetTotalCount",                 0, 0 }, /* TUPLE 64 */
    {"destinationTransportPort",        0, 0 }, /* UNSIGNED 16: 0, 11 */
    {"destinationTransportPort",        0, 0 }, /* UNSIGNED 16: 0, 11 */
    {"destinationTransportPort",        0, 0 }, /* UNSIGNED 16: 0, 11 */
    {"sourceTransportPort",             0, 0 }, /* TUPLE 16 */
    {"protocolIdentifier",              0, 0 }, /* UNSIGNED 8:  0, 4  */
    {"protocolIdentifier",              0, 0 }, /* UNSIGNED 8:  0, 4  */
    {"protocolIdentifier",              0, 0 }, /* UNSIGNED 8:  0, 4  */
    {"igmpType",                        0, 0 }, /* TUPLE 8 */
    {"sourceIPv4Address",               0, 0 }, /* TUPLE 32 */
    {"ingressInterface",                0, 0 }, /* UNSIGNED 32: 0, 10 */
    {"ingressInterface",                0, 0 }, /* UNSIGNED 32: 0, 10 */
    {"octetDeltaCount",                 0, 0 }, /* UNSIGNED 64: 0, 1  */
    {"octetDeltaCount",                 0, 0 }, /* UNSIGNED 64: 0, 1  */
    {"absoluteError",                   0, 0 }, /* FLOAT_64:    0, 320 */
    {"absoluteError",                   0, 0 }, /* FLOAT_64:    0, 320 */
    {"flowStartSeconds",                0, 0 }, /* DT SECONDS   0, 150 */
    {"flowStartSeconds",                0, 0 }, /* DT SECONDS   0, 150 */
    {"flowStartMilliseconds",           0, 0 }, /* DT MILLI     0, 152 */
    {"flowStartMilliseconds",           0, 0 }, /* DT MILLI     0, 152 */
    {"flowStartMicroseconds",           0, 0 }, /* DT MICRO     0, 154 */
    {"flowStartMicroseconds",           0, 0 }, /* DT MICRO     0, 154 */
    {"flowStartNanoseconds",            0, 0 }, /* DT NANO      0, 156 */
    {"flowStartNanoseconds",            0, 0 }, /* DT NANO      0, 156 */
    {"destinationIPv4Address",          0, 0 }, /* IPV4         0, 12 */
    {"destinationIPv4Address",          0, 0 }, /* IPV4         0, 12 */
    {"sourceIPv6Address",               0, 0 }, /* IPV6         0, 27 */
    {"sourceIPv6Address",               0, 0 }, /* IPV6         0, 27 */
    FB_IESPEC_NULL
};

/* associated struct for allTemplate */
typedef struct allVar_st {
    fbVarfield_t    octet1;
    fbVarfield_t    octet2;
    fbVarfield_t    string1;
    fbVarfield_t    string2;
    fbVarfield_t    interfaceDescription;
    uint64_t        octets;
    uint16_t        dport1;
    uint16_t        dport2;
    uint16_t        dport3;
    uint16_t        sport;
    uint8_t         proto1;
    uint8_t         proto2;
    uint8_t         proto3;
    uint8_t         igmpType;
    uint32_t        sip;
    uint32_t        u32_1;
    uint32_t        u32_2;
    uint64_t        u64_1;
    uint64_t        u64_2;
    double          dbl1;
    double          dbl2;
    uint32_t        dt_sec1;
    uint32_t        dt_sec2;
    uint64_t        dt_milli1;
    uint64_t        dt_milli2;
    uint64_t        dt_micro1;
    uint64_t        dt_micro2;
    uint64_t        dt_nano1;
    uint64_t        dt_nano2;
    uint32_t        dip1;
    uint32_t        dip2;
    uint8_t         ipv6_1[16];
    uint8_t         ipv6_2[16];
} allVar_t;

#define FLUSHCOUNT 64
#define FILEFLUSH  10000
#define FLUSH_TIMEOUT 18000 /* 5 mins */
#define MAX_EXPORT 256

/**
 * prototypes
 */

GTimer * timer;

typedef enum sockOrFiles_en {
    SOCKET = 1,
    ONE_FILE,
    MULTIPLE_FILES
} sockOrFiles_t;

/**
 * main
 *
 *
 */
int
main (int argc, char *argv[])
{
    fbSession_t            *exporterSession;
    fbInfoModel_t          *infoModel;
    struct fbConnSpec_st    eSocketDef;
    fBuf_t                 *exporterBuf;
    fbExporter_t           *exporter;

    GError                 *error   = NULL;
    gboolean                rc;
    size_t                  length;
    fbTemplate_t           *allTmpl;
    uint16_t                allID;
    allVar_t                all;
    int                     i;
    int                     loopNum = 1;
    sockOrFiles_t           socketOrFiles;
    char                    fileName[100];
    char                   *portOrDirString = NULL;
    uint32_t                twos = 0x22222222;
    uint32_t                fours = 0x44444444;

    memset(&all, 0, sizeof(allVar_t));

    if (argc != 4) {
        printf("./one... SOCKET/FILES loopNum portNumber/dir\n");
        return 1;
    }

    portOrDirString = argv[3];
    loopNum = atoi(argv[2]);
    if (strcmp(argv[1], "SOCKET") == 0) {
        socketOrFiles = SOCKET;
    } else if (strcmp(argv[1], "FILES") == 0) {
        socketOrFiles = MULTIPLE_FILES;
    } else if (strcmp(argv[1], "ONE_FILE") == 0) {
        socketOrFiles = ONE_FILE;
    } else {
        printf("Invalid arg 1\n");
        return 1;
    }

    infoModel = fbInfoModelAlloc();
    if (socketOrFiles != MULTIPLE_FILES) {
        /* allocate an info model which everything is built from */

        /* create a session to add eventual templates to */
        exporterSession = fbSessionAlloc(infoModel);
        allTmpl = fbTemplateAlloc(infoModel);
        fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);

        /* Create a template for each defined above (all, ips, and ports)
           Add each template as external templates to the session to get IDs */ 
        allID = fbSessionAddTemplate(exporterSession, TRUE, 1982,
                                 allTmpl, &error);

        /* add the data templates as internal templates to the session */
        if (!fbSessionAddTemplate(exporterSession, FALSE, allID, allTmpl, &error)) {
            printf("Couldn't add external template %d, %s\n", allID, error->message);
        }
    }
    if (socketOrFiles == SOCKET) {
        /* set up hardcoded connection to localhost 18000 */
        eSocketDef.transport = FB_TCP;
        eSocketDef.host = md_ehost;
        eSocketDef.svc = portOrDirString;
        eSocketDef.ssl_ca_file = NULL;
        eSocketDef.ssl_cert_file = NULL;
        eSocketDef.ssl_key_file = NULL;
        eSocketDef.ssl_key_pass = NULL;
        eSocketDef.vai = NULL;
        eSocketDef.vssl_ctx = NULL;

        exporter = fbExporterAllocNet(&eSocketDef);
        exporterBuf = fBufAllocForExport(exporterSession, exporter);
        fbSessionExportTemplates(exporterSession, &error);
    } else if (socketOrFiles == ONE_FILE) {
        memset(fileName, 0, 100);
        snprintf(fileName, 100, "%s/REPEAT.ipfix", portOrDirString);
        exporter = fbExporterAllocFile(fileName);
        exporterBuf = fBufAllocForExport(exporterSession, exporter);
        if (!exporterBuf) {
            printf("Couldn't alloc fbuf for ONE_FILE\n");
            return 1;
        }
        fbSessionExportTemplates(exporterSession, &error);
    }

    /* set the internal and external templates to the all template
       to send data in that format */

    all.octet1.len = 4;
    all.octet1.buf = (uint8_t*)&twos;
    all.octet2.len = 4;
    all.octet2.buf = (uint8_t*)&fours;

    all.string1.len = strlen ("dan");
    all.string1.buf = (uint8_t*)strdup("dan");
    all.string2.len = strlen ("da2");
    all.string2.buf = (uint8_t*)strdup("da2");

    all.interfaceDescription.len = strlen("boosh");
    all.interfaceDescription.buf = (uint8_t*)strdup("boosh");

    all.octets = 90909090;

    all.dport1  = 1;
    all.dport2  = 101;
    all.dport3  = 201;
    
    all.sport   = 999;

    all.proto1  = 2;
    all.proto2  = 102;
    all.proto3  = 202;

    all.igmpType    = 9;

    all.sip         = 0x90909090;
    
    all.u32_1       = 3;    
    all.u32_2       = 103;

    all.u64_1       = 4;
    all.u64_2       = 104;

    all.dbl1        = 5.5;
    all.dbl2        = 105.105;
    
    all.dt_sec1     = 6;
    all.dt_sec2     = 106;

    all.dt_milli1   = 7;
    all.dt_milli2   = 107;

    all.dt_micro1   = 8;
    all.dt_micro2   = 108;

    all.dt_nano1    = 9;
    all.dt_nano2    = 109;

    all.dip1        = 15;
    all.dip2        = 101;
    
    memset(all.ipv6_1, 11, 16);
    memset(all.ipv6_2, 111, 16);

    for (i = 0; i < loopNum; i ++) {
        sleep(2);
        if (socketOrFiles == MULTIPLE_FILES) {
            exporterSession = fbSessionAlloc(infoModel); 

            allTmpl = fbTemplateAlloc(infoModel);
            fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);
            /* Create a template for each defined above (all, ips, and ports)
            Add each template as external templates to the session to get IDs */
            allID = fbSessionAddTemplate(exporterSession, TRUE, 1982,
                                 allTmpl, &error);

            /* add the data templates as internal templates to the session */
            fbSessionAddTemplate(exporterSession, FALSE, allID, allTmpl, &error);

            memset(fileName, 0, 100);
            snprintf(fileName, 100, "%s/REPEAT%02d.ipfix", portOrDirString, i);
            exporter = fbExporterAllocFile(fileName);
            exporterBuf = fBufAllocForExport(exporterSession, exporter);
            if (!exporterBuf) {
                printf("no exporter buf\n");
                return 1;
            }
            fbSessionExportTemplates(exporterSession, &error);     
        }

        if (!fBufSetInternalTemplate(exporterBuf, allID, &error)) {
            printf("couldn't set internal template to %d, %s\n", allID, error->message);
        }
        fBufSetExportTemplate(exporterBuf, allID, &error);

        /* fill the data structure and send the record */
        length = sizeof(allVar_t);
        rc = fBufAppend(exporterBuf, (uint8_t *)&all, length,
        &error);

        /* change the stuff here */
        all.string2.buf[2]++;
        all.octet2.buf[3]++;
        all.dport2++;
        all.dport3++;

        all.proto2++;
        all.proto3++;

        all.u32_2++;
    
        all.u64_2++;
    
        all.dbl2++;
    
        all.dt_sec2++;
    
        all.dt_milli2++;
    
        all.dt_micro2++;
    
        all.dt_nano2++;
        all.dip2++;
        
        all.ipv6_2[0]++;

        /* send the data records */
        if (rc) {
            fBufEmit(exporterBuf, &error);
            if (FALSE == rc) {
               fprintf(stderr,"err with sending record to exporter, %s\n",
               error->message);
               fBufFree(exporterBuf);
            }
        } else {
            printf("didn't send the second...%s\n", error->message);
        }

        if (socketOrFiles == MULTIPLE_FILES) {
            fBufFree(exporterBuf);
        }
    }

    /* cleanup */
    if (socketOrFiles != MULTIPLE_FILES) {
        fbTemplateFreeUnused(allTmpl);
        fBufFree(exporterBuf);
    }
    fbInfoModelFree(infoModel);

    /** finished with no problems */
    return 0;
}
