/**
 * @OPENSOURCE_HEADER_START@
 * Use of this (and related) source code is subject to the terms
 * of the following licenses:
 *
 * GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 *
 * NO WARRANTY
 *
 * ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 * PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 * PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 * "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 * KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 * LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 * MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 * OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 * SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 * TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 * WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 * LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 * CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 * CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 * DELIVERABLES UNDER THIS LICENSE.
 *
 * Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 * Mellon University, its trustees, officers, employees, and agents from
 * all claims or demands made against them (and any related losses,
 * expenses, or attorney's fees) arising out of, or relating to Licensee's
 * and/or its sub licensees' negligent use or willful misuse of or
 * negligent conduct or willful misconduct regarding the Software,
 * facilities, or other rights or assistance granted by Carnegie Mellon
 * University under this License, including, but not limited to, any
 * claims of product liability, personal injury, death, damage to
 * property, or violation of any laws or regulations.
 *
 * Carnegie Mellon University Software Engineering Institute authored
 * documents are sponsored by the U.S. Department of Defense under
 * Contract F19628-00-C-0003. Carnegie Mellon University retains
 * copyrights in all material produced under this contract. The U.S.
 * Government retains a non-exclusive, royalty-free license to publish or
 * reproduce these documents, or allow others to do so, for U.S.
 * Government purposes only pursuant to the copyright license under the
 * contract clause at 252.227.7013.
 *
 * @OPENSOURCE_HEADER_END@
 * -----------------------------------------------------------
 */

#include <fixbuf/public.h>

static char * md_ehost = "localhost";

/* A template with sip, dip, sport and dport */
static fbInfoElementSpec_t  allTemplate[] = {
    {"interfaceName",                       0, 0 },
    {"sourceIPv4Address",                   0, 0 },
    {"destinationIPv4Address",              0, 0 },
    {"sourceTransportPort",                 0, 0 },
    {"destinationTransportPort",            0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for allTemplate */
typedef struct allVar_st {
    fbVarfield_t    varfield;
    uint32_t        sip;
    uint32_t        dip;
    uint16_t        sport;
    uint16_t        dport;
} allVar_t;

/* template with sip, dip, and a custom string */
static fbInfoElementSpec_t  ipsTemplate[] = {
    {"sourceIPv4Address",                   0, 0 },
    {"destinationIPv4Address",              0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for ipsTemplate */
typedef struct ipsVar_st {
    uint32_t        sip;
    uint32_t        dip;
} ipsVar_t;

/* template with sport, dport, and a custom uint64 */
static fbInfoElementSpec_t  ptsTemplate[] = {
    {"sourceTransportPort",                 0, 0 },
    {"destinationTransportPort",            0, 0 },
    FB_IESPEC_NULL
};

/* associated struct for ptsTemplate */
typedef struct ptsVar_st {
    uint16_t        sport;
    uint16_t        dport;
} ptsVar_t;

#define FLUSHCOUNT 64
#define FILEFLUSH  10000
#define FLUSH_TIMEOUT 18000 /* 5 mins */
#define MAX_EXPORT 256

/**
 * prototypes
 */

GTimer * timer;

typedef enum sockOrFiles_en {
    SOCKET = 1,
    ONE_FILE,
    MULTIPLE_FILES
} sockOrFiles_t;


/**
 * main
 *
 *
 */
int
main (int argc, char *argv[])
{
    fbSession_t            *exporterSession;
    fbInfoModel_t          *infoModel;
    struct fbConnSpec_st    eSocketDef;
    fBuf_t                 *exporterBuf;
    fbExporter_t           *exporter;

    GError                 *error   = NULL;
    gboolean                rc;
    size_t                  length;

    fbTemplate_t           *allTmpl;
    fbTemplate_t           *ipsTmpl;
    fbTemplate_t           *ptsTmpl;
    uint16_t                allIDExt;
    uint16_t                allIDInt;
    uint16_t                ipsIDExt;
    uint16_t                ptsIDExt;
    uint16_t                ipsIDInt;
    uint16_t                ptsIDInt;
    allVar_t                all;
    ipsVar_t                ips;
    ptsVar_t                pts;
    int                     i;
    int                     loopNum = 1;
    sockOrFiles_t           socketOrFiles;
    char                    fileName[100];
    int                     didOne = 0;
    char                   *stringBuf = NULL;
    char                   *portOrDirString = NULL;

    stringBuf = calloc(1, 100);

    memset(&all, 0, sizeof(allVar_t));
    memset(&ips, 0, sizeof(ipsVar_t));
    memset(&pts, 0, sizeof(ptsVar_t));

    if (argc != 4) {
        printf("./same... SOCKET/FILES loopNum portNumber/dir\n");
        return 1;
    }

    portOrDirString = argv[3];
    loopNum = atoi(argv[2]);
    if (strcmp(argv[1], "SOCKET") == 0) {
        socketOrFiles = SOCKET;
    } else if (strcmp(argv[1], "FILES") == 0) {
        socketOrFiles = MULTIPLE_FILES;
    } else if (strcmp(argv[1], "ONE_FILE") == 0) {
        socketOrFiles = ONE_FILE;
    } else {
        printf("Invalid arg 1\n");
        return 1;
    }

    infoModel = fbInfoModelAlloc();
    if (socketOrFiles != MULTIPLE_FILES) {
        /* allocate an info model which everything is built from */

        /* create a session to add eventual templates to */
        exporterSession = fbSessionAlloc(infoModel);
    }

    if (socketOrFiles == SOCKET) {
        /* set up hardcoded connection to localhost 18000 */
        eSocketDef.transport = FB_TCP;
        eSocketDef.host = md_ehost;
        eSocketDef.svc = portOrDirString;
        eSocketDef.ssl_ca_file = NULL;
        eSocketDef.ssl_cert_file = NULL;
        eSocketDef.ssl_key_file = NULL;
        eSocketDef.ssl_key_pass = NULL;
        eSocketDef.vai = NULL;
        eSocketDef.vssl_ctx = NULL;

        exporter = fbExporterAllocNet(&eSocketDef);
        exporterBuf = fBufAllocForExport(exporterSession, exporter);
        if (!exporterBuf) {
            printf("couldn't create exporter buf\n");
            return 0;
        }
        if (!fbSessionExportTemplates(exporterSession, &error)) {
            printf("couldn't export templates. Probably no listener\n");
            return 0;
        }
    } else if (socketOrFiles == ONE_FILE) {
        memset(fileName, 0, 100);
        snprintf(fileName, 100, "%s/SAME.ipfix", portOrDirString);
        exporter = fbExporterAllocFile(fileName);
        exporterBuf = fBufAllocForExport(exporterSession, exporter);
        if (!exporterBuf) {
            printf("Couldn't alloc fbuf for ONE_FILE\n");
            return 1;
        }
    }


    all.sip   = 0x12340000;
    all.dip   = 0x56780000;
    all.sport = 10;
    all.dport = 100;

    memset(stringBuf, 0, 100);
    all.varfield.len = snprintf(stringBuf, 100, "myString%02d", 0);
    all.varfield.buf = (uint8_t*)stringBuf;

    ips.sip   = 0x33330000;
    ips.dip   = 0x55550000;

    pts.sport       = 2400;
    pts.dport       = 20;

    for (i = 0; i < loopNum; i ++) {
        if (socketOrFiles == MULTIPLE_FILES) {
            exporterSession = fbSessionAlloc(infoModel);

            memset(fileName, 0, 100);
            snprintf(fileName, 100, "%s/SAME%02d.ipfix", portOrDirString, i);
            exporter = fbExporterAllocFile(fileName);
            exporterBuf = fBufAllocForExport(exporterSession, exporter);
            if (!exporterBuf) {
                printf("no exporter buf\n");
                return 1;
            }
        }

        allTmpl = fbTemplateAlloc(infoModel);
        fbTemplateAppendSpecArray(allTmpl, allTemplate, 0xffffffff, &error);

        ipsTmpl = fbTemplateAlloc(infoModel);
        fbTemplateAppendSpecArray(ipsTmpl, ipsTemplate, 0xffffffff, &error);

        ptsTmpl = fbTemplateAlloc(infoModel);
        fbTemplateAppendSpecArray(ptsTmpl, ptsTemplate, 0xffffffff, &error);

        allIDInt = fbSessionAddTemplate(exporterSession, TRUE, 1982, 
                                        allTmpl, &error);

        allIDExt = fbSessionAddTemplate(exporterSession, FALSE, 1982, 
                                        allTmpl, &error);


        if (!fBufSetInternalTemplate(exporterBuf, allIDInt, &error)) {
            printf("Couldn't set allIDS internal %s\n", error->message);
        }
        if (!fBufSetExportTemplate(exporterBuf, allIDExt, &error)) {
            printf("Couldn't set allIDS internal %s\n", error->message);
        }

        /* fill the data structure and send the record */
        length = sizeof(allVar_t);
        rc = fBufAppend(exporterBuf, (uint8_t *)&all, length, &error);

        all.sip++;
        all.dip++;
        all.sport++;
        all.dport++;

        memset(stringBuf, 0, 100);
        all.varfield.len = snprintf(stringBuf, 100, "myString%02d", i);
        all.varfield.buf = (uint8_t*)stringBuf;

        /* set the internal and external templates to the ips template
           to send data in that format */

        ipsIDInt = fbSessionAddTemplate(exporterSession, TRUE, 1982,
                                            ipsTmpl, &error);
        if (!ipsIDInt) {
            printf("Couldn't add internal IPS %s\n", error->message);
            return 0;
        }

        ipsIDExt = fbSessionAddTemplate(exporterSession, FALSE, 1982, 
                                            ipsTmpl, &error);
        if (!ipsIDExt) {
            printf("Couldn't add external IPS %s\n", error->message);
            return 0;
        }

        if (!fBufSetInternalTemplate(exporterBuf, ipsIDInt, &error)) {
            printf("Couldn't set ipsIDS internal %s\n", error->message);
        }
        if (!fBufSetExportTemplate(exporterBuf, ipsIDExt, &error)) {
            printf("Couldn't set ipsIDS external %s\n", error->message);
        } 

        length = sizeof(ipsVar_t);
        rc = fBufAppend(exporterBuf, (uint8_t *)&ips, length, &error);
        if (!rc) {
            printf("Couldn't fbuf append %s\n", error->message);
        }

        ips.sip++;
        ips.dip++;

        /* set the internal and external templates to the pts template
           to send data in that format */

        ptsIDInt = fbSessionAddTemplate(exporterSession, TRUE, 1982,
                                        ptsTmpl, &error);

        ptsIDExt = fbSessionAddTemplate(exporterSession, FALSE, 1982, 
                                        ptsTmpl, &error);

        if (!fBufSetInternalTemplate(exporterBuf, ptsIDInt, &error)) {
            printf("Couldn't set ports internal %s\n", error->message);
            return 0;
        }

        if (!fBufSetExportTemplate(exporterBuf, ptsIDExt, &error)) {
            printf("Couldn't set ports external %s\n", error->message);
            return 0;
        }
        /* fill the data structure and send the record */

        length = sizeof(ptsVar_t);
        rc = fBufAppend(exporterBuf, (uint8_t *)&pts, length,
        &error);

        pts.sport++;
        pts.dport++;

        /* send the data records */
        if (rc) {
            fBufEmit(exporterBuf, &error);
            if (FALSE == rc) {
               fprintf(stderr,"err with sending record to exporter, %s\n",
               error->message);
               fBufFree(exporterBuf);
            }
        } else {
            printf("didn't send the second...%s\n", error->message);
        }

        if (socketOrFiles == MULTIPLE_FILES) {
            fBufFree(exporterBuf);
        }

        didOne = 1;
    }

    /* cleanup */
    if (socketOrFiles != MULTIPLE_FILES) {
        fBufFree(exporterBuf);
/*        fbTemplateFreeUnused(allTmpl);
        fbTemplateFreeUnused(ipsTmpl);
        fbTemplateFreeUnused(ptsTmpl);*/
    }

    fbInfoModelFree(infoModel);

    free(stringBuf);

    /** finished with no problems */
    return 0;
}
