#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <schemaTools/schemaTools.h>
#include "testSchemaForSample.h"
#include <fixbuf/public.h>

int main(int argc, char **argv)
{
    scDataInfo_t           *inDataInfo  = NULL;
    scDataInfo_t           *outDataInfo = NULL;
    void                   *inRwStream  = NULL;
    int                     inRv;
    int                     rv;
    uint8_t                *inRec;
    uint8_t                *outRec;
    scSchema_t             *inSchema;
    scSchema_t             *outSchema;
    scSchema_t             *schemaUsed = NULL;;
    scInfoElement_t        *hits;
    scInfoElement_t        *abs;
    scInfoElement_t        *runs;
    scInfoElement_t        *rbis;
    scInfoElement_t        *average;
    scInfoElement_t        *runsCreated;
    uint16_t                hval;
    uint32_t                abval;
    uint8_t                 runVal;
    int16_t                 rbiVal;
    double                  averageVal;
    uint32_t                rcVal;
    scSchemaFreeRecord_fn   secFreeInRec;
    scSchemaFreeRecord_fn   secFreeOutRec;

    /* this module takes a schema of baseball stats, and converts:
       runs and rbis to runsCreated
       hits and atBats to average
       and copies those to the outgoing record 
    */
    
    /* request schema information */
    if (getSampleDataInfoAlloc(&inDataInfo, &outDataInfo)) {
        printf("couldn't get sample data info...wtf\n");
        return 0;
    }

    /* get the incoming and outgoing schemas, we know there's only one */   
    inSchema = scDataInfoGetFirstSchema(inDataInfo); 
    outSchema = scDataInfoGetFirstSchema(outDataInfo);

    /* get the specific IEs we're interested in */
    hits = scSchemaGetIEByID(inSchema, MY_STATS_PEN, 4);
    abs = scSchemaGetIEByID(inSchema, MY_STATS_PEN, 5);
    runs = scSchemaGetIEByID(inSchema, MY_STATS_PEN, 6);
    rbis = scSchemaGetIEByID(inSchema, MY_STATS_PEN, 8);
    average = scSchemaGetIEByID(outSchema, MY_STATS_PEN, 9);
    runsCreated = scSchemaGetIEByID(outSchema, MY_STATS_PEN, 10);

    /* allocated a new record according to each schema size */
    inRec = scSchemaNewRecord(inSchema);
    outRec = scSchemaNewRecord(outSchema);

    /* get the freeing functions so we can clean up */
    secFreeInRec = scSchemaGetSecondLevelFreeFunc(inSchema);
    secFreeOutRec = scSchemaGetSecondLevelFreeFunc(outSchema);

    /* loop through the inputs */
    while ((rv = inDataInfo->nextInput((void**)&inRwStream)) != 0) {
        /* loop through the records */
        while( (inRv = inDataInfo->getNextRecordCopy(inRwStream,
                                                     inRec, 
                                                     &schemaUsed)) 
                == SCGETNEXT_OK)
        {
            printf("******** INPUT *********\n");
            printStat(inRec); /* print the values in the record */

            /* get the values for hits, atbats, runs, and rbis */
            hits->copyVal(hits, inRec, (uint8_t*)&hval);
            abs->copyVal(abs, inRec, (uint8_t*)&abval);
            runs->copyVal(runs, inRec, &runVal);
            rbis->copyVal(rbis, inRec, (uint8_t*)&rbiVal);
    
            /* compute the runs created and average values */
            rcVal = runVal + rbiVal;
            if (abval) {
                averageVal = (double)((double)hval / (double)abval);
            } else {
                averageVal = 0;
            }

            /* copy all of the incoming values to the outgoing record */
            deepCopyBetweenSchemas(outSchema, outRec, inSchema, inRec);
            /* free the incoming record */
            secFreeInRec(inSchema, inRec);

            /* set the new values in the outgoing record */
            average->setFunc(average, outRec, (uint8_t*)&averageVal);
            runsCreated->setFunc(runsCreated, outRec, (uint8_t*)&rcVal); 

            /* print the results */
            printf("************** OUTPUT ***********\n");
            printOtherStat(outRec);

            /* free the outgoing record */
            secFreeOutRec(outSchema, outRec);
        }
    }


    /* clean up */
    freeSampleDataInfoAlloc(&inDataInfo, &outDataInfo);

    free(inRec);
    free(outRec);
    return 0;
}
