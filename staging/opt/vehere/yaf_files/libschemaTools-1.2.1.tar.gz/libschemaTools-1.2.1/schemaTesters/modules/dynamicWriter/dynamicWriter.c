#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <schemaTools/schemaTools.h>
#include <fixbuf/public.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <signal.h>
#include <time.h>
#include <libgen.h>
#include <unistd.h>
#include <errno.h>
#include <glib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <assert.h>
#include <fixbuf/public.h>

/*
 * This function loops through the elements of a data record
 * and calls the print function for each IE and data value
 */
void myPrintAllElements(
    scSchema_t *schema,
    uint8_t    *rec)
{
    char                stringBuf[300];
    scInfoElement_t    *ie = NULL;
    uint8_t             dataBuf[100];
    int                 printedSoFar = 0;
    
    memset(stringBuf, 0, 300);
    memset(dataBuf, 0, 100);

    printf("IE names: ");
    while((ie = scSchemaGetNextInfoElement(schema, ie))) {
        printf("%s ", ie->name);
                
        ie->copyVal(ie, rec, dataBuf);
        printedSoFar += ie->printFunc(ie, 
                                      (stringBuf + printedSoFar), 
                                      300 - printedSoFar, 
                                      dataBuf);
        snprintf(stringBuf + printedSoFar, 300 - printedSoFar, " ");
        printedSoFar++;    
    
        memset(dataBuf, 0, 100);
    }

    printf("\n");

    printf("Data values: %s\n", stringBuf);
}

int main(int argc, char **argv)
{
    scDataInfo_t               *inDataInfo  = NULL;
    scDataInfo_t               *outDataInfo = NULL;
    int                         rv;
    uint8_t                    *inRec;
    scSchema_t                 *schemaUsed;
    scSchemaFreeRecord_fn       secFreeInRec;
    scSchemaDeepCopyRecord_fn   copyRecord;
    scSchemaFreeRecord_fn       secondLevelFree;
    void                       *schemaState = NULL;
    void                       *outState = NULL;
    scSchema_t                 *lastSchema = NULL;
    scError_t                  *error;
    scConnSpec_t               *myConnSpec;
    scConnSpec_t               *myOutSpec = NULL;
    fbInfoModel_t              *infoModel;
    int num = 0;
    char    fileBuf[100];
    infoModel = fbInfoModelAlloc();


    myConnSpec = scConnSpecAlloc(SC_CS_TCP);
    scConnSpecConfigureFixbufSocket(myConnSpec, "localhost", "18000");

    error = scErrorAlloc();

    /* Retrieve the data info */
    
    if (getAnyFixbufConnection(myConnSpec, &inDataInfo,
                               &schemaState, infoModel, 1, error)) {
        printf("getting socket connection failed %s\n", error->msg);
        return 0;
    }

    memset(fileBuf, 0, 100);
    sprintf(fileBuf, "/afs/cert.org/usr/druef/ipfixFiles/awesomesuperTest.ipfix");
/*    myOutSpec = scConnSpecAlloc(SC_CS_FILE_OUTPUT);
    scConnSpecAddFile(myOutSpec, fileBuf);*/
            myOutSpec = scConnSpecAlloc(SC_CS_TCP);
            scConnSpecConfigureFixbufSocket(myOutSpec, "localhost", "19000");


    if (getAnyOutgoingFixbufConnectionWithoutSchemas(myOutSpec, &outDataInfo, &outState, NULL, error))
    {
        printf("creating empty outgoing connection failed %s\n", error->msg);
        return 0;
    }

    /* loop through all of the inputs */
    while ((rv = inDataInfo->nextInput(&schemaState)) != 0) {
        /* loop through all of the records in a given input */
        while((inRec = inDataInfo->getNextRecordPtr(schemaState, 
                                                    &schemaUsed)))
        {
            if (scSchemaGetCtx(schemaUsed) != (void*)11) {
                scSchemaSetCtx(schemaUsed, (void*)11, NULL);
                if (!addSchemaToOutgoingFixbufConnection(outDataInfo,
                                                        outState,
                                                        schemaUsed,
                                                        error))
                {
                    printf("Couldn't add schema: %s\n", error->msg);
                    return 0;
                }
            }
/*            memset(fileBuf, 0, 100);
            sprintf(fileBuf, "/afs/cert.org/usr/druef/ipfixFiles/superTest%d.ipfix", num);
            num++;
            if (myOutSpec) {
                scConnSpecFree(myOutSpec);
            }*/
/*            myOutSpec = scConnSpecAlloc(SC_CS_TCP);
            scConnSpecConfigureFixbufSocket(myOutSpec, "localhost", "19000");*/
/*            myOutSpec = scConnSpecAlloc(SC_CS_FILE_OUTPUT);
    scConnSpecAddFile(myOutSpec, fileBuf);

            if (outDataInfo) {
                freeAnyOutgoingFixbufConnection(outState);
            }
            outDataInfo = NULL;
            outState = NULL;
            printf("about to derive\n");
            if (deriveOutgoingFixbufConnection(myOutSpec, &outDataInfo, &outState,
                                       inDataInfo, error)) {
                printf("deriving outgoing connection failed %s\n", error->msg);
                return 0;
            }*/

            if (schemaUsed != lastSchema) {
                /* get the function to make copies of these records */
                copyRecord      = scSchemaGetCopyRecordFunc(schemaUsed);
                /* get the function to free the copied records */
                secFreeInRec    = scSchemaGetFreeRecordFunc(schemaUsed);
                /* get function to free the original record, but not buf */
                secondLevelFree = scSchemaGetSecondLevelFreeFunc(schemaUsed);
                /* find the dport in this schema */
                lastSchema = schemaUsed;
            }

            myPrintAllElements(schemaUsed, inRec);
            printf("\n");
            outDataInfo->writeRecord(outState, schemaUsed, inRec, scSchemaGetRecordLength(schemaUsed));
            secondLevelFree(schemaUsed, inRec);            
        }
    }

    if (myOutSpec) {
        scConnSpecFree(myOutSpec);
    }

    if (outDataInfo) {
        freeAnyOutgoingFixbufConnection(&outState);
    }

    /* free the schema informaiton */
/*    freeSocketFixbufConnection(&schemaState);*/

/*    free(inRec);*/

    scErrorFree(error);

    /* to be updated...*/
    scConnSpecFree(myConnSpec);
    return 0;
}
