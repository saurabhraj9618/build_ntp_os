#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <schemaTools/schemaTools.h>
#include "inAndOutIPFIXAddDesc.h"
#include <fixbuf/public.h>

#define ARG_IN          "-in"
#define ARG_OUT         "-out"
#define ARG_PORT        "-port"
#define ARG_HOSTNAME    "-hostname"
#define ARG_TCP         "TCP"
#define ARG_UDP         "UDP"
#define ARG_FILELIST    "FILELIST"
#define ARG_DIR         "DIR"
#define ARG_FILE        "NAMEDFILE" 

/*
    -in(out) (TCP, UDP, FILELIST, DIR, NAMEDFILE) 
   not listing an -ip means use localhost

*/

uint8_t stringBuf[100];

void portLookup(
    uint16_t        port,
    scVarfield_t   *desc)
{
    if (port == 22) {
        strcpy((char*)stringBuf, "Special22");
        desc->dataPtr = stringBuf;
        desc->len = strlen("Special22");
    } else if (port < 1024) {
        strcpy((char*)stringBuf, "Known");
        desc->dataPtr = stringBuf;
        desc->len = strlen("Known");
    } else {
        strcpy((char*)stringBuf, "Ephemeral");
        desc->dataPtr = stringBuf;
        desc->len = strlen("Ephemeral");
    }
}

void myPrintAllElements(
    scSchema_t *schema,
    uint8_t    *rec)
{
    char                stringBuf[300];
    scInfoElement_t    *ie = NULL;
    uint8_t             dataBuf[100];
    int                 printedSoFar = 0;

    memset(stringBuf, 0, 300);
    memset(dataBuf, 0, 100);

    printf("SchemaID: %d IE names: ", scSchemaGetId(schema));
    while((ie = scSchemaGetNextInfoElement(schema, ie))) {
        printf("%s ", ie->name);

        ie->copyVal(ie, rec, dataBuf);
        printedSoFar += ie->printFunc(ie,
                                      (stringBuf + printedSoFar),
                                      300 - printedSoFar,
                                      dataBuf);
        snprintf(stringBuf + printedSoFar, 300 - printedSoFar, " ");
        printedSoFar++;

        memset(dataBuf, 0, 100);
    }

    printf("\n");

    printf("Data values: %s\n", stringBuf);
}

#define CHECK_ARG_COUNT(_needed_)                                       \
    if (argc - i < _needed_) {                                          \
        printf("Not enough params for this comm type\n");               \
        return 0;                                                       \
    }

int parseASpec(
    scConnSpec_t   *connSpec,
    int             i,
    int             argc,
    char          **argv,
    int             incoming)
{
    int gotPort     = 0;
    int gotHostname = 0;
    if (i >= argc) {
        printf("Not enough params\n");
        return 0;
    }

    if (!strcmp(argv[i], ARG_TCP)) {
        i++;
        CHECK_ARG_COUNT(2);
        connSpec->type = SC_CS_TCP;
        if (!strcmp(argv[i], ARG_PORT)) {
            connSpec->connInfo.socket.portStr = strdup(argv[i+1]);
            gotPort = 1;
        } else if (!strcmp(argv[i], ARG_HOSTNAME)) {
            connSpec->connInfo.socket.hostname = strdup(argv[i+1]);
            gotHostname = 1;
        } else {
            printf("invalid switch for tcp %s\n", argv[i]);
            return 0;
        }
        i += 2;

        if (i >= argc) {
            return i;
        }

        if (!strcmp(argv[i], ARG_PORT)) {
            if (gotPort) {
                printf("already ahve a port\n");
                return 0;
            }
            connSpec->connInfo.socket.portStr = strdup(argv[i+1]);
        } else if (!strcmp(argv[i], ARG_HOSTNAME)) {
            if (gotHostname) {
                printf("already have hostname\n");
                return 0;
            }
            connSpec->connInfo.socket.hostname = strdup(argv[i+1]);
        } else {
            return i;
        }
        i += 2;
    } else if (!strcmp(argv[i], ARG_UDP)) {
        i++;
        CHECK_ARG_COUNT(2);
        connSpec->type = SC_CS_UDP;
        if (!strcmp(argv[i], ARG_PORT)) {
            connSpec->connInfo.socket.portStr = strdup(argv[i+1]);
            gotPort = 1;
        } else if (!strcmp(argv[i], ARG_HOSTNAME)) {
            connSpec->connInfo.socket.hostname = strdup(argv[i+1]);
            gotHostname = 1;
        } else {
            printf("invalid switch for tcp %s\n", argv[i]);
            return 0;
        }
        i += 2;

        if (i >= argc) {
            return i;
        }

        if (!strcmp(argv[i], ARG_PORT)) {
            if (gotPort) {
                printf("already ahve a port\n");
                return 0;
            }
            connSpec->connInfo.socket.portStr = strdup(argv[i+1]);
        } else if (!strcmp(argv[i], ARG_HOSTNAME)) {
            if (gotHostname) {
                printf("already have hostname\n");
                return 0;
            }
            connSpec->connInfo.socket.hostname = strdup(argv[i+1]);
        } else {
            return i;
        }
        i += 2;

    } else if (!strcmp(argv[i], ARG_FILELIST)) {
        i++;
        CHECK_ARG_COUNT(1);
        if (!incoming) {
            printf("Can't do a file list for outgoing connections\n");
            return 0;
        }
        connSpec->type = SC_CS_FILELIST_INPUT;
        printf("we don't do that yet\n");
        return 0;

    } else if (!strcmp(argv[i], ARG_DIR)) {
        i++;
        CHECK_ARG_COUNT(1);
        connSpec->type = SC_CS_DIRECTORY;
        printf("we don't do that yet\n");
        return 0;

    } else if (!strcmp(argv[i], ARG_FILE)) {
        i++;
        CHECK_ARG_COUNT(1);
        connSpec->type = SC_CS_FILE_OUTPUT;
        printf("we don't do that yet\n");
        return 0;

    } else {
        printf("Unknown communication type %s\n", argv[i]);
        return 0;
    }

    return i;
}

int parseOptions(
    scConnSpec_t   *inConnSpec,
    scConnSpec_t   *outConnSpec,
    int             argc,
    char          **argv)
{
    int i = 1;

    memset(inConnSpec, 0, sizeof(scConnSpec_t));
    memset(outConnSpec, 0, sizeof(scConnSpec_t));

    if (argc <= 1) {
        printf("Not enough params\n");
        return 1;
    }

    while (i < argc) {
        if (!strcmp(argv[i], ARG_IN)) {
            if (inConnSpec->type != SC_CS_NONE) {
                printf("We already have an in spec\n");
                return 1;
            }
            i++;
            i = parseASpec(inConnSpec, i, argc, argv, 1);
            if (!i) {
                return 1;
            }
        } else if (!strcmp(argv[i], ARG_OUT)) {
            if (outConnSpec->type != SC_CS_NONE) {
                printf("We already have an out spec\n");
                return 1;
            }
            i++;
            i = parseASpec(outConnSpec, i, argc, argv, 0);
            if (!i) {
                return 1;
            }
        } else {
            printf("Invalid param %s\n", argv[i]);
            return 1;
        }
    }

    return 0;
}

int main(int argc, char **argv) 
{
    scDataInfo_t           *inDataInfo;
    scConnSpec_t            inConnSpec;
    void                   *incomingState;

    scDataInfo_t           *outDataInfo;
    scConnSpec_t            outConnSpec;
    void                   *outgoingState;

    int                     rv;
    int                     inRv;
    uint8_t                *inRec;
    uint8_t                *outRec;
    uint16_t                sport;
    uint16_t                dport;
    uint16_t                portSum;
    scVarfield_t            sportDesc;
    scVarfield_t            dportDesc;
    scError_t              *error;
    scSchema_t             *lastSchema = NULL;
    scSchema_t             *schemaUsed = NULL;
    scSchema_t             *schemaOut;

    scInfoElement_t        *currentSport;
    scInfoElement_t        *currentDport;
/*    scInfoElement_t        *currentSportDesc;
    scInfoElement_t        *currentDportDesc;*/
    scInfoElement_t        *currentPortSum;
    uint32_t                rc;

    if (parseOptions(&inConnSpec, &outConnSpec, argc, argv)) {
        return 0;
    }

    error = scErrorAlloc();

    if (getAddDescIPFIXDataInfoAlloc(&inConnSpec, &inDataInfo, &incomingState,
                                 &outConnSpec, &outDataInfo, &outgoingState)) {
        printf("Bad data info...quitting\n");
        return 0;
    }

    inRec = calloc(1, scDataInfoGetMaxRecordLength(inDataInfo));
    outRec = calloc(1, scDataInfoGetMaxRecordLength(outDataInfo));

    while ((rv = inDataInfo->nextInput(&incomingState)) != 0) {
        /* loop through all of the records in a given input */
        while( (inRv = inDataInfo->getNextRecordCopy(incomingState,
                                                     inRec,
                                                     &schemaUsed))
            == SCGETNEXT_OK)
        {
            if (schemaUsed != lastSchema) {
                schemaOut = scSchemaGetAssociatedSchema(schemaUsed);
                if (!schemaOut) {
                    /* pick one I guess*/
                }
                currentSport = scSchemaGetIEByName(schemaUsed,
                                                   "sourceTransportPort");
                currentDport = scSchemaGetIEByName(schemaUsed,
                                                   "destinationTransportPort");
                currentPortSum = scSchemaGetIEByName(schemaOut,
                                                   "flowActiveTimeout");

/*                currentSportDesc = scSchemaGetIEByName(schemaOut,
                                                    "tunnelTechnology");
                currentDportDesc = scSchemaGetIEByName(schemaOut,
                                                    "encryptedTechnology"); */
                lastSchema = schemaUsed;
            }

            deepCopyBetweenSchemas(schemaOut, outRec, schemaUsed, inRec);

            sportDesc.len = 0;
            sportDesc.dataPtr = NULL;
            portSum = 0;
            
            if (currentSport) {
                currentSport->copyVal(currentSport, inRec, (uint8_t*)&sport);
/*                portLookup(sport, &sportDesc);*/
                portSum += sport;
            } else {
                strcpy((char*)stringBuf, "None");
                sportDesc.dataPtr = stringBuf;
                sportDesc.len = strlen("None");
            }

/*            if (currentSportDesc) {
                currentSportDesc->setFunc(currentSportDesc,
                                          outRec,
                                          (uint8_t*)&sportDesc);
            }*/

            dportDesc.len = 0;
            dportDesc.dataPtr = NULL;

            if (currentDport) {
                currentDport->copyVal(currentDport, inRec, (uint8_t*)&dport);
                portSum += dport;
                /*portLookup(dport, &dportDesc);*/
            } else {
/*                strcpy((char*)stringBuf, "None");
                dportDesc.dataPtr = stringBuf;
                dportDesc.len = strlen("None");*/
            }

            if (currentPortSum) {
                currentPortSum->setFunc(currentPortSum,
                                          outRec,
                                          (uint8_t*)&portSum);
            }

/*            if (currentDportDesc) {
                currentDportDesc->setFunc(currentDportDesc,
                                          outRec,
                                          (uint8_t*)&dportDesc);
            }*/

/*            myPrintAllElements(schemaUsed, inRec);
            printf("about to print new stuff\n");*/

        /*    myPrintAllElements(schemaOut, outRec);*/
            /*printSchemaIEsStandard(schemaOut);*/
            rc = outDataInfo->writeRecord(outgoingState, schemaOut, outRec, scSchemaGetRecordLength(schemaOut));
        }
    }


    scErrorFree(error);

    free(inRec);
    free(outRec);
    

    


    return 0;
}
