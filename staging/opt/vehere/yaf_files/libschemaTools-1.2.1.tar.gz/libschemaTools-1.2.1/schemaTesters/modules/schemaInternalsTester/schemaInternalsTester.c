#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <schemaTools/schemaTools.h>
#include <fixbuf/public.h>

#define SCHEMA_1_ID 1
#define SCHEMA_2_ID 2
#define SCHEMA_3_ID 3
#define SCHEMA_4_ID 4

#define MPLS_LABEL "SchemaTester\0"

typedef struct schema1_st {
    scVarfield_t    mplsLabel;
    uint32_t        sip;
    uint32_t        dip;
    uint8_t         flags;
    uint16_t        sport;
    uint16_t        dport;
    uint32_t        ingressInterface;
    scVarfield_t    interfaceName;
    uint64_t        maximumIpTotalLength;
} schema1_t;

typedef struct schema2_st {
    uint8_t         flags;
    uint16_t        sport;
    uint16_t        dport;
    uint32_t        sip;
    uint32_t        dip;
    uint32_t        ingressInterface;
    uint64_t        maximumIpTotalLength;
    scVarfield_t    mplsLabel;
    scVarfield_t    interfaceName;
} schema2_t;

typedef struct schema3_st {
    scVarfield_t    mplsLabel;
    uint8_t         flags;
    scVarfield_t    interfaceName;
    uint16_t        sport;
    uint64_t        maximumIpTotalLength;
    uint32_t        sip;
    uint32_t        dip;
    uint16_t        dport;
    uint32_t        ingressInterface;
} schema3_t;

typedef struct schema4_st {
    uint8_t         flags;
    scVarfield_t    interfaceName;
    uint16_t        sport;
    uint64_t        maximumIpTotalLength;
    uint32_t        sip;
    uint16_t        dport;
    uint8_t         proto;
} schema4_t;

/* this is ugly...but I don't care */
int verifySchema1Offsets(
    scDataInfo_t   *theDataInfo)
{
    scSchema_t         *schema  = NULL;
    schema1_t           s;
    scInfoElement_t    *ie      = NULL;
    uint32_t            offsets[10];
    int                 i;
    uint8_t            *ptr = (uint8_t*)&s;

    memset(offsets, 0, 40);
    offsets[1] = (uint8_t*)&s.sip - ptr;
    offsets[2] = (uint8_t*)&s.dip - ptr;
    offsets[3] = (uint8_t*)&s.flags - ptr;
    offsets[4] = (uint8_t*)&s.sport - ptr;
    offsets[5] = (uint8_t*)&s.dport - ptr;
    offsets[6] = (uint8_t*)&s.ingressInterface - ptr;
    offsets[7] = (uint8_t*)&s.interfaceName - ptr;
    offsets[8] = (uint8_t*)&s.maximumIpTotalLength - ptr;   

    while ((schema = scDataInfoGetNextSchema(theDataInfo, schema))) {
        if (scSchemaGetId(schema) != SCHEMA_1_ID) {
            continue;
        }

        ie = NULL;
        i = 0;
        while ((ie = scSchemaGetNextInfoElement(schema, ie))) {
            if (ie->offset != offsets[i]) {
                printf("Offset for %s is %d in ie, %d in struct\n", ie->name,
                                                                    ie->offset,
                                                                    offsets[i]);
                return 1;
            }           
            
            i++;
        }
        

        break;
    }

    if (!schema) {
        /* if it's null, we never found it */
        printf("Never found schema 1\n");
        return 1;
    }

    return 0;
}

int verifySchema2Offsets(
    scDataInfo_t   *theDataInfo)
{
    scSchema_t         *schema  = NULL;
    schema2_t           s;
    scInfoElement_t    *ie      = NULL;
    uint32_t            offsets[10];
    int                 i;
    uint8_t            *ptr = (uint8_t*)&s;

    memset(offsets, 0, 40);
    offsets[1] = (uint8_t*)&s.sport - ptr;
    offsets[2] = (uint8_t*)&s.dport - ptr;
    offsets[3] = (uint8_t*)&s.sip - ptr;
    offsets[4] = (uint8_t*)&s.dip - ptr;
    offsets[5] = (uint8_t*)&s.ingressInterface - ptr;
    offsets[6] = (uint8_t*)&s.maximumIpTotalLength - ptr;
    offsets[7] = (uint8_t*)&s.mplsLabel - ptr;
    offsets[8] = (uint8_t*)&s.interfaceName - ptr;

    while ((schema = scDataInfoGetNextSchema(theDataInfo, schema))) {
        if (scSchemaGetId(schema) != SCHEMA_2_ID) {
            continue;
        }

        ie = NULL;
        i = 0;
        while ((ie = scSchemaGetNextInfoElement(schema, ie))) {
            if (ie->offset != offsets[i]) {
                printf("Offset for %s is %d in ie, %d in struct\n", ie->name,
                                                                    ie->offset,
                                                                    offsets[i]);
                return 1;
            }

            i++;
        }


        break;
    }

    if (!schema) {
        /* if it's null, we never found it */
        printf("Never found schema 2\n");
        return 1;
    }

    return 0;
}

int verifySchema3Offsets(
    scDataInfo_t   *theDataInfo)
{
    scSchema_t         *schema  = NULL;
    schema3_t           s;
    scInfoElement_t    *ie      = NULL;
    uint32_t            offsets[10];
    int                 i;
    uint8_t            *ptr = (uint8_t*)&s;

    memset(offsets, 0, 40);
    offsets[1] = (uint8_t*)&s.flags - ptr;
    offsets[2] = (uint8_t*)&s.interfaceName - ptr;
    offsets[3] = (uint8_t*)&s.sport - ptr;
    offsets[4] = (uint8_t*)&s.maximumIpTotalLength - ptr;
    offsets[5] = (uint8_t*)&s.sip - ptr;
    offsets[6] = (uint8_t*)&s.dip - ptr;
    offsets[7] = (uint8_t*)&s.dport - ptr;
    offsets[8] = (uint8_t*)&s.ingressInterface - ptr;

    while ((schema = scDataInfoGetNextSchema(theDataInfo, schema))) {
        if (scSchemaGetId(schema) != SCHEMA_3_ID) {
            continue;
        }

        ie = NULL;
        i = 0;
        while ((ie = scSchemaGetNextInfoElement(schema, ie))) {
            if (ie->offset != offsets[i]) {
                printf("Offset for %s is %d in ie, %d in struct\n", ie->name,
                                                                    ie->offset,
                                                                    offsets[i]);
                return 1;
            }

            i++;
        }


        break;
    }

    if (!schema) {
        /* if it's null, we never found it */
        printf("Never found schema 3\n");
        return 1;
    }

    return 0;
}

int verifySchema4Offsets(
    scDataInfo_t   *theDataInfo)
{
    scSchema_t         *schema  = NULL;
    schema4_t           s;
    scInfoElement_t    *ie      = NULL;
    uint32_t            offsets[10];
    int                 i;
    uint8_t            *ptr = (uint8_t*)&s;

    memset(offsets, 0, 40);
    offsets[1] = (uint8_t*)&s.interfaceName - ptr;
    offsets[2] = (uint8_t*)&s.sport - ptr;
    offsets[3] = (uint8_t*)&s.maximumIpTotalLength - ptr;
    offsets[4] = (uint8_t*)&s.sip - ptr;
    offsets[5] = (uint8_t*)&s.dport - ptr;
    offsets[6] = (uint8_t*)&s.proto - ptr;

    while ((schema = scDataInfoGetNextSchema(theDataInfo, schema))) {
        if (scSchemaGetId(schema) != SCHEMA_4_ID) {
            continue;
        }

        ie = NULL;
        i = 0;
        while ((ie = scSchemaGetNextInfoElement(schema, ie))) {
            if (ie->offset != offsets[i]) {
                printf("Offset for %s is %d in ie, %d in struct\n", ie->name,
                                                                    ie->offset,
                                                                    offsets[i]);
                return 1;
            }

            i++;
        }


        break;
    }

    if (!schema) {
        /* if it's null, we never found it */
        printf("Never found schema 4\n");
        return 1;
    }

    return 0;
}


    

#define CHECK_IE(_ie_)                                                  \
    if (!_ie_) {                                                        \
        printf("Couldn't add IE %s\n", error->msg);                     \
        scErrorFree(error);                                             \
        return 1;                                                       \
    }

#define CHECK_ISV(_isv_)                                                  \
    if (!_isv_) {                                                        \
        printf("Couldn't add ISV %s\n", error->msg);                     \
        scErrorFree(error);                                             \
        return 1;                                                       \
    }




uint32_t doNothingNextInput(
    void  **streamBlobDP)
{
    return 1;
}

scDataInfoGetRecErr_t doNothingGetNextRecordCopy(
    void           *streamBlob,
    uint8_t        *buf,
    scSchema_t    **schemaUsed)
{
    return SCGETNEXT_OK;
}

void* doNothingGetNextRecPtr(
    void           *streamBlob,
    scSchema_t    **schema)
{
    return NULL;
}

void doNothingFree(
    scSchema_t *schema,
    uint8_t    *buf)
{
}

uint32_t doNothingCopyRecord(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src)
{
    return 0;
}

uint32_t doNothingWriteRecord(
    void       *streamBlob,
    scSchema_t *schema,
    uint8_t    *buf,
    uint32_t    length)
{
    return 0;
}

schema1_t               s1;
schema2_t               s2;
schema3_t               s3;
schema4_t               s4;

int verifyDataInStructs(
    void)
{
    if ((s1.mplsLabel.len != s2.mplsLabel.len) ||
        (s1.mplsLabel.len != s3.mplsLabel.len))
    {
        printf("Lengths for mplsLabel don't match %ld %ld %ld\n",
                                                    s1.mplsLabel.len,
                                                    s2.mplsLabel.len,
                                                    s3.mplsLabel.len);
        return 1;
    }

    if ((memcmp(s1.mplsLabel.dataPtr,
                 s2.mplsLabel.dataPtr,
                 s1.mplsLabel.len)) ||
        (memcmp(s1.mplsLabel.dataPtr,
                 s3.mplsLabel.dataPtr,
                 s1.mplsLabel.len)))
    {
        printf("Data for mplsLabel doesn't match\n");
        return 1;
    }

    if ((s1.sip != s2.sip) ||
        (s1.sip != s3.sip) ||
        (s1.sip != s4.sip))
    {
        printf("SIPs don't match: %x %x %x %x\n", s1.sip,
                                                  s2.sip, s3.sip, s4.sip);
        return 1;
    }

    if ((s1.dip != s2.dip) ||
        (s1.dip != s3.dip))
    {
        printf("DIPs don't match: %x %x %x\n", s1.dip, s2.dip, s3.dip);
        return 1;
    }

    if ((s1.flags != s2.flags) ||
        (s1.flags != s3.flags) ||
        (s1.flags != s4.flags))
    {
        printf("Flags don't match: %d %d %d %d\n", s1.flags, s2.flags,
                                                   s3.flags, s4.flags);
        return 1;
    }

    if ((s1.sport != s2.sport) ||
        (s1.sport != s3.sport) ||
        (s1.sport != s4.sport))
    {
        printf("Sports don't match: %d %d %d %d\n", s1.sport, s2.sport,
                                                   s3.sport, s4.sport);
        return 1;
    }

    if ((s1.dport != s2.dport) ||
        (s1.dport != s3.dport) ||
        (s1.dport != s4.dport))
    {
        printf("Dports don't match: %d %d %d %d\n", s1.sport, s2.sport,
                                                   s3.sport, s4.sport);
        return 1;
    }

    if ((s1.ingressInterface != s2.ingressInterface) ||
        (s1.ingressInterface != s3.ingressInterface))
    {
        printf("Ingress interfacess don't match: %d %d %d\n",
                                                    s1.ingressInterface,
                                                    s2.ingressInterface,
                                                    s3.ingressInterface);
        return 1;
    }

    if ((s1.interfaceName.len != s2.interfaceName.len) ||
        (s1.interfaceName.len != s3.interfaceName.len) ||
        (s1.interfaceName.len != s4.interfaceName.len))
    {
        printf("Lengths for interfaceName don't match %ld %ld %ld %ld\n",
                                                    s1.interfaceName.len,
                                                    s2.interfaceName.len,
                                                    s3.interfaceName.len,
                                                    s4.interfaceName.len);
        return 1;
    }

    if ((strncmp((char*)s1.interfaceName.dataPtr,
                 (char*)s2.interfaceName.dataPtr,
                 s1.interfaceName.len)) ||
        (strncmp((char*)s1.interfaceName.dataPtr,
                 (char*)s3.interfaceName.dataPtr,
                 s1.interfaceName.len)) ||
        (strncmp((char*)s1.interfaceName.dataPtr,
                 (char*)s4.interfaceName.dataPtr,
                 s1.interfaceName.len)))
    {
        printf("Data for interfaceName doesn't match\n");
        return 1;
    }

    if ((s1.maximumIpTotalLength != s2.maximumIpTotalLength) ||
        (s1.maximumIpTotalLength != s3.maximumIpTotalLength) ||
        (s1.maximumIpTotalLength != s4.maximumIpTotalLength))
    {
        printf("MaximumIpTotalLengths don't match %ld %ld %ld %ld\n", 
                                                s1.maximumIpTotalLength,
                                                s2.maximumIpTotalLength,
                                                s3.maximumIpTotalLength,
                                                s4.maximumIpTotalLength);
        return 1;
    }     

    if (s4.proto != 18) {
        printf("Setting of proto in schema 4 didn't work %d\n", s4.proto);
        return 1;
    }

    /* free the data info memory.  The only real checks here is whether it
     * crashes or not */

    return 0;
}

int main(int argc, char **argv)
{
    scDataInfo_t           *theDataInfo = NULL;
    scSchema_t             *schemaOrig;
    scSchema_t             *schemaCopy1;
    scSchema_t             *schemaCopy2;
    scSchema_t             *schemaCopy3;
    scInfoElement_t        *ie;
    scInfoElement_t        *otherIE;
    scInfoElement_t        *protoIE;
    scInfoElement_t        *dipIE;
    scGroupedElements_t    *group;
    scInfoStringVal_t      *flagsIsv    = NULL;
    scInfoStringVal_t      *flagsIsvRet = NULL;
    scError_t              *error       = scErrorAlloc();
    uint8_t                 arbitraryMem[11];
    uint16_t                protoVal    = 18;
    uint32_t                dipVal;

    memset(&s1, 0, sizeof(schema1_t));
    memset(&s2, 0, sizeof(schema2_t));
    memset(&s3, 0, sizeof(schema3_t));
    memset(&s4, 0, sizeof(schema4_t));

    theDataInfo = scDataInfoAlloc();

    if (scDataInfoFillAsInput(theDataInfo,
                              doNothingNextInput,
                              doNothingGetNextRecordCopy,
                              doNothingGetNextRecPtr,
                              NULL,
                              error))
    {
        printf("Couldn't fill data info for input %s\n", error->msg);
        return 1;
    }

    schemaOrig = scSchemaAlloc("test", SCHEMA_1_ID, 
                           doNothingFree,
                           doNothingFree,
                           doNothingCopyRecord,
                           error);

    if (!schemaOrig) {
        printf("Couldn't alloc schema %s\n", error->msg);
        return 1;
    }

    /* only AddStandardIEByID needs to be used, as what's being
       tested is the underneath storing of the schema, notably the offset */

    /* OCTET ARRAY mplsTopLabelStackSection */
    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 70, NULL, NULL, NULL, error);    
    CHECK_IE(ie);

    /* add SIP and DIP, then add them to a group of elements */
    group = scGroupedElementsAlloc(schemaOrig, "IPs", error);
    if (!group) {
        printf("Couldn't alloc grouped elements %s\n", error->msg);
        return 1;
    }

    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 8, NULL, NULL, NULL, error);
    CHECK_IE(ie);

    if (scGroupedElementsAddIE(group, ie, error)) {
        printf("Couldn't add SIP to group %s\n", error->msg);
        return 1;
    }
    
    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 12, NULL, NULL, NULL, error);
    CHECK_IE(ie);

    if (scGroupedElementsAddIE(group, ie, error)) {
        printf("Couldn't add DIP to group %s\n", error->msg);
        return 1;
    }

    scInfoStringValListInit(&flagsIsv);

    flagsIsvRet = scInfoStringValAddToList(&flagsIsv, (uint32_t)1, "F", error);
    CHECK_ISV(flagsIsvRet);

    flagsIsvRet = scInfoStringValAddToList(&flagsIsv, (uint32_t)2, "S", error);
    CHECK_ISV(flagsIsvRet);

    flagsIsvRet = scInfoStringValAddToList(&flagsIsv, (uint32_t)4, "R", error);
    CHECK_ISV(flagsIsvRet);

    flagsIsvRet = scInfoStringValAddToList(&flagsIsv, (uint32_t)8, "P", error);
    CHECK_ISV(flagsIsvRet);

    flagsIsvRet = scInfoStringValAddToList(&flagsIsv, (uint32_t)16, "A", error);
    CHECK_ISV(flagsIsvRet);

    flagsIsvRet = scInfoStringValAddToList(&flagsIsv, (uint32_t)32, "U", error);
    CHECK_ISV(flagsIsvRet);

    flagsIsvRet = scInfoStringValAddToList(&flagsIsv, (uint32_t)64, "E", error);
    CHECK_ISV(flagsIsvRet);

    flagsIsvRet = scInfoStringValAddToList(&flagsIsv, (uint32_t)128,"C", error);
    CHECK_ISV(flagsIsvRet);

    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 6, NULL, flagsIsv, NULL, error);

    /* add sport and dport, then add them to a group of elements */
    group = scGroupedElementsAlloc(schemaOrig, "Ports", error);
    if (!group) {
        printf("Couldn't alloc grouped elements %s\n", error->msg);
        return 1;
    }

    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 7, NULL, NULL, NULL, error);
    CHECK_IE(ie);

    if (scGroupedElementsAddIE(group, ie, error)) {
        printf("Couldn't add sport to group %s\n", error->msg);
        return 1;
    }

    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 11, NULL, NULL, NULL, error);
    CHECK_IE(ie);

    if (scGroupedElementsAddIE(group, ie, error)) {
        printf("Couldn't add dport to group %s\n", error->msg);
        return 1;
    }


    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 10, NULL, NULL, NULL, error);
    CHECK_IE(ie);

    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 82, NULL, NULL, NULL, error);
    CHECK_IE(ie);

    ie = scSchemaAddStandardIEByID(schemaOrig, 0, 26, NULL, NULL, NULL, error);
    CHECK_IE(ie);




    schemaCopy1 = scSchemaCopy(schemaOrig, SCHEMA_2_ID, "copy 1",
                               doNothingFree,
                               doNothingFree,
                               doNothingCopyRecord,
                               error);

    if (!schemaCopy1) {
        printf("Couldn't copy into schema 1. %s\n", error->msg);
        return 1;
    }

    
    schemaCopy2 = scSchemaCopy(schemaOrig, SCHEMA_3_ID, "copy 2",
                               doNothingFree,
                               doNothingFree,
                               doNothingCopyRecord,
                               error);

    if (!schemaCopy2) {
        printf("Couldn't copy into schema 2. %s\n", error->msg);
        return 1;
    }

    
    /* rearrange copy 1 */
    ie = scSchemaMoveIEBeforeAnotherByName(schemaCopy1,
                                           "destinationTransportPort",
                                           "sourceIPv4Address",
                                           error);

    ie = scSchemaMoveIEBeforeAnotherByName(schemaCopy1,
                                           "sourceTransportPort",
                                           "destinationTransportPort",
                                           error);

    ie = scSchemaMoveIEToBeginningByName(schemaCopy1,
                                         "tcpControlBits",
                                         error);

    ie = scSchemaMoveIEToEndByName(schemaCopy1,
                                   "mplsTopLabelStackSection",
                                   error);

    ie = scSchemaMoveIEToEndByName(schemaCopy1,
                                   "interfaceName",
                                   error);

    /* rearrange copy 2 */
    ie = scSchemaMoveIEAfterAnotherByName(schemaCopy2,
                                           "sourceIPv4Address",
                                           "maximumIpTotalLength",
                                           error);

    ie = scSchemaMoveIEAfterAnotherByName(schemaCopy2,
                                           "destinationIPv4Address",
                                           "sourceIPv4Address",
                                           error);

    ie = scSchemaMoveIEToEndByName(schemaCopy2,
                                   "ingressInterface",
                                   error);

    ie = scSchemaMoveIEAfterAnotherByName(schemaCopy2,
                                           "interfaceName",
                                           "tcpControlBits",
                                           error);

    
    ie = scSchemaMoveIEAfterAnotherByName(schemaCopy2,
                                           "destinationTransportPort",
                                           "destinationIPv4Address",
                                           error);


    /* rearrange copy 3 */
    schemaCopy3 = scSchemaCopy(schemaCopy2, SCHEMA_4_ID, "copy 3",
                               doNothingFree,
                               doNothingFree,
                               doNothingCopyRecord,
                               error);
    if (!schemaCopy3) {
        printf("Couldn't copy into schema 3. %s\n", error->msg);
        return 1;
    }

    if (scSchemaRemoveIEByID(schemaCopy3, 0, 70, error)) {
        printf("Couldn't remove 0, 70 %s\n", error->msg);
        return 1;
    }

    if (scSchemaRemoveIEByID(schemaCopy3, 0, 12, error)) {
        printf("Couldn't remove 0, 12 %s\n", error->msg);
        return 1;
    }

    otherIE = scSchemaGetIEByID(schemaCopy3, 0, 10);
    if (otherIE) {
        if (scSchemaRemoveIE(schemaCopy3, otherIE, error)) {
            printf("Couldn't remove 10 by pointer %s\n", error->msg);
            return 1;
        }
    } else {
        printf("Couldn't get 0, 10 from schema\n");
        return 1;
    } 

    /* add protocol to schema 4 */
    protoIE = scSchemaAddStandardIEByID(schemaCopy3, 0, 4, NULL, NULL, 
                                        NULL, error);
    CHECK_IE(protoIE);

    if (scDataInfoAddSchema(theDataInfo, schemaOrig, error)) {
        printf("Couldn't add schema 1 %s\n", error->msg);
        return 1;
    }


    if (scDataInfoAddSchema(theDataInfo, schemaCopy1, error)) {
        printf("Couldn't add schema 2 %s\n", error->msg);
        return 1;
    }

    if (scDataInfoAddSchema(theDataInfo, schemaCopy2, error)) {
        printf("Couldn't add schema 3 %s\n", error->msg);
        return 1;
    }

    if (scDataInfoAddSchema(theDataInfo, schemaCopy3, error)) {
        printf("Couldn't add schema 4 %s\n", error->msg);
        return 1;
    }

    if (verifySchema1Offsets(theDataInfo)) {
        printf("Couldn't verify schema 1\n");
        return 1;
    }
    
    if (verifySchema2Offsets(theDataInfo)) {
        printf("Couldn't verify schema 2\n");
        return 1;
    }

    if (verifySchema3Offsets(theDataInfo)) {
        printf("Couldn't verify schema 3\n");
        return 1;
    }
    if (verifySchema4Offsets(theDataInfo)) {
        printf("Couldn't verify schema 4\n");
        return 1;
    }

    /* internals look good, now try copying between schemas... */
    s1.interfaceName.len = strlen(MPLS_LABEL);
    s1.interfaceName.dataPtr = calloc(1, s1.mplsLabel.len);
    strncpy((char*)s1.interfaceName.dataPtr, MPLS_LABEL, s1.mplsLabel.len);
    s1.sip = 0x11111111;
    s1.dip = 0x22222222;
    s1.flags = 2;
    s1.sport = 15;
    s1.dport = 21;
    s1.ingressInterface = 12345;
    s1.mplsLabel.len = 10;
    s1.mplsLabel.dataPtr = arbitraryMem;
    s1.maximumIpTotalLength = 12345678;

    if (!copyBetweenSchemas(schemaCopy1, (uint8_t*)&s2, schemaOrig, (uint8_t*)&s1)) {
        printf("Unsuccessful copy from schema 1 to 2\n");
        return 1;
    }

    if (!copyBetweenSchemas(schemaCopy2, (uint8_t*)&s3, schemaOrig, (uint8_t*)&s1)) {
        printf("Unsuccessful copy from schema 1 to 3\n");
        return 1;
    }

    if (!copyBetweenSchemas(schemaCopy3, (uint8_t*)&s4, schemaOrig, (uint8_t*)&s1)) {
        printf("Unsuccessful copy from schema 1 to 4\n");
        return 1;
    }

    /* set the proto value to 18*/
    protoIE->setFunc(protoIE, (uint8_t*)&s4, (uint8_t*)&protoVal);

    /* now that we've copied, check that the values are equal */
    if (verifyDataInStructs()) {
        printf("Error in data copying\n");
        return 1;
    }

    /* start over and try the deep copies */
    memset(&s2, 0, sizeof(schema2_t));
    memset(&s3, 0, sizeof(schema3_t));
    memset(&s4, 0, sizeof(schema4_t));

    if (!deepCopyBetweenSchemas(schemaCopy1, (uint8_t*)&s2, schemaOrig, (uint8_t*)&s1)) {
        printf("Unsuccessful copy from schema 1 to 2\n");
        return 1;
    }
    if (!deepCopyBetweenSchemas(schemaCopy2, (uint8_t*)&s3, schemaOrig, (uint8_t*)&s1)) {
        printf("Unsuccessful copy from schema 1 to 3\n");
        return 1;
    }
    if (!deepCopyBetweenSchemas(schemaCopy3, (uint8_t*)&s4, schemaOrig, (uint8_t*)&s1)) {
        printf("Unsuccessful copy from schema 1 to 4\n");
        return 1;
    }
    
    /* set the proto value to 18*/
    protoIE->setFunc(protoIE, (uint8_t*)&s4, (uint8_t*)&protoVal);

    if (verifyDataInStructs()) {
        printf("Error in data copying\n");
        return 1;
    }

    /* use the lookups to check dips and protos */
    dipIE = scSchemaGetIEByName(schemaOrig, "destinationIPv4Address");
    if (!dipIE) {
        printf("Couldn't find dip IE in schema 1\n");
        return 1;
    }

    dipIE->copyVal(dipIE, (uint8_t*)&s1, (uint8_t*)&dipVal);
    if (dipVal != 0x22222222) {
        printf("Dip value not correct in lookup %x\n", dipVal);
        return 1;
    }
    dipIE = scSchemaGetIEByName(schemaCopy1, "destinationIPv4Address"); 
    if (!dipIE) {
        printf("Couldn't find dip IE in schema 2\n");
        return 1;
    }

    dipIE->copyVal(dipIE, (uint8_t*)&s2, (uint8_t*)&dipVal);
    if (dipVal != 0x22222222) {
        printf("Dip value not correct in lookup %x\n", dipVal);
        return 1;
    }
    dipIE = scSchemaGetIEByName(schemaCopy2, "destinationIPv4Address"); 
    if (!dipIE) {
        printf("Couldn't find dip IE in schema 3\n");
        return 1;
    }

    dipIE->copyVal(dipIE, (uint8_t*)&s3, (uint8_t*)&dipVal);
    if (dipVal != 0x22222222) {
        printf("Dip value not correct in lookup %x\n", dipVal);
        return 1;
    }
    dipIE = scSchemaGetIEByName(schemaCopy3, "destinationIPv4Address"); 
    if (dipIE) {
        printf("DIP shouldn't have been found in schema 4\n");
        return 1;
    }

    protoIE = scSchemaGetIEByID(schemaOrig, 0, 4);
    if (protoIE) {
        printf("Shouldn't have found proto in schema 1\n");
        return 1;
    }

    protoIE = scSchemaGetIEByID(schemaCopy1, 0, 4);
    if (protoIE) {
        printf("Shouldn't have found proto in schema 2\n");
        return 1;
    }

    protoIE = scSchemaGetIEByID(schemaCopy2, 0, 4);
    if (protoIE) {
        printf("Shouldn't have found proto in schema 3\n");
        return 1;
    }

    protoIE = scSchemaGetIEByID(schemaCopy3, 0, 4);
    if (!protoIE) {
        printf("Couldn't find proto in schema 4\n");
        return 1;
    }

    protoIE->copyVal(protoIE, (uint8_t*)&s4, (uint8_t*)&protoVal);
    if (protoVal != 18) {
        printf("Proto value not correct in lookup %d\n", protoVal);
        return 1;
    }

    scSchemaPrintIEs(schemaOrig);
    scSchemaPrintIEs(schemaCopy1); 
    scSchemaPrintIEs(schemaCopy2);
    scSchemaPrintIEs(schemaCopy3);

    scDataInfoFree(theDataInfo);
    scErrorFree(error);

    return 0;
}  
