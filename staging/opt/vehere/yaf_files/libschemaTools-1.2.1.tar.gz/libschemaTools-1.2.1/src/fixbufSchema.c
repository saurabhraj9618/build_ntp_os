#include <schemaTools/schemaTools.h>
#include <schemaTools/scpolldir.h>
#include "schemaToolsPrivate.h"
#include <dirent.h>

typedef struct ipfixSchemaState_st {
    fbSession_t            *collectorSession;
    fbSession_t            *fBufSession;
    struct fbConnSpec_st    socketDef;
    fbListener_t           *collectorListener;
    fbCollector_t          *collector;
    fbInfoModel_t          *infoModel;
    int                     IMFreedByConnection;
    fBuf_t                 *collectorBuf;
    uint8_t                 inputNum;
    size_t                  schemaLen;
    scSchemaTemplateMgmt_t *mgmt;
    GError                 *error;
    scDataInfo_t           *dataInfo;
    uint16_t                lastTid;
    scSchema_t             *lastSchema;
    uint32_t                nextInputIter;
    scConnSpec_t           *scConnSpec;
    uint16_t                nextTid;
} ipfixSchemaState_t;

typedef struct outIpfixSchemaState_st {
    fbSession_t            *exporterSession;
    struct fbConnSpec_st    fbConnSpec;
    fbExporter_t           *exporter;
    fBuf_t                 *exporterBuf;
    fbInfoModel_t          *infoModel;
    uint8_t                 IMFreedByConnection;
    GError                 *error;
    scSchemaTemplateMgmt_t *mgmt;
    size_t                  schemaLen;
    scDataInfo_t           *outDataInfo;
    scSchema_t             *lastSchema;
    uint16_t                lastTid;
    scConnSpec_t           *scConnSpec;
} outIpfixSchemaState_t;

static scFBufSessionAndState_t *sessStateListHead = NULL;
static uint16_t                 numSessStates = 0;

void fixbufSchemaBuilderMemFree(
    void   *builderMem)
{
    free(builderMem);
}

void* fixbufSchemaBuilderMemAllocAndCopy(
    scSchema_t *schema)
{
    void   *newBuilderMem;
    if (!schema->builderMem) {
        return NULL;
    }

    newBuilderMem = calloc(1, sizeof(scSchemaBuilderMem_t));
    memset(newBuilderMem, 0, sizeof(scSchemaBuilderMem_t));

    memcpy(newBuilderMem, schema->builderMem, sizeof(scSchemaBuilderMem_t));

    return newBuilderMem;
}

void makeNewSchemasTemplateCallback(
    fbSession_t    *session,
    uint16_t        tid,
    fbTemplate_t   *tmpl);

void justAddNewSchemasInternalTemplatesTemplateCallback(
    fbSession_t    *session,
    uint16_t        tid,
    fbTemplate_t   *tmpl);


void scFBufSessionAndStateAdd(
    fbSession_t    *session,
    void           *inState)
{
    scFBufSessionAndState_t    *sessState;
    ipfixSchemaState_t         *state = (ipfixSchemaState_t*)inState;
    uint16_t                    i;

    for (sessState = sessStateListHead, i = 0;
         i < numSessStates;
         sessState++, i++)
    {
        if (sessState->fBufSession == session) {
            sessState->schemaState = state;
            return;
        }
    }

    sessStateListHead = realloc(sessStateListHead,
                                sizeof(scFBufSessionAndState_t)
                                    * (numSessStates + 1));

    sessState = sessStateListHead + numSessStates;
    sessState->fBufSession = session;
    sessState->schemaState = state;

    numSessStates++;
}

void* scGetSchemaStateForFBufSession(
    fbSession_t    *session)
{
    scFBufSessionAndState_t    *sessState;
    uint16_t                    i;

    for (sessState = sessStateListHead, i = 0;
         i < numSessStates;
         sessState++, i++)
    {
        if (sessState->fBufSession == session) {
            return sessState->schemaState;
        }
    }

    return NULL;
}

void scFBufSessionAndStateRemove(
    fbSession_t    *session)
{
    uint16_t                    i;
    uint16_t                    j;
    scFBufSessionAndState_t    *sessState;

    for (sessState = sessStateListHead, i = 0;
         i < numSessStates;
         sessState++, i++)
    {
        if (sessState->fBufSession == session) {
            for (j = i; j < (numSessStates-1); j++) {
                sessStateListHead[j].fBufSession =
                    sessStateListHead[j+1].fBufSession;
                sessStateListHead[j].schemaState =
                    sessStateListHead[j+1].schemaState;
            }
            numSessStates--;
        }
    }
}

ipfixSchemaState_t* newIpfixSchemaState(
    void)
{
    ipfixSchemaState_t *state = calloc(1, sizeof(ipfixSchemaState_t));
    return state;
}

outIpfixSchemaState_t* newOutIpfixSchemaState(
    void)
{
    outIpfixSchemaState_t  *state = calloc(1, sizeof(outIpfixSchemaState_t));
    return state;
}

static int  nestedFreeing = 0;
static void freeRecordCopy(
    scSchema_t *schema,
    uint8_t    *rec)
{
    uint32_t            i;
    scVarfield_t       *varfield;
    scSchemaBuilderMem_t *builderMem = schema->builderMem;
    fbSubTemplateMultiListEntry_t  *entry;
    fbSubTemplateMultiList_t       *STML;
    scSchema_t                     *subSchema;
    ipfixSchemaState_t             *state = builderMem->schemaStateContext;
    void                           *entryDP;
    fbSubTemplateList_t            *STL;
    void                           *stlData;
    fbBasicList_t                  *theBL;
    uint16_t                        blIter;
    scVarfield_t                   *blVarfield;

    nestedFreeing = 1;

    /* loop through varfields freeing data */
    for (i = 0; i < builderMem->numVarfields; i++) {
        varfield = (scVarfield_t*)(rec + builderMem->varfieldOffsets[i]);
        free(varfield->dataPtr);
    }

    for (i = 0; i < builderMem->numBasicLists; i++) {
        theBL = (fbBasicList_t*)(rec + builderMem->basicListOffsets[i]);
        if (theBL->infoElement->len == FB_IE_VARLEN) {
            for (blIter = 0,
                 blVarfield = (scVarfield_t*)theBL->dataPtr;
                 blIter < theBL->numElements;
                 blIter++, blVarfield++)
            {
                free(blVarfield->dataPtr);
            }
        }

        fbBasicListClear(theBL);
    }

    for (i = 0; i < builderMem->numSTLs; i++) {
        STL = (fbSubTemplateList_t*)(rec + builderMem->STLoffsets[i]);
        if (!STL->numElements) {
            fbSubTemplateListClearWithoutFree(STL);
            continue;
        }
        subSchema = scSchemaTemplateMgmtGetSchemaForTid(state->mgmt, STL->tmplID);
        stlData = NULL;
        while ((stlData = fbSubTemplateListGetNextPtr(STL, stlData))) {
            subSchema->freeSecondLevelFields(subSchema, stlData);
        }
        fbSubTemplateListClear(STL);
    }

    for (i = 0; i < builderMem->numSTMLs; i++) {
        STML = (fbSubTemplateMultiList_t*)(rec + builderMem->STMLoffsets[i]);
        if (!STML->numElements) {
            fbSubTemplateMultiListClear((fbSubTemplateMultiList_t*)(rec + builderMem->STMLoffsets[i]));
            continue;
        }

        entry = NULL;
        while ((entry = fbSubTemplateMultiListGetNextEntry(STML, entry))) {
            if (!entry->numElements) {
                continue;
            }
            subSchema = scSchemaTemplateMgmtGetSchemaForTid(state->mgmt,
                                                     entry->tmplID);
            entryDP = NULL;
            while ((entryDP = fbSubTemplateMultiListEntryNextDataPtr(entry,
                                                                     entryDP)))
            {
                subSchema->freeSecondLevelFields(subSchema, entryDP);
            }
        }

        fbSubTemplateMultiListClear((fbSubTemplateMultiList_t*)(rec + builderMem->STMLoffsets[i]));
    }

    nestedFreeing = 0;

    /* free the buffer (record) itself */
    free(rec);
}

/* make a copy of a record described by a given schema */
static uint32_t copyRecord(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src)
{
    uint32_t                len = scSchemaGetRecordLength(schema);
    uint32_t                i;
    uint16_t                j;
    scVarfield_t           *srcVarfield;
    scVarfield_t           *dstVarfield;
    scSchemaBuilderMem_t   *builderMem = schema->builderMem;
    scBasicList_t          *srcBL;
    scBasicList_t          *dstBL;
    fbSubTemplateList_t        *srcSTL;
    fbSubTemplateList_t        *dstSTL;
    fbSubTemplateMultiList_t   *srcSTML;
    fbSubTemplateMultiList_t   *dstSTML;
    fbSubTemplateMultiListEntry_t  *srcEntry;
    fbSubTemplateMultiListEntry_t  *dstEntry;
    scSchema_t                     *subSchema;
    void                           *srcData;
    void                           *dstData;
    ipfixSchemaState_t             *state = builderMem->schemaStateContext;
    uint16_t                        blIter;

    /* simple copy of the first level fields */
    memcpy(dst, src, len);

    /* loop through the varfields making copies of second level data */
    for (i = 0; i < builderMem->numVarfields; i++) {
        srcVarfield = (scVarfield_t*)(src + builderMem->varfieldOffsets[i]);
        dstVarfield = (scVarfield_t*)(dst + builderMem->varfieldOffsets[i]);

        if (dstVarfield->len) {
            dstVarfield->dataPtr = calloc(1, dstVarfield->len);
            memcpy(dstVarfield->dataPtr, srcVarfield->dataPtr, dstVarfield->len);
        }
    }

    for (i = 0; i < builderMem->numBasicLists; i++) {
        srcBL = (scBasicList_t*)(src + builderMem->basicListOffsets[i]);
        dstBL = (scBasicList_t*)(dst + builderMem->basicListOffsets[i]);



        if (!srcBL->numElements) {
            dstBL->dataPtr = NULL;
            continue;
        }

        dstBL->dataPtr = g_slice_alloc(srcBL->dataLength);

        if (srcBL->infoElement->len == FB_IE_VARLEN) {
            for (blIter = 0,
                 srcVarfield = (scVarfield_t*)srcBL->dataPtr,
                 dstVarfield = (scVarfield_t*)dstBL->dataPtr;
                 blIter < srcBL->numElements;
                 blIter++, srcVarfield++, dstVarfield++)
            {
                dstVarfield->len = srcVarfield->len;
                dstVarfield->dataPtr = malloc(dstVarfield->len);
                memcpy(dstVarfield->dataPtr,
                       srcVarfield->dataPtr,
                       dstVarfield->len);
            }
        } else {
            memcpy(dstBL->dataPtr, srcBL->dataPtr, srcBL->dataLength);
        }
    }

    for (i = 0; i < builderMem->numSTLs; i++) {
        srcSTL = (fbSubTemplateList_t*)(src + builderMem->STLoffsets[i]);
        dstSTL = (fbSubTemplateList_t*)(dst + builderMem->STLoffsets[i]);

        if (!srcSTL->numElements) {
            dstSTL->dataPtr = NULL;
            continue;
        }

        dstSTL->dataPtr = g_slice_alloc(srcSTL->dataLength.length);

        subSchema = scSchemaTemplateMgmtGetSchemaForTid(state->mgmt,
                                                        srcSTL->tmplID);

        srcData = NULL;
        dstData = NULL;
        while ((srcData = fbSubTemplateListGetNextPtr(srcSTL, srcData))) {
            dstData = fbSubTemplateListGetNextPtr(dstSTL, dstData);
            subSchema->copyRecord(subSchema, dstData, srcData);
        }
    }


    for (i = 0; i < builderMem->numSTMLs; i++) {
        srcSTML = (fbSubTemplateMultiList_t*)(src + builderMem->STMLoffsets[i]);
        dstSTML = (fbSubTemplateMultiList_t*)(dst + builderMem->STMLoffsets[i]);

        if (!srcSTML->numElements) {
            dstSTML->firstEntry = NULL;
            continue;
        }

        /* copy the entries...this is all of the meta data needed...pointers
            to follow */
        dstSTML->firstEntry = g_slice_alloc0(dstSTML->numElements *
                                        sizeof(fbSubTemplateMultiListEntry_t));
        memcpy(dstSTML->firstEntry, srcSTML->firstEntry, dstSTML->numElements * sizeof(fbSubTemplateMultiListEntry_t));

        /* loop through the entries copying the STLs */
        for (srcEntry = srcSTML->firstEntry, dstEntry = dstSTML->firstEntry, j = 0;
             j < srcSTML->numElements;
             srcEntry++, dstEntry++, j++)
        {
            subSchema = scSchemaTemplateMgmtGetSchemaForTid(state->mgmt,
                                                     srcEntry->tmplID);

            dstEntry->dataPtr = g_slice_alloc0(dstEntry->dataLength);
            srcData = NULL;
            dstData = NULL;
            while ((srcData = fbSubTemplateMultiListEntryNextDataPtr(srcEntry,
                                                                     srcData)))
            {
                dstData = fbSubTemplateMultiListEntryNextDataPtr(dstEntry,
                                                                 dstData);
                subSchema->copyRecord(subSchema, dstData, srcData);
            }
        }
    }

    return len;
}

static void freeSecondLevelFields(
    scSchema_t *schema,
    uint8_t    *rec)
{
    scSchemaBuilderMem_t   *builderMem = schema->builderMem;
    fbSubTemplateMultiListEntry_t  *entry;
    fbSubTemplateMultiList_t       *STML;
    uint32_t                        i;
    scSchema_t                     *subSchema;
    ipfixSchemaState_t             *state = builderMem->schemaStateContext;
    void                           *entryDP;
    fbSubTemplateList_t            *STL;
    void                           *stlData;
    fbBasicList_t                  *BL;
    scVarfield_t                   *varfield;
    uint16_t                        blIter;

    if (!builderMem->numLists && !builderMem->numVarfields) {
        return;
    }

    if (nestedFreeing) {
        for (i = 0; i < builderMem->numVarfields; i++) {
            varfield = (scVarfield_t*)(rec + builderMem->varfieldOffsets[i]);
            if (varfield->len) {
                free(varfield->dataPtr);
            }
        }
    }

    for (i = 0; i < builderMem->numBasicLists; i++) {
        BL = (fbBasicList_t*)(rec + builderMem->basicListOffsets[i]);
        if (nestedFreeing) {
            if (BL->infoElement->len == FB_IE_VARLEN) {
                for (blIter = 0,
                     varfield = (scVarfield_t*)BL->dataPtr;
                     blIter < BL->numElements;
                     blIter++, varfield++)
                {
                    free(varfield->dataPtr);
                }
            }
        }

        fbBasicListClear(BL);
    }

    for (i = 0; i < builderMem->numSTLs; i++) {
        STL = (fbSubTemplateList_t*)(rec + builderMem->STLoffsets[i]);
        if (!STL->numElements) {
            fbSubTemplateListClearWithoutFree(STL);
            continue;
        }
        subSchema = scSchemaTemplateMgmtGetSchemaForTid(state->mgmt, STL->tmplID);
        stlData = NULL;
        while ((stlData = fbSubTemplateListGetNextPtr(STL, stlData))) {
            subSchema->freeSecondLevelFields(subSchema, stlData);
        }
        fbSubTemplateListClear(STL);
    }

    for (i = 0; i < builderMem->numSTMLs; i++) {
        STML = (fbSubTemplateMultiList_t*)(rec + builderMem->STMLoffsets[i]);
        if (!STML->numElements) {
            fbSubTemplateMultiListClear((fbSubTemplateMultiList_t*)(rec + builderMem->STMLoffsets[i]));
            continue;
        }
        entry = NULL;
        while ((entry = fbSubTemplateMultiListGetNextEntry(STML, entry))) {
            if (!entry->numElements) {
                continue;
            }
            subSchema = scSchemaTemplateMgmtGetSchemaForTid(state->mgmt,
                                                     entry->tmplID);
            entryDP = NULL;
            while ((entryDP = fbSubTemplateMultiListEntryNextDataPtr(entry,
                                                                     entryDP)))
            {
                subSchema->freeSecondLevelFields(subSchema, entryDP);
            }
        }
        fbSubTemplateMultiListClear((fbSubTemplateMultiList_t*)(rec + builderMem->STMLoffsets[i]));
    }
}

scSchema_t* scFixbufTemplateToSchema(
    fbSession_t    *session,
    fbTemplate_t   *tmpl,
    uint16_t        schemaId,
    char           *schemaName,
    scError_t      *error)
{
    scSchema_t             *schema;
    scSchemaBuilderMem_t   *builderMem;
    uint32_t                numIEs;
    uint32_t                i;
    const fbInfoElement_t  *ie;
    const fbInfoElement_t  *standardIE;
    scInfoElement_t        *addedIE;
    ipfixSchemaState_t     *thisState;

    thisState = scGetSchemaStateForFBufSession(session);

    /* at this point we have a data template, so we need a schema for this */
    numIEs = fbTemplateCountElements(tmpl);
    if (!numIEs) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Incoming template has no elements");
        return NULL;
    }

    /* allocate custom builder mem to attach to the new schema */
    builderMem = calloc(1, sizeof(scSchemaBuilderMem_t));
    memset(builderMem, 0, sizeof(scSchemaBuilderMem_t));
    builderMem->schemaStateContext = thisState;

    if (schemaName) {
        schema = scSchemaAlloc(schemaName, schemaId,
                                freeRecordCopy,
                                freeSecondLevelFields,
                                copyRecord,
                                error);
    } else {
        schema = scSchemaAlloc("fromIPFix", schemaId,
                                freeRecordCopy,
                                freeSecondLevelFields,
                                copyRecord,
                                error);
    }

    if (!schema) {
        ERR1("Couldn't allocate schema %s\n", error->msg);
        return NULL;
    }

    scSchemaSetBuilderMem(schema, builderMem,
                          fixbufSchemaBuilderMemAllocAndCopy,
                          fixbufSchemaBuilderMemFree);

    for (i = 0; i < numIEs; i++) {
        ie = fbTemplateGetIndexedIE(tmpl, i);
        standardIE = fbInfoModelGetElementByID(thisState->infoModel,
                                               ie->num, ie->ent);

        /* if this is a custom element, add to schema accordingly */
        if (standardIE) {
            if (ie->num != 210 || ie->ent != 0) {
                addedIE = scSchemaAddStandardIEByID(schema, ie->ent,
                                                    ie->num, NULL, NULL,
                                                    thisState->infoModel,
                                                    error);
            } else {
                continue;
            }
        } else {
            addedIE = scSchemaAddCustomIEStandardFuncs(schema,
                                                      ie->ent,
                                                      ie->num,
                                                      ie->type,
                                                      (char*)ie->description,
                                                      (char*)ie->ref.canon->ref.name,
                                                      ie->min,
                                                      ie->max,
                                                      FB_IE_SEMANTIC(ie->flags),
                                                      NULL,
                                                      FB_IE_UNITS(ie->flags),
                                                      error);
        }
        /* check if this IE is a list, varfield, or fixed,
         * keep track of where variable lengthed fields are
         */
        if (!addedIE) {
            ERR3("Couldn't add IE {%d, %d} %s\n", ie->ent, ie->num, error->msg);
            continue;
        }

        if ((ie->len != FB_IE_VARLEN) &&
            (ie->len != addedIE->len))
        {
            addedIE->len = ie->len;
            setAllOffsetsAndLen(schema);
        }

        if (standardIE && standardIE->len == FB_IE_VARLEN &&
            ie->len != FB_IE_VARLEN &&
            !(ie->ent == 0 && ie->num == 210))
        {
            addedIE = scSchemaOverrideLengthOfExistingIE(schema, addedIE,
                                            ie->len, error);
            if (!addedIE) {
                ERR1("Couldn't override length %s\n", error->msg);
            }
        }
    }

    schema->len = 0;
    for (addedIE = schema->firstPrimary; addedIE; addedIE = addedIE->next) {
        addedIE->offset = schema->len;
        schema->len += addedIE->len;
        switch (scInfoElementGetGeneralType(addedIE)) {
          case FIXED:
            break;
          case VARLEN_DATA:
            builderMem->varfieldOffsets[builderMem->numVarfields] =
                                                            addedIE->offset;
            builderMem->numVarfields++;
            break;
          case LIST_TYPE:
            builderMem->numLists++;
            switch (addedIE->type) {
              case BASIC_LIST:
                builderMem->basicListOffsets[builderMem->numBasicLists] =
                                addedIE->offset;
                builderMem->basicListIEs[builderMem->numBasicLists] = addedIE;
                builderMem->numBasicLists++;
                break;
              case SUB_TEMPLATE_LIST:
                builderMem->STLoffsets[builderMem->numSTLs] =
                                addedIE->offset;
                builderMem->STLies[builderMem->numSTLs] = addedIE;
                builderMem->numSTLs++;
                break;
              case SUB_TEMPLATE_MULTI_LIST:
                builderMem->STMLoffsets[builderMem->numSTMLs] =
                                addedIE->offset;
                builderMem->STMLies[builderMem->numSTMLs] = addedIE;
                builderMem->numSTMLs++;

                break;
              default:
                printf("a non list in list...wtf\n");
                break;
            }
            break;
        }
    }

    return schema;
}

fbTemplate_t* scSchemaToFixbufTemplate(
    fbSession_t    *session,
    scSchema_t     *schema)
{
    fbTemplate_t       *tmpl;
    fbInfoElement_t     newIE;
    scInfoElement_t    *schemaIE = NULL;
    GError             *error = NULL;

    tmpl = fbTemplateAlloc(fbSessionGetInfoModel(session));


    while ((schemaIE = scSchemaGetNextInfoElement(schema, schemaIE))) {
        memset(&newIE, 0, sizeof(fbInfoElement_t));

        newIE.ent = schemaIE->ent;
        newIE.num = schemaIE->id;

        if (scInfoElementIsVarlen(schemaIE)) {
            newIE.len = FB_IE_VARLEN;
        } else {
            newIE.len = scInfoElementGetLength(schemaIE);
        }

        if (!fbTemplateAppend(tmpl, &newIE, &error)) {
            printf("couldn't add element %s\n", error->message);
            g_clear_error(&error);
            return NULL;
        }
    }

    return tmpl;
}

void printMgmt(
    scSchemaTemplateMgmt_t *mgmt)
{
    uint32_t    i;
    scSchemaTemplate_t *tas;
    printf("Num Schemas: %d\n", mgmt->numSchemas);
    for (i = 0, tas = mgmt->head;
         i < mgmt->numSchemas;
         i++, tas++) {
        printf("tid: %d, schema %p\n", tas->tid, tas->schema);
    }
}



scSchemaTemplateMgmt_t* scSchemaTemplateMgmtInit(
    int isInput)
{
    scSchemaTemplateMgmt_t *mgmt = calloc(1, sizeof(scSchemaTemplateMgmt_t));
    mgmt->isInput = isInput;
    return mgmt;
}

int scSchemaTemplateMgmtAdd(
    scSchemaTemplateMgmt_t *mgmt,
    scSchema_t             *schema,
    uint16_t                tid)
{
    scSchemaTemplate_t *tas;
    int i;

    if (!schema || !tid) {
        return 1;
    }

    if (!mgmt->isInput) {
        for (i = 0, tas = mgmt->head;
             i < mgmt->numSchemas;
             i++, tas++)
        {
            if (tas->schema == schema) {
                if (tas->schema->id != schema->id) {
                    printf("pointers match, ids don't...this is weird\n");
                }
                tas->tid = tid;
                return 0;
            }

            if (tas->schema->id == schema->id) {
                tas->tid = tid;
                return 0;
            }
        }
    } else {
        for (i = 0, tas = mgmt->head;
             i < mgmt->numSchemas;
             i++, tas++)
        {
            if (tas->tid == tid) {
                tas->schema = schema;
                return 0;
            }
        }
    }

    mgmt->head = realloc(mgmt->head, sizeof(scSchemaTemplate_t) *
                                        (mgmt->numSchemas + 1));

    tas = mgmt->head + mgmt->numSchemas;
    tas->schema = schema;
    tas->tid = tid;

    mgmt->numSchemas++;

    return 0;
}

void scSchemaTemplateMgmtRemoveByTid(
    scSchemaTemplateMgmt_t *mgmt,
    uint16_t                tid)
{
    uint32_t                i;
    uint32_t                j;
    scSchemaTemplate_t     *tas;

    for (i = 0, tas = mgmt->head;
         i < mgmt->numSchemas;
         i++, tas++)
    {
        if (tas->tid == tid) {
            for (j = i; j < (mgmt->numSchemas-1); j++) {
                mgmt->head[j].tid = mgmt->head[j+1].tid;
                mgmt->head[j].schema = mgmt->head[j+1].schema;
            }

            mgmt->numSchemas--;
            return;
        }
    }
}

void scSchemaTemplateMgmtRemoveBySchema(
    scSchemaTemplateMgmt_t *mgmt,
    scSchema_t             *schema)
{
    uint32_t                i;
    uint32_t                j;
    scSchemaTemplate_t     *tas;

    for (i = 0, tas = mgmt->head;
         i < mgmt->numSchemas;
         i++, tas++)
    {
        if (tas->schema->id == schema->id) {
            for (j = i; j < (mgmt->numSchemas-1); j++) {
                mgmt->head[j].tid = mgmt->head[j+1].tid;
                mgmt->head[j].schema = mgmt->head[j+1].schema;
            }

            mgmt->numSchemas--;
            return;
        }
    }
}

void scSchemaTemplateMgmtFree(
    scSchemaTemplateMgmt_t *mgmt)
{
    if (mgmt) {
        if (mgmt->head) {
            free(mgmt->head);
        }
        free(mgmt);
    }
}

scSchema_t* scSchemaTemplateMgmtGetSchemaForTid(
    scSchemaTemplateMgmt_t  *mgmt,
    uint16_t                tid)
{
    uint32_t                i;
    scSchemaTemplate_t     *tas;

    for (i = 0, tas = mgmt->head;
         i < mgmt->numSchemas;
         i++, tas++)
    {
        if (tas->tid == tid) {
            return tas->schema;
        }
    }

    return NULL;
}

uint16_t scSchemaTemplateMgmtGetTidForSchema(
    scSchemaTemplateMgmt_t *mgmt,
    scSchema_t             *schema)
{
    uint32_t                i;
    scSchemaTemplate_t     *tas;

    for (i = 0, tas = mgmt->head;
         i < mgmt->numSchemas;
         i++, tas++)
    {
        if (tas->schema->id == schema->id) {
            return tas->tid;
        }
    }

    return 0;
}

/* does nothing */
uint32_t fixbufConnNextInputOneAndDone(
    void **schemaStateBlob)
{
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;
    if (!schemaState) {
        printf("not properly initialized during get info\n");
        return 0;
    }

    /* if this is the 2nd time it's called, quit */
    if (schemaState->nextInputIter) {
        return 0;
    }

    schemaState->nextInputIter = 1;

    return 1;
}

uint32_t fileListFixbufConnNextInputSameSchemas(
    void **schemaStateBlob)
{
    scFileList_t       *fileList;
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;
    GError             *gError = NULL;
    if (!schemaState) {
        printf("not properly initialized during get info\n");
        return 0;
    }

    fileList = &schemaState->scConnSpec->connInfo.fileList;

    if (fileList->currentFile == 0) {
        fileList->currentFile++;
        return 1;
    }


    /* cleanup the old fBuf */
    scFBufSessionAndStateRemove(fBufGetSession(schemaState->collectorBuf));
    fBufFree(schemaState->collectorBuf);
    schemaState->collectorBuf = NULL;
    schemaState->collectorSession = NULL;
    schemaState->fBufSession = NULL;


    if (fileList->currentFile == fileList->numFiles) {
        return 0;
    }

    schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

    /* get collector for the new file */
    schemaState->collector = fbCollectorAllocFile(NULL,
                            fileList->filenames[fileList->currentFile],
                            &gError);

    fileList->currentFile++;

    /* get the fBuf for the new file reader */
    schemaState->collectorBuf = fBufAllocForCollection(
                                                schemaState->collectorSession,
                                                schemaState->collector);

    /* store the session just cuz for now */
    schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
    scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

    /* set the fBuf to automatically insert custom element type records
     * to the info model */
    fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

    fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                            justAddNewSchemasInternalTemplatesTemplateCallback);

    return 1;
}

uint32_t pollDirFixbufConnNextInputSameSchemas(
    void **schemaStateBlob)
{
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;
    GError             *gError = NULL;
    scDirPoll_t        *dirPoll = &schemaState->scConnSpec->connInfo.pollDir;
    skPollDirErr_t      pderr;
    const char *c;
    char        path[300];
    int         rv;

    if (!schemaState) {
        printf("not properly initialized during get info\n");
        return 0;
    }

    if (!schemaState->nextInputIter) {
        schemaState->nextInputIter = 1;
        return 1;
    }

    if (dirPoll->currentFile[0]) {
        if (dirPoll->archiveDir) {
            c = strrchr(dirPoll->currentFile, '/');
            if (c) {
                c++;
            } else {
                c = dirPoll->currentFile;
            }

            rv = snprintf(path, sizeof(path), "%s/%s",
                          dirPoll->archiveDir, c);
            rv = rename(dirPoll->currentFile, path);
            if (rv != 0) {
                unlink(dirPoll->currentFile);
            }
        } else {
            if (unlink(dirPoll->currentFile) == -1) {
            }
        }

        /* cleanup the old fBuf */
        scFBufSessionAndStateRemove(fBufGetSession(schemaState->collectorBuf));
        fBufFree(schemaState->collectorBuf);
        schemaState->collectorBuf = NULL;
        schemaState->collectorSession = NULL;
        schemaState->fBufSession = NULL;

        memset(dirPoll->currentFile, 0, 200);
    }

    pderr = skPollDirGetNextFile(dirPoll->pollDir, dirPoll->currentFile, NULL);

    switch (pderr) {
      case PDERR_TIMEDOUT:
        return 2;
      case PDERR_MEMORY:
      case PDERR_SYSTEM:
      case PDERR_STOPPED:
        return 0;
      case PDERR_NONE:

        schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

        /* get collector for the new file */
        schemaState->collector = fbCollectorAllocFile(NULL,
                                dirPoll->currentFile,
                                &gError);

        /* get the fBuf for the new file reader */
        schemaState->collectorBuf = fBufAllocForCollection(
                                                schemaState->collectorSession,
                                                schemaState->collector);

        /* store the session just cuz for now */
        schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
        scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

        /* set the fBuf to automatically insert custom element type records
         * to the info model */
        fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

        fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                            justAddNewSchemasInternalTemplatesTemplateCallback);

        return 1;
    }

    return 0;
}

uint32_t fileListFixbufConnNextInputRedoSchemas(
    void **schemaStateBlob)
{
    scFileList_t       *fileList;
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;
    GError             *gError = NULL;
    if (!schemaState) {
        printf("not properly initialized during get info\n");
        return 0;
    }

    fileList = &schemaState->scConnSpec->connInfo.fileList;

    if (fileList->currentFile == 0) {
        fileList->currentFile++;
        return 1;
    }


    /* cleanup the old fBuf */
    scFBufSessionAndStateRemove(fBufGetSession(schemaState->collectorBuf));
    fBufFree(schemaState->collectorBuf);
    schemaState->collectorBuf = NULL;
    schemaState->collectorSession = NULL;
    schemaState->fBufSession = NULL;


    if (fileList->currentFile == fileList->numFiles) {
        return 0;
    }

    scDataInfoFreeContents(schemaState->dataInfo);

    scSchemaTemplateMgmtFree(schemaState->mgmt);
    schemaState->mgmt = NULL;
    schemaState->mgmt = scSchemaTemplateMgmtInit(1);

    schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

    /* get collector for the new file */
    schemaState->collector = fbCollectorAllocFile(NULL,
                            fileList->filenames[fileList->currentFile],
                            &gError);

    fileList->currentFile++;

    /* get the fBuf for the new file reader */
    schemaState->collectorBuf = fBufAllocForCollection(
                                                schemaState->collectorSession,
                                                schemaState->collector);

    /* store the session just cuz for now */
    schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
    scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

    /* set the fBuf to automatically insert custom element type records
     * to the info model */
    fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

    fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                                    makeNewSchemasTemplateCallback);

    return 1;
}

uint32_t pollDirFixbufConnNextInputRedoSchemas(
    void **schemaStateBlob)
{
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;
    GError             *gError = NULL;
    scDirPoll_t        *dirPoll = &schemaState->scConnSpec->connInfo.pollDir;
    skPollDirErr_t      pderr;
    const char *c;
    char        path[300];
    int         rv;
    if (!schemaState) {
        printf("not properly initialized during get info\n");
        return 0;
    }

    if (!schemaState->nextInputIter) {
        schemaState->nextInputIter = 1;
        return 1;
    }

    /* cleanup the old fBuf */
    scFBufSessionAndStateRemove(fBufGetSession(schemaState->collectorBuf));
    fBufFree(schemaState->collectorBuf);
    schemaState->collectorBuf = NULL;
    schemaState->collectorSession = NULL;
    schemaState->fBufSession = NULL;

    if (dirPoll->archiveDir) {
        c = strrchr(dirPoll->currentFile, '/');
        if (c) {
            c++;
        } else {
            c = dirPoll->currentFile;
        }

        rv = snprintf(path, sizeof(path), "%s/%s",
                      dirPoll->archiveDir, c);
        rv = rename(dirPoll->currentFile, path);
        if (rv != 0) {
            printf("Could not move '%s' to '%s': %s",
                   dirPoll->currentFile, path, strerror(rv));
        }
    } else {
        if (unlink(dirPoll->currentFile) == -1) {
            printf("Could not remove '%s': %s",
                       dirPoll->currentFile, strerror(errno));
        }
    }

    scDataInfoFreeContents(schemaState->dataInfo);

    scSchemaTemplateMgmtFree(schemaState->mgmt);
    schemaState->mgmt = NULL;
    schemaState->mgmt = scSchemaTemplateMgmtInit(1);

    schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

    /* get collector for the new file */

    memset(dirPoll->currentFile, 0, 200);

    while (PDERR_TIMEDOUT ==(pderr = skPollDirGetNextFile(dirPoll->pollDir,
                                                dirPoll->currentFile, NULL)))
    {
    }

    if (pderr != PDERR_NONE) {
        return 1;
    }

    schemaState->collector = fbCollectorAllocFile(NULL,
                            dirPoll->currentFile,
                            &gError);

    /* get the fBuf for the new file reader */
    schemaState->collectorBuf = fBufAllocForCollection(
                                                schemaState->collectorSession,
                                                schemaState->collector);

    /* store the session just cuz for now */
    schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
    scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

    /* set the fBuf to automatically insert custom element type records
 *      * to the info model */
    fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

    fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                                    makeNewSchemasTemplateCallback);

    return 1;
}


/* get the next record from the stream, calling fBufNext at the core */
scDataInfoGetRecErr_t fixbufConnGNRC(
    void           *someStreamBlob,
    uint8_t        *buf,
    scSchema_t    **schemaUsed)
{
    GError *error = NULL;
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)someStreamBlob;
    uint16_t            thisTid = 0;
    gboolean            rc;
    size_t              theLen = schemaState->schemaLen;
    scSchema_t         *thisSchema;

    if (!schemaState->collectorBuf) {
        /* the collector buf doesn't exist, call nextInput */
        return SCGETNEXT_ERR_NOT_BOUND;
    }

    /* Get the template used to define the next record */
    if (!schemaState->nextTid) {
        if(!fBufNextCollectionTemplate(schemaState->collectorBuf,
                                       &thisTid,
                                       &error))
        {
            g_clear_error(&error);
            return SCGETNEXT_ERR_EOF;
        }
        schemaState->nextTid = thisTid;
    } else {
        thisTid = schemaState->nextTid;
    }

    /* for now we know that the associated internal templates have same IDS */
    rc = fBufSetInternalTemplate(schemaState->collectorBuf,
                                 thisTid,
                                 &error);

    thisSchema = scSchemaTemplateMgmtGetSchemaForTid(schemaState->mgmt,
                                                     thisTid);

    if (!thisSchema) {
        schemaState->nextTid = 0;
        return SCGETNEXT_ERR_EOF;
    }

    theLen = thisSchema->len;

    schemaState->nextTid = 0;
    /* get the next record */
    if (fBufNext(schemaState->collectorBuf,
                 buf,
                 &theLen,
                 &(schemaState->error)))
    {
        *schemaUsed = thisSchema;
        schemaState->lastTid = thisTid;
        schemaState->lastSchema = *schemaUsed;

        return SCGETNEXT_OK;
    } else {
        if (strncmp(schemaState->error->message, "End of file",
             strlen("End of file")))
        {
        }

        g_clear_error(&(schemaState->error));
        return SCGETNEXT_ERR_EOF;
    }
}

void* fixbufConnGNRP(
    void           *someStreamBlob,
    scSchema_t    **schemaUsed)
{
    GError *error = NULL;
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)someStreamBlob;
    uint16_t            thisTid = 0;
    gboolean            rc;
    size_t              theLen;
    scSchema_t         *thisSchema = NULL;

    if (!schemaState->collectorBuf) {
        /* the collector buf doesn't exist, call nextInput */
        return NULL;
    }

    /* Get the template used to define the next record */
    if (!schemaState->nextTid) {
        if(!fBufNextCollectionTemplate(schemaState->collectorBuf,
                                       &thisTid,
                                       &error))
        {
            g_clear_error(&error);
            return NULL;
        }
        schemaState->nextTid = thisTid;
    } else {
        thisTid = schemaState->nextTid;
    }

    /* for now we know that the associated internal templates have same IDS */
    rc = fBufSetInternalTemplate(schemaState->collectorBuf,
                                 thisTid,
                                 &error);
    if (!rc) {
        g_clear_error(&error);
        schemaState->nextTid = 0;
        return NULL;
    }

    thisSchema = scSchemaTemplateMgmtGetSchemaForTid(schemaState->mgmt,
                                                     thisTid);

    if (!thisSchema) {
        schemaState->nextTid = 0;
        return NULL;
    }

    theLen = thisSchema->len;
    schemaState->nextTid = 0;

    /* get the next record */
    if (fBufNext(schemaState->collectorBuf,
                 thisSchema->recForPtr,
                 &theLen,
                 &(schemaState->error)))
    {
        *schemaUsed = thisSchema;
        schemaState->lastTid = thisTid;
        schemaState->lastSchema = *schemaUsed;

        return thisSchema->recForPtr;
    } else {
        if (strncmp(schemaState->error->message, "End of file",
             strlen("End of file")))
        {
        }

        g_clear_error(&(schemaState->error));
        return NULL;
    }

    return NULL;
}

uint32_t fixbufConnWriteRecord(
    void           *outState,
    scSchema_t     *schema,
    const uint8_t  *buf,
    uint32_t        length)
{
    outIpfixSchemaState_t  *state = (outIpfixSchemaState_t*)outState;
    uint16_t                tid;
    GError                 *error;
    int                     rc;

/*    if (state->lastSchema == schema) {

        tid = state->lastTid;
    } else {*/
    /* always lookup the outgoing template */
    tid = scSchemaTemplateMgmtGetTidForSchema(state->mgmt, schema);
/*    }*/

    if (!tid) {
        return 0;
    }

    if (!fBufSetInternalTemplate(state->exporterBuf, tid, &error)) {
        printf("couldn't set internal template: %s\n", error->message);
        g_clear_error(&error);
    }

    if (!fBufSetExportTemplate(state->exporterBuf, tid, &error)) {
        printf("couldn't set external template: %s\n", error->message);
        g_clear_error(&error);
    }

    error = NULL;
    rc = fBufAppend(state->exporterBuf, (uint8_t*)buf, length, &error);
    if (!rc) {
        printf("error appending %s\n", error->message);
        g_clear_error(&error);
        return 0;
    } else {
    }

    fBufEmit(state->exporterBuf, &error);

    return length;
}

scSchema_t* fixbufConnGetNextSchema(
    void           *someStreamBlob)
{
    GError *error = NULL;
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)someStreamBlob;
    uint16_t            thisTid = 0;

    if (!schemaState->collectorBuf) {
        /* the collector buf doesn't exist, call nextInput */
        return NULL;
    }

    /* Get the template used to define the next record */
    if (!schemaState->nextTid) {
        if(!fBufNextCollectionTemplate(schemaState->collectorBuf,
                                       &thisTid,
                                       &error))
        {
            g_clear_error(&error);
            return NULL;
        }
        schemaState->nextTid = thisTid;
    } else {
        thisTid = schemaState->nextTid;
    }

    schemaState->lastSchema = scSchemaTemplateMgmtGetSchemaForTid(
                                              schemaState->mgmt, thisTid);
    schemaState->lastTid = thisTid;
    return schemaState->lastSchema;
}

/* fixbuf template callback that runs when we receive a template
 * this function is responsible for parsing templates and creating schemas */

/* can I really get away with one version of this function...??? */
void makeNewSchemasTemplateCallback(
    fbSession_t    *session,
    uint16_t        tid,
    fbTemplate_t   *tmpl)
{
    uint32_t                numIEs;
    uint32_t                i;
    const fbInfoElement_t  *ie;
    const fbInfoElement_t  *ieForInternal;
    uint16_t                collectorTemplateID;
    GError                 *error = NULL;
    scSchema_t             *schema;
    fbTemplate_t           *newTemplate;
    scError_t               scError;
    ipfixSchemaState_t     *thisState;
    char                    schemaName[50];

    /* if this template is for sending custom IPFIX elements, ignore it */
    if (fbInfoModelTypeInfoRecord(tmpl)) {
        return;
    }

    thisState = scGetSchemaStateForFBufSession(session);

    if (fbTemplateCountElements(tmpl) == 0) {
        schema = scSchemaTemplateMgmtGetSchemaForTid(thisState->mgmt, tid);
        if (!schema) {
            /* no schema for thie empty template...weird...but nothing to do */
            return;
        }

        scSchemaTemplateMgmtRemoveByTid(thisState->mgmt, tid);
        if (scDataInfoRemoveSchema(thisState->dataInfo, schema, &scError)) {
        }

        fbSessionRemoveTemplate(session, FALSE, tid, &error);
        fbSessionRemoveTemplate(session, TRUE, tid, &error);
        return;
    }

    sprintf(schemaName, "%d", tid);

    schema = scFixbufTemplateToSchema(session, tmpl, tid, schemaName, &scError);

    if (schema) {
        if (scSchemaTemplateMgmtGetSchemaForTid(thisState->mgmt, tid)) {
            scSchemaTemplateMgmtRemoveByTid(thisState->mgmt, tid);
        }

        scSchemaTemplateMgmtAdd(thisState->mgmt, schema, tid);

        /* add the new schema to the data info */
        if (scDataInfoAddSchema(thisState->dataInfo, schema, &scError)) {
        }
    } else {
        return;
    }

    /* we need to build an internal template as well, so we decode
     * every element that arrives
     */
    newTemplate = fbTemplateAlloc(fbSessionGetInfoModel(session));

    numIEs = fbTemplateCountElements(tmpl);
    /* loop through the template's IEs */
    for (i = 0; i < numIEs; i++) {
        ie = fbTemplateGetIndexedIE(tmpl, i);
        if (ie->ent == 0 && ie->num == 210) {
            continue;
        }
        /* add this IE to the new internal template */

        ieForInternal = fbInfoModelGetElementByID(thisState->infoModel,
                                                  ie->num, ie->ent);
        if (!ieForInternal) {
            continue;
        }

        if (ieForInternal->len == FB_IE_VARLEN && ie->len != FB_IE_VARLEN) {
            fbInfoElementSpec_t    *spec = calloc(1, sizeof(fbInfoElementSpec_t));
            spec->name = strdup(ie->ref.canon->ref.name);
            spec->len_override = ie->len;
            spec->flags = 0;

            if (!fbTemplateAppendSpec(newTemplate, spec, 0, &error)) {
                g_clear_error(&error);
            }
            free(spec->name);
            free(spec);
        } else {
            if (!fbTemplateAppend(newTemplate,
                                  (fbInfoElement_t*)ieForInternal,
                                  &error))
            {
            }
        }
    }
    /* add the newly created template as an internal template */
    collectorTemplateID = fbSessionAddTemplate(session,
                                               TRUE, tid,
                                               newTemplate,
                                               &error);
    if (!collectorTemplateID) {
        g_clear_error(&error);
    }
    /* set internal template */
}

void justAddNewSchemasInternalTemplatesTemplateCallback(
    fbSession_t    *session,
    uint16_t        tid,
    fbTemplate_t   *tmpl)
{
    uint32_t                numIEs;
    uint32_t                i;
    const fbInfoElement_t  *ie;
    uint16_t                collectorTemplateID;
    GError                 *error = NULL;
    fbTemplate_t           *newTemplate;
    ipfixSchemaState_t     *thisState;
    scSchema_t             *schema;
    scError_t               scError;
    char                    schemaName[50];

    /* if this template is for sending custom IPFIX elements, ignore it */
    if (fbInfoModelTypeInfoRecord(tmpl)) {
        return;
    }

    thisState = scGetSchemaStateForFBufSession(session);

    if (fbTemplateCountElements(tmpl) == 0) {
        schema = scSchemaTemplateMgmtGetSchemaForTid(thisState->mgmt, tid);
        if (!schema) {
            /* no schema for thie empty template...weird...but nothing to do */
            return;
        }

        scSchemaTemplateMgmtRemoveByTid(thisState->mgmt, tid);
        if (scDataInfoRemoveSchema(thisState->dataInfo, schema, &scError)) {
        }

        fbSessionRemoveTemplate(session, FALSE, tid, &error);
        fbSessionRemoveTemplate(session, TRUE, tid, &error);
        return;
    }

    sprintf(schemaName, "%d", tid);

    if (!scSchemaTemplateMgmtGetSchemaForTid(thisState->mgmt, tid)) {

        schema = scFixbufTemplateToSchema(session, tmpl, tid, schemaName, &scError);

        if (schema) {
            scSchemaTemplateMgmtRemoveByTid(thisState->mgmt, tid);

            scSchemaTemplateMgmtAdd(thisState->mgmt, schema, tid);

            /* add the new schema to the data info */
            if (scDataInfoAddSchema(thisState->dataInfo, schema, &scError)) {
            }
        } else {
            return;
        }
    }

    /* we need to build an internal template as well, so we decode
     * every element that arrives
     */
    newTemplate = fbTemplateAlloc(fbSessionGetInfoModel(session));

    numIEs = fbTemplateCountElements(tmpl);
    /* loop through the template's IEs */
    for (i = 0; i < numIEs; i++) {
        ie = fbTemplateGetIndexedIE(tmpl, i);
        if (ie->ent == 0 && ie->num == 210) {
            continue;
        }
        /* add this IE to the new internal template */
        if (!fbTemplateAppend(newTemplate,
                              (fbInfoElement_t*)ie,
                              &error))
        {
        }
    }
    /* add the newly created template as an internal template */
    collectorTemplateID = fbSessionAddTemplate(session,
                                               TRUE, tid,
                                               newTemplate,
                                               &error);
    /* set internal template */
}

uint32_t getFixbufConnObservationDomain(
    void   *schemaState)
{
    ipfixSchemaState_t *state = (ipfixSchemaState_t*)schemaState;

    if (state->collectorBuf) {
        return fbCollectorGetObservationDomain(
                        fBufGetCollector(state->collectorBuf));
    }

    return -1;
}

struct sockaddr* getFixbufConnPeerSocket(
    void   *schemaState)
{
    ipfixSchemaState_t *state = (ipfixSchemaState_t*)schemaState;
    if (!state) {
        printf("null state\n");
        return NULL;
    }

    if (!state->scConnSpec) {
        printf("null conn spec\n");
        return NULL;
    }


    if (state->scConnSpec->type == SC_CS_TCP ||
        state->scConnSpec->type == SC_CS_UDP)
    {
        return fbCollectorGetPeer(state->collector);
    }

    printf("returning null\n");
    return NULL;
}

int getFixbufConnCurrentInputName(
    void   *schemaState,
    char   *buf,
    size_t  len)
{
    ipfixSchemaState_t *theState = (ipfixSchemaState_t*)schemaState;
    scConnSpec_t       *theSpec;

    theSpec = theState->scConnSpec;

    switch (theSpec->type) {
      case SC_CS_NONE:  return snprintf(buf, len, "No Input Selected");
      case SC_CS_TCP:   return snprintf(buf, len, "IPFIX TCP: Hostname: %s. Port: %s",
                                        theSpec->connInfo.socket.hostname,
                                        theSpec->connInfo.socket.portStr);
      case SC_CS_UDP:   return snprintf(buf, len, "IPFIX UDP: Hostname: %s. Port: %s",
                                        theSpec->connInfo.socket.hostname,
                                        theSpec->connInfo.socket.portStr);
      case SC_CS_POLL_DIR: return snprintf(buf, len, "IPFIX File: %s",
                            theSpec->connInfo.pollDir.currentFile);
      case SC_CS_DIRECTORY:
      case SC_CS_FILELIST_INPUT:
        /* the current file is actually one ahead from initializion cleverness
         * so we need to subtract one unless it's 0 */
        if (theSpec->connInfo.fileList.currentFile) {
                        return snprintf(buf, len, "IPFIX File: %s",
                               theSpec->connInfo.fileList.filenames[
                               theSpec->connInfo.fileList.currentFile-1]);
        } else {
            return snprintf(buf, len, "IPFIX File: %s",
                               theSpec->connInfo.fileList.filenames[
                               theSpec->connInfo.fileList.currentFile]);
        }
      case SC_CS_STANDARD_IN:
            return snprintf(buf, len, "Standard In");
      default:
            return snprintf(buf, len, "Invalid conn spec");
    }

    return 0;
}

int getAnyFixbufConnection(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *error)
{
    if (connSpec->redoOrSame == SC_CS_SAME_SCHEMAS) {
        switch (connSpec->type) {
          case SC_CS_UDP:
          case SC_CS_TCP:
            return getSocketFixbufConnection(connSpec, inDataInfo,
                                             potentialState, infoModel,
                                             IMFreedByConnection, error);
            break;
          case SC_CS_FILELIST_INPUT:
          case SC_CS_DIRECTORY:
            return getFileListFixbufConnectionSameSchemas(connSpec,
                                                            inDataInfo,
                                                            potentialState,
                                                            infoModel,
                                                        IMFreedByConnection,
                                                            error);
            break;
          case SC_CS_POLL_DIR:
            return getPollFileDirFixbufConnectionSameSchemas(connSpec,
                                                               inDataInfo,
                                                               potentialState,
                                                               infoModel,
                                                            IMFreedByConnection,
                                                               error);
          default:
            return 1;
            break;
        }
    } else {
        switch (connSpec->type) {
          case SC_CS_UDP:
          case SC_CS_TCP:
            return getSocketFixbufConnection(connSpec, inDataInfo,
                                             potentialState, infoModel,
                                             IMFreedByConnection, error);
            break;
          case SC_CS_FILELIST_INPUT:
          case SC_CS_DIRECTORY:
            return getFileListFixbufConnection(connSpec, inDataInfo,
                                             potentialState, infoModel,
                                             IMFreedByConnection, error);
            break;
          case SC_CS_POLL_DIR:
            return getPollFileDirFixbufConnection(connSpec, inDataInfo,
                                                  potentialState,
                                                  infoModel,
                                                  IMFreedByConnection,
                                                  error);
          default:
            return 1;
            break;
        }
    }
}

int getSocketFixbufConnection(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *error)
{
    ipfixSchemaState_t *schemaState;
    GError             *gError = NULL;
    scDataInfo_t       *theDataInfo = NULL;

    if (!error) {
        return 1;
    }

    scErrorClear(error);

    if (!connSpec || !inDataInfo || !potentialState) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("NULL parameter passed to SocketFixbufConnection\n");
        return 1;
    }

    if (connSpec->type != SC_CS_TCP &&
        connSpec->type != SC_CS_UDP)
    {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Connection specification must be for a socket\n");
        /* invalid conn spec */
        return 1;
    }

    if (!*potentialState) {
        if (*inDataInfo) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("In Data info isn't null for creation of new schema state\n");
            return 1;
        }
        *potentialState = newIpfixSchemaState();
        schemaState = *potentialState;


        if (connSpec->type == SC_CS_TCP) {
            schemaState->socketDef.transport = FB_TCP;
        } else {
            schemaState->socketDef.transport = FB_UDP;
        }
        schemaState->socketDef.host = connSpec->connInfo.socket.hostname;

        schemaState->socketDef.svc = connSpec->connInfo.socket.portStr;

        schemaState->socketDef.ssl_ca_file = NULL;
        schemaState->socketDef.ssl_cert_file = NULL;
        schemaState->socketDef.ssl_key_file = NULL;
        schemaState->socketDef.ssl_key_pass = NULL;
        schemaState->socketDef.vai = NULL;
        schemaState->socketDef.vssl_ctx = NULL;

        /* start Fixbuf specific stuff...get an info model */
        if (infoModel) {
            schemaState->IMFreedByConnection = IMFreedByConnection;
            schemaState->infoModel = infoModel;
        } else {
            schemaState->infoModel = fbInfoModelAlloc();
            schemaState->IMFreedByConnection = 1;
        }

        /* get a collector session from that model */
        schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

        schemaState->collectorListener = fbListenerAlloc(
                                                &(schemaState->socketDef),
                                                schemaState->collectorSession,
                                                NULL, NULL, &gError);

        if (!schemaState->collectorListener) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR1("Couldn't create listener: %s\n", gError->message);
            g_clear_error(&gError);
            return 1;
        }

        schemaState->scConnSpec = scConnSpecCopy(connSpec);
    } else {
        schemaState = *potentialState;
        scFBufSessionAndStateRemove(schemaState->fBufSession);

        fBufFree(schemaState->collectorBuf);
        schemaState->collectorBuf = NULL;
        schemaState->fBufSession = NULL;
        schemaState->collectorBuf = NULL;
        schemaState->nextInputIter = 0;
        schemaState->lastTid = 0;
        schemaState->lastSchema = NULL;
        scSchemaTemplateMgmtFree(schemaState->mgmt);
        schemaState->mgmt = NULL;

        if (*inDataInfo != schemaState->dataInfo) {
            printf("data infos don't line up...wtf???\n");
        }
        scDataInfoFree(schemaState->dataInfo);
        *inDataInfo = NULL;
        schemaState->dataInfo = NULL;
    }

    schemaState->mgmt = scSchemaTemplateMgmtInit(1);

    /* regardless of first or next, we need new data info, and need to reset
     * the pointer from the user */
    *inDataInfo = scDataInfoAlloc();
    theDataInfo = *inDataInfo;
    theDataInfo->infoModel = schemaState->infoModel;
    schemaState->dataInfo = *inDataInfo;

    schemaState->collectorBuf = fbListenerWait(schemaState->collectorListener,
                                               &gError);

    if (!schemaState->collectorBuf) {
        error->code = SC_ERROR_WARNING;
        /* double check this was from the interrupt */
        g_clear_error(&gError);
        ERR0("Get Next Connection got interrupted, shutting down cleanly\n");
        return 1;
    }

    schemaState->collector = fBufGetCollector(schemaState->collectorBuf);
    schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
    scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

    /* set the fBuf to automatically insert custom element type records
     * to the info model */
    fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

    /* set the schema builder template callback to be run with new templates
     * arrive */
    fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                                                makeNewSchemasTemplateCallback);

    /* make fixbuf look for the next collection template.
     * this forces it to process all of the templates, which yields the
     * callback, so we get our schemas
     */
    fBufNextCollectionTemplate(schemaState->collectorBuf, NULL, &gError);

    /* now that we have everything, fill in the data info struct */
    scDataInfoFillAsInput(theDataInfo,
                    fixbufConnNextInputOneAndDone,
                    fixbufConnGNRC,
                    fixbufConnGNRP,
                    fixbufConnGetNextSchema,
                    error);

    /* set the max record length */
    schemaState->schemaLen = scDataInfoGetMaxRecordLength(theDataInfo);

    return 0;
}

void freeIpfixSchemaState(
    void  **schemaStateBlob)
{
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;
    if (!schemaState) {
        return;
    }

    if (schemaState->collectorBuf) {
        fBufFree(schemaState->collectorBuf);
        schemaState->collectorBuf = NULL;
    }

    if (schemaState->collectorListener) {
        fbListenerFree(schemaState->collectorListener);
        schemaState->collectorListener = NULL;
    }

    if (schemaState->IMFreedByConnection && schemaState->infoModel) {
        fbInfoModelFree(schemaState->infoModel);
        schemaState->infoModel = NULL;
    }

    if (schemaState->mgmt) {
        scSchemaTemplateMgmtFree(schemaState->mgmt);
        schemaState->mgmt = NULL;
    }

    if (schemaState->dataInfo) {
        scDataInfoFree(schemaState->dataInfo);
        schemaState->dataInfo = NULL;
    }

    if (schemaState->collectorSession) {
        fbSessionFree(schemaState->collectorSession);
        schemaState->collectorSession = NULL;
    }

    if (schemaState->scConnSpec) {
        scConnSpecFree(schemaState->scConnSpec);
        schemaState->scConnSpec = NULL;
    }


    free(schemaState);

    *schemaStateBlob = NULL;
}

void freeAnyOutgoingFixbufConnection(
    void  **outStateBlob)
{
    outIpfixSchemaState_t  *schemaState = (outIpfixSchemaState_t*)*outStateBlob;
    GError                 *error;

    /* clean up connection before freeing and stopping */
    switch (schemaState->scConnSpec->type) {
      case SC_CS_FILE_OUTPUT:
        fBufEmit(schemaState->exporterBuf, &error);
        break;
      case SC_CS_TCP:
      case SC_CS_UDP:
        fBufEmit(schemaState->exporterBuf, &error);
        break;
      default:
        printf("INvalid connection type for outgoing\n");
        break;
    }
    if (schemaState->exporterBuf) {
        fBufFree(schemaState->exporterBuf);
    }

    if (schemaState->IMFreedByConnection && schemaState->infoModel) {
        fbInfoModelFree(schemaState->infoModel);
    }

    if (schemaState->mgmt) {
        scSchemaTemplateMgmtFree(schemaState->mgmt);
    }

    if (schemaState->outDataInfo) {
        scDataInfoFree(schemaState->outDataInfo);
    }

    scConnSpecFree(schemaState->scConnSpec);

    free(schemaState);
    *outStateBlob = NULL;
}

void fixbufSocketConnectionInterrupt(
    void  **schemaStateBlob)
{
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;

    fbListenerInterrupt(schemaState->collectorListener);
}

void fixbufPollDirConnectionInterrupt(
    void  **schemaStateBlob)
{
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;

    skPollDirStop(schemaState->scConnSpec->connInfo.pollDir.pollDir);
}

void fixbufAnyConnectionInterrupt(
    void  **schemaStateBlob)
{
    ipfixSchemaState_t *schemaState = (ipfixSchemaState_t*)*schemaStateBlob;
    switch (schemaState->scConnSpec->type) {
      case SC_CS_UDP:
      case SC_CS_TCP:
        fixbufSocketConnectionInterrupt(schemaStateBlob);
        break;
      case SC_CS_POLL_DIR:
        fixbufPollDirConnectionInterrupt(schemaStateBlob);
        break;
      default:
        break;
    }
}


void freeAnyIncomingFixbufConnection(
    void          **schemaStateBlob)
{
    freeIpfixSchemaState(schemaStateBlob);
}

int getPollFileDirFixbufConnection(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *error)
{
    ipfixSchemaState_t *schemaState;
    GError             *gError = NULL;
    skPollDirErr_t      pderr;
    scDataInfo_t       *theDataInfo = NULL;
    scDirPoll_t        *dirPoll = NULL;

    scErrorClear(error);

    if (!connSpec || !inDataInfo || !potentialState) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("NULL parameter passed to PollFileDirFixbufConnection\n");
        return 1;
    }

    if (connSpec->type != SC_CS_POLL_DIR)
    {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Connection specification must be for a poll file directory\n");
        return 1;
    }

    if (connSpec->connInfo.pollDir.directory == NULL) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("There is no directory to poll\n");
        return 1;
    }

    dirPoll = &connSpec->connInfo.pollDir;

    if (*potentialState) {
        schemaState = *potentialState;
        /* clear out all of the old stuff */
        scDataInfoFree(*inDataInfo);
        schemaState->dataInfo = NULL;
        scFBufSessionAndStateRemove(fBufGetSession(schemaState->collectorBuf));
        fBufFree(schemaState->collectorBuf);
        schemaState->collectorBuf = NULL;
        schemaState->collectorSession = NULL;
        schemaState->fBufSession = NULL;
        scSchemaTemplateMgmtFree(schemaState->mgmt);
        schemaState->mgmt = NULL;
        /* delete the file that was just processed */
        if (dirPoll->archiveDir) {

        } else {
            remove(dirPoll->currentFile);
            memset(dirPoll->currentFile, 0, 200);
        }


    } else {
        /* start from the beginning */
        *potentialState = newIpfixSchemaState();
        schemaState = *potentialState;
        if (infoModel) {
            schemaState->IMFreedByConnection = IMFreedByConnection;
            schemaState->infoModel = infoModel;
        } else {
            schemaState->IMFreedByConnection = 1;
            schemaState->infoModel = fbInfoModelAlloc();
        }
        schemaState->scConnSpec = scConnSpecCopy(connSpec);

        dirPoll->pollDir = skPollDirCreate(dirPoll->directory,
                                           dirPoll->pollingInterval);
        if (!dirPoll->pollDir) {
            ERR0("Could not create directory poller\n");
            return 1;
        }

        if (dirPoll->timeoutSeconds) {
            skPollDirSetFileTimeout(dirPoll->pollDir, dirPoll->timeoutSeconds);
        }
        /* delete all of the old files that are there on startup */
        memset(dirPoll->currentFile, 0, 200);
        while ((skPollDirGetNextFile(dirPoll->pollDir, dirPoll->currentFile,
                NULL)
                == PDERR_NONE)) {
            remove(dirPoll->currentFile);
        }
    }

    schemaState->nextInputIter = 0;

    while (PDERR_TIMEDOUT ==(pderr = skPollDirGetNextFile(dirPoll->pollDir, dirPoll->currentFile, NULL))) {
    }

    if (pderr != PDERR_NONE) {
        ERR1("Error getting next file, %s\n", skPollDirStrError(pderr));
        return 1;
    }

    *inDataInfo = scDataInfoAlloc();
    theDataInfo = *inDataInfo;
    schemaState->dataInfo = *inDataInfo;

    schemaState->mgmt = scSchemaTemplateMgmtInit(1);
    /* get a collector session from that model */
    schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

    /* don't need a listener for file reading */
    schemaState->collectorListener = NULL;

    schemaState->collector = fbCollectorAllocFile(NULL,
                            dirPoll->currentFile,
                            &gError);

    schemaState->collectorBuf = fBufAllocForCollection(
                                                schemaState->collectorSession,
                                                schemaState->collector);

    schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
    if (schemaState->fBufSession == schemaState->collectorSession) {
        schemaState->collectorSession = NULL;
    }
    scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

    /* set the fBuf to automatically insert custom element type records
     * to the info model */
    fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

    /* set the schema builder template callback to be run with new templates
     * arrive */
    fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                                                makeNewSchemasTemplateCallback);

    fBufNextCollectionTemplate(schemaState->collectorBuf, NULL, &gError);

     scDataInfoFillAsInput(theDataInfo,
                    pollDirFixbufConnNextInputRedoSchemas,
                    fixbufConnGNRC,
                    fixbufConnGNRP,
                    fixbufConnGetNextSchema,
                    error);

    schemaState->schemaLen = scDataInfoGetMaxRecordLength(theDataInfo);

    return 0;
}

int getPollFileDirFixbufConnectionSameSchemas(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *error)
{
    ipfixSchemaState_t *schemaState;
    GError             *gError = NULL;
    skPollDirErr_t      pderr;
    scDataInfo_t       *theDataInfo = NULL;
    scDirPoll_t        *dirPoll = NULL;

    scErrorClear(error);

    if (!connSpec || !inDataInfo || !potentialState) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("NULL parameter passed to PollFileDirFixbufConnection\n");
        return 1;
    }

    if (connSpec->type != SC_CS_POLL_DIR)
    {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Connection specification must be for a poll file directory\n");
        return 1;
    }

    if (connSpec->connInfo.pollDir.directory == NULL) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("There is no directory to poll\n");
        return 1;
    }

    /* this function is only supposed to be called once,
       or at least to have things reset to be started again
     */
    if (*potentialState) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("State is not NULL. This function is only to be called once\n");
        return 1;
    }


    *potentialState = newIpfixSchemaState();
    schemaState = *potentialState;

    if (infoModel) {
        schemaState->IMFreedByConnection = IMFreedByConnection;
        schemaState->infoModel = infoModel;
    } else {
        schemaState->IMFreedByConnection = 1;
        schemaState->infoModel = fbInfoModelAlloc();
    }

    schemaState->scConnSpec = scConnSpecCopy(connSpec);

    dirPoll = &schemaState->scConnSpec->connInfo.pollDir;
    if (dirPoll->pollingInterval) {
        dirPoll->pollDir = skPollDirCreate(dirPoll->directory,
                                           dirPoll->pollingInterval);
    } else {
        dirPoll->pollDir = skPollDirCreate(dirPoll->directory, 15);
    }
    if (!dirPoll->pollDir) {
        ERR0("Could not create directory poller\n");
        return 1;
    }

    if (dirPoll->pollingTimeout) {
        skPollDirSetFileTimeout(dirPoll->pollDir, dirPoll->pollingTimeout);
    } else {
        skPollDirSetFileTimeout(dirPoll->pollDir, 1);
    }
    /* delete all of the old files that are there on startup */
    memset(dirPoll->currentFile, 0, 200);

    /* wait for a file, then build schemas from it */
    while (PDERR_TIMEDOUT ==(pderr = skPollDirGetNextFile(dirPoll->pollDir,
                                                dirPoll->currentFile, NULL)))
    {
    }


    if (pderr != PDERR_NONE) {
        ERR1("Error getting next file, %s\n", skPollDirStrError(pderr));
        return 1;
    }

    *inDataInfo = scDataInfoAlloc();
    theDataInfo = *inDataInfo;
    theDataInfo->infoModel = schemaState->infoModel;
    schemaState->dataInfo = *inDataInfo;

    schemaState->mgmt = scSchemaTemplateMgmtInit(1);
    /* get a collector session from that model */
    schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

    /* don't need a listener for file reading */
    schemaState->collectorListener = NULL;

    schemaState->collector = fbCollectorAllocFile(NULL,
                            dirPoll->currentFile,
                            &gError);

    schemaState->collectorBuf = fBufAllocForCollection(
                                                schemaState->collectorSession,
                                                schemaState->collector);

    schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
    if (schemaState->fBufSession == schemaState->collectorSession) {
        schemaState->collectorSession = NULL;
    }
    scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

    /* set the fBuf to automatically insert custom element type records
     * to the info model */
    fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

    /* set the schema builder template callback to be run with new templates
     * arrive */
    fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                                                makeNewSchemasTemplateCallback);

    fBufNextCollectionTemplate(schemaState->collectorBuf, NULL, &gError);

    /* do a bunch of stuff, then use: skPollDirPutBackFile()
    use nextinput to get new stuff for data.
    clear out the current files
    if the rest of the files don't match the first...we're boned */

    scDataInfoFillAsInput(theDataInfo,
                    pollDirFixbufConnNextInputSameSchemas,
                    fixbufConnGNRC,
                    fixbufConnGNRP,
                    fixbufConnGetNextSchema,
                    error);

    schemaState->schemaLen = scDataInfoGetMaxRecordLength(theDataInfo);

    schemaState->nextInputIter = 0;
    return 0;
}

int getFileListFixbufConnection(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *error)
{
    ipfixSchemaState_t *schemaState;
    GError             *gError = NULL;
    scDataInfo_t       *theDataInfo = NULL;
    scFileList_t       *fileList;

    scErrorClear(error);

    if (!connSpec || !inDataInfo || !potentialState) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("NULL parameter passed to FileListFixbufConnection\n");
        return 1;
    }

    if (connSpec->type != SC_CS_FILELIST_INPUT &&
        connSpec->type != SC_CS_DIRECTORY)
    {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Connection specification must be for a file list or directory\n");
        return 1;
    }

    if (connSpec->connInfo.fileList.numFiles == 0) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("There are no files in the file list\n");
        return 1;
    }

    fileList = &connSpec->connInfo.fileList;
    if (*potentialState) {
        schemaState = *potentialState;
        /* clear out all of the old stuff */
        scDataInfoFree(*inDataInfo);
        schemaState->dataInfo = NULL;
        scFBufSessionAndStateRemove(fBufGetSession(schemaState->collectorBuf));
        fBufFree(schemaState->collectorBuf);
        schemaState->collectorBuf = NULL;
        schemaState->collectorSession = NULL;
        schemaState->fBufSession = NULL;
        scSchemaTemplateMgmtFree(schemaState->mgmt);
        schemaState->mgmt = NULL;


        if (fileList->currentFile == fileList->numFiles) {
            return 1;
        }

    } else {
        /* start from the beginning */
        *potentialState = newIpfixSchemaState();
        schemaState = *potentialState;
        if (infoModel) {
            schemaState->IMFreedByConnection = IMFreedByConnection;
            schemaState->infoModel = infoModel;
        } else {
            schemaState->IMFreedByConnection = 1;
            schemaState->infoModel = fbInfoModelAlloc();
        }

        schemaState->scConnSpec = scConnSpecCopy(connSpec);
        fileList->currentFile = 0;
    }

    schemaState->nextInputIter = 0;

    /* this stuff is all new no matter what */
    *inDataInfo = scDataInfoAlloc();
    theDataInfo = *inDataInfo;
    theDataInfo->infoModel = schemaState->infoModel;
    schemaState->dataInfo = *inDataInfo;

    schemaState->mgmt = scSchemaTemplateMgmtInit(1);
    /* get a collector session from that model */
    schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

    /* don't need a listener for file reading */
    schemaState->collectorListener = NULL;

    /* get collector for the new file */
    schemaState->collector = fbCollectorAllocFile(NULL,
                            fileList->filenames[fileList->currentFile],
                            &gError);

    schemaState->collectorBuf = fBufAllocForCollection(
                                                schemaState->collectorSession,
                                                schemaState->collector);

    schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
    if (schemaState->fBufSession == schemaState->collectorSession) {
        schemaState->collectorSession = NULL;
    }
    scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

    /* set the fBuf to automatically insert custom element type records
     * to the info model */
    fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

    /* set the schema builder template callback to be run with new templates
     * arrive */
    fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                                                makeNewSchemasTemplateCallback);

    fBufNextCollectionTemplate(schemaState->collectorBuf, NULL, &gError);

    scDataInfoFillAsInput(theDataInfo,
                    fileListFixbufConnNextInputRedoSchemas,
                    fixbufConnGNRC,
                    fixbufConnGNRP,
                    fixbufConnGetNextSchema,
                    error);

    /* set the max record length */
    schemaState->schemaLen = scDataInfoGetMaxRecordLength(theDataInfo);

    return 0;
}

int getFileListFixbufConnectionSameSchemas(
    scConnSpec_t   *connSpec,
    scDataInfo_t  **inDataInfo,
    void          **potentialState,
    fbInfoModel_t  *infoModel,
    int             IMFreedByConnection,
    scError_t      *error)
{
    ipfixSchemaState_t *schemaState;
    GError             *gError = NULL;
    scDataInfo_t       *theDataInfo = NULL;
    scFileList_t       *fileList;

    scErrorClear(error);

    if (!connSpec || !inDataInfo || !potentialState) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("NULL parameter passed to FileListFixbufConnection\n");
        return 1;
    }

    if (connSpec->type != SC_CS_FILELIST_INPUT &&
        connSpec->type != SC_CS_DIRECTORY)
    {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Connection specification must be for a file list or directory\n");
        return 1;
    }

    if (connSpec->connInfo.fileList.numFiles == 0) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("There no files in the file list\n");
        return 1;
    }

    fileList = &connSpec->connInfo.fileList;
    if (*potentialState) {
        printf("Potential state pointer is not null. Setting to NULL and continuing, possible memory leak\n");
        *potentialState = NULL;
    }

    /* start from the beginning */
    *potentialState = newIpfixSchemaState();
    schemaState = *potentialState;
    if (infoModel) {
        schemaState->IMFreedByConnection = IMFreedByConnection;
        schemaState->infoModel = infoModel;
    } else {
        schemaState->IMFreedByConnection = 1;
        schemaState->infoModel = fbInfoModelAlloc();
    }

    schemaState->scConnSpec = scConnSpecCopy(connSpec);
    fileList->currentFile = 0;

    schemaState->nextInputIter = 0;

    /* this stuff is all new no matter what */
    *inDataInfo = scDataInfoAlloc();
    theDataInfo = *inDataInfo;
    theDataInfo->infoModel = schemaState->infoModel;
    schemaState->dataInfo = *inDataInfo;

    schemaState->mgmt = scSchemaTemplateMgmtInit(1);
    /* get a collector session from that model */
    schemaState->collectorSession = fbSessionAlloc(schemaState->infoModel);

    /* don't need a listener for file reading */
    schemaState->collectorListener = NULL;

    /* get collector for the new file */
    schemaState->collector = fbCollectorAllocFile(NULL,
                            fileList->filenames[fileList->currentFile],
                            &gError);

    if (!schemaState->collector) {
        ERR1("Error created a file collector: %s\n", gError->message);
        g_clear_error(&gError);
        return 1;
    }

    schemaState->collectorBuf = fBufAllocForCollection(
                                                schemaState->collectorSession,
                                                schemaState->collector);

    if (!schemaState->collectorBuf) {
        ERR0("Could not create file collector fBuf\n");
        return 1;
    }

    schemaState->fBufSession = fBufGetSession(schemaState->collectorBuf);
    if (schemaState->fBufSession == schemaState->collectorSession) {
        schemaState->collectorSession = NULL;
    }
    scFBufSessionAndStateAdd(schemaState->fBufSession, schemaState);

    /* set the fBuf to automatically insert custom element type records
     * to the info model */
    fBufSetAutomaticInsert(schemaState->collectorBuf, &gError);

    /* set the schema builder template callback to be run with new templates
     * arrive */
    fbSessionAddTemplateCallback(fBufGetSession(schemaState->collectorBuf),
                                                makeNewSchemasTemplateCallback);

    if (!fBufNextCollectionTemplate(schemaState->collectorBuf, NULL, &gError)) {
        ERR1("NextCollectionTemplate failed: %s\n", gError->message);
        g_clear_error(&gError);
        return 1;
    }

    scDataInfoFillAsInput(theDataInfo,
                    fileListFixbufConnNextInputSameSchemas,
                    fixbufConnGNRC,
                    fixbufConnGNRP,
                    fixbufConnGetNextSchema,
                    error);

    /* set the max record length */
    schemaState->schemaLen = scDataInfoGetMaxRecordLength(theDataInfo);

    return 0;
}

int getMultiThreadedAnyConnection(
    scConnSpec_t   *connSpec)
{
    return 0;
}

int getMultiThreadedSocketConnection(
    scConnSpec_t   *connSpec)
{
    return 0;
}

int getMultiThreadedFileDirConnection(
    scConnSpec_t   *connSpec)
{
    return 0;
}

/* for all of these functions:
 * derive* means from dataInfo
 * make* means from a schema list
 *
 * The infoModel passed to any of these functions CANNOT be the same as passed
 * to the functions used to make incoming connections. This info model pointer
 * now becomes property of the outgoing state and will be freed by it. If the
 * same pointer it used, it will be an invalid double free on cleanup
 */
int deriveOutgoingFixbufConnection(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    const scDataInfo_t *inDataInfo,
    fbInfoModel_t      *infoModel,
    scError_t          *error)
{
    return makeOutgoingFixbufConnection(connSpec,
                                        outDataInfo,
                                        potentialState,
                                        inDataInfo->firstSchema,
                                        infoModel,
                                        error);
}

int makeOutgoingFixbufConnection(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    scSchema_t         *firstSchema,
    fbInfoModel_t      *infoModel,
    scError_t          *error)
{
    switch (connSpec->type) {
      case SC_CS_UDP:
      case SC_CS_TCP:
      case SC_CS_FILE_OUTPUT:
        return makeOutgoingSocketOrFileFixbufConnection(connSpec,
                                                        outDataInfo,
                                                        potentialState,
                                                        firstSchema,
                                                        infoModel,
                                                        error);
        break;
      default:
        return 1;
        break;
    }


    return 0;
}

int makeOutgoingSocketOrFileFixbufConnection(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    scSchema_t         *firstSchema,
    fbInfoModel_t      *infoModel,
    scError_t          *error)
{
    outIpfixSchemaState_t  *outState;

    GError                 *gError = NULL;
    scDataInfo_t           *theDataInfo = NULL;
    scSchema_t             *schema;
    fbTemplate_t           *newTemplate;
    uint16_t                newTid;
    scSchemaBuilderMem_t   *builderMem;
    scInfoElement_t        *addedIE;
    fbInfoElement_t         newIE;

    if (!connSpec || !firstSchema || !outDataInfo || !potentialState) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("NULL parameter passed to OutgoingSocketFixbufConnection\n");
        return 1;
    }

    switch (connSpec->type) {
      case SC_CS_TCP:
      case SC_CS_UDP:
        if (!connSpec->connInfo.socket.hostname ||
            !connSpec->connInfo.socket.portStr)
        {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Null hostname or port string passed to socket creation\n");
            return 1;
        }
        break;
      case SC_CS_FILE_OUTPUT:
        if (!connSpec->connInfo.fileList.filenames[0]) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Null filename passed to file creation\n");
            return 1;
        }
        break;
      default:
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Connection specification must be for a socket or file\n");
        return 1;
    }

    *potentialState = newOutIpfixSchemaState();
    outState = *potentialState;

    if (infoModel) {
        outState->infoModel = infoModel;
    } else {
        outState->IMFreedByConnection = 1;
        outState->infoModel = fbInfoModelAlloc();
    }

    outState->exporterSession = fbSessionAlloc(outState->infoModel);

    outState->scConnSpec = scConnSpecCopy(connSpec);
    outState->mgmt      = scSchemaTemplateMgmtInit(0);

    *outDataInfo    = scDataInfoAlloc();
    outState->outDataInfo = *outDataInfo;
    theDataInfo->infoModel = outState->infoModel;
    theDataInfo = *outDataInfo;
    if (scDataInfoFillAsOutput(theDataInfo, fixbufConnWriteRecord, error)) {
        printf("Couldn't fill data as output %s\n", error->msg);
        return 1;
    }

    while (firstSchema) {
        builderMem = calloc(1, sizeof(scSchemaBuilderMem_t));
        memset(builderMem, 0, sizeof(scSchemaBuilderMem_t));

        schema = scSchemaCopy(firstSchema,
                              firstSchema->id,
                              firstSchema->name,
                              firstSchema->freeRecordCopy,
                              firstSchema->freeSecondLevelFields,
                              firstSchema->copyRecord,
                              error);
        if (!schema) {
            printf(" no schema copy %s\n", error->msg);
        }

        scSchemaSetBuilderMem(schema, builderMem,
                              fixbufSchemaBuilderMemAllocAndCopy,
                              fixbufSchemaBuilderMemFree);

        newTemplate = scSchemaToFixbufTemplate(outState->exporterSession,
                                               schema);

        addedIE = NULL;
        while((addedIE = scSchemaGetNextInfoElement(schema, addedIE))) {
            memset(&newIE, 0, sizeof(fbInfoElement_t));

            switch (scInfoElementGetGeneralType(addedIE)) {
              case FIXED:
                break;
              case VARLEN_DATA:
                builderMem->varfieldOffsets[builderMem->numVarfields] =
                                                                addedIE->offset;
                builderMem->numVarfields++;
                break;
              case LIST_TYPE:
                printf("got a list type in the schema\n");
                builderMem->numLists++;
                switch (addedIE->type) {
                  case BASIC_LIST:
                    printf("setting up a basic list\n");
                    builderMem->basicListOffsets[builderMem->numBasicLists] =
                                    addedIE->offset;
                    builderMem->basicListIEs[builderMem->numBasicLists] = addedIE;
                    builderMem->numBasicLists++;
                    break;
                  case SUB_TEMPLATE_LIST:
                    printf("still need to go STL\n");
                    break;
                  case SUB_TEMPLATE_MULTI_LIST:
                    printf("still need to do STML\n");
                    break;
                  default:
                    printf("a non list in list...wtf\n");
                    break;
                }
                break;
            }
        }

        newTid = fbSessionAddTemplate(outState->exporterSession, TRUE, FB_TID_AUTO, newTemplate, &gError);
        fbSessionAddTemplate(outState->exporterSession, FALSE, newTid, newTemplate, &gError);
        scSchemaTemplateMgmtAdd(outState->mgmt, schema, newTid);

        if (scDataInfoAddSchema(theDataInfo, schema, error)) {
            printf("Couldn't add schema to out data info %s\n", error->msg);
            return 1;
        }

        firstSchema = firstSchema->next;
    }

    switch (connSpec->type) {
      case SC_CS_TCP:
      case SC_CS_UDP:
        if (connSpec->type == SC_CS_TCP) {
            outState->fbConnSpec.transport = FB_TCP;
        } else {
            outState->fbConnSpec.transport = FB_UDP;
        }

        outState->fbConnSpec.host = connSpec->connInfo.socket.hostname;

        outState->fbConnSpec.svc = connSpec->connInfo.socket.portStr;

        outState->fbConnSpec.ssl_ca_file = NULL;
        outState->fbConnSpec.ssl_cert_file = NULL;
        outState->fbConnSpec.ssl_key_file = NULL;
        outState->fbConnSpec.ssl_key_pass = NULL;
        outState->fbConnSpec.vai = NULL;
        outState->fbConnSpec.vssl_ctx = NULL;

        outState->exporter = fbExporterAllocNet(&outState->fbConnSpec);
        break;
      case SC_CS_FILE_OUTPUT:
        outState->exporter = fbExporterAllocFile(outState->scConnSpec->connInfo.fileList.filenames[0]);
        break;
      default:
        printf("invalid output format\n");
        return 1;
    }
    outState->exporterBuf = fBufAllocForExport(outState->exporterSession, outState->exporter);
    fbSessionExportTemplates(outState->exporterSession, &gError);

    return 0;
}

int getAnyOutgoingFixbufConnectionWithoutSchemas(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    fbInfoModel_t      *infoModel,
    scError_t          *error)
{
    switch (connSpec->type) {
      case SC_CS_UDP:
      case SC_CS_TCP:
      case SC_CS_FILE_OUTPUT:
        return getOutgoingSocketOrFileFixbufConnectionWithoutSchemas(connSpec,
                                                                  outDataInfo,
                                                                 potentialState,
                                                          infoModel,
                                                          error);
        break;
      default:
        return 1;
        break;
    }

    return 0;
}

int getOutgoingSocketOrFileFixbufConnectionWithoutSchemas(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    fbInfoModel_t      *infoModel,
    scError_t          *error)
{
    outIpfixSchemaState_t  *outState;
    scDataInfo_t           *theDataInfo = NULL;

    if (!connSpec || !outDataInfo || !potentialState) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("NULL parameter passed to OutgoingSocketFixbufConnection\n");
        return 1;
    }

    switch (connSpec->type) {
      case SC_CS_TCP:
      case SC_CS_UDP:
        if (!connSpec->connInfo.socket.hostname ||
            !connSpec->connInfo.socket.portStr)
        {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Null hostname or port string passed to socket creation\n");
            return 1;
        }
        break;
      case SC_CS_FILE_OUTPUT:
        if (!connSpec->connInfo.fileList.filenames[0]) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Null filename passed to file creation\n");
            return 1;
        }
        break;
      default:
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Connection specification must be for a socket or file\n");
        return 1;
    }

    *potentialState = newOutIpfixSchemaState();
    outState = *potentialState;

    if (infoModel) {
        outState->infoModel = infoModel;
    } else {
        outState->IMFreedByConnection = 1;
        outState->infoModel = fbInfoModelAlloc();
    }

    outState->exporterSession = fbSessionAlloc(outState->infoModel);

    outState->scConnSpec = scConnSpecCopy(connSpec);
    outState->mgmt      = scSchemaTemplateMgmtInit(0);

    *outDataInfo    = scDataInfoAlloc();
    outState->outDataInfo = *outDataInfo;
    theDataInfo = *outDataInfo;
    theDataInfo->infoModel = outState->infoModel;
    if (scDataInfoFillAsOutput(theDataInfo, fixbufConnWriteRecord, error)) {
        printf("Couldn't fill data as output %s\n", error->msg);
        return 1;
    }

    switch (connSpec->type) {
      case SC_CS_TCP:
      case SC_CS_UDP:
        if (connSpec->type == SC_CS_TCP) {
            outState->fbConnSpec.transport = FB_TCP;
        } else {
            outState->fbConnSpec.transport = FB_UDP;
        }

        outState->fbConnSpec.host = connSpec->connInfo.socket.hostname;

        outState->fbConnSpec.svc = connSpec->connInfo.socket.portStr;

        outState->fbConnSpec.ssl_ca_file = NULL;
        outState->fbConnSpec.ssl_cert_file = NULL;
        outState->fbConnSpec.ssl_key_file = NULL;
        outState->fbConnSpec.ssl_key_pass = NULL;
        outState->fbConnSpec.vai = NULL;
        outState->fbConnSpec.vssl_ctx = NULL;

        outState->exporter = fbExporterAllocNet(&outState->fbConnSpec);
        break;
      case SC_CS_FILE_OUTPUT:
        outState->exporter = fbExporterAllocFile(outState->scConnSpec->connInfo.fileList.filenames[0]);
        break;
      default:
        printf("invalid output format\n");
        return 1;
    }
    outState->exporterBuf = fBufAllocForExport(outState->exporterSession, outState->exporter);

    return 0;
}

scSchema_t* addSchemaToOutgoingFixbufConnection(
    scDataInfo_t       *outDataInfo,
    void               *theState,
    scSchema_t         *oldSchema,
    scError_t          *error)
{
    outIpfixSchemaState_t  *outState = (outIpfixSchemaState_t*)theState;
    GError                 *gError = NULL;
    scSchema_t             *schema;
    fbTemplate_t           *newTemplate;
    uint16_t                newTid;
    scSchemaBuilderMem_t   *builderMem;
    scInfoElement_t        *addedIE;
    fbInfoElement_t         newIE;

    builderMem = calloc(1, sizeof(scSchemaBuilderMem_t));
    memset(builderMem, 0, sizeof(scSchemaBuilderMem_t));

    schema = scSchemaCopy(oldSchema,
                          oldSchema->id,
                          oldSchema->name,
                          oldSchema->freeRecordCopy,
                          oldSchema->freeSecondLevelFields,
                          oldSchema->copyRecord,
                          error);
    if (!schema) {
        ERR1("Error copying schema to add to dataInfo: %s\n", error->msg);
        return NULL;
    }

    scSchemaSetBuilderMem(schema, builderMem,
                          fixbufSchemaBuilderMemAllocAndCopy,
                          fixbufSchemaBuilderMemFree);

    newTemplate = scSchemaToFixbufTemplate(outState->exporterSession,
                                           schema);

    addedIE = NULL;
    while((addedIE = scSchemaGetNextInfoElement(schema, addedIE))) {
        memset(&newIE, 0, sizeof(fbInfoElement_t));

        switch (scInfoElementGetGeneralType(addedIE)) {
          case FIXED:
            break;
          case VARLEN_DATA:
            builderMem->varfieldOffsets[builderMem->numVarfields] =
                                                            addedIE->offset;
            builderMem->numVarfields++;
            break;
          case LIST_TYPE:
            builderMem->numLists++;
            switch (addedIE->type) {
              case BASIC_LIST:
                builderMem->basicListOffsets[builderMem->numBasicLists] =
                                addedIE->offset;
                builderMem->basicListIEs[builderMem->numBasicLists] = addedIE;
                builderMem->numBasicLists++;
                break;
              case SUB_TEMPLATE_LIST:
                printf("still need to go STL\n");
                break;
              case SUB_TEMPLATE_MULTI_LIST:
                printf("still need to do STML\n");
                break;
              default:
                printf("a non list in list...wtf\n");
                break;
            }
            break;
        }
    }

    newTid = fbSessionAddTemplate(outState->exporterSession, TRUE, FB_TID_AUTO, newTemplate, &gError);
    fbSessionAddTemplate(outState->exporterSession, FALSE, newTid, newTemplate, &gError);
    scSchemaTemplateMgmtAdd(outState->mgmt, schema, newTid);

    if (scDataInfoAddSchema(outDataInfo, schema, error)) {
        printf("Couldn't add schema to out data info %s\n", error->msg);
        return NULL;
    }

    fbSessionExportTemplates(outState->exporterSession, &gError);

    return schema;
}

/**
 * Adds a schema to an outgoing fixbuf connection.
 * If a schema with that ID already exists, it finds a new ID, and adds
 * the schema.
 * If the schema added in this way is an incoming schema, then it's possible
 * that the schema IDs will not match, and thus, the incoming schema
 * cannot be passed to the writeRecord function such that the correct template
 * will be used to send data. If this function is used to add new schemas,
 * management of the links between incoming and outgoing schemas will need
 * to be used such that the outgoing schema is passed to the write function.
 * This function returns the new schema copy on success, NULL on failure
 */
scSchema_t* addSchemaToOutgoingFixbufConnectionAutoId(
    scDataInfo_t       *outDataInfo,
    void               *theState,
    scSchema_t         *oldSchema,
    scError_t          *error)
{
    outIpfixSchemaState_t  *outState = (outIpfixSchemaState_t*)theState;
    GError                 *gError = NULL;
    scSchema_t             *schema;
    fbTemplate_t           *newTemplate;
    uint16_t                newTid;
    scSchemaBuilderMem_t   *builderMem;
    scInfoElement_t        *addedIE;
    fbInfoElement_t         newIE;

    builderMem = calloc(1, sizeof(scSchemaBuilderMem_t));
    memset(builderMem, 0, sizeof(scSchemaBuilderMem_t));

    schema = scSchemaCopy(oldSchema,
                          oldSchema->id,
                          oldSchema->name,
                          oldSchema->freeRecordCopy,
                          oldSchema->freeSecondLevelFields,
                          oldSchema->copyRecord,
                          error);
    if (!schema) {
        ERR1("Error copying schema to add to dataInfo: %s\n", error->msg);
        return NULL;
    }

    scSchemaSetBuilderMem(schema, builderMem,
                          fixbufSchemaBuilderMemAllocAndCopy,
                          fixbufSchemaBuilderMemFree);

    newTemplate = scSchemaToFixbufTemplate(outState->exporterSession,
                                           schema);

    addedIE = NULL;
    while((addedIE = scSchemaGetNextInfoElement(schema, addedIE))) {
        memset(&newIE, 0, sizeof(fbInfoElement_t));

        switch (scInfoElementGetGeneralType(addedIE)) {
          case FIXED:
            break;
          case VARLEN_DATA:
            builderMem->varfieldOffsets[builderMem->numVarfields] =
                                                            addedIE->offset;
            builderMem->numVarfields++;
            break;
          case LIST_TYPE:
            builderMem->numLists++;
            switch (addedIE->type) {
              case BASIC_LIST:
                builderMem->basicListOffsets[builderMem->numBasicLists] =
                                addedIE->offset;
                builderMem->basicListIEs[builderMem->numBasicLists] = addedIE;
                builderMem->numBasicLists++;
                break;
              case SUB_TEMPLATE_LIST:
                printf("still need to go STL\n");
                break;
              case SUB_TEMPLATE_MULTI_LIST:
                printf("still need to do STML\n");
                break;
              default:
                printf("a non list in list...wtf\n");
                break;
            }
            break;
        }
    }

    newTid = fbSessionAddTemplate(outState->exporterSession, TRUE, FB_TID_AUTO, newTemplate, &gError);
    fbSessionAddTemplate(outState->exporterSession, FALSE, newTid, newTemplate, &gError);

    if (scDataInfoAddSchemaForce(outDataInfo, schema, error)) {
        ERR1("Couldn't add schema to out data info %s\n", error->msg);
        return NULL;
    }

    scSchemaTemplateMgmtAdd(outState->mgmt, schema, newTid);

    fbSessionExportTemplates(outState->exporterSession, &gError);
    return schema;
}

int scConnSpecConfigureFixbufSocket(
    scConnSpec_t   *connSpec,
    char           *hostname,
    char           *portString)
{
    scSocket_t *sock;
    if (connSpec->type != SC_CS_TCP &&
        connSpec->type != SC_CS_UDP)
    {
        return 1;
    }

    sock = &connSpec->connInfo.socket;

    sock->portStr = strdup(portString);
    if (hostname) {
        sock->hostname = strdup(hostname);
    } else {
        sock->hostname = NULL;
    }

    return 0;
}

int scConnSpecConfigureSocketWithInts(
    scConnSpec_t   *connSpec,
    uint32_t        ip,
    uint16_t        port)
{
    scSocket_t *sock;
    if (connSpec->type != SC_CS_TCP &&
        connSpec->type != SC_CS_UDP)
    {
        return 1;
    }

    sock = &connSpec->connInfo.socket;

    sock->portInt = port;
    sock->ipAddr = ip;

    return 0;
}

int scConnSpecAddFile(
    scConnSpec_t   *connSpec,
    const char     *filename)
{
    char           *newFilename;
    scFileList_t   *fileList;

    if (connSpec->type != SC_CS_FILELIST_INPUT &&
        connSpec->type != SC_CS_DIRECTORY &&
        connSpec->type != SC_CS_FILE_OUTPUT)
    {
        return 1;
    }

    fileList = &connSpec->connInfo.fileList;

    newFilename = strdup(filename);

    fileList->filenames = realloc(fileList->filenames,
                                  (sizeof(char*) * (fileList->numFiles + 1)));

    fileList->filenames[fileList->numFiles] = newFilename;
    fileList->numFiles++;

    return 0;
}

int scConnSpecAddDirectory(
    scConnSpec_t   *connSpec,
    const char     *directory,
    uint32_t        timeoutSeconds,
    uint32_t        pollingInterval,
    uint32_t        pollingTimeout)
{
    DIR            *dp;
    struct dirent  *ep;
    char            fullFilename[200];

    if (connSpec->type == SC_CS_DIRECTORY) {
        dp = opendir(directory);
        if (dp != NULL) {
            while ((ep = readdir(dp))) {
                if (strcmp(ep->d_name, ".") && strcmp(ep->d_name, "..")) {
                    memset(fullFilename, 0, 200);
                    snprintf(fullFilename, 200, "%s/%s", directory, ep->d_name);
                    scConnSpecAddFile(connSpec, fullFilename);
                }
            }
            closedir(dp);
        } else {
            printf("couldn't open directory\n");
        }
        return 0;
    } else if (connSpec->type == SC_CS_POLL_DIR) {
        connSpec->connInfo.pollDir.directory = strdup(directory);
        connSpec->connInfo.pollDir.timeoutSeconds = timeoutSeconds;
        connSpec->connInfo.pollDir.pollingInterval = pollingInterval;
        connSpec->connInfo.pollDir.pollingTimeout  = pollingTimeout;
        return 0;
    }

    return 1;
}

int scConnSpecAddArchiveDirectory(
    scConnSpec_t   *connSpec,
    const char     *archiveDir)
{
    if (connSpec->type != SC_CS_POLL_DIR) {
        return 1;
    }

    connSpec->connInfo.pollDir.archiveDir = strdup(archiveDir);
    return 0;
}

uint8_t* scBasicListGetDataPtrFromRec(
    scInfoElement_t    *ie,
    uint8_t            *rec)
{
    fbBasicList_t  *bl;
    if (ie->type != BASIC_LIST) {
        return NULL;
    }

    bl = (fbBasicList_t*)ie->retPtr(ie, rec);
    return bl->dataPtr;
}

uint8_t* scBasicListGetDataPtr(
    scBasicList_t  *basicList)
{
    return basicList->dataPtr;
}

/* IE is the BL, pass in full rec
 */
uint16_t scBasicListGetNumElementsFromRec(
    scInfoElement_t    *ie,
    uint8_t            *rec)
{
    fbBasicList_t  *bl;
    if (ie->type != BASIC_LIST) {
        return 0;
    }

    bl = (fbBasicList_t*)ie->retPtr(ie, rec);
    return bl->numElements;
}

uint16_t scBasicListGetNumElements(
    scBasicList_t  *basicList)
{
    return basicList->numElements;
}
