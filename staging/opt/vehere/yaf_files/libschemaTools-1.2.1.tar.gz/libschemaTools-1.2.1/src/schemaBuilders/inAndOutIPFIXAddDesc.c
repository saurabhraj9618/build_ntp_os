#include <fixbuf/public.h>

#include "inAndOutIPFIXAddDesc.h"

scError_t   scError;
/* structure that ties schemas to templates */
typedef struct ipfixTemplateSchema_st {
    scSchema_t *schema;
    uint16_t    tid;
} ipfixTemplateSchema_t;

/* structure that contains the IPFIX information for a data info */
typedef struct ipfixIncomingSchemaState_st {
    fbSession_t            *collectorSession;
    struct fbConnSpec_st    socketDef;
    fbListener_t           *collectorListener;
    fbInfoModel_t          *infoModel;
    fBuf_t                 *collectorBuf;
    uint8_t                 inputNum;
    size_t                  schemaLen;
    GError                 *error;
} ipfixIncomingSchemaState_t;

typedef struct ipfixOutgoingSchemaState_st {
    fbSession_t            *exporterSession;
    struct fbConnSpec_st    socketDef;
    fbExporter_t           *exporter;
    fBuf_t                 *exporterBuf;
    fbInfoModel_t          *infoModel;
    GError                 *error;
} ipfixOutgoingSchemaState_t;

/* structure that accompanies each schema, created by the builder */
typedef struct schemaBuilderMem_st {
    uint32_t    numVarfields;
    uint32_t    varfieldOffsets[100];
    uint32_t    numLists;
    uint32_t    listOffsets[100];
} schemaBuilderMem_t;

ipfixIncomingSchemaState_t* newIncomingIpfixSchemaState(void);
ipfixOutgoingSchemaState_t* newOutgoingIpfixSchemaState(void);
void freeIncomingIpfixSchemaState(ipfixIncomingSchemaState_t   *schemaState);
void freeOutgoingIpfixSchemaState(ipfixOutgoingSchemaState_t   *schemaState);

void templateReaderCallback(fbSession_t    *session, 
                            uint16_t        tid,
                            fbTemplate_t   *tmpl);

ipfixIncomingSchemaState_t *incomingState                   = NULL;
ipfixOutgoingSchemaState_t *outgoingState                   = NULL;          
scDataInfo_t               *theInDataInfo                   = NULL;
scDataInfo_t               *theOutDataInfo                  = NULL;

ipfixTemplateSchema_t      *inputTemplateSchemaListHead     = NULL;
ipfixTemplateSchema_t      *outputTemplateSchemaListHead    = NULL;
uint32_t                    inputNumSchemas                 = 0;
uint32_t                    outputNumSchemas                = 0;
uint16_t                    lastInputTid                    = 0;
uint16_t                    lastOutputTid                   = 0;
scSchema_t                 *lastInputSchema                 = NULL;
scSchema_t                 *lastOutputSchema                = NULL;

/* get the schema for a given tid seen so far */
scSchema_t* getInputSchemaForTid(
    uint16_t thisTid)
{
    uint32_t                i;
    ipfixTemplateSchema_t  *tas;

    for (i = 0, tas = inputTemplateSchemaListHead;
         i < inputNumSchemas;
         i++, tas++)
    {
        if (tas->tid == thisTid) {
            lastInputTid     = thisTid;
            lastInputSchema  = tas->schema;
            return tas->schema;
        }
    }

    return NULL;
}

uint16_t getOutputTidForSchema(
    scSchema_t *thisSchema)
{
    uint32_t                i;
    ipfixTemplateSchema_t  *tas;

    for (i = 0, tas = outputTemplateSchemaListHead;
         i < outputNumSchemas;
         i++, tas++)
    {
        if (tas->schema == thisSchema) {
            lastOutputTid       = tas->tid;
            lastOutputSchema    = tas->schema;
            return tas->tid;
        }
    }

    return 0;
}


void* inAndOutBuilderMemAllocAndCopy(
    scSchema_t *schema)
{
    void   *newBuilder = calloc(1, sizeof(schemaBuilderMem_t));

    memcpy(newBuilder, scSchemaGetBuilderMem(schema), sizeof(schemaBuilderMem_t));

    return newBuilder;
}

void inAndOutBuilderMemFree(
    void   *builderMem)
{
    free(builderMem);
}

uint32_t doNothingCopyRecord(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src)
{
    return 0;
}

void doNothingFreeRecordCopy(
    scSchema_t *schema,
    uint8_t    *rec)
{
}

void doNothingFreeSecondLevel(
    scSchema_t *schema,
    uint8_t    *rec)
{
}

/* make a copy of a record described by a given schema */
uint32_t copyRecord(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src)
{
    uint32_t            len = scSchemaGetRecordLength(schema);
    uint32_t            i;
    scVarfield_t       *srcVarfield;
    scVarfield_t       *dstVarfield;
    schemaBuilderMem_t *builderMem;

    /* get the builder mem, containing varfield listings, for schema */
    builderMem = scSchemaGetBuilderMem(schema);

    /* simple copy of the first level fields */
    memcpy(dst, src, len);

    /* loop through the varfields making copies of second level data */
    for (i = 0; i < builderMem->numVarfields; i++) {
        srcVarfield = (scVarfield_t*)(src + builderMem->varfieldOffsets[i]);
        dstVarfield = (scVarfield_t*)(dst + builderMem->varfieldOffsets[i]);

        dstVarfield->dataPtr = calloc(1, dstVarfield->len);
        memcpy(dstVarfield->dataPtr, srcVarfield->dataPtr, dstVarfield->len);
    }

    return len;
}

/* Frees an entire record created by copyRecord, buffer included */
void freeRecordCopy(
    scSchema_t *schema,
    uint8_t    *rec)
{
    uint32_t            i;
    scVarfield_t       *varfield;
    schemaBuilderMem_t *builderMem;

    builderMem = scSchemaGetBuilderMem(schema);

    /* loop through varfields freeing data */
    for (i = 0; i < builderMem->numVarfields; i++) {
        varfield = (scVarfield_t*)(rec + builderMem->varfieldOffsets[i]);
        free(varfield->dataPtr);
    }

    /* free the buffer (record) itself */
    free(rec);
}

/* frees the second level fields where needed */
void freeSecondLevelFields(
    scSchema_t *schema,
    uint8_t    *rec)
{
    /*
    This doesn't go here as the varfields reference a pointer in their own 
    back in the buffer, can't double free

    there will be somethign here for lists and other copied things
    uint32_t        i;
    scVarfield_t   *varfield;

    printf("num VF's %d\n", numVarfields);
    for (i = 0; i < numVarfields; i++) {
        printf("offset: %d\n", varfieldOffsets[i]);
        varfield = (scVarfield_t*)(rec + varfieldOffsets[i]);
        free(varfield->dataPtr);
    }
    */
}

/* this builder is set to read from a stream, which is just one input */
uint32_t rawIPFIXnextInput(
    void **streamBlobDP)
{
    ipfixIncomingSchemaState_t *schemaState = 
                                    (ipfixIncomingSchemaState_t*)*streamBlobDP;
    if (!schemaState) {
        printf("not properly initialized during get info\n");
        return 0;
    }

    /* if this is the 2nd time it's called, quit */
    if (schemaState->inputNum) {
        return 0;
    }

    schemaState->inputNum = 1;

    return 1;
}

/* get the next record from the stream, calling fBufNext at the core */
scDataInfoGetRecErr_t getNextRecordCopy(
    void           *someStreamBlob,
    uint8_t        *buf,
    scSchema_t    **schemaUsed)
{
    GError *error = NULL;
    ipfixIncomingSchemaState_t *schemaState = 
                                (ipfixIncomingSchemaState_t*)someStreamBlob;
    uint16_t            thisTid = 0;
    gboolean            rc;
    size_t              theLen = schemaState->schemaLen;

    /* Get the template used to define the next record */
    if(!fBufNextCollectionTemplate(schemaState->collectorBuf,
                                   &thisTid, 
                                   &error)) 
    {
        g_error_free(error);    
        return SCGETNEXT_ERR_EOF;
    }

    /* for now we know that the associated internal templates have same IDS */
    rc = fBufSetInternalTemplate(schemaState->collectorBuf, 
                                 thisTid, 
                                 &error);
        
    /* get the next record */ 
    if (fBufNext(schemaState->collectorBuf, 
                 buf, 
                 &theLen,
                 &(schemaState->error)))
    {
        /* set the schema used variable */
        if (thisTid == lastInputTid) {
            *schemaUsed = lastInputSchema;
        } else {
            *schemaUsed = getInputSchemaForTid(thisTid);
        }
        return SCGETNEXT_OK;
    } else {
        return SCGETNEXT_ERR_EOF;
    }
}    

uint32_t writeRecord(
    void           *someStreamBlob,
    scSchema_t     *schema,
    const uint8_t  *buf,
    uint32_t        length)
{
    uint16_t    tid;
    ipfixOutgoingSchemaState_t *state = 
                                (ipfixOutgoingSchemaState_t*)someStreamBlob;
    GError     *error;
    int         rc;
    
    if (!state->exporterBuf) {
        state->exporter = fbExporterAllocNet(&(state->socketDef));
        if (state->exporter) {
            state->exporterBuf = fBufAllocForExport(state->exporterSession,
                                                    state->exporter);
            if (!state->exporterBuf) {
                printf("couldn't get exporterBuf\n");
                return 0;
            }
        } else {
            printf("couldn't get exporter\n");
            return 0;
        }
        
        if (!fbSessionExportTemplates(outgoingState->exporterSession, &error)) {
            printf("exported templates failed\n");
        }

    }

    if (lastOutputSchema == schema) {
        tid = lastOutputTid;
    } else {
        tid = getOutputTidForSchema(schema);
    }
    if (!tid) {
        printf("no tid for that schema dummy %d\n", scSchemaGetId(schema));
        return 0;
    }

    if (!fBufSetInternalTemplate(state->exporterBuf, tid, &error)) {
        printf("couldn't set internal template\n");
    }
    if (!fBufSetExportTemplate(state->exporterBuf, tid, &error)) {
        printf("couldn't set external template\n");
    }

    error = NULL;
    rc = fBufAppend(state->exporterBuf, (uint8_t*)buf, length, &error);
    if (!rc) {
        printf("error appending %s\n", error->message);
        return 0;
    } else {
    }

    fBufEmit(state->exporterBuf, &error);

    return length;
}

/* we don't handle this yet */
void* getNextRecordPtr(
    void           *someStreamBlob,
    scSchema_t    **schemaUsed)
{
    return NULL;
}

/* fixbuf template callback that runs when we receive a template
 * this function is responsible for parsing templates and creating schemas */
void templateReaderCallback(
    fbSession_t    *session,
    uint16_t        tid,
    fbTemplate_t   *tmpl)
{
    uint32_t                numIEs;
    uint32_t                i;
    const fbInfoElement_t  *ie;
    scInfoElement_t        *addedIE;
    fbInfoElement_t         newIE;
    uint16_t                collectorTemplateID;
    uint16_t                exporterTemplateID;
    GError                 *error = NULL;
    scSchema_t             *schema;
    scSchema_t             *outSchema;
    ipfixTemplateSchema_t  *tas;
    schemaBuilderMem_t     *builderMem;
    fbTemplate_t           *newTemplate;

    /* if this template is for sending custom IPFIX elements, ignore it */
    if (fbInfoModelTypeInfoRecord(tmpl)) {
        return;
    }

    /* at this point we have a data template, so we need a schema for this */
    numIEs = fbTemplateCountElements(tmpl);

    /* allocate custom builder mem to attach to the new schema */
    builderMem = calloc(1, sizeof(schemaBuilderMem_t));
    memset(builderMem, 0, sizeof(schemaBuilderMem_t));

    /* allocate a new schema, use TID for id, attach builder mem, and use 
     * the same functions each time as they are generic */
    schema = scSchemaAlloc("fromIPFix", tid,
                            freeRecordCopy,
                            freeSecondLevelFields,
                            copyRecord,
                            &scError);

    scSchemaSetBuilderMem(schema, builderMem, inAndOutBuilderMemAllocAndCopy,
                                              inAndOutBuilderMemFree);

    /* create a new entry in the schema-template table kept by the builder */
    inputTemplateSchemaListHead = realloc(inputTemplateSchemaListHead,
                                     sizeof(ipfixTemplateSchema_t) * 
                                        (inputNumSchemas + 1));

    /* fill in the new entry */
    tas = inputTemplateSchemaListHead + inputNumSchemas;
    tas->schema = schema;
    tas->tid    = tid;
    inputNumSchemas++;

    /* we need to build an internal template as well, so we decode
     * every element that arrives
     */
    newTemplate = fbTemplateAlloc(fbSessionGetInfoModel(session));

    /* loop through the template's IEs */
    for (i = 0; i < numIEs; i++) {
        ie = fbTemplateGetIndexedIE(tmpl, i);
        /* add this IE to the new internal template */
        if (!fbTemplateAppend(newTemplate,
                              (fbInfoElement_t*)ie,
                              &error)) 
        {
        }

        /* if this is a custom element, add to schema accordingly */
        if (ie->ent) {
            addedIE = scSchemaAddCustomIEStandardFuncs(schema,
                                                      ie->ent,
                                                      ie->num,
                                                      ie->type,
                                                      (char*)ie->description,
                                                      (char*)ie->ref.canon->ref.name,
                                                      ie->min,
                                                      ie->max,
                                                      FB_IE_SEMANTIC(ie->flags),
                                                      NULL,
                                                      FB_IE_UNITS(ie->flags),
                                                      &scError);
                                                       
        } else {
            addedIE = scSchemaAddStandardIEByID(schema, ie->ent, ie->num, 
                                                NULL, NULL, NULL, &scError);
        }

        /* check if this IE is a list, varfield, or fixed,
         * keep track of where variable lengthed fields are 
         */
        switch (scInfoElementGetGeneralType(addedIE)) {
          case FIXED:
            break;
          case VARLEN_DATA:
            builderMem->varfieldOffsets[builderMem->numVarfields] = 
                                                            addedIE->offset;
            builderMem->numVarfields++;
            break;
          case LIST_TYPE:
            builderMem->listOffsets[builderMem->numLists] = addedIE->offset;
            builderMem->numLists++;
            break;
        }
    }

    /* add the newly created template as an internal template */
    collectorTemplateID = fbSessionAddTemplate(session,
                                               TRUE, tid,
                                               newTemplate, 
                                               &error);

    /* add the new schema to the data info */
    if (scDataInfoAddSchema(theInDataInfo, schema, &scError)) {
        printf("error adding schema to in data info %s\n", scError.msg);
        return;
    }

    outSchema = scSchemaCopy(schema, tid - 100, "outputSchema",
                             doNothingFreeRecordCopy,
                             doNothingFreeSecondLevel,
                             doNothingCopyRecord, &scError);

    if (!outSchema) {
        printf("couldn't copy schema %s\n", scError.msg);
    }

    builderMem = calloc(1, sizeof(schemaBuilderMem_t));
    memset(builderMem, 0, sizeof(schemaBuilderMem_t));
    
    scSchemaSetBuilderMem(outSchema, builderMem, inAndOutBuilderMemAllocAndCopy,
                                                 inAndOutBuilderMemFree);

    addedIE = scSchemaAddStandardIEByID(outSchema, 0, 36, NULL, NULL, NULL, 
                                                                &scError);
    if (!addedIE) {
        printf("couldn't add the sum %s\n", scError.msg);
        return;
    }


/*    addedIE = scSchemaAddStandardIEByID(outSchema, 0, 289, NULL, NULL, 
                                                                &scError);
    if (!addedIE) {
        printf("couldn't add sport desc %s\n", scError.msg);
        return;
    }

    addedIE = scSchemaAddStandardIEByID(outSchema, 0, 290, NULL, NULL,
                                                                &scError);
    if (!addedIE) {
        printf("couldn't add dport desc %s\n", scError.msg);
        return;
    }*/

    newTemplate = fbTemplateAlloc(fbSessionGetInfoModel(
                                            outgoingState->exporterSession));
    
    addedIE = NULL;
    while((addedIE = scSchemaGetNextInfoElement(outSchema, addedIE))) {
        memset(&newIE, 0, sizeof(fbInfoElement_t));
/*        if (addedIE->id == 289) {
            padding.len_override = 6;
            if (!fbTemplateAppendSpec(newTemplate, &padding, 1, &error)) { 
                printf("couldn't add element of padding\n");
            }
        }*/

        newIE.ent = addedIE->ent;
        newIE.num = addedIE->id;
        if (scInfoElementIsVarlen(addedIE)) {
            newIE.len = FB_IE_VARLEN;
        } else {
            newIE.len = scInfoElementGetLength(addedIE);
        }
    
        if (!fbTemplateAppend(newTemplate, &newIE, &error)) {
            printf("couldn't add element\n");
        }

        switch (scInfoElementGetGeneralType(addedIE)) {
          case FIXED:
            break;
          case VARLEN_DATA:
            builderMem->varfieldOffsets[builderMem->numVarfields] =
                                                            addedIE->offset;
            builderMem->numVarfields++;
            break;
          case LIST_TYPE:
            builderMem->listOffsets[builderMem->numLists] = addedIE->offset;
            builderMem->numLists++;
            break;
        }
    }

    exporterTemplateID = fbSessionAddTemplate(outgoingState->exporterSession,
                                              FALSE, scSchemaGetId(outSchema),
                                              newTemplate,
                                              &error);

    exporterTemplateID = fbSessionAddTemplate(outgoingState->exporterSession,
                                              TRUE, exporterTemplateID,
                                              newTemplate,
                                              &error);

    outputTemplateSchemaListHead = realloc(outputTemplateSchemaListHead,
                                     sizeof(ipfixTemplateSchema_t) *
                                        (outputNumSchemas + 1));

    /* fill in the new entry */
    tas = outputTemplateSchemaListHead + outputNumSchemas;
    tas->schema = outSchema;
    tas->tid    = exporterTemplateID;

    outputNumSchemas++;

    if (scDataInfoAddSchema(theOutDataInfo, outSchema, &scError)) {
        printf("Couldn't add schema to out data info %s\n", scError.msg);
        return;
    }

    scSchemaAssociate(schema, outSchema, &scError);
}

int getAddDescIPFIXDataInfoAlloc(
    scConnSpec_t   *inConnSpec,
    scDataInfo_t  **inDataInfo,
    void          **inPotentialState,
    scConnSpec_t   *outConnSpec,
    scDataInfo_t  **outDataInfo,
    void          **outPotentialState)
{
    *inDataInfo = scDataInfoAlloc();
    *outDataInfo = scDataInfoAlloc();
    return getAddDescIPFIXDataInfo(inConnSpec,
                                   *inDataInfo, 
                                   inPotentialState,
                                   outConnSpec,
                                   *outDataInfo,
                                   outPotentialState);
}

int getAddDescIPFIXDataInfo(
    scConnSpec_t   *inConnSpec,
    scDataInfo_t   *inDataInfo,
    void          **inPotentialState,
    scConnSpec_t   *outConnSpec,
    scDataInfo_t   *outDataInfo,
    void          **outPotentialState)
{
    GError             *error   = NULL;
    ipfixIncomingSchemaState_t *inSchemaState;
    ipfixOutgoingSchemaState_t *outSchemaState;

    scErrorClear(&scError);

    if (incomingState) {
        printf("there is already a state.  A program called get info twice\n");
        return 1;
    }

    theInDataInfo = inDataInfo;
    theOutDataInfo = outDataInfo;

    /* get a new ipfix state struct with fixbuf variables */
    *inPotentialState = newIncomingIpfixSchemaState();
    *outPotentialState = newOutgoingIpfixSchemaState();

    inSchemaState = *inPotentialState;
    outSchemaState = *outPotentialState;

    if (inConnSpec->type == SC_CS_TCP) {
        inSchemaState->socketDef.transport = FB_TCP;
    } else if (inConnSpec->type == SC_CS_UDP) {
        inSchemaState->socketDef.transport = FB_UDP;
    } else {
        printf("I can't handle that type of comms\n");
        return 1;
    }

    /* this needs fixed for real life */
    inSchemaState->socketDef.host = inConnSpec->connInfo.socket.hostname;
    inSchemaState->socketDef.svc = inConnSpec->connInfo.socket.portStr;

    inSchemaState->socketDef.ssl_ca_file = NULL;
    inSchemaState->socketDef.ssl_cert_file = NULL;
    inSchemaState->socketDef.ssl_key_file = NULL;
    inSchemaState->socketDef.ssl_key_pass = NULL;
    inSchemaState->socketDef.vai = NULL;
    inSchemaState->socketDef.vssl_ctx = NULL;

    /* start Fixbuf specific stuff...get an info model */
    inSchemaState->infoModel = fbInfoModelAlloc();

    /* get a collector session from that model */
    inSchemaState->collectorSession = fbSessionAlloc(inSchemaState->infoModel);

    /* create a listener based on the session */
    inSchemaState->collectorListener = fbListenerAlloc(&(inSchemaState->socketDef),
                              inSchemaState->collectorSession,
                              NULL, NULL, &error);

    /* make the exporting portion before beginning to wait */
    if (outConnSpec->type == SC_CS_TCP) {
        outSchemaState->socketDef.transport = FB_TCP;
    } else if (outConnSpec->type == SC_CS_UDP) {
        outSchemaState->socketDef.transport = FB_UDP;
    } else {
        printf("I can't handle that type of comms\n");
        return 1;
    }

    /* this needs fixed for real life */
    outSchemaState->socketDef.host = outConnSpec->connInfo.socket.hostname;
    outSchemaState->socketDef.svc = outConnSpec->connInfo.socket.portStr;

    outSchemaState->socketDef.ssl_ca_file = NULL;
    outSchemaState->socketDef.ssl_cert_file = NULL;
    outSchemaState->socketDef.ssl_key_file = NULL;
    outSchemaState->socketDef.ssl_key_pass = NULL;
    outSchemaState->socketDef.vai = NULL;
    outSchemaState->socketDef.vssl_ctx = NULL;

    /* start Fixbuf specific stuff...get an info model */
    outSchemaState->infoModel = fbInfoModelAlloc();

    outSchemaState->exporterSession = fbSessionAlloc(outSchemaState->infoModel);

    outSchemaState->exporter = fbExporterAllocNet(&(outSchemaState->socketDef));
    if (outSchemaState->exporter) {
        outSchemaState->exporterBuf = fBufAllocForExport(
                                            outSchemaState->exporterSession,
                                            outSchemaState->exporter);
        if (!outSchemaState->exporterBuf) {
            printf("couldn't get exporterBuf\n");
        }
    } else {
        outSchemaState->exporter = NULL;
        printf("couldn't get exporter\n");
    }
    /* move on to making connections */

    /* wait for a connection to that listener */
    inSchemaState->collectorBuf = fbListenerWait(inSchemaState->collectorListener,
                                               &error);

    /* set the fBuf to automatically insert custom element type records
     * to the info model */
    fBufSetAutomaticInsert(inSchemaState->collectorBuf, &error);

    incomingState = inSchemaState;
    outgoingState = outSchemaState;

    /* set the schema builder template callback to be run with new templates
     * arrive */
    fbSessionAddTemplateCallback(fBufGetSession(inSchemaState->collectorBuf),
                                                templateReaderCallback);

    /* make fixbuf look for the next collection template.
     * this forces it to process all of the templates, which yields the
     * callback, so we get our schemas
     */
    fBufNextCollectionTemplate(inSchemaState->collectorBuf, NULL, &error);

    /* now that we have everything, fill in the data info struct */
    if(scDataInfoFillAsInput(inDataInfo,
                   rawIPFIXnextInput,
                   getNextRecordCopy, 
                   getNextRecordPtr, NULL, &scError))
    {
        printf("Couldn't fill data info as input %s\n", scError.msg);
        return 1;
    }

    if (scDataInfoFillAsOutput(outDataInfo,
                           writeRecord,
                           &scError))
    {
        printf("Couldn't fill data info as output %s\n", scError.msg);
        return 1;
    }
    
    /* set the max record length */
    inSchemaState->schemaLen = scDataInfoGetMaxRecordLength(inDataInfo);
    return 0;
}

ipfixIncomingSchemaState_t* newIncomingIpfixSchemaState(
    void)
{
    ipfixIncomingSchemaState_t *state = calloc(1, sizeof(ipfixIncomingSchemaState_t));
    return state;
}

ipfixOutgoingSchemaState_t* newOutgoingIpfixSchemaState(
    void)
{
    ipfixOutgoingSchemaState_t *state = calloc(1, sizeof(ipfixOutgoingSchemaState_t));
    return state;
}


void freeIncomingIpfixSchemaState(
    ipfixIncomingSchemaState_t   *schemaState)
{
    free(inputTemplateSchemaListHead);
    fBufFree(schemaState->collectorBuf);
    fbListenerFree(schemaState->collectorListener);
    fbInfoModelFree(schemaState->infoModel);
    free(schemaState);
}

void freeOutgoingIpfixSchemaState(
    ipfixOutgoingSchemaState_t *schemaState)
{
    fBufFree(schemaState->exporterBuf);
    fbInfoModelFree(schemaState->infoModel);
    free(schemaState);
}

void freeAddDescIPFIXDataInfo(
    scDataInfo_t   *inDataInfo,
    void           *inPotentialState,
    scDataInfo_t   *outDataInfo,
    void           *outPotentialState)
{
    freeIncomingIpfixSchemaState(inPotentialState);
    freeOutgoingIpfixSchemaState(outPotentialState);
    scDataInfoFreeContents(inDataInfo);
    scDataInfoFreeContents(outDataInfo);
}
    

void freeAddDescIPFIXDataInfoAlloc(
    scDataInfo_t  **inDataInfo,
    void           *inPotentialState,
    scDataInfo_t  **outDataInfo,
    void           *outPotentialState)
{
    freeIncomingIpfixSchemaState(inPotentialState);
    freeOutgoingIpfixSchemaState(outPotentialState);
    scDataInfoFree(*inDataInfo);
    scDataInfoFree(*outDataInfo);
}
