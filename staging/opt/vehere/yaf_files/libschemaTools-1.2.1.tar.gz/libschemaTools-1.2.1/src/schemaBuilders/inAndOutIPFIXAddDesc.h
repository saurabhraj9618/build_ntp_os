#ifndef _INANDOUTIPFIXADDDESC_H
#define _INANDOUTIPFIXADDDESC_H

#include <schemaTools/schemaTools.h>

int getAddDescIPFIXDataInfo(
                        scConnSpec_t   *inConnSpec,
                        scDataInfo_t   *inDataInfo,
                        void          **inPotentialState,
                        scConnSpec_t   *outConnSpec,
                        scDataInfo_t   *outDataInfo,
                        void          **outPotentialState);

int getAddDescIPFIXDataInfoAlloc(
                        scConnSpec_t   *inConnSpec,
                        scDataInfo_t  **inDataInfo,
                        void          **inPotentialState,
                        scConnSpec_t   *outConnSpec,
                        scDataInfo_t  **outDataInfo,
                        void          **outPotentialState);

void freeAddDescIPFIXDataInfo(
                        scDataInfo_t   *inDataInfo,
                        void           *inPotentialState,
                        scDataInfo_t   *outDataInfo,
                        void           *outPotentialState);

void freeAddDescIPFIXDataInfoAlloc(
                        scDataInfo_t  **inDataInfo,
                        void           *inPotentialState,
                        scDataInfo_t  **outDataInfo,
                        void           *outPotentialState);


#endif /* _INANDOUTIPFIXADDDESC_H */
