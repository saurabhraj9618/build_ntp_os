#include <fixbuf/public.h>

#include "testSchemaForSample.h"
#include <string.h>

scDataInfoGetRecErr_t nextStat(void        *streamBlob,
                               uint8_t     *buf,
                               scSchema_t **schemaUsed);
uint32_t testNextInput(void   **streamBlobDP);
void fillInStats(void);

#define FREE_ERROR_RETURN_1()                                           \
    scErrorFree(error);                                                 \
    return 1;

#define CHECK_IE(_ie_)                                                  \
    if (!_ie_) {                                                        \
        printf("Couldn't add IE %s\n", error->msg);                     \
        scErrorFree(error);                                             \
        return 1;                                                       \
    }


/* predefined strings for data records */
#define CUTCH "Andrew McCutchen"
#define PEDRO "Pedro Alvarez"
#define KID   "Neil Walker"
#define HAM   "Josh Hamilton"
#define BRAUN "Ryan Braun"
#define BUCS  "Pittsburgh Pirates"
#define RANG  "Texas Rangers"
#define BREW  "Milwaukee Brewers"

/* struct containing the values for the input*/
typedef struct myPlayerStat_st {
    scVarfield_t    playerName;
    int8_t          hrs;
    scVarfield_t    team;
    int32_t         sbs;
    uint16_t        hits;
    uint32_t        atBats;
    uint8_t         runs;
    int16_t         rbis;
} myPlayerStat_t;

/* struct containing the values for the output*/
typedef struct myOtherStat_st {
    uint32_t        runsCreated;
    double          average;
    int32_t         sbs;
    scVarfield_t    team;
    int8_t          hrs;
    scVarfield_t    playerName;
} myOtherStat_t;

/* helper function for readability */
void fillAStat(
    myPlayerStat_t *s,
    char           *playerName,
    char           *team,
    uint32_t        atBats,
    uint8_t         runs,
    uint16_t        hits,
    int8_t          hrs,
    int16_t         rbis,
    int32_t         sbs);

/* struct used as state to keep track of where we are in the data to copy */
typedef struct statInputInfo_st {
    uint32_t    statIndex;
    uint32_t    inputIndex;
} statInputInfo_t;

/* Makes a completely new copy of the record */
uint32_t baseballRecCopy(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src)
{
    myPlayerStat_t *dstStat = (myPlayerStat_t*)dst;
    myPlayerStat_t *srcStat = (myPlayerStat_t*)src;

    /* copy from the original data to the new buffer */
    memcpy(dst, src, scSchemaGetRecordLength(schema));

    /* Give the new records their own copy of the strings */
    dstStat->playerName.dataPtr = calloc(1, dstStat->playerName.len);
    memcpy(dstStat->playerName.dataPtr,
           srcStat->playerName.dataPtr,
           dstStat->playerName.len);

    dstStat->team.dataPtr = calloc(1, dstStat->team.len);
    memcpy(dstStat->team.dataPtr,
           srcStat->team.dataPtr,
           dstStat->team.len);

    return scSchemaGetRecordLength(schema);
}

/* This function completely frees a record that was copied with
 * baseballRecCopy, including freeing the buffer
 */
void baseballRecFree(
    scSchema_t *schema,
    uint8_t    *buf)
{
    myPlayerStat_t *theStat = (myPlayerStat_t*)buf;

    /* free the strings, then free the record */
    free(theStat->playerName.dataPtr);
    free(theStat->team.dataPtr);

    free(theStat);
}

/* This function frees a record created with baseballRecCopy, but does NOT
 * free the buffer, just the secondary fields
 */
void secondaryBaseballRecFree(
    scSchema_t *schema,
    uint8_t    *rec)
{
    myPlayerStat_t *theStat = (myPlayerStat_t*)rec;

    /* just free the strings */
    free(theStat->playerName.dataPtr);
    free(theStat->team.dataPtr);
}

/* frees the entire output record */
void otherRecFree(
    scSchema_t *schema,
    uint8_t    *rec)
{
    myOtherStat_t *theStat = (myOtherStat_t*)rec;

    free(theStat->playerName.dataPtr);
    free(theStat->team.dataPtr);

    free(theStat);
}

/* frees output records, but not the buffer, allows reuse */
void secondaryOtherRecFree(
    scSchema_t *schema,
    uint8_t    *rec)
{
    myOtherStat_t *theStat = (myOtherStat_t*)rec;

    free(theStat->playerName.dataPtr);
    free(theStat->team.dataPtr);
}

uint32_t otherRecCopy(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src)
{
    myOtherStat_t *dstStat = (myOtherStat_t*)dst;
    myOtherStat_t *srcStat = (myOtherStat_t*)src;

    /* copy from the original data to the new buffer */
    memcpy(dst, src, scSchemaGetRecordLength(schema));

    /* Give the new records their own copy of the strings */
    dstStat->playerName.dataPtr = calloc(1, dstStat->playerName.len);
    memcpy(dstStat->playerName.dataPtr,
           srcStat->playerName.dataPtr,
           dstStat->playerName.len);

    dstStat->team.dataPtr = calloc(1, dstStat->team.len);
    memcpy(dstStat->team.dataPtr,
           srcStat->team.dataPtr,
           dstStat->team.len);

    return scSchemaGetRecordLength(schema);
}


/* holds the data records */
#define NUM_STATS 5
#define NUM_INPUTS 5
static myPlayerStat_t   monday[NUM_STATS];
static myPlayerStat_t   tuesday[NUM_STATS];
static myPlayerStat_t   wednesday[NUM_STATS];
static myPlayerStat_t   thursday[NUM_STATS];
static myPlayerStat_t   friday[NUM_STATS];

static myPlayerStat_t  *today;

/* copy the next stat record (getNextRecordCopy) */
scDataInfoGetRecErr_t nextStat(
    void           *streamBlob,
    uint8_t        *buf,
    scSchema_t    **schemaUsed)
{
    statInputInfo_t    *inputPtr    = streamBlob;
    myPlayerStat_t     *dstStat      = (myPlayerStat_t*)buf;
    myPlayerStat_t     *srcStat     = (today +
                                                        inputPtr->statIndex);

    /* if the statIndex gets to the end, return end of file (call nextInput) */
    if (inputPtr->statIndex >= NUM_STATS) {
        return SCGETNEXT_ERR_EOF;
    }

    /* copy the record into the buffer, then copy the strings */
    memcpy(dstStat, srcStat, sizeof(myPlayerStat_t));
    dstStat->playerName.dataPtr = calloc(1, dstStat->playerName.len);
    memcpy(dstStat->playerName.dataPtr,
           srcStat->playerName.dataPtr,
           dstStat->playerName.len);

    dstStat->team.dataPtr = calloc(1, dstStat->team.len);
    memcpy(dstStat->team.dataPtr,
           srcStat->team.dataPtr,
           dstStat->team.len);

    /* move the stat index to the next player */
    inputPtr->statIndex++;

    return SCGETNEXT_OK;
}

/* Moves the state onto the next input, which is another "day" in this file */
uint32_t testNextInput(
    void  **streamBlobDP)
{
    statInputInfo_t    *sStream;

    /* if this is the first time, allocate the state */
    if (!(*streamBlobDP)) {
        *streamBlobDP = calloc(1, sizeof(statInputInfo_t));
    }

    sStream = *streamBlobDP;

    /* set the state to the appropriate "day", treated like a file */
    switch (sStream->inputIndex) {
      case 0:
        today = monday;
        break;
      case 1:
        today = tuesday;
        break;
      case 2:
        today = wednesday;
      case 3:
        today = thursday;
        break;
      case 4:
        today = friday;
        break;
      case 5:
        /* the last day has been processed, quit and free the blob */
        free(*streamBlobDP);
        return 0;
    }

    /* reset to the first player in the day (file), and increment */
    sStream->statIndex = 0;
    sStream->inputIndex++;

    /* return that there's more data */
    return 1;
}

/* helper function for building record tables */
void fillAStat(
    myPlayerStat_t *s,
    char           *playerName,
    char           *team,
    uint32_t        atBats,
    uint8_t         runs,
    uint16_t        hits,
    int8_t          hrs,
    int16_t         rbis,
    int32_t         sbs)
{
    s->playerName.len       = strlen(playerName);
    s->playerName.dataPtr   = (uint8_t*)strdup(playerName);
    s->team.len             = strlen(team);
    s->team.dataPtr         = (uint8_t*)strdup(team);
    s->runs                 = runs;
    s->hits                 = hits;
    s->atBats               = atBats;
    s->hrs                  = hrs;
    s->rbis                 = rbis;
    s->sbs                  = sbs;
}
    
/* builds the record table */
void fillInStats(
    void)
{
    memset(monday, 0, NUM_STATS * sizeof(myPlayerStat_t));
    memset(tuesday, 0, NUM_STATS * sizeof(myPlayerStat_t));
    memset(wednesday, 0, NUM_STATS * sizeof(myPlayerStat_t));
    memset(thursday, 0, NUM_STATS * sizeof(myPlayerStat_t));
    memset(friday, 0, NUM_STATS * sizeof(myPlayerStat_t));
    fillAStat(&(monday[0]),     CUTCH, BUCS, 0, 0, 0, 0, 0, 0); 
    fillAStat(&(tuesday[0]),    CUTCH, BUCS, 2, 1, 1, 1, 1, 0); 
    fillAStat(&(wednesday[0]),  CUTCH, BUCS, 4, 2, 4, 1, 2, 0); 
    fillAStat(&(thursday[0]),   CUTCH, BUCS, 3, 1, 1, 0, 1, 3); 
    fillAStat(&(friday[0]),     CUTCH, BUCS, 4, 0, 0, 0, 0, 3); 

    fillAStat(&(monday[1]),     PEDRO, BUCS, 0, 0, 0, 0, 0, 0); 
    fillAStat(&(tuesday[1]),    PEDRO, BUCS, 4, 0, 0, 0, 0, 0); 
    fillAStat(&(wednesday[1]),  PEDRO, BUCS, 4, 0, 0, 0, 0, 0); 
    fillAStat(&(thursday[1]),   PEDRO, BUCS, 3, 0, 0, 0, 0, 0); 
    fillAStat(&(friday[1]),     PEDRO, BUCS, 3, 0, 0, 0, 0, 0); 

    fillAStat(&(monday[2]),     KID, BUCS, 0, 0, 0, 0, 0, 0); 
    fillAStat(&(tuesday[2]),    KID, BUCS, 3, 0, 1, 0, 1, 0); 
    fillAStat(&(wednesday[2]),  KID, BUCS, 4, 0, 1, 0, 1, 0); 
    fillAStat(&(thursday[2]),   KID, BUCS, 3, 0, 1, 0, 1, 0); 
    fillAStat(&(friday[2]),     KID, BUCS, 5, 0, 0, 0, 0, 0); 

    fillAStat(&(monday[3]),     HAM, RANG, 4, 1, 1, 1, 2, 0); 
    fillAStat(&(tuesday[3]),    HAM, RANG, 5, 4, 5, 4, 8, 3); 
    fillAStat(&(wednesday[3]),  HAM, RANG, 0, 0, 0, 0, 0, 0); 
    fillAStat(&(thursday[3]),   HAM, RANG, 4, 1, 1, 1, 2, 0); 
    fillAStat(&(friday[3]),     HAM, RANG, 4, 3, 3, 2, 2, 3); 

    fillAStat(&(monday[4]),     BRAUN, BREW, 4, 1, 2, 1, 1, 0); 
    fillAStat(&(tuesday[4]),    BRAUN, BREW, 4, 2, 3, 0, 1, 5); 
    fillAStat(&(wednesday[4]),  BRAUN, BREW, 4, 1, 2, 1, 1, 0); 
    fillAStat(&(thursday[4]),   BRAUN, BREW, 0, 0, 0, 0, 0, 0); 
    fillAStat(&(friday[4]),     BRAUN, BREW, 2, 1, 0, 0, 0, 0); 
}

/* used for schema debugging */
void printStatOffsets(
    void)
{
    myPlayerStat_t  s;
    uint8_t        *ptr = (uint8_t*)&s;

    printf("name:       %ld\n", (uint8_t*)&s.playerName - ptr);
    printf("hrs:        %ld\n", (uint8_t*)&s.hrs - ptr);
    printf("team:       %ld\n", (uint8_t*)&s.team - ptr);
    printf("sbs:        %ld\n", (uint8_t*)&s.sbs - ptr);
    printf("hits:       %ld\n", (uint8_t*)&s.hits - ptr);
    printf("atBats:     %ld\n", (uint8_t*)&s.atBats - ptr);
    printf("runs:       %ld\n", (uint8_t*)&s.runs - ptr);
    printf("rbis:       %ld\n", (uint8_t*)&s.rbis - ptr);
}

void printOtherStatOffsets(
    void)
{
    myOtherStat_t  s;
    uint8_t        *ptr = (uint8_t*)&s;

    printf("runsCreated %ld\n", (uint8_t*)&s.runsCreated - ptr);
    printf("average:    %ld\n", (uint8_t*)&s.average - ptr);
    printf("sbs:        %ld\n", (uint8_t*)&s.sbs - ptr);
    printf("team:       %ld\n", (uint8_t*)&s.team - ptr);
    printf("hrs:        %ld\n", (uint8_t*)&s.hrs - ptr);
    printf("name:       %ld\n", (uint8_t*)&s.playerName - ptr);
    printf("Sizeof:     %ld\n", sizeof(myOtherStat_t));
}

/* return the data info, and allocate the memory needed for the data info */
int getSampleDataInfoAlloc(
    scDataInfo_t  **inputDataInfo,
    scDataInfo_t  **outputDataInfo)
{
    *inputDataInfo = scDataInfoAlloc();
    *outputDataInfo = scDataInfoAlloc();
    return getSampleDataInfo(*inputDataInfo, *outputDataInfo);
} 

/* return the data info to an already allocated data info struct */
int getSampleDataInfo(
    scDataInfo_t    *inputDataInfo,
    scDataInfo_t    *outputDataInfo)
{
    scSchema_t             *inputSchema     = NULL;
    scSchema_t             *outputSchema    = NULL;
    scInfoElement_t        *ie              = NULL;
    scError_t              *error;

    error = scErrorAlloc();

    /* set up the data records */
    fillInStats();

    /* allocate input schema with the functions outlined above */
    inputSchema            = scSchemaAlloc("baseballTeam", 1110,
                                        baseballRecFree, 
                                        secondaryBaseballRecFree,
                                        baseballRecCopy,
                                        error); 

    if (!inputSchema) {
        printf("couldn't alloc schema...%s\n", error->msg);
        FREE_ERROR_RETURN_1();
    }

    /* fill in the data info with record level functions */
    if (scDataInfoFillAsInput(inputDataInfo, testNextInput, nextStat, 
                              NULL, NULL, error)) 
    {
        printf("error filling data in data info %s\n", error->msg);
        FREE_ERROR_RETURN_1();
    }

    /* string player name */
    ie = scSchemaAddCustomIEStandardFuncs(inputSchema, MY_STATS_PEN, 1, STRING, 
                                NULL, "PLAYER", 0, 0, DEFAULT, NULL, NONE, error);
    CHECK_IE(ie);

    /* int 8 homeruns */
    ie = scSchemaAddCustomIEStandardFuncs(inputSchema, MY_STATS_PEN, 3, 
                   SIGNED_8, NULL, "HRS", 0, 162, QUANTITY, NULL, NONE, error);
    CHECK_IE(ie);

    /* string team */
    ie = scSchemaAddCustomIEStandardFuncs(inputSchema, MY_STATS_PEN, 2, STRING, 
                                NULL, "TEAM", 0, 0, DEFAULT, NULL, NONE, error);
    CHECK_IE(ie);

    /* int32 stolen bases */
    ie = scSchemaAddCustomIEStandardFuncs(inputSchema, MY_STATS_PEN, 7, 
                    SIGNED_32, NULL, "SBS", 0, 162, QUANTITY, NULL, NONE, error);
    CHECK_IE(ie);

    /* uint16 hits */
    ie = scSchemaAddCustomIEStandardFuncs(inputSchema, MY_STATS_PEN, 4, 
                    UNSIGNED_16, NULL, "HITS", 0, 162, QUANTITY, NULL, NONE, error);
    CHECK_IE(ie);

    /* uin32 at bats */
    ie = scSchemaAddCustomIEStandardFuncs(inputSchema, MY_STATS_PEN, 5, 
                    UNSIGNED_32, NULL, "ATBATS", 0, 162, QUANTITY, NULL, NONE, error);
    CHECK_IE(ie);

    /* uint8 runs */
    ie = scSchemaAddCustomIEStandardFuncs(inputSchema, MY_STATS_PEN, 6, 
                    UNSIGNED_8, NULL, "RUNS", 0, 162,QUANTITY, NULL, NONE, error);
    CHECK_IE(ie);

    /* int16 runs batted in */
    ie = scSchemaAddCustomIEStandardFuncs(inputSchema, MY_STATS_PEN, 8, 
                    SIGNED_16, NULL, "RBIS", 0, 162, QUANTITY, NULL, NONE, error);
    CHECK_IE(ie);

    /* copy the input schema into an output schema to be changed */
    outputSchema = scSchemaCopy(inputSchema, 1, "outputschema",
                                otherRecFree,
                                secondaryOtherRecFree,
                                otherRecCopy,
                                error);

    if (!outputSchema) {
        printf("error copying schema: %s\n", error->msg);
        return 1;
    }

    /* add the input schema to the input data info */
    scDataInfoAddSchema(inputDataInfo, inputSchema, error);

    /* remove hits, atbats, runs, and rbis */
    scSchemaRemoveIEByID(outputSchema, MY_STATS_PEN, 4, error);
    scSchemaRemoveIEByID(outputSchema, MY_STATS_PEN, 5, error);
    scSchemaRemoveIEByID(outputSchema, MY_STATS_PEN, 6, error);
    scSchemaRemoveIEByID(outputSchema, MY_STATS_PEN, 8, error);

    /* reorder remaining elements */
    scSchemaMoveIEToEndByName(outputSchema, "PLAYER", error);
    scSchemaMoveIEBeforeAnotherByName(outputSchema, "TEAM", "HRS", error);
    scSchemaMoveIEBeforeAnotherByName(outputSchema, "SBS", "TEAM", error);

    
    /* uint32 runs created (runs + rbis) */
    ie = scSchemaAddCustomIEStandardFuncs(outputSchema, MY_STATS_PEN, 10,
             UNSIGNED_32, NULL, "RUNS_CREATED", 0, 162, QUANTITY, NULL, NONE, error);
    CHECK_IE(ie);

    /* float 64 average */
    ie = scSchemaAddCustomIEStandardFuncs(outputSchema, MY_STATS_PEN, 9,
                    FLOAT_64, NULL, "AVERAGE", 0, 162, QUANTITY, NULL, NONE, error);
    CHECK_IE(ie);

    /* reorder new elements */
    scSchemaMoveIEToBeginningByName(outputSchema, "RUNS_CREATED", error); 
    scSchemaMoveIEAfterAnotherByName(outputSchema, "AVERAGE", "RUNS_CREATED",
                                                        error);

    /* fill in the output data info */
    scDataInfoFillAsOutput(outputDataInfo, NULL, error);
    
    /* add output schema to output data info */
    scDataInfoAddSchema(outputDataInfo, outputSchema, error);

    /* validate input data info */
    if (scDataInfoValidate(inputDataInfo, error)) {
        printf("bad data info\n");
    } else {
        printf("in data info validated\n");
    }

    scErrorFree(error);

    return 0;
}

void freeStats(void); 

void freeSampleDataInfo(
    scDataInfo_t   *inputDataInfo,
    scDataInfo_t   *outputDataInfo)
{
    freeStats();
    scSchemaFree(scDataInfoGetFirstSchema(inputDataInfo));
    scSchemaFree(scDataInfoGetFirstSchema(outputDataInfo));
}

void freeSampleDataInfoAlloc(
    scDataInfo_t  **inputDataInfo,
    scDataInfo_t  **outputDataInfo)
{
    freeStats();
    scDataInfoFree(*inputDataInfo);
    scDataInfoFree(*outputDataInfo);
}

void freeStats(
    void)
{
    int i;
    for (i = 0; i < NUM_STATS; i++) {
        free(monday[i].playerName.dataPtr);
        free(tuesday[i].playerName.dataPtr);
        free(wednesday[i].playerName.dataPtr);
        free(thursday[i].playerName.dataPtr);
        free(friday[i].playerName.dataPtr);
        free(monday[i].team.dataPtr);
        free(tuesday[i].team.dataPtr);
        free(wednesday[i].team.dataPtr);
        free(thursday[i].team.dataPtr);
        free(friday[i].team.dataPtr);
    }
}

void printStat(
    uint8_t    *myStat)
{
    myPlayerStat_t *s = (myPlayerStat_t*)myStat;

    printf("name:       %s\n", s->playerName.dataPtr);
    printf("hrs:        %d\n", s->hrs);
    printf("team:       %s\n", s->team.dataPtr);
    printf("sbs:        %d\n", s->sbs);
    printf("hits:       %d\n", s->hits);
    printf("atBats:     %d\n", s->atBats);
    printf("runs:       %d\n", s->runs);
    printf("rbis:       %d\n", s->rbis);
}

void printOtherStat(
    uint8_t    *otherStat)
{
    myOtherStat_t *s = (myOtherStat_t*)otherStat;

    printf("runsCreated %d\n", s->runsCreated);
    printf("average:    %f\n", s->average);
    printf("sbs:        %d\n", s->sbs);
    printf("team:       %s\n", s->team.dataPtr);
    printf("hrs:        %d\n", s->hrs);
    printf("name:       %s\n", s->playerName.dataPtr);
}
