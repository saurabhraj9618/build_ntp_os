#ifndef _TESTSCHEMAFORSAMPLE_H
#define _TESTSCHEMAFORSAMPLE_H

#include <schemaTools/schemaTools.h>
#define MY_STATS_PEN 15

/* this function assumes a previously allocated scDataInfo_t variable
 * scDataInfo_t  dataInfo;
 * scSchema_t          *topSchema;
 * getSampleDataInfo(&dataInfo);
 * topSchema = scDataInfoGetTopLevelSchema(&dataInfo);
 * { run the guts of the program }
 * scSchemaFree(topSchema);
 */
int getSampleDataInfo(scDataInfo_t    *inputDataInfo,
                       scDataInfo_t    *outputDataInfo);

/* this function assumes nothing has been allocated
 * scDataInfo_t *dataInfo = NULL;
 * getBasebaseballDataInfoAlloc(&dataInfo);
 * { run the guts of the program }
 * scDataInfoFree(dataInfo);
 */
int getSampleDataInfoAlloc(scDataInfo_t  **inputDataInfo,
                            scDataInfo_t  **outputDataInfo);

void freeSampleDataInfo(scDataInfo_t   *inputDataInfo,
                        scDataInfo_t   *outputDataInfo);

void freeSampleDataInfoAlloc(scDataInfo_t  **inputDataInfo,
                             scDataInfo_t  **outputDataInfo);

void printStat(uint8_t *myStat);
void printOtherStat(uint8_t    *otherStat);

#endif /* _TESTSCHEMAFORSAMPLE_H */
