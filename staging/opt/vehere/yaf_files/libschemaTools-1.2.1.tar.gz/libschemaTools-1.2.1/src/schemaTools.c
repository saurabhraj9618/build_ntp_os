#include <schemaTools/schemaTools.h>
#include "schemaToolsPrivate.h"
#include <fixbuf/public.h>

/**
 * Struct building and interactions

 */
static fbInfoModel_t  *lookupInfoModel = NULL;

static int standardTypeBasedNonIEPrintFunc(
    scInfoType_t        type,
    char               *buf,
    int                 maxlen,
    const uint8_t      *val);


uint32_t ieTypeLengths[] = {
    sizeof(scVarfield_t), /* OCTET_ARRAY */
    1, /* u8 */
    2, /* u16 */
    4,
    8, /* u64 */
    1, /* s8 */
    2,
    4,
    8, /* s64*/
    4, /*f 32 */
    8, /* f64 */
    1, /* boolean */
    6, /* mac */
    sizeof(scVarfield_t), /* STRING */
    4,
    8,
    8,/* 8's are times */
    8,
    4, /* ipv4 */
    16, /* IPv6 ADDRESS */
    sizeof(fbBasicList_t),
    sizeof(fbSubTemplateList_t),
    sizeof(fbSubTemplateMultiList_t)};

scInfoElement_t* scInfoElementAllocAndFill(
    fbInfoModel_t  *infoModel,
    uint32_t        ent,
    uint32_t        id)
{
    scInfoElement_t    *ie = calloc(1, sizeof(scInfoElement_t));

    if (lookupAndFillIE(infoModel, ie, ent, id, NULL)) {
        scInfoElementFree(ie);
        return NULL;
    }

    return ie;
}

/* internal function, no need for error reporting */
int lookupAndFillIE(
    fbInfoModel_t      *infoModel,
    scInfoElement_t    *ie,
    uint32_t            ent,
    uint32_t            id,
    char               *name)
{
    const fbInfoElement_t    *lookupIE;

    if (name) {
        if (infoModel) {
            lookupIE = fbInfoModelGetElementByName(infoModel, name);
            if (!lookupIE) {
                printf("no lookup IE 1 %s\n", name);
                return 1;
            }
        } else {
            if (!lookupInfoModel) {
                lookupInfoModel = fbInfoModelAlloc();
            }

            lookupIE = fbInfoModelGetElementByName(lookupInfoModel, name);
            if (!lookupIE) {
                printf("no lookup IE 2 %s\n", name);
                return 1;
            }
        }
    } else {
        if (infoModel) {
            lookupIE = fbInfoModelGetElementByID(infoModel, id, ent);
            if (!lookupIE) {
                printf("no lookup IE 3 %d %d\n", ent, id);
                return 1;
            }
        } else {
            if (!lookupInfoModel) {
                lookupInfoModel = fbInfoModelAlloc();
            }

            lookupIE = fbInfoModelGetElementByID(lookupInfoModel, id, ent);
            if (!lookupIE) {
                printf("no lookup IE 4 %d %d\n", ent, id);
                return 1;
            }
        }
    }

    ie->ent         = lookupIE->ent;
    ie->id          = lookupIE->num;
    ie->type        = lookupIE->type;
    if (lookupIE->len != FB_IE_VARLEN) {
        ie->len         = lookupIE->len;
    } else {
        ie->len = ieTypeLengths[ie->type];
    }

    if ((ie->type == OCTET_ARRAY || ie->type == STRING) &&
            lookupIE->len != FB_IE_VARLEN)
    {
        ie->lenOverride = ie->len;
    }
    ie->name        = strdup(lookupIE->ref.name);
    ie->rangeMin    = lookupIE->min;
    ie->rangeMax    = lookupIE->max;
    ie->semantic    = FB_IE_SEMANTIC(lookupIE->flags);
    ie->units       = FB_IE_UNITS(lookupIE->flags);

    return 0;
}

int scDataInfoFillAsInput(
    scDataInfo_t                   *dataInfo,
    scDataInfoNextInput_fn          nextInput,
    scDataInfoGetNextRecCopy_fn     getNextRecordCopy,
    scDataInfoGetNextRecPtr_fn      getNextRecordPtr,
    scDataInfoGetNextSchema_fn      getNextSchema,
    scError_t                      *error)
{
    if (!dataInfo) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null data info in DataInfoFillAsInput\n");
        return 1;
    }

    if (!nextInput) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Next Input function required for input data info\n");
        return 1;
    }

    if (!getNextRecordCopy && !getNextRecordPtr) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Need either get next copy and cleanup or get ptr\n");
        return 1;
    }

    dataInfo->nextInput         = nextInput;
    dataInfo->getNextRecordCopy = getNextRecordCopy;
    dataInfo->getNextRecordPtr  = getNextRecordPtr;
    dataInfo->getNextSchema     = getNextSchema;
    dataInfo->isInputDataInfo   = 1;

    return 0;
}

int scDataInfoFillAsOutput(
    scDataInfo_t               *dataInfo,
    scDataInfoWriteRecord_fn    writeRecord,
    scError_t                  *error)
{
    if (!dataInfo) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null data info in DataInfoFillAsOutput\n");
        return 1;
    }

    if (!writeRecord)
    {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Write Record function is null for data info as output\n");
        return 1;
    }

    dataInfo->writeRecord       = writeRecord;
    dataInfo->isInputDataInfo   = 0;

    return 0;
}

/*  DataInfo manipulation functions */
scDataInfo_t* scDataInfoAlloc(
    void)
{
    scDataInfo_t    *dataInfo = calloc(1, sizeof(scDataInfo_t));

    return dataInfo;
}

void scDataInfoFreeContents(
    scDataInfo_t    *dataInfo)
{
    scSchema_t     *schema;

    if (!dataInfo) {
        return;
    }

    while(dataInfo->firstSchema) {
        scDetachHeadOfDLL((scDLL_t**)&(dataInfo->firstSchema),
                          NULL,
                          (scDLL_t**)&schema);
        scSchemaFree(schema);
    }

    dataInfo->lastSchema = NULL;
    dataInfo->numSchemas = 0;

    dataInfo->maxRecordLength = 0;

    if (lookupInfoModel) {
        fbInfoModelFree(lookupInfoModel);
        lookupInfoModel = NULL;
    }
}

void scDataInfoFree(
    scDataInfo_t   *dataInfo)
{
    if (!dataInfo) {
        return;
    }

    scDataInfoFreeContents(dataInfo);

    free(dataInfo);
}

int scDataInfoAddSchema(
    scDataInfo_t   *dataInfo,
    scSchema_t     *schema,
    scError_t      *error)
{
    scSchema_t         *sch;
    if (!dataInfo || !schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter passed to DataInfoAddSchema\n");
        return 1;
    }

    for (sch = dataInfo->firstSchema; sch; sch = sch->next) {
        if (sch->id == schema->id) {
            scDetachThisEntryOfDLL((scDLL_t**)&dataInfo->firstSchema,
                                   (scDLL_t**)&dataInfo->lastSchema,
                                   (scDLL_t*)sch);
            scSchemaFree(sch);
            break;
        }
    }

    if (scSchemaValidate(schema, error)) {
        return 1;
    }

    scSchemaRemoveEmptyGroups(schema);

    scSchemaForceRecPtrAlloc(schema);

    scAttachTailToDLL((scDLL_t**)&(dataInfo->firstSchema),
                      (scDLL_t**)&(dataInfo->lastSchema),
                      (scDLL_t*)schema);

    schema->len = schema->lastPrimary->offset + schema->lastPrimary->len;

    if (schema->forcedFixedLen) {
        schema->len = schema->forcedFixedLen;
    }

    dataInfo->numSchemas++;

    if (schema->len > dataInfo->maxRecordLength) {
        dataInfo->maxRecordLength = schema->len;
    }

    return 0;
}

int scDataInfoAddSchemaForce(
    scDataInfo_t   *dataInfo,
    scSchema_t     *schema,
    scError_t      *error)
{
    scSchema_t         *sch;
    scSchema_t         *schemaIter = NULL;
    uint16_t            i;
    if (!dataInfo || !schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter passed to DataInfoAddSchema\n");
        return 1;
    }

    for (sch = dataInfo->firstSchema; sch; sch = sch->next) {
        if (sch->id == schema->id) {
            /* the ID coming in already exists, find a new one */
            for (i = 1; i < UINT16_MAX; i++) {
                for (schemaIter = dataInfo->firstSchema;
                     schemaIter;
                     schemaIter = schemaIter->next)
                {
                    if (schemaIter->id == i) {
                        break;
                    }
                }
                if (!schemaIter) { /* made it to the end of the loop */
                    schema->id = i;
                    break;
                }
            }
            break;
        }
    }

    if (scSchemaValidate(schema, error)) {
        return 1;
    }

    scSchemaForceRecPtrAlloc(schema);

    scAttachTailToDLL((scDLL_t**)&(dataInfo->firstSchema),
                      (scDLL_t**)&(dataInfo->lastSchema),
                      (scDLL_t*)schema);

    schema->len = schema->lastPrimary->offset + ieTypeLengths[schema->lastPrimary->type];

    if (schema->forcedFixedLen) {
        schema->len = schema->forcedFixedLen;
    }

    dataInfo->numSchemas++;

    if (schema->len > dataInfo->maxRecordLength) {
        dataInfo->maxRecordLength = schema->len;
    }

    return 0;
}

int scDataInfoRemoveSchema(
    scDataInfo_t   *dataInfo,
    scSchema_t     *schema,
    scError_t      *error)
{
    scSchema_t *sch;
    for (sch = dataInfo->firstSchema; sch; sch = sch->next) {
        if (sch->id == schema->id) {
            scDetachThisEntryOfDLL((scDLL_t**)&dataInfo->firstSchema,
                                   (scDLL_t**)&dataInfo->lastSchema,
                                   (scDLL_t*)sch);
            scSchemaFree(sch);
            return 0;
        }
    }

    if (sch) {
        dataInfo->numSchemas--;
        dataInfo->maxRecordLength = 0;
        for (sch = dataInfo->firstSchema; sch; sch = sch->next) {
            if (sch->len > dataInfo->maxRecordLength) {
                dataInfo->maxRecordLength = sch->len;
            }
        }

        /* TODO...deal with IE table */

        return 0;
    } else {
        ERR0("Schema not found");
        return 1;
    }
}


scSchema_t* scDataInfoGetNextSchema(
    scDataInfo_t    *dataInfo,
    scSchema_t      *lastSchema)
{
    if (lastSchema) {
        return lastSchema->next;
    }

    return dataInfo->firstSchema;
}

scSchema_t* scDataInfoGetFirstSchema(
    scDataInfo_t   *dataInfo)
{
    return dataInfo->firstSchema;
}

uint32_t scDataInfoGetMaxRecordLength(
    scDataInfo_t   *dataInfo)
{
    return dataInfo->maxRecordLength;
}

scDataInfoNextInput_fn scDataInfoGetNextInputFunc(
    scDataInfo_t    *dataInfo)
{
    return dataInfo->nextInput;
}

scDataInfoGetNextRecCopy_fn scDataInfoGetRecordCopyFunc(
    scDataInfo_t    *dataInfo)
{
    return dataInfo->getNextRecordCopy;
}

scDataInfoGetNextRecPtr_fn scDataInfoGetRecordPtrFunc(
    scDataInfo_t    *dataInfo)
{
    return dataInfo->getNextRecordPtr;
}

scDataInfoWriteRecord_fn scDataInfoGetWriteRecordFunc(
    scDataInfo_t       *dataInfo)
{
    return dataInfo->writeRecord;
}

scDataInfoGetNextSchema_fn scDataInfoGetNextSchemaFunc(
    scDataInfo_t       *dataInfo)
{
    return dataInfo->getNextSchema;
}

uint8_t scDataInfoValidate(
    scDataInfo_t   *dataInfo,
    scError_t      *error)
{
    uint8_t haveCopy    = 0;
    uint8_t havePtr     = 0;

    if (!dataInfo) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null data info passed to DataInfoValidate\n");
        return 1;
    }

    if (dataInfo->isInputDataInfo) {
        if (!dataInfo->nextInput) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Next Input function required for input data info\n");
            return 1;
        }

        if (dataInfo->getNextRecordPtr) {
            havePtr = 1;
        }

        if (dataInfo->getNextRecordCopy) {
            haveCopy = 1;
        }

        if (!haveCopy && !havePtr) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Record copy(and cleanup) or record pointer is required\n");
            return 1;
        }
    } else {
        if (!dataInfo->writeRecord) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Write Record function missing from output data info\n");
            return 1;
        }
    }

    if (!dataInfo->firstSchema) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("At least one schema required for data info\n");
        return 1;
    }

    /* Don't need to validate schemas, checked when added to dataInfo*/

    return 0;
}

/*************************** End of Data Information functions */

/*************************** Schema manipulation functions */
scSchema_t* scSchemaAlloc(
    char                       *schemaName,
    uint32_t                    schemaId,
    scSchemaFreeRecord_fn       freeRecordCopy,
    scSchemaFreeRecord_fn       freeSecondLevelFields,
    scSchemaDeepCopyRecord_fn   copyRecord,
    scError_t                  *error)
{
    scInfoType_t            type;
    scGroupedElements_t    *group;
    scSchema_t             *schema = calloc(1, sizeof(scSchema_t));

    if (!(freeRecordCopy && copyRecord && freeSecondLevelFields))
    {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR1("Schema %s given incomplete function pointers\n", schemaName);
        free(schema);
        return NULL;
    }

    schema->id                      = schemaId;
    schema->name                    = strdup(schemaName);
    schema->freeRecordCopy          = freeRecordCopy;
    schema->copyRecord              = copyRecord;
    schema->freeSecondLevelFields   = freeSecondLevelFields;
    schema->hasVarFields            = 0;

    schema->elementTableID          = g_hash_table_new_full(
                                                (GHashFunc)scInfoElementHash,
                                                (GEqualFunc)scInfoElementEqual,
                                                NULL, NULL);
    schema->elementTableName        = g_hash_table_new_full(
                                                g_str_hash, g_str_equal,
                                                NULL, NULL);
    schema->groupsByName            = g_hash_table_new_full(
                                                g_str_hash, g_str_equal,
                                                NULL, NULL);
    /* allocate groups for all types */
    /* allocate a hash table for groups with key as the name and group
     * as the value. No need to free them */
    for (type = OCTET_ARRAY; type != BASIC_LIST; type++) {
        group = scGroupedElementsAlloc(schema, getIETypeString(type),
                                       error);
        group->isDefaultTypeGroup = 1;
        if (!group) {
            ERR0("Couldn't allocate standard groups by type for schema\n");
            scSchemaFree(schema);
            return NULL;
        }

        /* add group to hash table based on username */
        g_hash_table_insert(schema->groupsByName,
                            scGroupedElementsGetUserString(group),
                            group);

    }

    return schema;
}

void scSchemaFree(
    scSchema_t *schema)
{
    scGroupedElements_t    *group;
    scInfoElement_t        *ie;
    scSchemaCopyPlan_t     *plan;

    if (!schema) {
        return;
    }

    while (schema->firstGroup) {
        scDetachHeadOfDLL((scDLL_t**)&(schema->firstGroup),
                        NULL,
                        (scDLL_t**)&group);

        scGroupedElementsFree(group);
    }

    while (schema->firstPrimary) {
        scDetachHeadOfDLL((scDLL_t**)&(schema->firstPrimary),
                          (scDLL_t**)&(schema->lastPrimary),
                          (scDLL_t**)&ie);

        scInfoElementFree(ie);
    }

    while (schema->firstVirtual) {
        scDetachHeadOfDLL((scDLL_t**)&(schema->firstVirtual),
                          (scDLL_t**)&(schema->lastVirtual),
                          (scDLL_t**)&ie);

        scInfoElementFree(ie);
    }

    while (schema->firstPlanAsSource) {
        scDetachHeadOfDLL((scDLL_t**)&(schema->firstPlanAsSource),
                          NULL,
                          (scDLL_t**)&plan);

        scSchemaCopyPlanFree(plan);
    }

    while (schema->firstDeepOnlyPlanAsSource) {
        scDetachHeadOfDLL((scDLL_t**)&(schema->firstDeepOnlyPlanAsSource),
                          NULL,
                          (scDLL_t**)&plan);

        scSchemaCopyPlanFree(plan);
    }

    if (schema->elementTableID) {
        g_hash_table_destroy(schema->elementTableID);
    }

    if (schema->elementTableName) {
        g_hash_table_destroy(schema->elementTableName);
    }

    if (schema->groupsByName) {
        g_hash_table_destroy(schema->groupsByName);
    }

    if (schema->builderMem) {
        schema->builderMemFree(schema->builderMem);
    }

    free(schema->name);

    if (schema->ctxFreeFunction) {
        schema->ctxFreeFunction(schema->ctx);
    }

    if (schema->recForPtr) {
        free(schema->recForPtr);
    }

    free(schema);
}

uint8_t scSchemaValidate(
    scSchema_t *schema,
    scError_t  *error)
{
    if (!schema->firstPrimary) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR1("Primary info elements required for schema %s\n", schema->name);
        return 1;
    }

    return 0;
}

uint8_t* scSchemaNewRecord(
    scSchema_t *schema)
{
    return calloc(1, schema->len);
}

int scSchemaAssociate(
    scSchema_t *inSchema,
    scSchema_t *outSchema,
    scError_t  *error)
{
    if (!inSchema || !outSchema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null schema pointer passed to scSchemaAssociate\n");
        return 1;
    }

    inSchema->associatedSchema = outSchema;
    outSchema->associatedSchema = inSchema;

    return 0;
}

void addIEToHashAndDefaultGroups(
    scSchema_t         *schema,
    scInfoElement_t    *ie)
{
    scInfoElement_t    *inTable = NULL;
    scGroupedElements_t    *group = NULL;

    inTable = g_hash_table_lookup(schema->elementTableID, &(ie->ent));
    if (inTable) { /* loop */
        while (inTable->nextIdenticalIE) {
            inTable = inTable->nextIdenticalIE;
        }
        inTable->nextIdenticalIE = ie;
    } else {
        g_hash_table_insert(schema->elementTableID, &(ie->ent), ie);
        g_hash_table_insert(schema->elementTableName, ie->name, ie);
    }

    if (!schema->emptyGroupsRemoved) {
        group = g_hash_table_lookup(schema->groupsByName,
                                    getIETypeString(ie->type));
        if (group) {
            scError_t   error;
            scGroupedElementsAddIE(group, ie, &error);
        }
    }
}

scSchema_t* scSchemaDuplicate(
    scSchema_t                 *schema,
    scError_t                  *error)
{
    scSchema_t *newSchema;
    newSchema = scSchemaCopy(schema,
                        schema->id,
                        schema->name,
                        schema->freeRecordCopy,
                        schema->freeSecondLevelFields,
                        schema->copyRecord,
                        error);
    if (schema->builderMem) {
        newSchema->builderMem = schema->builderMemAllocAndCopy(schema);
        newSchema->builderMemFree = schema->builderMemFree;
        newSchema->builderMemAllocAndCopy = schema->builderMemAllocAndCopy;
    }

    return newSchema;
}

scSchema_t* scSchemaCopy(
    scSchema_t                 *schema,
    uint32_t                    newSchemaID,
    char                       *newSchemaName,
    scSchemaFreeRecord_fn       freeRecordCopy,
    scSchemaFreeRecord_fn       freeSecondLevelFields,
    scSchemaDeepCopyRecord_fn   copyRecord,
    scError_t                  *error)
{
    scInfoElement_t        *oldIE;
    scInfoElement_t        *newIE;
    scGroupedElements_t    *newGroup;
    scGroupedElements_t    *oldGroup;
    scNestedIE_t           *oldNested;
    scSchema_t             *newSchema;

    if (!schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null schema passed to schema copy\n");
        return NULL;
    }

    if (!newSchemaID) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("schema ID of 0 passed to schema copy, 0 isn't allowed\n");
        return NULL;
    }

    if (!newSchemaName) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Null schema name passed to schema copy, must have a name\n");
        return NULL;
    }

    newSchema = scSchemaAlloc(newSchemaName,
                              newSchemaID,
                              freeRecordCopy,
                              freeSecondLevelFields,
                              copyRecord,
                              error);

    if (!newSchema) {
        return NULL;
    }

    newSchema->numElements          = schema->numElements;
    newSchema->len                  = schema->len;
    newSchema->hasVarFields         = schema->hasVarFields;
    newSchema->ctx                  = NULL;
    newSchema->ctxFreeFunction      = NULL;

    newSchema->firstPlanAsSource    = NULL;

    /* move over info elements */
    for (oldIE = schema->firstPrimary; oldIE; oldIE = oldIE->next) {
        newIE = scInfoElementCopy(oldIE, error);
        if (!newIE) {
            ERR_APPEND("scSchemaCopy");
            scSchemaFree(newSchema);
            return NULL;
        }
        scAttachTailToDLL((scDLL_t**)&(newSchema->firstPrimary),
                    (scDLL_t**)&(newSchema->lastPrimary),
                    (scDLL_t*)newIE);
        addIEToHashAndDefaultGroups(newSchema, newIE);
    }

    for (oldIE = schema->firstVirtual; oldIE; oldIE = oldIE->next) {
        newIE = scInfoElementCopy(oldIE, error);
        if (!newIE) {
            ERR_APPEND("scSchemaCopy");
            scSchemaFree(newSchema);
            return NULL;
        }
        scAttachTailToDLL((scDLL_t**)&(newSchema->firstVirtual),
                    (scDLL_t**)&(newSchema->lastVirtual),
                    (scDLL_t*)newIE);
        addIEToHashAndDefaultGroups(newSchema, newIE);
    }


    /* move over groups */
    newSchema->numGroups = schema->numGroups;
    for (oldGroup = schema->firstGroup; oldGroup; oldGroup = oldGroup->next) {
        if (oldGroup->isDefaultTypeGroup) {
            continue;
        }
        newGroup = scGroupedElementsAlloc(newSchema, oldGroup->userString,
                                          error);
        if (!newGroup) {
            ERR_APPEND("scSchemaCopy");
            scSchemaFree(newSchema);
            return NULL;
        }
        for (oldNested = oldGroup->firstNestedElement;
             oldNested;
             oldNested = oldNested->next)
        {
            if(scGroupedElementsAddIE(newGroup, scSchemaGetIEByID(newSchema,
                                             oldNested->ie->ent,
                                             oldNested->ie->id),
                                             error))
            {
                ERR_APPEND("scSchemaCopy");
                scSchemaFree(newSchema);
                return NULL;
            }
        }
    }

    return newSchema;
}

scInfoElement_t* scSchemaGetIEByID(
    scSchema_t *schema,
    uint32_t    ent,
    uint32_t    id)
{
    scIENums_t          nums;
    nums.ent = ent;
    nums.id = id;

    if (!schema) {
        return NULL;
    }
    return g_hash_table_lookup(schema->elementTableID, &nums);
}

scInfoElement_t* scSchemaGetNextRepeatedIEByID(
    scSchema_t         *schema,
    uint32_t            ent,
    uint32_t            id,
    scInfoElement_t    *baseIE)
{
    if (!schema) {
        return NULL;
    }

    if (!baseIE) {
        return scSchemaGetIEByID(schema, ent, id);
    }

    return baseIE->nextIdenticalIE;
}

scInfoElement_t* scSchemaGetIEByName(
    scSchema_t *schema,
    char       *name)
{
    if (!schema || !name) {
        return NULL;
    }

    return g_hash_table_lookup(schema->elementTableName, name);




/*    for (ie = schema->firstPrimary; ie; ie = ie->next) {
        if (!strcmp(ie->name, name)) {
            return ie;
        }
    }

    for (ie = schema->firstVirtual; ie; ie = ie->next) {
        if (!strcmp(ie->name, name)) {
            return ie;
        }
    }*/

    /* not finding one isn't an error, just return NULL */
    return NULL;
}

int scSchemaIEInSchema(
    scSchema_t         *schema,
    scInfoElement_t    *inIE)
{
    scInfoElement_t    *ie;
    if (!schema || !inIE) {
        return 0;
    }

    for (ie = schema->firstPrimary; ie; ie = ie->next) {
        if (ie == inIE) {
            return 1;
        }
    }

    for (ie = schema->firstVirtual; ie; ie = ie->next) {
        if (ie == inIE) {
            return 1;
        }
    }

    /* not finding the IE isn't an error, just return 0 */
    return 0;
}

scInfoElement_t* scSchemaGetNextRepeatedIEByName(
    scSchema_t         *schema,
    char               *name,
    scInfoElement_t    *baseIE)
{
    if (!schema || !name) {
        return NULL;
    }

    if (!baseIE) {
        return scSchemaGetIEByName(schema, name);
    }

    return baseIE->nextIdenticalIE;

/*    if (baseIE->dataLevel == PRIMARY) {
        for (baseIE = baseIE->next; baseIE; baseIE = baseIE->next) {
            if (!strcmp(baseIE->name, name)) {
                return baseIE;
            }
        }

        for (baseIE = schema->firstVirtual; baseIE; baseIE = baseIE->next) {
            if (!strcmp(baseIE->name, name)) {
                return baseIE;
            }
        }
    } else {
        for (baseIE = baseIE->next; baseIE; baseIE = baseIE->next) {
            if (!strcmp(baseIE->name, name)) {
                return baseIE;
            }
        }
    }*/

    /* not finding one isn't an error, just return NULL */
    return NULL;
}


scSchema_t* scSchemaGetNextSchema(
    scSchema_t *schema)
{
    if (schema) {
        return schema->next;
    }

    return NULL;
}

void scSchemaRemoveEmptyGroups (
    scSchema_t *schema)
{
    scGroupedElements_t    *group;
    scGroupedElements_t    *tmp;

    schema->emptyGroupsRemoved = 1;

    group = schema->firstGroup;
    while (group) {
        if (group->numElements) {
            group = group->next;
            continue;
        }

        tmp = group->next;
        scDetachThisEntryOfDLL((scDLL_t**)&schema->firstGroup,
                               NULL,
                               (scDLL_t*)group);
        scGroupedElementsFree(group);
        group = tmp;
    }
}

void* scSchemaGetBuilderMem(
    scSchema_t *schema)
{
    return schema->builderMem;
}

void scSchemaSetBuilderMem(
    scSchema_t *schema,
    void       *builderMem,
    scSchemaBuilderMemAllocAndCopy_fn   builderMemCopy,
    scSchemaBuilderMemFree_fn           builderMemFree)
{
    schema->builderMem = builderMem;
    schema->builderMemAllocAndCopy = builderMemCopy;
    schema->builderMemFree = builderMemFree;
}

void* scSchemaGetCtx(
    scSchema_t *schema)
{
    return schema->ctx;
}

void scSchemaSetCtx(
    scSchema_t *schema,
    void       *ctx,
    scSchemaCtxFree_fn freeFunction)
{
    schema->ctx = ctx;
    schema->ctxFreeFunction = freeFunction;
}

void scSchemaForceRecPtrAlloc(
    scSchema_t *schema)
{
    if (schema->recForPtr) {
        free(schema->recForPtr);
    }
    schema->recForPtr = calloc(1, schema->len);
}

int scSchemaEqual(
    scSchema_t *schema1,
    scSchema_t *schema2)
{
    scInfoElement_t        *ie1 = NULL;
    scInfoElement_t        *ie2 = NULL;
    scGroupedElements_t    *group1 = NULL;
    scGroupedElements_t    *group2 = NULL;

    if (!schema1 || !schema2) { return 0; }

    if (schema1 == schema2) { return 1; }

    if (schema1->numElements != schema2->numElements) { return 0; }

    if (schema1->len != schema2->len) { return 0; }

    if (schema1->numGroups != schema2->numGroups) { return 0; }

    /* non IE details of the schemas have been tested */

    while ((ie1 = scSchemaGetNextInfoElement(schema1, ie1)) &&
           (ie2 = scSchemaGetNextInfoElement(schema2, ie2)))
    {
        if (scInfoElementCompare(ie1, ie2)) { return 0; }
    }

    while ((group1 = scSchemaGetNextGroupOfElements(schema1, group1)) &&
           (group2 = scSchemaGetNextGroupOfElements(schema2, group2)))
    {
        if (scGroupedElementsGetNumElements(group1) !=
            scGroupedElementsGetNumElements(group2))
        { return 0; }

        if (strcmp(scGroupedElementsGetUserString(group1),
                   scGroupedElementsGetUserString(group2)))
        { return 0; }

        /* TODO, could loop through nested, but then we have n squared time */
    }

    return 1;
}


scInfoElement_t* scInfoElementCopy(
    scInfoElement_t    *ie,
    scError_t          *error)
{
    scInfoElement_t    *newIE;

    if (!ie) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null IE passed to info element copy\n");
        return NULL;
    }
    newIE = scInfoElementAlloc();

    newIE->ent             = ie->ent;
    newIE->id              = ie->id;
    newIE->type            = ie->type;
    if (ie->description) {
        newIE->description     = strdup(ie->description);
    }

    newIE->name             = strdup(ie->name);
    newIE->rangeMin         = ie->rangeMin;
    newIE->rangeMax         = ie->rangeMax;
    newIE->semantic         = ie->semantic;
    newIE->lenOverride      = ie->lenOverride;
    newIE->len              = ie->len;

    if (ie->ctx) {
        newIE->ctx              = ie->ctxAllocAndCopy(ie);
        newIE->ctxAllocAndCopy  = ie->ctxAllocAndCopy;
        newIE->ctxFree          = ie->ctxFree;
    }

    if (ie->firstStringVal) {
        newIE->firstStringVal   = scInfoStringValListCopy(ie->firstStringVal,
                                                          error);
        if (!newIE->firstStringVal) {
            ERR_APPEND("scInfoElementCopy");
            scInfoElementFree(newIE);
            return NULL;
        }
    } else {
        newIE->firstStringVal = NULL;
    }

    newIE->units            = ie->units;
    newIE->dataLevel        = ie->dataLevel;
    newIE->copyVal          = ie->copyVal;
    newIE->retPtr           = ie->retPtr;
    newIE->copyValIter      = ie->copyValIter;
    newIE->retPtrIter       = ie->retPtrIter;
    newIE->setFunc          = ie->setFunc;
    newIE->printFunc        = ie->printFunc;
    newIE->mergeFunc        = ie->mergeFunc;
    newIE->offset           = ie->offset;

    newIE->higherLevelIE    = ie->higherLevelIE;
    /*newIE->nextIdenticalIE  = ie->nextIdenticalIE;*/


    if (ie->valPtr) {
        newIE->valPtr = calloc(1, newIE->len);
    }


    return newIE;
}

scInfoStringValList_t* scInfoStringValListCopy(
    scInfoStringValList_t  *list,
    scError_t              *error)
{
    scInfoStringValList_t  *newList;
    scInfoStringVal_t      *isv;
    scInfoStringVal_t      *ret = (scInfoStringVal_t*)0x1;

    if (!list) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null list pointer passed to InfoStringValListCopy\n");
        return NULL;
    }

    scInfoStringValListInit(&newList);

    isv = list;
    while (isv) {
        if (isv->next == NULL) {
            /* found the last one */
            break;
        }
    
        isv = isv->next;
    }

    for (; isv && ret; isv = isv->prev) {
        ret = scInfoStringValAddToList(&newList,
                                       isv->val,
                                       isv->userString,
                                       error);
    }

    if (ret) {
        return newList;
    } else {
        ERR_APPEND("scInfoStringValListCopy");
        return NULL;
    }
}

int verifyTypeSemUnits(
    scInfoType_t        type,
    scInfoSemantic_t    semantic,
    scInfoUnits_t       units,
    scError_t          *error)
{
    switch (type) {
      case UNSIGNED_8:
      case UNSIGNED_16:
      case UNSIGNED_32:
      case UNSIGNED_64:
        /* everything is allowed for these */
        break;
      case SIGNED_8:
      case SIGNED_16:
      case SIGNED_32:
      case SIGNED_64:
        /* all but flags are allowed */
        if (semantic == FLAGS) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Signed integer types cannot have FLAGS as a semantic\n");
            return 1;
        }
        break;
      case BASIC_LIST:
      case SUB_TEMPLATE_LIST:
      case SUB_TEMPLATE_MULTI_LIST:
        if (semantic != LIST) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("The list types must have semantic value of LIST\n");
            return 1;
        }
        break;
      case OCTET_ARRAY:
      case STRING:
      case MAC_ADDRESS:
      case IPV4_ADDRESS:
      case IPV6_ADDRESS:
      case BOOLEAN:
      case DATETIME_SECONDS:
      case DATETIME_MILLISECONDS:
      case DATETIME_MICROSECONDS:
      case DATETIME_NANOSECONDS:
        if (semantic != DEFAULT) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR1("An IE with type %s must have DEFAULT as the semantic\n",
                                                    getIETypeString(type));
            return 1;
        }
        break;
      case FLOAT_32:
      case FLOAT_64:
        if (semantic == FLAGS || semantic == IDENTIFIER) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR0("Floats cannot have FLAGS or IDENTIFIER as a semantic\n");
            return 1;
        }
        break;
    }

    return 0;
}

int scInfoElementValidate(
    scInfoElement_t    *ie,
    scError_t          *error)
{
    scInfoStringVal_t  *isv;
    if (!ie->name) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("All info elements require a name\n");
        return 1;
    }

    if (!ie->id) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR1("All IEs must have non-zero ids.  This ie is: %s\n", ie->name);
        return 1;
    }

    if (ie->rangeMin > ie->rangeMax) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR1("range max must be >= range min for info element %s\n", ie->name);
        return 1;
    }

    if (verifyTypeSemUnits(ie->type, ie->semantic, ie->units, error)) {
        ERR_APPEND("scInfoElementValidate");
        return 1;
    }

    if (ie->dataLevel == VIRTUAL) {
        /* some standard functions are illegal */
        if (ie->copyVal == standardCopyVal) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR1("Virtual info element %s requires a custom copy val func\n",
                                                                    ie->name);
            return 1;
        }

        if (ie->retPtr == standardRetPtr) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR1("Virtual info element %s requires a custom ret ptr func\n",
                                                                    ie->name);
            return 1;
        }

        if (ie->setFunc) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR1("A set function for vitual element %s shouldn't be used\n",
                                                                    ie->name);
        }

        /* print and merge functions are allowed to be standard */
    }

    if (ie->semantic == FLAGS) { /* make sure there's an ISV with 1 letter */
        for (isv = ie->firstStringVal; isv; isv = isv->next) {
            if (strlen(isv->userString) != 1) {
                ERR2("Illegal flags value of %s for IE %s, must be 1 letter\n",
                                                                isv->userString,
                                                                ie->name);
                return 1;
            }
        }
    }

    if (ie->semantic == CUSTOM_NUM_REP) { /* make sure there's an isv */
        if (!ie->firstStringVal) {
            ERR1("%s is semantic CUSTOM_NUM_REP, it needs info string vals\n",
                                                                    ie->name);
            return 1;
        }


    }

    return 0;
}

scInfoElement_t* scSchemaOverrideLengthOfExistingIE(
    scSchema_t         *schema,
    scInfoElement_t    *ie,
    uint16_t            len,
    scError_t          *error)
{
    switch (ie->type) {
      case OCTET_ARRAY:
      case STRING:
        ie->lenOverride = len;
        ie->len = ie->lenOverride;
        setAllOffsetsAndLen(schema);
        ie->copyVal = standardLenOverrideCopyVal;
        return ie;
        break;
      default:
        ERR1("Cannot override length for fixed field %s\n",
                                            getIETypeString(ie->type));
        return NULL;
    }
}

scInfoElement_t* scSchemaAddStandardIEByID(
    scSchema_t         *schema,
    uint32_t            ent,
    uint32_t            id,
    char               *userStringOveride,
    scInfoStringVal_t  *firstStringVal,
    fbInfoModel_t      *infoModel,
    scError_t          *error)

{
    return privateAddStandardIE(schema, ent, id, NULL, userStringOveride,
                                firstStringVal, infoModel, error);
}
scInfoElement_t* scSchemaAddStandardIEByName(
    scSchema_t         *schema,
    char               *name,
    char               *userStringOveride,
    scInfoStringVal_t  *firstStringVal,
    fbInfoModel_t      *infoModel,
    scError_t          *error)
{
    return privateAddStandardIE(schema, 0, 0, name, userStringOveride,
                                firstStringVal, infoModel, error);
}


scInfoElement_t* privateAddStandardIE(
    scSchema_t         *schema,
    uint32_t            ent,
    uint32_t            id,
    char               *name,
    char               *userStringOveride,
    scInfoStringVal_t  *firstStringVal,
    fbInfoModel_t      *infoModel,
    scError_t          *error)
{
    scInfoElement_t    *ie;

    if (!schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null schema passed to add standard ie by id\n");
        return NULL;
    }

    if (schema->forcedFixedLen) {
        ERR1("Could not add element as forced fixed length already set at %d\n",
                                            schema->forcedFixedLen);
        return NULL;
    }

    ie = scInfoElementAlloc();

    if (lookupAndFillIE(infoModel, ie, ent, id, name)) {
        error->code = SC_ERROR_NOT_FOUND;
        if (name) {
            ERR1("There is no standard element with name: %s\n", name);
        } else {
            ERR2("There is no standard element with enterprise %d and id %d\n",
                                                                    ent, id);
        }
        free(ie);
        return NULL;
    }

    if (userStringOveride) {
        free(ie->name);
        ie->name = strdup(userStringOveride);
    }

    ie->firstStringVal  = firstStringVal;
    ie->copyVal         = standardCopyVal;
    ie->retPtr          = standardRetPtr;
    ie->setFunc         = standardSetFunc;

    if (ie->semantic == FLAGS && ie->firstStringVal) {
        ie->printFunc   = standardFlagsPrintFunc;
    } else if (ie->semantic == CUSTOM_NUM_REP && ie->firstStringVal) {
        ie->printFunc   = standardCustomNumRepPrintFunc;
    } else {
        ie->printFunc       = standardPrintFunc;
    }
    ie->mergeFunc       = standardMergeFunc;

    ie->dataLevel       = PRIMARY;

    if (scInfoElementIsVarlen(ie)) {
        schema->hasVarFields = 1;
    }

    if (scInfoElementValidate(ie, error)) {
        ERR_APPEND("scSchemaAddStandardIEByID");
        scInfoElementFree(ie);
        return NULL;
    }

    schema->numElements++;

    scAttachTailToDLL((scDLL_t**)&(schema->firstPrimary),
                    (scDLL_t**)&(schema->lastPrimary),
                    (scDLL_t*)ie);

    addIEToHashAndDefaultGroups(schema, ie);

    setAllOffsetsAndLen(schema);

    return ie;
}


/* take standard IE fields, but custom functions */
scInfoElement_t* scSchemaAddIEByIDCustomFuncs(
    scSchema_t             *schema,
    uint32_t                ent,
    uint32_t                id,
    char                   *userStringOveride,
    scInfoStringValList_t  *firstStringVal,
    scDataLevel_t           dataLevel,
    scInfoElementCopyVal_fn copyVal,
    scInfoElementRetPtr_fn  retPtr,
    scInfoElementSetVal_fn  setFunc,
    scInfoElementPrint_fn   printFunc,
    scInfoElementMerge_fn   mergeFunc,
    fbInfoModel_t          *infoModel,
    scError_t              *error)
{
    return privateAddIECustomFuncs(schema, ent, id, NULL, userStringOveride,
                                   firstStringVal, dataLevel, copyVal,
                                   retPtr, setFunc, printFunc, mergeFunc,
                                   infoModel, error);
}

scInfoElement_t* scSchemaAddIEByNameCustomFuncs(
    scSchema_t             *schema,
    char                   *name,
    char                   *userStringOveride,
    scInfoStringValList_t  *firstStringVal,
    scDataLevel_t           dataLevel,
    scInfoElementCopyVal_fn copyVal,
    scInfoElementRetPtr_fn  retPtr,
    scInfoElementSetVal_fn  setFunc,
    scInfoElementPrint_fn   printFunc,
    scInfoElementMerge_fn   mergeFunc,
    fbInfoModel_t          *infoModel,
    scError_t              *error)
{
    return privateAddIECustomFuncs(schema, 0, 0, name, userStringOveride,
                                   firstStringVal, dataLevel, copyVal,
                                   retPtr, setFunc, printFunc, mergeFunc,
                                   infoModel, error);
}

scInfoElement_t* privateAddIECustomFuncs(
    scSchema_t             *schema,
    uint32_t                ent,
    uint32_t                id,
    char                   *name,
    char                   *userStringOveride,
    scInfoStringValList_t  *firstStringVal,
    scDataLevel_t           dataLevel,
    scInfoElementCopyVal_fn copyVal,
    scInfoElementRetPtr_fn  retPtr,
    scInfoElementSetVal_fn  setFunc,
    scInfoElementPrint_fn   printFunc,
    scInfoElementMerge_fn   mergeFunc,
    fbInfoModel_t          *infoModel,
    scError_t              *error)
{
    scInfoElement_t    *ie;

    if (!schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null schema passed to add ie by id custom funcs\n");
        return NULL;
    }

    if (schema->forcedFixedLen) {
        ERR1("Could not add element as forced fixed length already set at %d\n",
                                            schema->forcedFixedLen);
        return NULL;
    }

    ie = calloc(1, sizeof(scInfoElement_t));

    if (lookupAndFillIE(infoModel, ie, ent, id, name)) {
        error->code = SC_ERROR_NOT_FOUND;
        ERR2("There is no standard element with enterprise %d and id %d\n",
                                                                    ent, id);
        free(ie);
        return NULL;
    }

    if (userStringOveride) {
        free(ie->name);
        ie->name = strdup(userStringOveride);
    }

    ie->firstStringVal  = firstStringVal;

    if (copyVal) {
        ie->copyVal         = copyVal;
    } else {
        ie->copyVal         = standardCopyVal;
    }

    if (retPtr) {
        ie->retPtr          = retPtr;
    } else {
        ie->retPtr          = standardRetPtr;
    }

    if (setFunc) {
        ie->setFunc         = setFunc;
    } else {
        ie->setFunc         = standardSetFunc;
    }

    if (printFunc) {
        ie->printFunc       = printFunc;
    } else {
        if (ie->semantic == FLAGS && ie->firstStringVal) {
            ie->printFunc   = standardFlagsPrintFunc;
        } else if (ie->semantic == CUSTOM_NUM_REP && ie->firstStringVal) {
            ie->printFunc   = standardCustomNumRepPrintFunc;
        } else {
            ie->printFunc   = standardPrintFunc;
        }
    }

    if (mergeFunc) {
        ie->mergeFunc       = mergeFunc;
    } else {
        ie->mergeFunc       = standardMergeFunc;
    }

    ie->dataLevel       = dataLevel;

    if (scInfoElementIsVarlen(ie)) {
        schema->hasVarFields = 1;
    }

    if (scInfoElementValidate(ie, error)) {
        ERR_APPEND("scSchemaAddIEByIDCustomFuncs");
        scInfoElementFree(ie);
        return NULL;
    }

    schema->numElements++;

    if (dataLevel == PRIMARY) {
        scAttachTailToDLL((scDLL_t**)&(schema->firstPrimary),
                          (scDLL_t**)&(schema->lastPrimary),
                          (scDLL_t*)ie);

        setAllOffsetsAndLen(schema);
    } else {
        ie->valPtr = calloc(1, ieTypeLengths[ie->type]);
        scAttachTailToDLL((scDLL_t**)&(schema->firstVirtual),
                                      (scDLL_t**)&(schema->lastVirtual),
                                      (scDLL_t*)ie);
    }
    addIEToHashAndDefaultGroups(schema, ie);

    return ie;
}

/* IE must be primary */
scInfoElement_t* scSchemaAddCustomIEStandardFuncs(
    scSchema_t             *schema,
    uint32_t                ent,
    uint32_t                id,
    scInfoType_t            type,
    char                   *description,
    char                   *name,
    uint64_t                rangeMin,
    uint64_t                rangeMax,
    scInfoSemantic_t        semantic,
    scInfoStringValList_t  *firstStringVal,
    scInfoUnits_t           units,
    scError_t              *error)
{
    scInfoElement_t    *ie;

    if (!schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null schema passed to custom ie standard funcs\n");
        return NULL;
     }

    if (!ent) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Custom IE must have a non-zero enterprise id\n");
        return NULL;
    }

    if (schema->forcedFixedLen) {
        ERR1("Could not add element as forced fixed length already set at %d\n",
                                            schema->forcedFixedLen);
        return NULL;
    }

    ie = scInfoElementAlloc();

    ie->ent             = ent;
    ie->id              = id;
    if (description) {
        ie->description     = strdup(description);
    }
    ie->name            = strdup(name);
    ie->rangeMin        = rangeMin;
    ie->rangeMax        = rangeMax;
    ie->type            = type;
    ie->len             = ieTypeLengths[type];
    ie->semantic        = semantic;
    ie->firstStringVal  = firstStringVal;
    ie->units           = units;

    ie->copyVal         = standardCopyVal;
    ie->retPtr          = standardRetPtr;
    ie->setFunc         = standardSetFunc;
    if (ie->semantic == FLAGS && ie->firstStringVal) {
        ie->printFunc   = standardFlagsPrintFunc;
    } else if (ie->semantic == CUSTOM_NUM_REP && ie->firstStringVal) {
        ie->printFunc   = standardCustomNumRepPrintFunc;
    } else {
        ie ->printFunc  = standardPrintFunc;
    }
    ie->mergeFunc       = standardMergeFunc;

    ie->dataLevel       = PRIMARY;

    if (scInfoElementIsVarlen(ie)) {
        schema->hasVarFields = 1;
    }

    if (scInfoElementValidate(ie, error)) {
        ERR_APPEND("scSchemaAddCustomIEStandardFuncs");
        scInfoElementFree(ie);
        return NULL;
    }

    schema->numElements++;

    scAttachTailToDLL((scDLL_t**)&(schema->firstPrimary),
                      (scDLL_t**)&(schema->lastPrimary),
                      (scDLL_t*)ie);

    setAllOffsetsAndLen(schema);
    addIEToHashAndDefaultGroups(schema, ie);

    return ie;
}

/* creates completely custom IE, adds to schema */
scInfoElement_t* scSchemaAddCustomIE(
    scSchema_t             *schema,
    uint32_t                ent,
    uint32_t                id,
    scInfoType_t            type,
    char                   *description,
    char                   *name,
    uint64_t                rangeMin,
    uint64_t                rangeMax,
    scInfoSemantic_t        semantic,
    scInfoStringValList_t  *firstStringVal,
    scInfoUnits_t           units,
    scDataLevel_t           dataLevel,
    scInfoElementCopyVal_fn copyVal,
    scInfoElementRetPtr_fn  retPtr,
    scInfoElementSetVal_fn  setFunc,
    scInfoElementPrint_fn   printFunc,
    scInfoElementMerge_fn   mergeFunc,
    scError_t              *error)
{
    scInfoElement_t    *ie;

    if (!schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null schema passed to custom ie standard funcs\n");
        return NULL;
     }

    if (!ent) {
        error->code = SC_ERROR_INVALID_INPUT;
        ERR0("Custom IE must have a non-zero enterprise id\n");
        return NULL;
    }

    if (schema->forcedFixedLen) {
        ERR1("Could not add element as forced fixed length already set at %d\n",
                                            schema->forcedFixedLen);
        return NULL;
    }

    ie = scInfoElementAlloc();

    ie->ent             = ent;
    ie->id              = id;
    ie->type            = type;
    ie->len             = ieTypeLengths[type];
    if (description) {
        ie->description     = strdup(description);
    }

    ie->name            = strdup(name);
    ie->rangeMin        = rangeMin;
    ie->rangeMax        = rangeMax;
    ie->semantic        = semantic;
    ie->firstStringVal  = firstStringVal;
    ie->units           = units;
    ie->dataLevel       = dataLevel;

    if (scInfoElementIsVarlen(ie)) {
        schema->hasVarFields = 1;
    }

    if (copyVal) {
        ie->copyVal         = copyVal;
    } else {
        ie->copyVal         = standardCopyVal;
    }

    if (retPtr) {
        ie->retPtr          = retPtr;
    } else {
        ie->retPtr          = standardRetPtr;
    }

    if (setFunc) {
        ie->setFunc         = setFunc;
    } else {
        ie->setFunc         = standardSetFunc;
    }

    if (printFunc) {
        ie->printFunc       = printFunc;
    } else {
        if (ie->semantic == FLAGS && ie->firstStringVal) {
            ie->printFunc   = standardFlagsPrintFunc;
        } else if (ie->semantic == CUSTOM_NUM_REP && ie->firstStringVal) {
            ie->printFunc   = standardCustomNumRepPrintFunc;
        } else {
            ie->printFunc   = standardPrintFunc;
        }
    }

    if (mergeFunc) {
        ie->mergeFunc       = mergeFunc;
    } else {
        ie->mergeFunc       = standardMergeFunc;
    }

    if (scInfoElementValidate(ie, error)) {
        ERR_APPEND("scSchemaAddCustomIE");
        scInfoElementFree(ie);
        return NULL;
    }


    schema->numElements++;

    if (dataLevel == PRIMARY) {
        ie->offset = calculateNewOffset(schema->len, ie);
        schema->len = calculateNewOffset(schema->len, ie) +
                                         ieTypeLengths[ie->type];

        scAttachTailToDLL((scDLL_t**)&(schema->firstPrimary),
                          (scDLL_t**)&(schema->lastPrimary),
                          (scDLL_t*)ie);
    } else {
        ie->valPtr = calloc(1, ieTypeLengths[ie->type]);
        scAttachTailToDLL((scDLL_t**)&(schema->firstVirtual),
                                      (scDLL_t**)&(schema->lastVirtual),
                                      (scDLL_t*)ie);
    }

    addIEToHashAndDefaultGroups(schema, ie);
    return ie;
}

scInfoElement_t* scSchemaAddExistingIE(
    scSchema_t         *schema,
    scInfoElement_t    *oldIE,
    scError_t          *error)
{
    scInfoElement_t    *ie;

    if (schema->forcedFixedLen) {
        ERR1("Could not add element as forced fixed length already set at %d\n",
                                            schema->forcedFixedLen);
        return NULL;
    }

    ie = scInfoElementCopy(oldIE, error);
    if (!ie) {
        printf("copy of element %s had the error %s\n", oldIE->name, error->msg);
        return NULL;
    }

    if (scInfoElementValidate(ie, error)) {
        ERR_APPEND("scSchemaAddCustomIE");
        scInfoElementFree(ie);
        return NULL;
    }

    ie->offset = calculateNewOffset(schema->len, ie);

    schema->numElements++;

    if (ie->dataLevel == PRIMARY) {
        schema->len = calculateNewOffset(schema->len, ie) +
                                         ieTypeLengths[ie->type];

        scAttachTailToDLL((scDLL_t**)&(schema->firstPrimary),
                          (scDLL_t**)&(schema->lastPrimary),
                          (scDLL_t*)ie);
    } else {
        scAttachTailToDLL((scDLL_t**)&(schema->firstVirtual),
                                      (scDLL_t**)&(schema->lastVirtual),
                                      (scDLL_t*)ie);
    }

    addIEToHashAndDefaultGroups(schema, ie);

    return ie;
}

scInfoElement_t* scSchemaMoveIEBeforeAnother(
    scSchema_t         *schema,
    scInfoElement_t    *ieToMove,
    scInfoElement_t    *beforeHere,
    scError_t          *error)
{
    if (!ieToMove || !beforeHere) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null pointer passed to SchemaMoveIEBeforeAnother\n");
        return NULL;
    }

    if (ieToMove->dataLevel == VIRTUAL ||
        beforeHere->dataLevel == VIRTUAL)
    {
        error->code = SC_ERROR_WARNING;
        ERR0("Only primary elements can be moved around, pointless call\n");
        return NULL;
    }

    scDetachThisEntryOfDLL((scDLL_t**)&(schema->firstPrimary),
                           (scDLL_t**)&(schema->lastPrimary),
                           (scDLL_t*)ieToMove);

    scAttachBeforeThisEntryOfDLL((scDLL_t**)&(schema->firstPrimary),
                                 (scDLL_t**)&(schema->lastPrimary),
                                 (scDLL_t*)ieToMove,
                                 (scDLL_t*)beforeHere);

    setAllOffsetsAndLen(schema);

    return ieToMove;
}

scInfoElement_t* scSchemaMoveIEBeforeAnotherByName(
    scSchema_t *schema,
    char       *ieToMove,
    char       *beforeHere,
    scError_t  *error)
{
    scInfoElement_t    *toMove;
    scInfoElement_t    *befHere;

    if (!schema || !ieToMove || !beforeHere) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter to SchemaMoveIEBeforeAnotherByName\n");
        return NULL;
    }

    toMove = scSchemaGetIEByName(schema, ieToMove);
    if (!toMove) {
        error->code = SC_ERROR_NOT_FOUND;
        ERR2("No IE in schema %s by name %s\n", schema->name, ieToMove);
        return NULL;
    }

    befHere = scSchemaGetIEByName(schema, beforeHere);
    if (!befHere) {
        error->code = SC_ERROR_NOT_FOUND;
        ERR2("no IE in schema %s by name %s\n", schema->name, beforeHere);
        return NULL;
    }

    return scSchemaMoveIEBeforeAnother(schema, toMove, befHere, error);
}

scInfoElement_t* scSchemaMoveIEAfterAnother(
    scSchema_t         *schema,
    scInfoElement_t    *ieToMove,
    scInfoElement_t    *afterHere,
    scError_t          *error)
{
    if (!schema || !ieToMove || !afterHere) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter to SchemaMoveIEAfterAnother\n");
        return NULL;
    }

    if (ieToMove->dataLevel == VIRTUAL ||
        afterHere->dataLevel == VIRTUAL)
    {
        error->code = SC_ERROR_WARNING;
        ERR0("Only primary elements can be moved around, pointless call\n");
        return NULL;
    }

    scDetachThisEntryOfDLL((scDLL_t**)&(schema->firstPrimary),
                           (scDLL_t**)&(schema->lastPrimary),
                           (scDLL_t*)ieToMove);

    scAttachAfterThisEntryOfDLL((scDLL_t**)&(schema->firstPrimary),
                                 (scDLL_t**)&(schema->lastPrimary),
                                 (scDLL_t*)ieToMove,
                                 (scDLL_t*)afterHere);

    setAllOffsetsAndLen(schema);

    return ieToMove;
}

scInfoElement_t* scSchemaMoveIEAfterAnotherByName(
    scSchema_t *schema,
    char       *ieToMove,
    char       *afterHere,
    scError_t  *error)
{
    scInfoElement_t    *toMove;
    scInfoElement_t    *afHere;

    if (!schema || !ieToMove || !afterHere) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter to SchemaMoveIEAfterAnotherByName\n");
        return NULL;
    }


    toMove = scSchemaGetIEByName(schema, ieToMove);
    if (!toMove) {
        error->code = SC_ERROR_NOT_FOUND;
        ERR2("No IE in schema %s by name %s\n", schema->name, ieToMove);
        return NULL;
    }

    afHere = scSchemaGetIEByName(schema, afterHere);
    if (!afHere) {
        error->code = SC_ERROR_NOT_FOUND;
        ERR2("No IE in schema %s by name %s\n", schema->name, afterHere);
        return NULL;
    }

    return scSchemaMoveIEAfterAnother(schema, toMove, afHere, error);
}

scInfoElement_t* scSchemaMoveIEToBeginning(
    scSchema_t         *schema,
    scInfoElement_t    *ieToMove,
    scError_t          *error)
{
    if (!schema || !ieToMove) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter to SchemaMoveIEToBeginning\n");
        return NULL;
    }

    if (ieToMove->dataLevel == VIRTUAL) {
        error->code = SC_ERROR_WARNING;
        ERR0("Only primary elements can be moved around, pointless call\n");
        return NULL;
    }

    scDetachThisEntryOfDLL((scDLL_t**)&(schema->firstPrimary),
                           (scDLL_t**)&(schema->lastPrimary),
                           (scDLL_t*)ieToMove);

    scAttachHeadToDLL((scDLL_t**)&(schema->firstPrimary),
                      (scDLL_t**)&(schema->lastPrimary),
                      (scDLL_t*)ieToMove);

    setAllOffsetsAndLen(schema);

    return ieToMove;
}

scInfoElement_t* scSchemaMoveIEToBeginningByName(
    scSchema_t *schema,
    char       *ieToMove,
    scError_t  *error)
{
    scInfoElement_t    *toMove;

    if (!schema || !ieToMove) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter passed to MoveIEToBeginningByName\n");
        return NULL;
    }

    toMove = scSchemaGetIEByName(schema, ieToMove);
    if (!toMove) {
        error->code = SC_ERROR_NOT_FOUND;
        ERR2("no IE in schema %s by name %s\n", schema->name, ieToMove);
        return NULL;
    }

    return scSchemaMoveIEToBeginning(schema, toMove, error);
}

scInfoElement_t* scSchemaMoveIEToEnd(
    scSchema_t         *schema,
    scInfoElement_t    *ieToMove,
    scError_t          *error)
{
    if (!schema || !ieToMove) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter passed to MoveIEToEnd\n");
        return NULL;
    }

    if (ieToMove->dataLevel == VIRTUAL) {
        error->code = SC_ERROR_WARNING;
        ERR0("Only primary elements can be moved around, pointless call\n");
        return NULL;
    }

    scDetachThisEntryOfDLL((scDLL_t**)&(schema->firstPrimary),
                           (scDLL_t**)&(schema->lastPrimary),
                           (scDLL_t*)ieToMove);

    scAttachTailToDLL((scDLL_t**)&(schema->firstPrimary),
                      (scDLL_t**)&(schema->lastPrimary),
                      (scDLL_t*)ieToMove);

    setAllOffsetsAndLen(schema);

    return ieToMove;
}

scInfoElement_t* scSchemaMoveIEToEndByName(
    scSchema_t *schema,
    char       *ieToMove,
    scError_t  *error)
{
    scInfoElement_t    *toMove;

    if (!schema || !ieToMove) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter passed to MoveIEToEndByName\n");
        return NULL;
    }


    toMove = scSchemaGetIEByName(schema, ieToMove);
    if (!toMove) {
        error->code = SC_ERROR_NOT_FOUND;
        ERR2("No IE in schema %s by name %s\n", schema->name, ieToMove);
        return NULL;
    }

    return scSchemaMoveIEToEnd(schema, toMove, error);
}

int scSchemaRemoveIEByID(
    scSchema_t         *schema,
    uint32_t            ent,
    uint32_t            id,
    scError_t          *error)
{
    scInfoElement_t    *ie;

    if (!schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null schema passed to RemoveIEByID\n");
        return 1;
    }

    ie = scSchemaGetIEByID(schema, ent, id);

    if (ie) {
        return scSchemaRemoveIE(schema, ie, error);
    }

    error->code = SC_ERROR_NOT_FOUND;
    ERR3("IE with enterprise %d and ID %d is not in the schema %s\n", ent,
                                                        id, schema->name);

    return 1;
}

int scSchemaRemoveIE(
    scSchema_t         *schema,
    scInfoElement_t    *ie,
    scError_t          *error)
{
    scGroupedElements_t    *group;

    if (!ie || !schema) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter passed to schema remove IE\n");
        return 1;
    }

    if (!scSchemaIEInSchema(schema, ie)) {
        error->code = SC_ERROR_NOT_FOUND;
        ERR0("IE to be removed is not in the schema, ie pointer not freed\n");
        return 1;
    }

    /* update number of elements */
    schema->numElements--;

    /* remove the element */
    if (ie->dataLevel == PRIMARY) {
        scDetachThisEntryOfDLL((scDLL_t**)&(schema->firstPrimary),
                               (scDLL_t**)&(schema->lastPrimary),
                               (scDLL_t*)ie);

        setAllOffsetsAndLen(schema);
    } else {
        if (ie->valPtr) {
            free(ie->valPtr);
        }
        scDetachThisEntryOfDLL((scDLL_t**)&(schema->firstVirtual),
                              (scDLL_t**)&(schema->lastVirtual),
                              (scDLL_t*)ie);
    }

    /* see if the element is in one of the groups */
    /* leave the group there, even if there are now no elements */
    for (group = schema->firstGroup; group; group = group->next) {
        scGroupedElementsRemoveIE(group, ie, error);
    }

    scInfoElementFree(ie);
    return 0;
}

uint8_t* scSchemaGetRecPtr(
    scSchema_t *schema)
{
    return schema->recForPtr;
}

scInfoElement_t* scSchemaGetTimingSource(
    scSchema_t *schema)
{
    return schema->timingSource;
}

int scSchemaSetTimingSource(
    scSchema_t         *schema,
    scInfoElement_t    *ie)
{
    scInfoElement_t    *temp;
    if (!ie) {
        return 1;
    }

    for (temp = schema->firstPrimary; temp; temp = temp->next) {
        if (temp->ent == ie->ent &&
            temp->id  == ie->id)
        {
            schema->timingSource = ie;
            return 0;
        }
    }

    for (temp = schema->firstVirtual; temp; temp = temp->next) {
        if (temp->ent == ie->ent &&
            temp->id  == ie->id)
        {
            schema->timingSource = ie;
            return 0;
        }
    }

    return 1;
}

char* scSchemaGetName(
    scSchema_t *schema)
{
    return schema->name;
}

uint16_t scSchemaGetId(
    scSchema_t *schema)
{
    return schema->id;
}

scSchema_t* scSchemaGetAssociatedSchema(
    scSchema_t *schema)
{
    return schema->associatedSchema;
}

uint32_t scSchemaGetRecordLength(
    scSchema_t *schema)
{
    return schema->len;
}

int scSchemaForceRecordLength(
    scSchema_t *schema,
    uint32_t    forcedLength,
    scError_t  *error)
{
    if (forcedLength < schema->len) {
        ERR2("Forced length of %d less then calculated length of %d\n",
                                                forcedLength, schema->len);
        return 1;
    }
    schema->forcedFixedLen = forcedLength;
    return 0;
}

uint32_t scSchemaGetNumInfoElements(
    scSchema_t *schema)
{
    return schema->numElements;
}

uint8_t scSchemaHasVarLenFields(
    scSchema_t *schema)
{
    return schema->hasVarFields;
}

uint32_t scSchemaGetNumOfElementGroups(
    scSchema_t *schema)
{
    return schema->numGroups;
}

scGroupedElements_t* scSchemaGetFirstGroupOfElements(
    scSchema_t *schema)
{
    return schema->firstGroup;
}

scGroupedElements_t* scSchemaGetNextGroupOfElements(
    scSchema_t             *schema,
    scGroupedElements_t    *lastGroup)
{
    if (lastGroup) {
        return lastGroup->next;
    }

    return schema->firstGroup;
}

scGroupedElements_t* scSchemaGetGroupedElementsByUserString(
    scSchema_t *schema,
    char       *userString)
{
    return g_hash_table_lookup(schema->groupsByName, userString);
}

scInfoElement_t* scSchemaGetNextInfoElement(
    scSchema_t         *schema,
    scInfoElement_t    *previousIE)
{
    if (!previousIE) {
        if (schema->firstPrimary) {
            return schema->firstPrimary;
        } else {
            return schema->firstVirtual;
        }
    }

    if (previousIE->next) {
        return previousIE->next;
    } else if (previousIE->dataLevel == PRIMARY) {
        return schema->firstVirtual;
    } else {
        return NULL;
    }
}

scSchemaDeepCopyRecord_fn scSchemaGetCopyRecordFunc(
    scSchema_t *schema)
{
    return schema->copyRecord;
}

scSchemaFreeRecord_fn scSchemaGetFreeRecordFunc(
    scSchema_t *schema)
{
    return schema->freeRecordCopy;
}

scSchemaFreeRecord_fn scSchemaGetSecondLevelFreeFunc(
    scSchema_t *schema)
{
    return schema->freeSecondLevelFields;
}

uint32_t callSchemaDeepCopyRecord(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src)
{
    return schema->copyRecord(schema, dst, src);
}

void callSchemaFreeRecord(
    scSchema_t *schema,
    uint8_t    *rec)
{
    schema->freeRecordCopy(schema, rec);
}

void callSchemaFreeSecondLevel(
    scSchema_t *schema,
    uint8_t    *rec)
{
    schema->freeSecondLevelFields(schema, rec);
}

/******************************* End of schema functions */

/******************************* Grouped Elements functions */
scGroupedElements_t* scGroupedElementsAlloc(
    scSchema_t *schema,
    char       *string,
    scError_t  *error)
{
    scGroupedElements_t    *group;

    if (!schema || !string) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter passed to grouped elements alloc\n");
        return NULL;
    }

    for (group = schema->firstGroup; group; group = group->next) {
        if (!strcmp(group->userString, string)) {
            return group;
        }
    }

    group = calloc(1, sizeof(scGroupedElements_t));

    group->userString = strdup(string);

    scAttachHeadToDLL((scDLL_t**)&(schema->firstGroup),
                    NULL,
                    (scDLL_t*)group);

    g_hash_table_insert(schema->groupsByName, string, group);

    return group;
}

void scGroupedElementsFree(
    scGroupedElements_t    *ge)
{
    scNestedIE_t   *nie;

    while (ge->firstNestedElement) {
        scDetachHeadOfDLL((scDLL_t**)&(ge->firstNestedElement),
                          (scDLL_t**)&(ge->lastNestedElement),
                          (scDLL_t**)&nie);
        scNestedIEFree(nie);
    }
    free(ge->userString);
    free(ge);
}

scGroupedElements_t* scGroupedElementsGetNextGroup(
    scGroupedElements_t    *group)
{
    return group->next;
}

char* scGroupedElementsGetUserString(
    scGroupedElements_t    *group)
{
    return group->userString;
}

uint32_t scGroupedElementsGetNumElements(
    scGroupedElements_t    *group)
{
    return group->numElements;
}

scNestedIE_t* scGroupedElementsGetFirstNestedIE(
    scGroupedElements_t    *group)
{
    return group->firstNestedElement;
}

scNestedIE_t* scGroupedElementsGetNextNestedIE(
    scGroupedElements_t    *group,
    scNestedIE_t           *nestedIE)
{
    if (!nestedIE) {
        return group->firstNestedElement;
    }

    return nestedIE->next;
}

int scGroupedElementsAddIE(
    scGroupedElements_t    *ge,
    scInfoElement_t        *ie,
    scError_t              *error)
{
    scNestedIE_t   *nie;
    scInfoElement_t    *firstIE;
    if (!ie || !ge) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null pointers passed to GroupedElementsAddIE\n");
        return -1;
    }

    if (ge->numElements) {
        firstIE = ge->firstNestedElement->ie;
        if (ie->type        != firstIE->type) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR2("New grouped element %s doesn't match existing element %s\n",
                                                                ie->name,
                                                                firstIE->name);
            return -1;
        }
    }

    nie = scNestedIEAlloc();

    nie->ie = ie;
    ge->numElements++;
    scAttachTailToDLL((scDLL_t**)&(ge->firstNestedElement),
                      (scDLL_t**)&(ge->lastNestedElement),
                    (scDLL_t*)nie);

    return 0;
}

int scGroupedElementsRemoveIE(
    scGroupedElements_t    *ge,
    scInfoElement_t        *ie,
    scError_t              *error)
{
    scNestedIE_t   *nie;

    if (!ge || !ie) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null pointers passed to GroupedElementsRemoveIE\n");
        return -1;
    }

    for (nie = ge->firstNestedElement; nie; nie = nie->next) {
        if (nie->ie == ie) {
            scDetachThisEntryOfDLL((scDLL_t**)&(ge->firstNestedElement),
                                   (scDLL_t**)&(ge->lastNestedElement),
                                   (scDLL_t*)nie);
            ge->numElements--;
            scNestedIEFree(nie);
            return 0;
        }
    }

    error->code = SC_ERROR_INVALID_INPUT;
    ERR0("IE is not in the group of elements\n");

    return -1;
}


/******************************* End of grouped elements functions */
uint32_t scInfoElementHash(
    scIENums_t *ieNums)
{
    return ((ieNums->ent & 0x0000ffff) << 16) | (ieNums->id);
}

gboolean scInfoElementEqual(
    scIENums_t *a,
    scIENums_t *b)
{
    return ((a->ent == b->ent) && (a->id == b->id));
}

/******************************* Nested IE functions */
scNestedIE_t* scNestedIEAlloc(
    void)
{
    scNestedIE_t   *nestedIE = calloc(1, sizeof(scNestedIE_t));

    return nestedIE;
}

void scNestedIEFree(
    scNestedIE_t  *nie)
{
    free(nie);
}


scNestedIE_t* scNestedIEGetNextNestedIE(
    scNestedIE_t           *nestedIE)
{
    return nestedIE->next;
}

void scNestedIEGetIds(
    scNestedIE_t           *nestedIE,
    uint32_t               *entIdPtr,
    uint32_t               *idPtr)
{
    *entIdPtr   = nestedIE->ie->ent;
    *idPtr      = nestedIE->ie->id;
}

scInfoElement_t* scNestedIEGetIE(
    scNestedIE_t           *nestedIE)
{
    return nestedIE->ie;
}

/******************************* End of Nested IE functions */


/******************************* Info Element functions ***/
scInfoElement_t* scInfoElementAlloc(
    void)
{
    scInfoElement_t    *newIe = calloc(1, sizeof(scInfoElement_t));

    return newIe;
}

void scInfoElementFree(
    scInfoElement_t    *ie)
{
    scInfoStringVal_t  *isv;

    free(ie->description);
    free(ie->name);

    while (ie->firstStringVal) {
        scDetachHeadOfDLL((scDLL_t**)&(ie->firstStringVal),
                          NULL,
                          (scDLL_t**)&isv);
        scInfoStringValFree(isv);
    }

    if (ie->valPtr) {
        free(ie->valPtr);
    }

    if (ie->ctx) {
        ie->ctxFree(ie->ctx);
    }

    free(ie);
}

/**
 * @brief Set the user defined context pointer for the given IE
 * @param ie    The pointer to the IE to set
 * @param ctx       Pointer to the user allocated memory to set for the IE
 * @param freeFunction The function to call(can be NULL) to free the context
 *                      The context pointer is only freed if a function is
 *                      provided here.
 */
void scInfoElementSetCtx(
    scInfoElement_t    *ie,
    void               *ctx,
    scInfoElementCtxAllocAndCopy_fn     ctxCopy,
    scInfoElementCtxFree_fn             freeFunction)
{
    ie->ctx             = ctx;
    ie->ctxAllocAndCopy = ctxCopy;
    ie->ctxFree         = freeFunction;
}

scIEDiffReason_t scInfoElementCompare(
    scInfoElement_t    *ie1,
    scInfoElement_t    *ie2)
{
    if (!ie1 || !ie2) { return IE_DR_NULL_PTR; }

    if (ie1 == ie2) { return IE_DR_EQUAL; }

    if (ie1->ent != ie2->ent ) { return IE_DR_ENT; }

    if (ie1->dataLevel != ie2->dataLevel) { return IE_DR_DATA_LEVEL; }

    if (ie1->len != ie2->len) { return IE_DR_LEN; }

    /* if the IDS aren't equal, return 0. If they are AND the enterprise ID
     * is 0, it's a standard element and {ent, id} is all you need
     */
    if (ie1->id != ie2->id) { return IE_DR_ID; }
    else
    {
        if (ie1->ent == 0) {
            return IE_DR_EQUAL;
        }
    }

    /* at this point it's a custom or enterprise element */
    if (ie1->type       != ie2->type)       { return IE_DR_TYPE; }
    if (ie1->semantic   != ie2->semantic)   { return IE_DR_SEMANTIC; }
    if (ie1->units      != ie2->units)      { return IE_DR_UNITS; }
    if (ie1->rangeMin   != ie2->rangeMin)   { return IE_DR_RANGE_MIN; }
    if (ie1->rangeMax   != ie2->rangeMax)   { return IE_DR_RANGE_MAX; }

    if (strcmp(ie1->name, ie2->name))       { return IE_DR_NAME; }

    return IE_DR_EQUAL;
}

scInfoStringVal_t* scInfoElementGetNextStringVal(
    scInfoElement_t    *ie,
    scInfoStringVal_t  *isv)
{
    if (!isv) {
        return ie->firstStringVal;
    }

    return isv->next;
}

uint8_t scInfoElementIsVarlen(
    const scInfoElement_t    *ie)
{
    switch (ie->type) {
      case OCTET_ARRAY:
      case STRING:
      case BASIC_LIST:
      case SUB_TEMPLATE_LIST:
      case SUB_TEMPLATE_MULTI_LIST:
        if (ie->lenOverride) {
            return 0;
        }
        return 1;
      default:
        return 0;
    }
}

scGeneralType_t scInfoElementGetGeneralType(
    scInfoElement_t   *ie)
{
    switch (ie->type) {
      case OCTET_ARRAY:
      case STRING:
        if (ie->lenOverride) {
            return FIXED;
        }
        return VARLEN_DATA;
      case BASIC_LIST:
      case SUB_TEMPLATE_LIST:
      case SUB_TEMPLATE_MULTI_LIST:
        return LIST_TYPE;
      default:
        return FIXED;
    }
}
/******************************** End of Info Element functions */

/******************************** Info String Value functions */
void scInfoStringValListInit(
    scInfoStringValList_t **list)
{
    *list = NULL;
}

scInfoStringVal_t* scInfoStringValAddToList(
    scInfoStringValList_t **list,
    uint32_t                val,
    char                   *userString,
    scError_t              *error)
{
    scInfoStringVal_t  *isv;

    if (!list || !userString) {
        error->code = SC_ERROR_NULL_PARAM;
        ERR0("Null parameter passed to info string val add to list\n");
        return NULL;
    }

    for (isv = *list; isv; isv = isv->next) {
        if (!strcmp(isv->userString, userString)) {
            error->code = SC_ERROR_INVALID_INPUT;
            ERR1("info string vals must be unique, a value for %s already exists\n", userString);
            return NULL;
        }
    }


    isv = calloc(1, sizeof(scInfoStringVal_t));

    isv->val = val;
    isv->userString = strdup(userString);
    scAttachHeadToDLL((scDLL_t**)list, NULL,
                        (scDLL_t*)isv);

    return isv;
}

void scInfoStringValFree(
    scInfoStringVal_t  *isv)
{
    free(isv->userString);
    free(isv);
}

scInfoStringVal_t* scInfoStringValGetNextISV(
    scInfoStringVal_t  *isv)
{
    return isv->next;
}

uint64_t scInfoStringValGetVal(
    scInfoStringVal_t  *isv)
{
    return isv->val;
}

char* scInfoStringValGetString(
    scInfoStringVal_t  *isv)
{
    return isv->userString;
}

/******************************* Standard functions */
scSchemaCopyPlan_t* scSchemaCopyPlanAlloc(
    scSchema_t     *schema,
    uint32_t        dstSchema)
{
    scSchemaCopyPlan_t *plan = calloc(1, sizeof(scSchemaCopyPlan_t));

    plan->dstSchema = dstSchema;

    scAttachHeadToDLL((scDLL_t**)&(schema->firstPlanAsSource),
                            NULL,
                            (scDLL_t*)plan);

    return plan;
}

scSchemaCopyPlan_t* scSchemaCopyPlanAllocDeepOnly(
    scSchema_t     *schema,
    uint32_t        dstSchema)
{
    scSchemaCopyPlan_t *plan = calloc(1, sizeof(scSchemaCopyPlan_t));

    plan->dstSchema = dstSchema;

    scAttachHeadToDLL((scDLL_t**)&(schema->firstDeepOnlyPlanAsSource),
                            NULL,
                            (scDLL_t*)plan);

    return plan;
}


void scSchemaCopyPlanFree(
    scSchemaCopyPlan_t *plan)
{
    scSchemaCopyTuple_t    *tuple;

    while (plan->firstCopyTuple) {
        scDetachHeadOfDLL((scDLL_t**)&(plan->firstCopyTuple),
                          NULL,
                          (scDLL_t**)&tuple);
        scSchemaCopyTupleFree(tuple);
    }

    free(plan);
}

scSchemaCopyTuple_t* scSchemaCopyTupleAlloc(
    scSchemaCopyPlan_t *plan,
    uint32_t            src,
    uint32_t            dst,
    uint32_t            len)
{
    scSchemaCopyTuple_t    *tuple = calloc(1, sizeof(scSchemaCopyTuple_t));

    tuple->src = src;
    tuple->dst = dst;
    tuple->len = len;

    scAttachHeadToDLL((scDLL_t**)&(plan->firstCopyTuple),
                      NULL,
                      (scDLL_t*)tuple);

    return tuple;
}

void scSchemaCopyTupleFree(
    scSchemaCopyTuple_t *tuple)
{
    free(tuple);
}

uint32_t copyBetweenSchemas(
    scSchema_t *dstSchema,
    uint8_t    *dstBuf,
    scSchema_t *srcSchema,
    uint8_t    *srcBuf)
{
    scSchemaCopyPlan_t     *plan;
    scSchemaCopyTuple_t    *tuple;
    uint32_t                lenCopied = 0;
    scInfoElement_t        *sie;
    scInfoElement_t        *die;

    /* only ever have to worry about PRIMARY elements */

    if (dstSchema == srcSchema) { /* just a shallow memcpy */
        memcpy(dstBuf, srcBuf, dstSchema->len);
        return dstSchema->len;
    }

    for (plan = srcSchema->firstPlanAsSource; plan; plan = plan->next) {
        if (plan->dstSchema == dstSchema->id) {
            for (tuple = plan->firstCopyTuple; tuple; tuple = tuple->next) {
                memcpy(dstBuf + tuple->dst,
                       srcBuf + tuple->src,
                       tuple->len);
                lenCopied += tuple->len;
            }

            return lenCopied;
        }
    }

    /* make one */
    sie = srcSchema->firstPrimary;
    while (sie) {
        if ((die = scSchemaGetIEByID(dstSchema, sie->ent, sie->id))) {
            /* we have a match, need a plan */
            if (!plan) {
                plan = scSchemaCopyPlanAlloc(srcSchema, dstSchema->id);
            }
            /* found the first element in the new tuple*/
            /* initialize the tuple...we can adjust later */
            tuple = scSchemaCopyTupleAlloc(plan,
                                           sie->offset,
                                           die->offset,
                                           ieTypeLengths[sie->type]);
            while (tuple) {
                sie = sie->next;
                die = die->next;
                if (!sie || !die) {
                    tuple = NULL;
                    break;
                }
                /* if the next ones match...adjust the tuple */
                if (sie->ent == die->ent && sie->id == die->id) {
                    tuple->len = die->offset - tuple->dst +
                                  ieTypeLengths[die->type];
                } else {
                    /* not contiguous...move on */
                    tuple = NULL;
                }
            }
            /* they didn't match.  start over with this sie */
            continue;
        }

        sie = sie->next;
    }

    return copyBetweenSchemas(dstSchema, dstBuf, srcSchema, srcBuf);
}

uint32_t deepCopyBetweenSchemas(
    scSchema_t     *dstSchema,
    uint8_t        *dstBuf,
    scSchema_t     *srcSchema,
    const uint8_t  *srcBuf)
{
    scSchemaCopyPlan_t     *plan;
    scSchemaCopyPlan_t     *varPlan;
    scSchemaCopyTuple_t    *tuple;
    uint32_t                lenCopied = 0;
    scVarfield_t           *srcV;
    scVarfield_t           *dstV;
    scInfoElement_t        *sie;
    scInfoElement_t        *die;

    /* only ever have to worry about PRIMARY elements */

    if (dstSchema == srcSchema) { /* just a deep copy */
        return srcSchema->copyRecord(srcSchema, dstBuf, srcBuf);
    }

    for (plan = srcSchema->firstPlanAsSource; plan; plan = plan->next) {
        if (plan->dstSchema == dstSchema->id) {
            for (tuple = plan->firstCopyTuple; tuple; tuple = tuple->next) {
                /* could it be this easy */
                memcpy(dstBuf + tuple->dst,
                       srcBuf + tuple->src,
                       tuple->len);
                lenCopied += tuple->len;
            }
            break;
        }
    }

    for (plan = srcSchema->firstDeepOnlyPlanAsSource; plan; plan = plan->next) {
        if (plan->dstSchema == dstSchema->id) {
            for (tuple = plan->firstCopyTuple; tuple; tuple = tuple->next) {
                srcV = (scVarfield_t*)(srcBuf + tuple->src);
                dstV = (scVarfield_t*)(dstBuf + tuple->dst);

                dstV->len = srcV->len;
                dstV->dataPtr = calloc(1, srcV->len);
                memcpy(dstV->dataPtr, srcV->dataPtr, dstV->len);
                lenCopied += dstV->len;
            }
            break;
        }
    }

    if (lenCopied) {
        return lenCopied;
    }

    /* make one deep copied */
    /* make one */
    plan    = NULL;
    varPlan = NULL;

    sie = srcSchema->firstPrimary;
    while (sie) {
        if ((die = scSchemaGetIEByID(dstSchema, sie->ent, sie->id))) {
            switch(scInfoElementGetGeneralType(sie)) {
              case VARLEN_DATA:
                if (!varPlan) {
                    varPlan = scSchemaCopyPlanAllocDeepOnly(srcSchema,
                                                            dstSchema->id);
                }
                tuple = scSchemaCopyTupleAlloc(varPlan,
                                               sie->offset,
                                               die->offset,
                                               ieTypeLengths[sie->type]);
                /* we only do one varfield per tuple */
                sie = sie->next;
                continue;
              case FIXED:
                if (!plan) {
                    plan = scSchemaCopyPlanAlloc(srcSchema, dstSchema->id);
                }
                tuple = scSchemaCopyTupleAlloc(plan,
                                           sie->offset,
                                           die->offset,
                                           ieTypeLengths[sie->type]);
                while (tuple) {
                    sie = sie->next;
                    die = die->next;

                    if (!die || !sie) {
                        /* out of elements on either src or dst */
                        tuple = NULL;
                        continue;
                    }
                    if (scInfoElementIsVarlen(sie)) {
                        /* next one is varlen...end plan */
                        tuple = NULL;
                        continue;
                    }
                    /* if the next ones match...adjust the tuple */
                    if (sie->ent == die->ent && sie->id == die->id) {
                        tuple->len = die->offset - tuple->dst +
                                      ieTypeLengths[die->type];
                    } else {
                        /* not contiguous...move on */
                        tuple = NULL;
                    }
                }
                /* they didn't match.  start over with this sie */
                continue;
              case LIST_TYPE:
                break;
            }
        }

        sie = sie->next;
    }

    return deepCopyBetweenSchemas(dstSchema, dstBuf, srcSchema, srcBuf);
}



int standardLenOverrideCopyVal(
    scInfoElement_t    *ie,
    const uint8_t      *rec,
    uint8_t            *outBuf)
{
    memcpy(outBuf, rec + ie->offset, ie->lenOverride);

    return ie->lenOverride;
}

/* data working functions */
int standardCopyVal(
    scInfoElement_t    *ie,
    const uint8_t      *rec,
    uint8_t            *outBuf)
{
    memcpy(outBuf, rec + ie->offset, ie->len);

    return ie->len;
}

uint8_t* standardRetPtr(
    scInfoElement_t    *ie,
    const uint8_t      *rec)
{
    return (uint8_t*)(rec + ie->offset);
}

int standardSetFunc(
    scInfoElement_t    *ie,
    uint8_t            *rec,
    uint8_t            *inBuf)
{
    scVarfield_t   *varfield = (scVarfield_t*)(rec + ie->offset);

    switch (scInfoElementGetGeneralType(ie)) {
      case VARLEN_DATA:
      {
        scVarfield_t *inVarfield = (scVarfield_t*)inBuf;
        varfield->len = inVarfield->len;
        varfield->dataPtr = calloc(1, varfield->len);
        memcpy(varfield->dataPtr, inVarfield->dataPtr, varfield->len);
        break;
      }
      case FIXED:
        memcpy(rec + ie->offset, inBuf, ieTypeLengths[ie->type]);
        break;
      case LIST_TYPE:
        break;
    }

    return ieTypeLengths[ie->type];
}

int standardFlagsPrintFunc(
    scInfoElement_t    *ie,
    char               *buf,
    int                 maxlen,
    const uint8_t      *val)
{
    scInfoStringVal_t  *isv;
    uint64_t            theVal      = 0;
    uint8_t            *ptr8        = (uint8_t*)val;
    uint16_t           *ptr16       = (uint16_t*)val;
    uint32_t           *ptr32       = (uint32_t*)val;
    uint64_t           *ptr64       = (uint64_t*)val;
    int                 lengthUsed  = 0;

    switch (ie->type) {
      case UNSIGNED_8:
        theVal = *ptr8;
        break;
      case UNSIGNED_16:
        theVal = *ptr16;
        break;
      case UNSIGNED_32:
        theVal = *ptr32;
        break;
      case UNSIGNED_64:
        theVal = *ptr64;
        break;
      default:
        printf("A non-unsigned type was assigned to FLAGS, this is bad\n");
        return 0;
    }

    if (theVal == 0) {
        lengthUsed += snprintf(buf + lengthUsed, maxlen - lengthUsed,
                               "<none>");
    } else {
        for (isv = ie->firstStringVal; isv; isv = isv->next) {
            if (theVal & isv->val) {
                lengthUsed += snprintf(buf + lengthUsed,
                                       maxlen - lengthUsed,
                                       "%s", isv->userString);
            }
        }
    }

    return lengthUsed;
}

int standardCustomNumRepPrintFunc(
    scInfoElement_t    *ie,
    char               *buf,
    int                 maxlen,
    const uint8_t      *val)
{
    scInfoStringVal_t  *isv;
    uint64_t            theVal      = 0;
    uint8_t            *ptr8        = (uint8_t*)val;
    uint16_t           *ptr16       = (uint16_t*)val;
    uint32_t           *ptr32       = (uint32_t*)val;
    uint64_t           *ptr64       = (uint64_t*)val;
    int                 lengthUsed  = 0;

    switch (ie->type) {
      case UNSIGNED_8:
        theVal = *ptr8;
        break;
      case UNSIGNED_16:
        theVal = *ptr16;
        break;
      case UNSIGNED_32:
        theVal = *ptr32;
        break;
      case UNSIGNED_64:
        theVal = *ptr64;
        break;
      default:
        printf("A non-unsigned type was assigned to FLAGS, this is bad\n");
        return 0;
    }


    for (isv = ie->firstStringVal; isv; isv = isv->next) {
        if (theVal == isv->val) {
            lengthUsed += snprintf(buf + lengthUsed,
                                   maxlen - lengthUsed,
                                   "%s", isv->userString);
            return lengthUsed;
        }
    }

    /* didn't find it...print number */
    lengthUsed += snprintf(buf + lengthUsed,
                                   maxlen - lengthUsed,
                                   "%ld", theVal);
    return lengthUsed;
}
int standardPrintFunc(
    scInfoElement_t    *ie,
    char               *buf,
    int                 maxlen,
    const uint8_t      *val)
{
    switch (ie->type) {
      case OCTET_ARRAY:
      {
        gchar  *encodedString;
        int     encodedLen = 0;
        if (ie->lenOverride) {
            encodedString = g_base64_encode(val, ie->lenOverride);
            encodedLen = snprintf(buf, maxlen, "%s", encodedString);
            g_free(encodedString);
            return encodedLen;
        } else {
            scVarfield_t   *varfield = (scVarfield_t*)val;
            uint8_t        *ptr = varfield->dataPtr;

            encodedString = g_base64_encode(ptr, varfield->len);
            encodedLen = snprintf(buf, maxlen, "%s", encodedString);
            g_free(encodedString);
            return encodedLen;
        }
      }
      case UNSIGNED_8:
      case SIGNED_8:
      {
        const uint8_t    *ptr = val;
        return snprintf(buf, maxlen, "%" PRIu8, *ptr);
      }
      case UNSIGNED_16:
      case SIGNED_16:
      {
        if (ie->len == 2) {
            return snprintf(buf, maxlen, "%" PRIu16, *((uint16_t*)val));
        } else if (ie->len == 1) {
            return snprintf(buf, maxlen, "%" PRIu8, *((uint8_t*)val));
        }

        return 0;
      }
      case UNSIGNED_32:
      case SIGNED_32:
      {
        if (ie->len == 4) {
            return snprintf(buf, maxlen, "%" PRIu32, *((uint32_t*)val));
        } else if (ie->len == 2) {
            return snprintf(buf, maxlen, "%" PRIu16, *((uint16_t*)val));
        } else if (ie->len == 1) {
            return snprintf(buf, maxlen, "%" PRIu8, *((uint8_t*)val));
        }

        return 0;

      }
      case UNSIGNED_64:
      case SIGNED_64:
      {
        if (ie->len == 8) {
            return snprintf(buf, maxlen, "%" PRIu64, *((uint64_t*)val));
        } else if (ie->len == 4) {
            return snprintf(buf, maxlen, "%" PRIu32, *((uint32_t*)val));
        } else if (ie->len == 2) {
            return snprintf(buf, maxlen, "%" PRIu16, *((uint16_t*)val));
        } else if (ie->len == 1) {
            return snprintf(buf, maxlen, "%" PRIu8, *((uint8_t*)val));
        }

        return 0;
      }
      case FLOAT_32:
      {
        return snprintf(buf, maxlen, "%f", *((float*)val));
      }
      case FLOAT_64:
      {
        if (ie->len == 8) {
            return snprintf(buf, maxlen, "%f", *((double*)val));
        } else if (ie->len == 4) {
            return snprintf(buf, maxlen, "%f", *((float*)val));
        }
      }
      case BOOLEAN:
      {
        const uint8_t    *ptr = (const uint8_t*)val;
        if (*ptr) {
            return snprintf(buf, maxlen, "TRUE");
        } else {
            return snprintf(buf, maxlen, "FALSE");
        }
      }
      case MAC_ADDRESS:
      {
        uint32_t    i;
        for (i = 0; i < 6; i++) {
            snprintf(buf + 2*i,
                           maxlen - 2*i,
                           "%02x",
                           val[i]);
        }
        return 12;
      }
      case STRING:
      {
        int escapedQuotes = 0;
        if (ie->lenOverride) {
            uint32_t        i;
            for (i = 0; i < ie->lenOverride && ((maxlen - i) > 0); i++) {
                if (val[i] == '"') {
                    snprintf(buf + i,
                         maxlen - i,
                         "\\%c",
                         val[i]);
                    escapedQuotes++;
                } else {            
                    snprintf(buf + i,
                             maxlen - i,
                             "%c",
                             val[i]);
                }
            }
            return ie->lenOverride + escapedQuotes;
        } else {
            scVarfield_t   *varfield = (scVarfield_t*)val;
            if (varfield->len != 0) {
                uint32_t        i;
                uint32_t        j = 0;
                uint8_t        *ptr = varfield->dataPtr;
                for (i = 0; i < varfield->len && ((maxlen - i) > 0); i++, j++) {
                    if (ptr[i] == 34) {
                        snprintf(buf + j,
                             maxlen - j,
                             "\\%c",
                             ptr[i]);
                        j++;
                        escapedQuotes++;
                    } else {
                        snprintf(buf + j,
                                 maxlen - j,
                                 "%c",
                                 ptr[i]);
                    }
                }
                return varfield->len + escapedQuotes;
            } else {
                return snprintf(buf, maxlen, "<empty>");
            }
        }
      }
      case DATETIME_SECONDS:
      {
        uint64_t secs = *((uint32_t*)val);
        struct tm time_tm;
        gmtime_r((time_t *)(&secs), &time_tm);
        return snprintf(buf, maxlen,
                 "%04u-%02u-%02u %02u:%02u:%02u",
                 time_tm.tm_year+1900, time_tm.tm_mon+1, time_tm.tm_mday,
                 time_tm.tm_hour, time_tm.tm_min, time_tm.tm_sec);
      }
      case DATETIME_MILLISECONDS:
      {
        uint64_t secs = *((uint64_t*)val) / 1000;
        struct tm time_tm;
        gmtime_r((time_t *)(&secs), &time_tm);
        return snprintf(buf, maxlen,
                 "%04u-%02u-%02u %02u:%02u:%02u",
                 time_tm.tm_year+1900, time_tm.tm_mon+1, time_tm.tm_mday,
                 time_tm.tm_hour, time_tm.tm_min, time_tm.tm_sec);
      }
      case DATETIME_MICROSECONDS:
      {
        uint64_t secs = *((uint64_t*)val) / 1000000;
        struct tm time_tm;
        gmtime_r((time_t *)(&secs), &time_tm);
        return snprintf(buf, maxlen,
                 "%04u-%02u-%02u %02u:%02u:%02u",
                 time_tm.tm_year+1900, time_tm.tm_mon+1, time_tm.tm_mday,
                 time_tm.tm_hour, time_tm.tm_min, time_tm.tm_sec);
      }
      case DATETIME_NANOSECONDS:
      {
        uint64_t secs = *((uint64_t*)val) / 1000000000;
        struct tm time_tm;
        gmtime_r((time_t *)(&secs), &time_tm);
        return snprintf(buf, maxlen,
                 "%04u-%02u-%02u %02u:%02u:%02u",
                 time_tm.tm_year+1900, time_tm.tm_mon+1, time_tm.tm_mday,
                 time_tm.tm_hour, time_tm.tm_min, time_tm.tm_sec);

      }
      case IPV4_ADDRESS:
      {
        const uint32_t   *ptr = (const uint32_t*)val;
        return snprintf(buf, maxlen, "%d.%d.%d.%d", (*ptr & 0xFF000000) >> 24,
                                                    (*ptr & 0x00FF0000) >> 16,
                                                    (*ptr & 0x0000FF00) >> 8,
                                                    (*ptr & 0x000000FF));
      }
      case IPV6_ADDRESS:
      {
        uint32_t    i;
        size_t      lastLen = 0;

        uint16_t   *thisGroup = (uint16_t*)val;
        for (i = 0; i < 7; i++, thisGroup++) {
            lastLen += snprintf(buf + lastLen,
                               maxlen - lastLen,
                               "%04x:",
                               ntohs(*thisGroup));
        }

        lastLen += snprintf(buf + lastLen,
                           maxlen - lastLen,
                           "%04x",
                           ntohs(*thisGroup));
        return lastLen;
      }
      case BASIC_LIST: {
        scBasicList_t      *bl = (scBasicList_t*)val;
        uint16_t            numElements = scBasicListGetNumElements(bl);
        const fbInfoElement_t    *fbIE = bl->infoElement;
        uint16_t            i;
        size_t              lastLen = 0;

        lastLen = snprintf(buf + lastLen, maxlen, "[");

        for (i = 0; i < numElements; i++) {
            lastLen += standardTypeBasedNonIEPrintFunc(fbIE->type, buf + lastLen, maxlen - lastLen,
                                       scBasicListGetIndexedDataPtr(bl, i));
            lastLen += snprintf(buf + lastLen, maxlen - lastLen, ",");
        }
        if (buf[lastLen-1] == ',') {
            lastLen--;
        }
        lastLen += snprintf(buf + lastLen, maxlen - lastLen, "]");
        return lastLen;
      }
      case SUB_TEMPLATE_LIST:
      case SUB_TEMPLATE_MULTI_LIST:
      break;
    }

    return 0;
}

static int standardTypeBasedNonIEPrintFunc(
    scInfoType_t        type,
    char               *buf,
    int                 maxlen,
    const uint8_t      *val)
{
    switch (type) {
      case OCTET_ARRAY:
      {
        uint32_t        i;
        scVarfield_t   *varfield = (scVarfield_t*)val;
        uint8_t        *ptr = varfield->dataPtr;
        for (i = 0; i < varfield->len && ((maxlen - i) > 0); i++) {
            snprintf(buf + 2*i,
                     maxlen - 2*i,
                     "%02x",
                     ptr[i]);
        }
        return 2*i;
      }
      case UNSIGNED_8:
      case SIGNED_8:
      {
        const uint8_t    *ptr = val;
        return snprintf(buf, maxlen, "%" PRIu8, *ptr);
      }
      case UNSIGNED_16:
      case SIGNED_16:
      {
        const uint16_t   *ptr = (const uint16_t*)val;
        return snprintf(buf, maxlen, "%" PRIu16, *ptr);
      }
      case UNSIGNED_32:
      case SIGNED_32:
      {
        const uint32_t   *ptr = (const uint32_t*)val;
        return snprintf(buf, maxlen, "%" PRIu32, *ptr);
      }
      case UNSIGNED_64:
      case SIGNED_64:
      {
        const uint64_t   *ptr = (const uint64_t*)val;
        return snprintf(buf, maxlen, "%" PRIu64, *ptr);
      }
      case FLOAT_32:
      {
        const float      *ptr = (const float*)val;
        return snprintf(buf, maxlen, "%f", *ptr);
      }
      case FLOAT_64:
      {
        const double     *ptr = (const double*)val;
        return snprintf(buf, maxlen, "%f", *ptr);
      }
      case BOOLEAN:
      {
        const uint8_t    *ptr = (const uint8_t*)val;
        if (*ptr) {
            return snprintf(buf, maxlen, "TRUE");
        } else {
            return snprintf(buf, maxlen, "FALSE");
        }
      }
      case MAC_ADDRESS:
      {
        uint32_t    i;
        for (i = 0; i < 6; i++) {
            snprintf(buf + 2*i,
                           maxlen - 2*i,
                           "%02x",
                           val[i]);
        }
        return 12;
      }
      case STRING:
      {
        scVarfield_t   *varfield = (scVarfield_t*)val;
        if (varfield->len != 0) {
            uint32_t        i;
            uint8_t        *ptr = varfield->dataPtr;
            for (i = 0; i < varfield->len && ((maxlen - i) > 0); i++) {
                snprintf(buf + i,
                         maxlen - i,
                         "%c",
                         ptr[i]);
            }
            return varfield->len;
        } else {
            return snprintf(buf, maxlen, "<empty>");
        }
      }
      case DATETIME_SECONDS:
      {
        uint64_t secs = *((uint32_t*)val);
        struct tm time_tm;
        gmtime_r((time_t *)(&secs), &time_tm);
        return snprintf(buf, maxlen,
                 "%04u-%02u-%02u %02u:%02u:%02u",
                 time_tm.tm_year+1900, time_tm.tm_mon+1, time_tm.tm_mday,
                 time_tm.tm_hour, time_tm.tm_min, time_tm.tm_sec);
      }
      case DATETIME_MILLISECONDS:
      {
        uint64_t secs = *((uint64_t*)val) / 1000;
        struct tm time_tm;
        gmtime_r((time_t *)(&secs), &time_tm);
        return snprintf(buf, maxlen,
                 "%04u-%02u-%02u %02u:%02u:%02u",
                 time_tm.tm_year+1900, time_tm.tm_mon+1, time_tm.tm_mday,
                 time_tm.tm_hour, time_tm.tm_min, time_tm.tm_sec);
      }
      case DATETIME_MICROSECONDS:
      {
        uint64_t secs = *((uint64_t*)val) / 1000000;
        struct tm time_tm;
        gmtime_r((time_t *)(&secs), &time_tm);
        return snprintf(buf, maxlen,
                 "%04u-%02u-%02u %02u:%02u:%02u",
                 time_tm.tm_year+1900, time_tm.tm_mon+1, time_tm.tm_mday,
                 time_tm.tm_hour, time_tm.tm_min, time_tm.tm_sec);
      }
      case DATETIME_NANOSECONDS:
      {
        uint64_t secs = *((uint64_t*)val) / 1000000000;
        struct tm time_tm;
        gmtime_r((time_t *)(&secs), &time_tm);
        return snprintf(buf, maxlen,
                 "%04u-%02u-%02u %02u:%02u:%02u",
                 time_tm.tm_year+1900, time_tm.tm_mon+1, time_tm.tm_mday,
                 time_tm.tm_hour, time_tm.tm_min, time_tm.tm_sec);

      }

      case IPV4_ADDRESS:
      {
        const uint32_t   *ptr = (const uint32_t*)val;
        return snprintf(buf, maxlen, "%d.%d.%d.%d", (*ptr & 0xFF000000) >> 24,
                                                    (*ptr & 0x00FF0000) >> 16,
                                                    (*ptr & 0x0000FF00) >> 8,
                                                    (*ptr & 0x000000FF));
      }
      case IPV6_ADDRESS:
      {
        uint32_t    i;
        size_t      lastLen = 0;

        uint16_t   *thisGroup = (uint16_t*)val;
        for (i = 0; i < 7; i++, thisGroup++) {
            lastLen += snprintf(buf + lastLen,
                               maxlen - lastLen,
                               "%04x:",
                               ntohs(*thisGroup));
        }

        lastLen += snprintf(buf + lastLen,
                           maxlen - lastLen,
                           "%04x",
                           ntohs(*thisGroup));
        return lastLen;
      }
      default:
        printf("NESTED printign of a list %s...BAD NEWS\n", getIETypeString(type));
        return 0;
    }



}


uint32_t standardMergeFunc(
    scInfoElement_t    *ie,
    uint8_t            *outBuf,
    uint8_t            *buf1,
    uint8_t            *buf2)
{
    switch(ie->type) {
      case OCTET_ARRAY:
      case STRING:
        /* still figuring out varfields...*/
        break;
      case MAC_ADDRESS:
      case IPV4_ADDRESS:
      case IPV6_ADDRESS:
        /* no clue what to do with these */
        break;
      case BASIC_LIST:
      case SUB_TEMPLATE_LIST:
      case SUB_TEMPLATE_MULTI_LIST:
        /* will eventually combine all of these */
        break;
      case UNSIGNED_8:
        *outBuf = *buf1 + *buf2;
        break;
      case UNSIGNED_16:
        *((uint16_t*)outBuf) = *((uint16_t*)buf1) + *((uint16_t*)buf2);
        break;
      case UNSIGNED_32:
      case DATETIME_SECONDS:
        *((uint32_t*)outBuf) = *((uint32_t*)buf1) + *((uint32_t*)buf2);
        break;
      case UNSIGNED_64:
        *((uint64_t*)outBuf) = *((uint64_t*)buf1) + *((uint64_t*)buf2);
        break;
      case SIGNED_8:
        *((int8_t*)outBuf) = *((int8_t*)buf1) + *((int8_t*)buf2);
        break;
      case SIGNED_16:
        *((int16_t*)outBuf) = *((int16_t*)buf1) + *((int16_t*)buf2);
        break;
      case SIGNED_32:
        *((int32_t*)outBuf) = *((int32_t*)buf1) + *((int32_t*)buf2);
        break;
      case SIGNED_64:
        *((int64_t*)outBuf) = *((int64_t*)buf1) + *((int64_t*)buf2);
        break;
      case BOOLEAN:
        *((uint8_t*)outBuf) = *((uint8_t*)buf1) || *((uint8_t*)buf2);
        break;
      case DATETIME_MILLISECONDS:
      case DATETIME_MICROSECONDS:
      case DATETIME_NANOSECONDS:
        *((uint64_t*)outBuf) = *((uint64_t*)buf1) + *((uint64_t*)buf2);
        break;
      case FLOAT_32:
      case FLOAT_64:
        /* need to track down sizes for floats*/
        break;
    }

    return ieTypeLengths[ie->type];
}

void doNothingFreeCopiedRecord(
    scSchema_t *schema,
    uint8_t    *rec)
{

}

void doNothingSecondLevelFreeRecord(
    scSchema_t *schema,
    uint8_t    *rec)
{

}

void scDataInfoDoNothingCleanupRecordCopy(
    uint8_t    *rec)
{
}


uint32_t doNothingDeepCopyRecord(
    scSchema_t     *schema,
    uint8_t        *dst,
    const uint8_t  *src)
{
    return 0;
}

uint32_t calculateNewOffset(
    uint32_t            lastLen,
    scInfoElement_t    *ie)
{
    static uint32_t ptrSize         = sizeof(void*);
    uint32_t        nextLevel       = (lastLen / ptrSize) + 1;
    uint32_t        thisTypeLen     = ie->len;

    if (lastLen == 0) {
        return 0;
    }

    /* ipv6 and macs are stored as arrays...no need for fancy calculation */
    if (ie->type == IPV6_ADDRESS || ie->type == MAC_ADDRESS || ie->lenOverride) {
        return lastLen;
    }
    /* if the length of the new field stretches past the next ptr-length
        boundary, move it up there */
    if (thisTypeLen > (nextLevel * ptrSize - lastLen)) {
        if ((lastLen % ptrSize == 0)) {
            /* however, if it's perfectly on the alignment, do nothing */
            return lastLen;
        } else {
            /* if it stradles, move on up */
            return (nextLevel * ptrSize);
        }
    } else { /* within the pointer boundary */
        if (((lastLen % thisTypeLen) == 0) ||
            (lastLen % ptrSize == 0))
        {
            /* if this new ie is length aligned, ok */
            return lastLen;
        } else { /* not length aligned, like a u16 following a u8 */
            return ((lastLen / thisTypeLen) + 1) * thisTypeLen;
        }
    }
}

void setAllOffsetsAndLen(
    scSchema_t *schema)
{
    scInfoElement_t    *ie;
    uint32_t            ptrSize = sizeof(void*);

    schema->len = 0;
    for (ie = schema->firstPrimary; ie; ie = ie->next) {
        ie->offset = calculateNewOffset(schema->len, ie);
        if (ie->lenOverride) {
            schema->len = ie->offset + ie->lenOverride;
        } else {
            schema->len = ie->offset + ie->len;
        }
    }

    if ((schema->len % ptrSize) != 0) {
        schema->len = (((schema->len / ptrSize) + 1) * ptrSize);
    }
}

scError_t* scErrorAlloc(
    void)
{
    scError_t  *error = calloc(1, sizeof(scError_t));

    return error;
}

void scErrorFree(
    scError_t  *error)
{
    free(error);
}

void scErrorClear(
    scError_t  *error)
{
    error->code = 0;
    memset(error->msg, 0, SC_ERROR_MAX_LEN);
}

/****************************** End of standard functions */

/****************************** String and helper functions */
char* getIETypeString(
    scInfoType_t    type)
{
    switch (type) {
      case OCTET_ARRAY:             return "OCTET_ARRAY";
      case UNSIGNED_8:              return "UNSIGNED_8";
      case UNSIGNED_16:             return "UNSIGNED_16";
      case UNSIGNED_32:             return "UNSIGNED_32";
      case UNSIGNED_64:             return "UNSIGNED_64";
      case SIGNED_8:                return "SIGNED_8";
      case SIGNED_16:               return "SIGNED_16";
      case SIGNED_32:               return "SIGNED_32";
      case SIGNED_64:               return "SIGNED_64";
      case FLOAT_32:                return "FLOAT_32";
      case FLOAT_64:                return "FLOAT_64";
      case BOOLEAN:                 return "BOOLEAN";
      case MAC_ADDRESS:             return "MAC_ADDRESS";
      case STRING:                  return "STRING";
      case DATETIME_SECONDS:        return "DATETIME_SECONDS";
      case DATETIME_MILLISECONDS:   return "DATETIME_MILLISECONDS";
      case DATETIME_MICROSECONDS:   return "DATETIME_MICROSECONDS";
      case DATETIME_NANOSECONDS:    return "DATETIME_NANOSECONDS";
      case IPV4_ADDRESS:            return "IPV4_ADDRESS";
      case IPV6_ADDRESS:            return "IPV6_ADDRESS";
      case BASIC_LIST:              return "BASIC_LIST";
      case SUB_TEMPLATE_LIST:       return "SUB_TEMPLATE_LIST";
      case SUB_TEMPLATE_MULTI_LIST: return "SUB_TEMPLATE_MULTI_LIST";
      default:                      return "INVALID_TYPE";
    }
}

char* getIESemanticString(
    scInfoSemantic_t    semantic)
{
    switch (semantic) {
      case DEFAULT:                 return "DEFAULT";
      case QUANTITY:                return "QUANTITY";
      case TOTAL_COUNTER:           return "TOTAL COUNTER";
      case DELTA_COUNTER:           return "DELTA COUNTER";
      case IDENTIFIER:              return "IDENTIFIER";
      case FLAGS:                   return "FLAGS";
      case LIST:                    return "LIST";
      default:                      return "INVALID SEMANTIC";
    }
}

char* getIEUnitsString(
    scInfoUnits_t   units)
{
    switch (units) {
      case NONE:                    return "NONE";
      case BITS:                    return "BITS";
      case OCTETS:                  return "OCTETS";
      case PACKETS:                 return "PACKETS";
      case FLOWS:                   return "FLOWS";
      case SECONDS:                 return "SECONDS";
      case MILLISECONDS:            return "MILLISECONDS";
      case MICROSECONDS:            return "MICROSECONDS";
      case NANOSECONDS:             return "NANOSECONDS";
      case FOUR_OCTET_WORDS:        return "FOUR OCTET WORDS";
      case MESSAGES:                return "MESSAGES";
      case HOPS:                    return "HOPS";
      case ENTRIES:                 return "ENTRIES";
      default:                      return "INVALID UNITS";
    }
}

char* getIEDiffReasonString(
    scIEDiffReason_t    dr)
{
    switch (dr) {
      case IE_DR_EQUAL:             return "EQUAL";
      case IE_DR_NULL_PTR:          return "NULL POINTER";
      case IE_DR_ENT:               return "ENTERPRISE NUMBER";
      case IE_DR_DATA_LEVEL:        return "DATA LEVEL";
      case IE_DR_LEN:               return "LENGTH";
      case IE_DR_ID:                return "ID";
      case IE_DR_TYPE:              return "TYPE";
      case IE_DR_SEMANTIC:          return "SEMANTIC";
      case IE_DR_UNITS:             return "UNITS";
      case IE_DR_RANGE_MIN:         return "RANGE MIN";
      case IE_DR_RANGE_MAX:         return "RANGE MAX";
      case IE_DR_NAME:              return "NAME";
    }

    return NULL;
}

char* getIEDataLevelString(
    scDataLevel_t   level)
{
    switch (level) {
      case PRIMARY:                 return "PRIMARY";
      case VIRTUAL:                 return "VIRTUAL";
    }
    return NULL;
}

void scDetachHeadOfSLL(
    scSLL_t **head,
    scSLL_t **toRemove)
{
    /*  set the outgoing pointer to point to the head listing */
    *toRemove = *head;
    /*  move the head pointer down one */
    *head = (*head)->next;
}

void scAttachHeadToSLL(
    scSLL_t **head,
    scSLL_t  *newEntry)
{

    /*  works evan if *head starts out null, being no elements scAttach
     *  the new entry to the head */
    newEntry->next = *head;
    /*  reassign the head pointer to the new entry */
    *head = newEntry;
}

void scDetachTailOfSLL(
    scSLL_t **head,
    scSLL_t **toRemove)
{
    scSLL_t *entry;

    if (NULL == (*head)->next) {
        *toRemove = *head;
        *head = NULL;
        return;
    }

    /* find the next to the last entry */
    for (entry = *head; entry->next->next; entry = entry->next);

    *toRemove = entry->next;
    entry->next = NULL;
}

void scAttachTailToSLL(
    scSLL_t **head,
    scSLL_t *newEntry)
{
    scSLL_t *entry;

    if (!(*head)) {
        scAttachHeadToSLL(head, newEntry);
        return;
    }

    entry = *head;
    while (entry->next) {
        entry = entry->next;
    }

    newEntry->next = NULL;
entry->next = newEntry;
}

void scDetachNextEntryOfSLL(
    scSLL_t  *entry,
    scSLL_t **nextEntry)
{
    /*  point nextEntry to its location */
    *nextEntry = entry->next;

    /*  if there is a node after the next node, connect the
     *  elements */
    if (*nextEntry) {
        entry->next = (*nextEntry)->next;
    } else {
        entry->next = NULL;
    }

    /*  if there is a legit element to return, make sure it's scDetached
     *  from the list by setting its next pointer to NULL */
    if (*nextEntry) {
        (*nextEntry)->next = NULL;
    }
}

void scDetachHeadOfDLL(
    scDLL_t **head,
    scDLL_t **tail,
    scDLL_t **toRemove)
{
    /*  assign the out pointer to the head */
    *toRemove = *head;
    /*  move the head pointer to pointer to the next element*/
    *head = (*head)->next;

    /*  if the new head's not NULL, set its prev to NULL */
    if (*head) {
        (*head)->prev = NULL;
    } else {
        /*  if it's NULL, it means there are no more elements, if
         *  there's a tail pointer, set it to NULL too */
        if (tail) {
            *tail = NULL;
        }
    }
}

void scDetachTailOfDLL(
    scDLL_t **head,
    scDLL_t **tail,
    scDLL_t **toRemove)
{
    /*  set toRemove to the tail element */
    *toRemove = *tail;
    /*  move tail back to the new tail */
    *tail = (*tail)->prev;
    /*  if there are still elements in the list, set the tail->next to
     *  null */
    if (*tail) {
        (*tail)->next = NULL;
    } else {
        /*  no more elements, set the head pointer to null */
        *head = NULL;
    }
}

void scDetachThisEntryOfDLL(
    scDLL_t **head,
    scDLL_t **tail,
    scDLL_t  *entry)
{
    /*  entry already points to the entry to remove, so we're good
     *  there */
    /*  if it's NOT the head of the list, patch up entry->prev */
    if (entry->prev != NULL) {
        entry->prev->next = entry->next;
    } else {
        /*  if it's the head, reassign the head */
        *head = entry->next;
    }
    /*  if it's NOT the tail of the list, patch up entry->next */
    if (entry->next != NULL) {
        entry->next->prev = entry->prev;
    } else {
        /*  it is the last entry in the list, if we're tracking the
         *  tail, reassign */
        if (tail) {
            *tail = entry->prev;
        }
    }

    /*  finish scDetaching by setting the next and prev pointers to
     *  null */
    entry->prev = NULL;
    entry->next = NULL;
}

void scAttachBeforeThisEntryOfDLL(
    scDLL_t   **head,
    scDLL_t   **tail,
    scDLL_t    *entryToAttach,
    scDLL_t    *beforeThisOne)
{
    entryToAttach->next = beforeThisOne;
    entryToAttach->prev = beforeThisOne->prev;
    if (entryToAttach->prev == NULL) {
        *head = entryToAttach;
    } else {
        entryToAttach->prev->next = entryToAttach;
    }

    beforeThisOne->prev = entryToAttach;
}

void scAttachAfterThisEntryOfDLL(
    scDLL_t   **head,
    scDLL_t   **tail,
    scDLL_t    *entryToAttach,
    scDLL_t    *afterThisOne)
{
    entryToAttach->prev = afterThisOne;
    entryToAttach->next = afterThisOne->next;
    if (entryToAttach->next == NULL) {
        *tail = entryToAttach;
    } else {
        entryToAttach->next->prev = entryToAttach;
    }

    afterThisOne->next = entryToAttach;
}


void scAttachHeadToDLL(
    scDLL_t **head,
    scDLL_t **tail,
    scDLL_t  *newEntry)
{
    /*  if this is NOT the first entry in the list */
    if (*head) {
        /*  typical linked list scAttachements */
        newEntry->next = *head;
        newEntry->prev = NULL;
        (*head)->prev = newEntry;
        *head = newEntry;
    } else {
        /*  the new entry is the only entry now, set head to it */
        *head = newEntry;
        newEntry->prev = NULL;
        newEntry->next = NULL;
        /*  if we're keeping track of tail, assign that too */
        if (tail) {
            *tail = newEntry;
        }
    }
}

void scAttachTailToDLL(
    scDLL_t **head,
    scDLL_t **tail,
    scDLL_t  *newEntry)
{
    /*  if this is NOT the first entry in the list */
    if (*tail) {
        /*  expected doubly linked list scAttachments */
        newEntry->prev = *tail;
        newEntry->next = NULL;
        (*tail)->next = newEntry;
        *tail = newEntry;
    } else {
        /*  this is the only element in the list.  Updated head and
         *  tail */
        *head = newEntry;
        *tail = newEntry;
        newEntry->prev = NULL;
        newEntry->next = NULL;
    }
}

void scSchemaPrintIEs(
    scSchema_t *schema)
{
    scInfoElement_t        *ie;
    scNestedIE_t           *nie;
    scGroupedElements_t    *group;
    scInfoStringVal_t      *isv;

    printf("SCHEMA: %s. Length %d\n", schema->name, schema->len);
    printf("Primary IEs...\n");
    for (ie = schema->firstPrimary; ie; ie = ie->next) {
        printf("%s at offset %d\n", ie->name, ie->offset);
        if (ie->firstStringVal) {
            for (isv = ie->firstStringVal; isv; isv = isv->next) {
                printf("\t%s %ld\n", isv->userString, isv->val);
            }
        }
    }

    printf("Secondary IEs...\n");
    for (ie = schema->firstVirtual; ie; ie = ie->next) {
        printf("%s ptr %p\n", ie->name, ie);
        if (ie->firstStringVal) {
            for (isv = ie->firstStringVal; isv; isv = isv->next) {
                printf("\t%s %ld\n", isv->userString, isv->val);
            }
        }
    }

    for (group = schema->firstGroup; group; group = group->next) {
        printf("Group: %s\n", group->userString);
        for (nie = group->firstNestedElement; nie; nie = nie->next) {
            printf("IE: %s\n", nie->ie->name);
        }
    }
}

scConnSpec_t* scConnSpecAlloc(
    scConnSpecType_t    type)
{
    scConnSpec_t   *connSpec = calloc(1, sizeof(scConnSpec_t));

    connSpec->type = type;
    connSpec->redoOrSame = SC_CS_REDO_SCHEMAS;

    switch (connSpec->type) {
      case SC_CS_TCP:
      case SC_CS_UDP:
        connSpec->connInfo.socket.portStr = NULL;
        connSpec->connInfo.socket.hostname = NULL;
        break;
      case SC_CS_FILELIST_INPUT:
      case SC_CS_DIRECTORY:
        connSpec->connInfo.fileList.filenames = NULL;
        connSpec->connInfo.fileList.numFiles = 0;
        connSpec->connInfo.fileList.currentFile = 0;
        break;
      case SC_CS_POLL_DIR:
        connSpec->connInfo.pollDir.directory = NULL;
        connSpec->connInfo.pollDir.timeoutSeconds = 0;
        connSpec->connInfo.pollDir.pollDir = NULL;
        connSpec->connInfo.pollDir.archiveDir = NULL;
        break;
      default:
        break;
    }

    return connSpec;
}

scConnSpec_t* scConnSpecAllocUseSameSchemas(
    scConnSpecType_t    type)
{
    scConnSpec_t   *connSpec = scConnSpecAlloc(type);
    connSpec->redoOrSame = SC_CS_SAME_SCHEMAS;
    return connSpec;
}

void scConnSpecUseSameSchemas(
    scConnSpec_t   *connSpec)
{
    connSpec->redoOrSame = SC_CS_SAME_SCHEMAS;
}


void scConnSpecFree(
    scConnSpec_t   *connSpec)
{
    uint32_t    i;
    scFileList_t   *fileList;
    scSocket_t     *sock;
    scDirPoll_t    *dirPoll;
    switch (connSpec->type) {
      case SC_CS_TCP:
      case SC_CS_UDP:
        sock = &connSpec->connInfo.socket;
        if (sock->portStr) {
            free(sock->portStr);
        }
        if (sock->hostname) {
            free(sock->hostname);
        }
        break;
      case SC_CS_FILELIST_INPUT:
      case SC_CS_FILE_OUTPUT:
      case SC_CS_DIRECTORY:
        fileList = &connSpec->connInfo.fileList;
        for (i = 0; i < fileList->numFiles; i++) {
            free(fileList->filenames[i]);
        }
        free(fileList->filenames);
        break;
      case SC_CS_POLL_DIR:
        dirPoll = &connSpec->connInfo.pollDir;
        if (dirPoll->archiveDir) {
            free(dirPoll->archiveDir);
        }

        if (dirPoll->directory) {
            free(dirPoll->directory);
        }

        if (dirPoll->pollDir) {
            skPollDirDestroy(dirPoll->pollDir);
        }

        break;

      default:
        break;
    }

    free(connSpec);
}

scConnSpec_t* scConnSpecCopy(
    scConnSpec_t   *connSpec)
{
    scConnSpec_t   *newCS = NULL;
    switch (connSpec->type) {
      case SC_CS_TCP:
      case SC_CS_UDP:
      {
        scSocket_t     *newSock;
        scSocket_t     *oldSock = &connSpec->connInfo.socket;

        newCS = scConnSpecAlloc(connSpec->type);
        newSock = &newCS->connInfo.socket;

        newSock->portStr    = strdup(oldSock->portStr);
        if (oldSock->hostname) {
            newSock->hostname   = strdup(oldSock->hostname);
        } else {
            newSock->hostname = NULL;
        }
        newSock->portInt    = oldSock->portInt;
        newSock->ipAddr     = oldSock->ipAddr;

        break;
      }
      case SC_CS_DIRECTORY:
      case SC_CS_FILELIST_INPUT:
      case SC_CS_FILE_OUTPUT:
      {
        scFileList_t   *newFL;
        scFileList_t   *oldFL = &connSpec->connInfo.fileList;
        uint32_t        i;

        if (connSpec->redoOrSame == SC_CS_SAME_SCHEMAS) {
            newCS = scConnSpecAllocUseSameSchemas(connSpec->type);
        } else {
            newCS = scConnSpecAlloc(connSpec->type);
        }

        newFL = &newCS->connInfo.fileList;

        for (i = 0; i < oldFL->numFiles; i++) {
            scConnSpecAddFile(newCS, oldFL->filenames[i]);
        }

        newFL->currentFile = 0;

        break;
      }
      case SC_CS_POLL_DIR:
      {
        scDirPoll_t    *oldPoll = &connSpec->connInfo.pollDir;

        if (connSpec->redoOrSame == SC_CS_SAME_SCHEMAS) {
            newCS = scConnSpecAllocUseSameSchemas(connSpec->type);
        } else {
            newCS = scConnSpecAlloc(connSpec->type);
        }

        scConnSpecAddDirectory(newCS,
                               oldPoll->directory,
                               oldPoll->timeoutSeconds,
                               oldPoll->pollingInterval,
                               oldPoll->pollingTimeout);

        if (oldPoll->archiveDir) {
            scConnSpecAddArchiveDirectory(newCS, oldPoll->archiveDir);
        }

        break;
      }
      default:
        printf("Conn Spec type not handled %d\n", connSpec->type);
    }

    return newCS;
}

scInfoElement_t* scDataInfoGetElementFromModelByName(
    scDataInfo_t   *dataInfo,
    char           *name)
{
    const fbInfoElement_t    *fbIE;
    if (dataInfo->infoModel) {
        if ((fbIE = fbInfoModelGetElementByName(dataInfo->infoModel, name))) {
            return scInfoElementAllocAndFill(dataInfo->infoModel,
                                             fbIE->ent,
                                             fbIE->num);
        } else {
            return NULL;
        }
    } else {
        return NULL;
    }
}

scInfoElement_t* scDataInfoGetElementFromModelByID(
    scDataInfo_t   *dataInfo,
    uint32_t        ent,
    uint32_t        id)
{
    if (dataInfo->infoModel) {
        return scInfoElementAllocAndFill(dataInfo->infoModel, ent, id);
    } else {
        printf("no info model\n");
        return NULL;
    }
}

void scInfoElementSetStandardFuncs(
    scInfoElement_t    *ie)
{
    ie->copyVal         = standardCopyVal;
    ie->retPtr          = standardRetPtr;
    ie->setFunc         = standardSetFunc;
    if (ie->semantic == FLAGS && ie->firstStringVal) {
        ie->printFunc   = standardFlagsPrintFunc;
    } else if (ie->semantic == CUSTOM_NUM_REP && ie->firstStringVal) {
        ie->printFunc   = standardCustomNumRepPrintFunc;
    } else {
        ie->printFunc       = standardPrintFunc;
    }
    ie->mergeFunc       = standardMergeFunc;
}

void removeWarnings(
    void)
{
    scDetachHeadOfSLL(NULL, NULL);
    scDetachTailOfSLL(NULL, NULL);
    scAttachTailToSLL(NULL, NULL);
    scDetachNextEntryOfSLL(NULL, NULL);
    scDetachTailOfDLL(NULL, NULL, NULL);
}
