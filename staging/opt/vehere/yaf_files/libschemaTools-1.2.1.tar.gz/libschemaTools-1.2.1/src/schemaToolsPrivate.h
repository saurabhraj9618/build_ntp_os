#ifndef _SCHEMATOOLSSTRUCTS_H
#define _SCHEMATOOLSSTRUCTS_H

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdarg.h>
#include <inttypes.h>
#include <schemaTools/schemaTools.h>
#include <schemaTools/scpolldir.h>

void printVarfield(scVarfield_t   *varfield);

extern uint32_t ieTypeLengths[];

typedef struct scIENums_st {
    uint32_t    ent;
    uint32_t    id;
} scIENums_t;

#ifndef DOXYGEN_SHOULD_SKIP_THIS
/* structures */
struct scUniqueIE_st {
    uint32_t    ent;
    uint32_t    id;
    char       *name;
};

/* ties a user string to a value - S (for tcp SYN) = 2 */
struct scInfoStringVal_st {
    scInfoStringVal_t *next;
    scInfoStringVal_t *prev;
    uint64_t            val;
    char               *userString;
};

/** Used in group elements.  This is needed because the next and prev
 * pointers in the information elements cannot be changed.  This is the only
 * way to group the elements */
struct scNestedIE_st {
    scNestedIE_t       *next;
    scNestedIE_t       *prev;
    scInfoElement_t    *ie; /** nested pointer to the IE in the group */
};

/** Used to group elements with a string name
 * e.g. SIP and DIP make up a group reference by IP
 */
struct scGroupedElements_st {
    scGroupedElements_t    *next;
    scGroupedElements_t    *prev;
    char                   *userString; /** String that defines the group. */
    uint32_t                numElements; /** num elements in the group */
    scNestedIE_t           *firstNestedElement; /** pointer to the list */
    scNestedIE_t           *lastNestedElement; /** pointer to the list end */
    int                     isDefaultTypeGroup;
};

typedef struct scSchemaCopyPlan_st  scSchemaCopyPlan_t;
typedef struct scSchemaCopyTuple_st scSchemaCopyTuple_t;

struct scSchemaCopyPlan_st {
    scSchemaCopyPlan_t         *next;
    scSchemaCopyPlan_t         *prev;
    uint32_t                    dstSchema;
    scSchemaCopyTuple_t        *firstCopyTuple;
};

struct scSchemaCopyTuple_st {
    scSchemaCopyTuple_t        *next;
    scSchemaCopyTuple_t        *prev;
    uint32_t                    src;
    uint32_t                    dst;
    uint32_t                    len;
};

/**
 * Holds schema information that defines a record.
 * This informtion includes the elements, schema name and id, grouped elements,
 * and functions to handle records defined by this schema
 */
struct scSchema_st {
    scSchema_t                 *next;
    scSchema_t                 *prev;
    char                       *name;           /** string name for schema */
    uint16_t                    id;             /** schema id (template id?) */
    uint32_t                    ieTableOffset;
    uint32_t                    len;            /** num bytes needed to hold
                                               data records using this schema*/
    uint32_t                    forcedFixedLen;
    uint32_t                    numElements;    /** number of elements listed */
    scInfoElement_t            *firstPrimary;   /** pointer to first element */
    scInfoElement_t            *lastPrimary;    /** pointer to last element */
    scInfoElement_t            *firstVirtual;
    scInfoElement_t            *lastVirtual;
    uint32_t                    numGroups;      /** num of groups of elements */
    scGroupedElements_t        *firstGroup;     /** first group of elements */
    int                         emptyGroupsRemoved;
    scSchemaDeepCopyRecord_fn   copyRecord;     /** copy a record of this type*/
    scSchemaFreeRecord_fn       freeRecordCopy; /** free a copied record */
    scSchemaFreeRecord_fn       freeSecondLevelFields; /** varlen fields */
    scSchemaCopyPlan_t         *firstPlanAsSource;
    scSchemaCopyPlan_t         *firstDeepOnlyPlanAsSource;
    void                       *builderMem;
    scSchemaBuilderMemAllocAndCopy_fn   builderMemAllocAndCopy;
    scSchemaBuilderMemFree_fn   builderMemFree;
    scSchema_t                 *associatedSchema;
    uint8_t                     hasVarFields;
    void                       *ctx;
    scSchemaCtxFree_fn          ctxFreeFunction;
    uint8_t                    *recForPtr;
    scInfoElement_t            *timingSource;
    int                         hasBL;
    int                         hasSTL;
    int                         hasSTML;
    int                         subElementChanged;
    GHashTable                 *elementTableID;
    GHashTable                 *elementTableName;
    GHashTable                 *groupsByName;
};


#endif

uint32_t scInfoElementHash(scIENums_t *ieNums);

gboolean scInfoElementEqual(
    scIENums_t *a,
    scIENums_t *b);

scNestedIE_t* scNestedIEAlloc(void);
void scNestedIEFree(scNestedIE_t  *nie);

scInfoElement_t* scInfoElementAlloc(void);

int lookupAndFillIE(
    fbInfoModel_t      *infoModel,
    scInfoElement_t    *ie,
    uint32_t            ent,
    uint32_t            id,
    char               *name);

void setAllOffsetsAndLen(
    scSchema_t         *schema);

uint32_t calculateNewOffset(
    uint32_t            lastLen,
    scInfoElement_t    *ie);

/* copy between schemas functions */
scSchemaCopyPlan_t* scSchemaCopyPlanAlloc(
    scSchema_t     *schema,
    uint32_t        dstSchema);

scSchemaCopyPlan_t* scSchemaCopyPlanAllocDeepOnly(
    scSchema_t     *schema,
    uint32_t        dstSchema);

void scSchemaCopyPlanFree(
    scSchemaCopyPlan_t *plan);

scSchemaCopyTuple_t* scSchemaCopyTupleAlloc(
    scSchemaCopyPlan_t *plan,
    uint32_t            src,
    uint32_t            dst,
    uint32_t            len);

void scSchemaCopyTupleFree(
    scSchemaCopyTuple_t *tuple);

/* All of the standard IE functions... */
int standardCopyVal(
    scInfoElement_t    *ie,
    const uint8_t      *rec,
    uint8_t            *outBuf);

int standardLenOverrideCopyVal(
    scInfoElement_t    *ie,
    const uint8_t      *rec,
    uint8_t            *outBuf);

uint8_t* standardRetPtr(
    scInfoElement_t    *ie,
    const uint8_t      *rec);

uint8_t* varlenStandardRetPtr(
    scInfoElement_t    *ie,
    const uint8_t      *rec);

int standardSetFunc(
    scInfoElement_t    *ie,
    uint8_t            *rec,
    uint8_t            *inBuf);

int standardFlagsPrintFunc(
    scInfoElement_t    *ie,
    char               *buf,
    int                 maxlen,
    const uint8_t      *val);

int standardCustomNumRepPrintFunc(
    scInfoElement_t    *ie,
    char               *buf,
    int                 maxlen,
    const uint8_t      *val);

int standardPrintFunc(
    scInfoElement_t    *ie,
    char               *buf,
    int                 maxlen,
    const uint8_t      *val);

uint32_t standardMergeFunc(
    scInfoElement_t    *ie,
    uint8_t            *outBuf,
    uint8_t            *buf1,
    uint8_t            *buf2);

void scSchemaForceRecPtrAlloc(
    scSchema_t *schema);

/* Lined list stuff */

/* more copies of linked list stuff...these schema tools probably need
    their own copy...I know this is getting silly */
typedef struct scSLL_st scSLL_t;
typedef struct scDLL_st scDLL_t;

#ifndef DOXYGEN_SHOULD_SKIP_THIS
/*
 *    All structures defined below with a next pointer must have it
 *    first in the structure.
 */
struct scSLL_st {
    scSLL_t *next;
};

/*
 *    All structures defined below with next and prev pointers must
 *    have them first in the structure in the following order.
 */
struct scDLL_st {
    scDLL_t *next;
    scDLL_t *prev;
};
#endif

#define ERR0(_string_)                                                  \
    snprintf(error->msg, SC_ERROR_MAX_LEN, _string_);

#define ERR1(_string_, _arg1_)                                          \
    snprintf(error->msg, SC_ERROR_MAX_LEN, _string_, _arg1_);

#define ERR2(_string_, _arg1_, _arg2_)                                  \
    snprintf(error->msg, SC_ERROR_MAX_LEN, _string_, _arg1_, _arg2_);

#define ERR3(_string_, _arg1_, _arg2_, _arg3_)                          \
    snprintf(error->msg, SC_ERROR_MAX_LEN, _string_, _arg1_, _arg2_, _arg3_);

#define ERR_APPEND(_string_)                                            \
    snprintf(error->msg + strlen(error->msg), SC_ERROR_MAX_LEN, "called by %s\n",         \
                                            _string_);


void scDetachHeadOfSLL(scSLL_t **head, scSLL_t **entry);

void scAttachHeadToSLL(scSLL_t**head, scSLL_t *newEntry);

void scDetachTailOfSLL(scSLL_t **head, scSLL_t **entry);

void scAttachTailToSLL(scSLL_t**head, scSLL_t *newEntry);

void scDetachNextEntryOfSLL(scSLL_t *entry, scSLL_t **nextEntryToDetach);

void scDetachHeadOfDLL(scDLL_t **head, scDLL_t **tail, scDLL_t **entry);

void scDetachTailOfDLL(scDLL_t **head, scDLL_t **tail, scDLL_t **entry);

void scDetachThisEntryOfDLL(
    scDLL_t **head,
    scDLL_t **tail,
    scDLL_t  *entryToDetach);

void scAttachBeforeThisEntryOfDLL(
    scDLL_t   **head,
    scDLL_t   **tail,
    scDLL_t    *entryToAttach,
    scDLL_t    *beforeThisOne);

void scAttachAfterThisEntryOfDLL(
    scDLL_t   **head,
    scDLL_t   **tail,
    scDLL_t    *entryToAttach,
    scDLL_t    *afterThisOne);

void scAttachHeadToDLL(scDLL_t **head, scDLL_t **tail, scDLL_t *newEntry);

void scAttachTailToDLL(scDLL_t **head, scDLL_t **tail, scDLL_t *newEntry);

int makeOutgoingSocketOrFileFixbufConnection(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    scSchema_t         *firstSchema,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

int getOutgoingSocketOrFileFixbufConnectionWithoutSchemas(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

int makeOutgoingFileDirFixbufConnection(
    scConnSpec_t       *connSpec,
    scDataInfo_t      **outDataInfo,
    void              **potentialState,
    scSchema_t         *firstSchema,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

scInfoElement_t* privateAddIECustomFuncs(
    scSchema_t             *schema,
    uint32_t                ent,
    uint32_t                id,
    char                   *name,
    char                   *userStringOveride,
    scInfoStringValList_t  *firstStringVal,
    scDataLevel_t           dataLevel,
    scInfoElementCopyVal_fn copyVal,
    scInfoElementRetPtr_fn  retPtr,
    scInfoElementSetVal_fn  setFunc,
    scInfoElementPrint_fn   printFunc,
    scInfoElementMerge_fn   mergeFunc,
    fbInfoModel_t          *infoModel,
    scError_t              *error);

scInfoElement_t* privateAddStandardIE(
    scSchema_t         *schema,
    uint32_t            ent,
    uint32_t            id,
    char               *name,
    char               *userStringOveride,
    scInfoStringVal_t  *firstStringVal,
    fbInfoModel_t      *infoModel,
    scError_t          *error);

#endif
