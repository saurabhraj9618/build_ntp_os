#!/bin/bash

#self contained baseball
../schemaTesters/baseball &
