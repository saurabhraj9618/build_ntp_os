#!/bin/bash

#self contained baseball

$srcdir/baseballTest.sh > baseballTry.txt

sleep 1
if diff baseballTry.txt $srcdir/baseballKey.txt;
    then
        echo "baseball passed"
	exit 0
    else
        echo "baseball failed"
        exit 1
fi
