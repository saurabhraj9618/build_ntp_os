#!/bin/bash

if [ -a basicListTry.txt ]
    then
        rm basicListTry.txt
fi

../schemaTesters/theBasicListReader SOCK 18001 > basicListTry.txt &  

sleep 1

../schemaTesters/basicListOneTemplate SOCKET 2 18001 

if diff basicListTry.txt $srcdir/basicListKey.txt;
    then
        echo "basic list test passed"
	exit 0
    else
        echo "basic list test failed"
        exit 1
fi
