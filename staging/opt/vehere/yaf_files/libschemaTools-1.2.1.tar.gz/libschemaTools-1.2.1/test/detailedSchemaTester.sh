#!/bin/bash

mkdir -p tempFileDir

#srcdir is for make distcheck.

../schemaTesters/schemaInternalsTester > schemaDetailsTry.txt

rc=$?

if [[ $rc != 0 ]]
    then
        echo "Detailed schema test failed, see schemaDetailsTry.txt for details"
	exit 1
fi

if [[ $rc == 0 ]]
    then
        if [[ "" == $(diff schemaDetailsTry.txt $srcdir/schemaDetailsKey.txt) ]]
            then
                echo "Schema Details Passed"
		exit 0
        else 
            if [[ "" == $(diff schemaDetailsTry.txt $srcdir/schemaDetailsKey32Bit.txt) ]]
                then 
                    echo "Schema Details Passed 32"
		    exit 0
            else
                echo "Schema Details Failed for both 32 and 64 bit systems"
		exit 1
            fi
        fi
fi

