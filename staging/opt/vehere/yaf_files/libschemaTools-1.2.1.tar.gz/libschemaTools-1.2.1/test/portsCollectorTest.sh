#!/bin/bash

# big test.  exporter -> ports -> collector
../schemaTesters/genericPortsCollector &
sleep 1
../schemaTesters/portDescriber -in TCP -port 18000 -out TCP -port 21000 -hostname localhost &
sleep 1
../schemaTesters/multipleTemplatesOneRecord SOCKET 1 18000 &
