#!/bin/bash

# big test.  exporter -> ports -> collector

$srcdir/portsCollectorTest.sh > portsTry.txt

sleep 1
if diff portsTry.txt $srcdir/portsKey.txt;
    then
        echo "passed"
        exit 0
    else
        echo "failed"
        exit 1
fi
