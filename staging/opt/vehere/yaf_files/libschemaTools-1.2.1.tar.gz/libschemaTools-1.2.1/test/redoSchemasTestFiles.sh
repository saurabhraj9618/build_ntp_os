#!/bin/bash

if [ -a rawDirRedoTry.txt ]
    then
        rm rawDirRedoTry.txt
fi
if [ -a rawListRedoTry.txt ]
    then
        rm rawListRedoTry.txt
fi

../schemaTesters/oneTemplateMultipleRecords ONE_FILE 2 tempFileDir

../schemaTesters/multipleTemplatesOneRecord ONE_FILE 2 tempFileDir

../schemaTesters/repeatElementsOneTemplate ONE_FILE 2 tempFileDir

../schemaTesters/sameTemplateIdMultipleTemplate ONE_FILE 2 tempFileDir


../schemaTesters/templateRightBeforeRecord ONE_FILE 2 tempFileDir

sleep 1

../schemaTesters/sampleIPFIX FILEDIRREDO tempFileDir > rawDirRedoTry.txt

sleep 1

rm -rf tempFileDir/*

if diff rawDirRedoTry.txt $srcdir/rawDirRedoKey.txt;
    then
        echo "raw ipfix dir redo schemas passed"
    else
        echo "raw ipfix dir redo schemas failed"
        exit 1
fi


../schemaTesters/oneTemplateMultipleRecords ONE_FILE 2 tempFileDir

../schemaTesters/multipleTemplatesOneRecord ONE_FILE 2 tempFileDir

../schemaTesters/repeatElementsOneTemplate ONE_FILE 2 tempFileDir

../schemaTesters/sameTemplateIdMultipleTemplate ONE_FILE 2 tempFileDir


../schemaTesters/templateRightBeforeRecord ONE_FILE 2 tempFileDir

sleep 1

../schemaTesters/sampleIPFIX FILELISTREDO tempFileDir/* > rawListRedoTry.txt

sleep 1

rm -rf tempFileDir/*

if diff rawListRedoTry.txt $srcdir/rawListRedoKey.txt;
    then
        echo "raw ipfix list redo schemas passed"
	    exit 0
    else
        echo "raw ipfix list redo schemas failed"
        exit 1
fi

