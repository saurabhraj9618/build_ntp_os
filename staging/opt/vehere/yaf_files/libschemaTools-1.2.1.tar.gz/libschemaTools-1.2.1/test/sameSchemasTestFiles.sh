#!/bin/bash

if [ -a rawDirSameTry.txt ]
    then
        rm rawDirSameTry.txt
fi


../schemaTesters/oneTemplateMultipleRecords FILES 3 tempFileDir

sleep 1

../schemaTesters/sampleIPFIX FILEDIRSAME tempFileDir > rawDirSameTry.txt

rm -rf tempFileDir/*

if diff rawDirSameTry.txt $srcdir/rawDirSameKey.txt;
    then
        echo "raw ipfix dir same schemas passed"
    else
        echo "raw ipfix dir same schemas failed"
        exit 1
fi

if [ -a rawListSameTry.txt ]
    then
        rm rawListSameTry.txt
fi


../schemaTesters/oneTemplateMultipleRecords FILES 3 tempFileDir

sleep 1

../schemaTesters/sampleIPFIX FILELISTSAME tempFileDir/* > rawListSameTry.txt

rm -rf tempFileDir/*

if diff rawListSameTry.txt $srcdir/rawListSameKey.txt;
    then
        echo "raw ipfix list same schemas passed"
    else
        echo "raw ipfix list same schemas failed"
        exit 1
fi

exit 0

