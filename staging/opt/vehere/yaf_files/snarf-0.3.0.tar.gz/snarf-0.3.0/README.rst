==========
 Overview
==========

``snarf`` is a distributed alert reporting system.  Applications can use
``snarf``'s libraries to send network alert messages, which can then be routed
to multiple destinations in a configurable manner.  ``snarf`` is designed to
allow application and script developers to emit network alert messages without
being concerned with the details of how the messages will be formatted
downstream, or what destinations they will be routed to.

Alert processing happens in three steps:

    * **origination** - An alert begins with an application call to either the
      alert and source APIs of :ref:`libsnarf` or :ref:`snarf-python`.  Alert
      sources use these APIs to build alerts and send them to :ref:`snarfd`, an
      alert routing daemon.

    * **routing** - :ref:`snarfd` matches fields in the alert's envelope against
      a set of configured routing rules, and routes the alert message to the
      appropriate destination(s) via a publish-subscribe mechanism.  To support
      a distributed, hierarchical alerting architecture, :ref:`snarfd` processes
      can subscribe to alert channels on another :ref:`snarfd` upstream to
      distribute alerts from remote sites.

    * **delivery** - Alert sinks subscribe to alert channels published by
      :ref:`snarfd`, delivering the alerts to the appropriate destination.

The ``snarf`` suite consists of the following software components:

* :ref:`libsnarf`, a C library for constructing, sending, and receiving alerts.

* :ref:`snarf-python`, a Python module for snarf alerting.

* :ref:`snarfd`, an alert routing daemon

The following system diagram details the flow of alert messages through these
software components, and how these components interact with external systems.

.. image:: doc/images/snarf_system_diagram.pdf

--------------
 Requirements
--------------

``libsnarf`` requires the following third-party software:

    * glib_ version 2.36 or later
    * zeromq_ version 3.x
    * protobuf-c_ version 1.01 or later

.. _glib: http://www.gtk.org/download/
.. _zeromq: http://www.zeromq.org/
.. _protobuf-c: http://code.google.com/p/protobuf-c/

``snarfd`` has the same requirements as ``libsnarf``, along with: 

    * libyaml_ version 0.1.4 or later

.. _libyaml: http://www.zeromq.org/

``snarf-python`` requires Python >= 2.7, along with the following Python modules
and third-party packages:

    * pyzmq_ version 14.3 or later
    * netsa-python_ version 1.4 or later
    * protobuf_ version 2.5.0 or later

.. _netsa-python: http://tools.netsa.cert.org/netsa-python/
.. _pyzmq: http://zeromq.github.com/pyzmq/
.. _protobuf: http://code.google.com/p/protobuf/

--------------
 Installation
--------------

If you're running RedHat Enterprise Linux 7 or CentOS 7, we recommend
using the cert-forensics-repository_ and installing using ``yum``.

.. _cert-forensics-repository: https://forensics.cert.org/

After configuring this repository, install snarf with, e.g.::

    $ yum install snarf snarf-devel snarf-python

Installation of ``libsnarf`` and ``snarfd`` is accomplished through a standard
``./configure && make && make install`` process.  If a supported Python
installation is detected during installation, ``snarf-python`` will also be
installed.

---------
 License
---------

* GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
* Government Purpose License Rights (GPLR) pursuant to DFARS 252.227-7013

---------
 Support
---------

For help with snarf installation/usage, or to submit a bug report, send email to
netsa-help@cert.org
