GNU GENERAL PUBLIC LICENSE
==========================
.. include:: GPL.txt
   :literal:
