.. _alert_api:

===========
 Alert API
===========

A ``snarf`` alert is structured as follows:

.. .. ditaa::
..   :scale: 0.33

  +----------------------------+                
  |          Envelope      cCCC|
  +----------------------------+
  | generator                  |
  | generator_version          |
  | timestamp                  |
  | severity                   |
  | analysis_tags              |
  |                        cEEE|
  +----------------------------+
  |           Body         cCCC|
  +----------------------------+
  | field1 = [value1, ...]     |
  | field2 = [value1, ...]     |
  | ...                        |
  |                        cEEE|
  +----------------------------+

.. image:: images/snarf_alert.png
   :scale: 33%

The envelope contains all mandatory fields that must be present in every alert.
These fields are used to route the alert to the appropriate destination based on
routing logic defined in the :ref:`snarfd` configuration file.

The fields and values present in the alert body are application-specific, but it
is recommended that the set of fields and values are consistent among alerts
tagged with a particular analysis tag.  The receiver of the alert can then use
these tags to determine which fields to expect in the alert body.

---------------------
 Constructing Alerts
---------------------

To create a snarf alert object, use the snarf_alert_new function:

   .. doxygenfunction:: snarf_alert_new

The severity field should be one of:
    
    .. doxygenenum:: snarf_alert_severity_t
       :outline:

---------------
 Adding Fields
---------------

Fields can be added to the alert with the following functions:

    .. doxygenfunction:: snarf_alert_add_flow_v4

    .. doxygenfunction:: snarf_alert_add_flow_v6

    .. doxygenfunction:: snarf_alert_add_text_field

    .. doxygenfunction:: snarf_alert_add_int_field

    .. doxygenfunction:: snarf_alert_add_double_field

    .. doxygenfunction:: snarf_alert_add_ipset_field

    .. doxygenfunction:: snarf_alert_free

----------------------
 Accessing Alert Data
----------------------

Alert sink code should use the following functions to work with alert objects
once they are received:

    .. doxygenfunction:: snarf_alert_severity

    .. doxygenfunction:: snarf_alert_get_field

    .. doxygenfunction:: snarf_alert_field_value_count

    .. doxygenfunction:: snarf_alert_field_value

--------------------------------------
 Printing / Formatting Alert Messages
--------------------------------------

``snarf`` Output Buffers
========================

``snarf`` output buffers handle some aspects of field delimiting and formatting
for you.

To print alerts, first create an output buffer to hold the printed data:

    .. doxygenfunction:: snarf_output_buffer_new
       :outline:

To customize formatting in an alert buffer, use the following functions:

    .. doxygenfunction:: snarf_output_buffer_set_format
       :outline:

The built-in output formats are:

    .. doxygenenum:: snarf_output_format_t
       :outline:

For the delimited output format, you can set the delimiter with:

    .. doxygenfunction:: snarf_output_buffer_set_delimiter
       :outline:

Alert severity can be printed as either a symbolic name e.g. ``LOW``, or an integer:

    .. doxygenfunction:: snarf_output_buffer_set_severity_format
       :outline:

    .. doxygenenum:: snarf_output_severity_format_t
       :outline:

The format of the alert timestamp can be changed with:

    .. doxygenfunction:: snarf_output_buffer_set_timestamp_format
       :outline:

The available timestamp formats are:

    .. doxygenenum:: snarf_output_severity_format_t
       :outline:

The format of any TCP flags printed in the alert's flow fields can be set with:

    .. doxygenfunction:: snarf_output_buffer_set_tcp_flags_format
       :outline:

The available TCP flag formats are:

    .. doxygenenum:: snarf_output_tcp_flags_format_t
       :outline:

After you're done with the output buffer, free it with:

    .. doxygenfunction:: snarf_output_buffer_free
       :outline:

Field Printing Helpers
======================

Several helper functions are available for printing alert data:

    .. doxygenfunction:: snarf_alert_print_envelope_field

    .. doxygenfunction:: snarf_alert_print_value

    .. doxygenfunction:: snarf_alert_print_string

    .. doxygenfunction:: snarf_alert_print_string_raw

    .. doxygenfunction:: snarf_alert_print_flow_field

    .. doxygenfunction:: snarf_alert_write_ipset
