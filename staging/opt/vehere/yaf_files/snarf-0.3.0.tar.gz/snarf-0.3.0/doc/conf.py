# -*- coding: utf-8 -*-

import sys
from netsa_sphinx_config import *

#source_suffix = ""
#master_doc = 'README'

docpath = os.path.abspath(".")


have_breathe = False
try:
    import breathe
    have_breathe = True
except ImportError:
    pass

if have_breathe:
    breathe_projects = {
        "libsnarf": docpath +"/xml",
        }
    breathe_default_project = "libsnarf"
    extensions.append("breathe")


# extensions.append("ditaa")
# ditaa = "ditaa"
# ditaa_args = ["-s 2", "-E"]


