.. _libsnarf:

============
  libsnarf
============

``libsnarf`` is a library that enables application developers to:

    * build and parse snarf alert messages from C applications

    * send alerts to a ``snarfd`` for routing to alert destinations

    * subscribe to and receive alerts

These three capabilities correspond respectively to the ``snarf``
:ref:`alert_api`, :ref:`source_api`, and :ref:`sink_api`.


.. toctree::

   alert_api

   source_api

   sink_api
   
