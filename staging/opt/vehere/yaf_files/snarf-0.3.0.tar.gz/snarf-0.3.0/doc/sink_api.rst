.. _sink_api:

==========
 Sink API
==========

The ``snarf`` sink API facilitates the development of programs that wish to
subscribe to alerts.

To begin receiving alerts, create a new alert sink with:

   .. doxygenfunction:: snarf_sink_init

If you simply want to output alerts using one of the built-in output formats,
you can do so by configuring the sink with the following function:

   .. doxygenfunction:: snarf_sink_configure

For more custom alert processing, configure the sink with this function:

   .. doxygenfunction:: snarf_sink_configure_full

To subscribe to specific alert channels, call:

   .. doxygenfunction:: snarf_sink_subscribe

   Keep in mind that if you do not subscribe to a specific channel, you will
   receive all alerts broadcast on the sink's destination socket. 

To being processing alerts:

   .. doxygenfunction:: snarf_sink_process

To stop processing of alerts:

   .. doxygenfunction:: snarf_sink_destroy






