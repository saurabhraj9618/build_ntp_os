.. _snarfd:

============
 ``snarfd``
============

``snarfd`` is an alert routing daemon.  Configuring a ``snarfd`` is accomplished
by defining:

    *  a set of *sockets* on which alerts are received and sent
    *  a list of *routes* that map alert attributes to *alert channels*

Routes are organized into *route groups* that all operate on the same set of
sockets.  Simpler installations with just a single receiving and sending socket
will only need a single route group, but more complex architectures may create
multiple route groups, e.g. a group for local alerts, groups for alerts
received from remote sites, etc.

Each route in a route group is defined by a set of input attributes, which map
to an output alert channel.

It may be easier to explain these concepts by looking at an example snarfd
configuration file::

    # SNARF configuration file
    %YAML 1.1
    ---
    # This configuration file allows you to customize how snarfd routes alerts.

    # Begin snarfd configuration
    snarfd:

        # if this is true, snarfd will reload the conf file when it's modified
        reload: true

        sockets:
            # Use the "sockets" section to define a list of sockets snarfd listens
            # on.  The simplest mode of operation would be two sockets, one for
            # inbound messages and one for outbound messages.  The format of each
            # entry in this list is:
            #
            # <name>:
            #     endpoint: <endpoint>
            #     type: [pub|sub|pull]
            #     identity: <identity>
            #     hwm: <hwm>
            #     channel: <channel>
            #
            # where:
            #
            #     <name> is a meaningful symbolic name for the socket, such as "in".
            #     No spaces are allowed.  This symbolic name is used to refer to the
            #     socket in the "routes" section below.
            #
            #     <endpoint> is a socket specifier in protocol://address:port
            #     format, with "protocol" being one of:
            #
            #             * tcp: TCP sockets (reliable unicast)
            #             * epgm: EPGM sockets (reliable multicast)
            #             * ipc: UNIX domain sockets (for processes on the same
            #             * host)
            #
            #     <type> indicates what the socket does.  Valid types are:
            #
            #         * pull - a socket for receiving alerts from alert sources
            #         * pub - a socket for publishing alerts for alert subscribers
            #         * sub - a socket for subscribing to published alerts
            #
            #     <hwm> is an optional "high water mark" setting.  This is an
            #     integer specifying how many messages to keep in memory while
            #     waiting for the receiver to get them.  The default is 1024.
            #
            #     <channel>, which is only valid for "sub" socket types, is the name
            #     of an alert channel to subscribe to on the remote snarfd.  For
            #     more info on alert channels, see the "routes" section.

            inbound:
                # A socket named "inbound" that receives alerts on TCP port 5555
                endpoint: tcp://127.0.0.1:5555
                type: pull

            outbound:
                # a socket named "outbound" that publishes alerts on TCP port 5556
                endpoint: tcp://127.0.0.1:5556
                type: pub
                hwm: 256

            remote:
                # a socket named "remote" that subscribes to another snarfd's
                # "events" channel
                endpoint: tcp://10.10.10.10:5557
                type: sub
                channel: events

        stats:
            # snarfd can output alerts containing statistics on the number of alerts
            # processed.  Change "enabled" to true and stats will be sent to the
            # <socket> channel every <interval> seconds.
            enabled: false
            socket: inbound
            interval: 60

        routes:
            # The "routes" section contains directives which define how alerts are
            # routed to subscribers via the sockets defined above.  For simplicity,
            # routes are organized into "route groups" that operate on the same
            # incoming and outgoing sockets.
            #
            # The structure of each route group is:
            #
            # - from: <in-socket>
            # - to: <out-socket>
            # - rules:
            #     -
            #         - in:
            #             - <attribute>:
            #                 - <value>
            #                 - <value>
            #             - <attribute>:
            #                 - <value>
            #                 - <value>
            #         - out:
            #             - <channel>
            #
            # where:
            #
            #     <in-socket> is the symbolic name of a socket defined in the
            #     "sockets" section above that receives alerts from alert sources.
            #     Only sockets of types "pull" and "sub" are valid as "in" sockets
            #     in route group definitions.
            #
            #     <out-socket> is the symbolic name of a socket defined in the
            #     "sockets" section above that publishes alerts to alert sinks.
            #     Only sockets of type "pub" are valid as "out" sockets in route
            #     group definitions.
            #
            #     Each item in the rules: section of a route group specifies routing
            #     rules that apply to messages received on the "in:" socket.  The
            #     routing is based on a set of attributes and a list of values for
            #     each of those attributes.  At this time, the recognized attributes
            #     are:
            #
            #         * generator - identifies the software that detected and
            #           generated the alert.  By convention, generator strings
            #           should be in the form of the reverse fully-qualified domain
            #           name of the software publisher, followed by the name of the
            #           software -- e.g., if an alert detection program "foobar" is
            #           published by the "hackers" division of Acme Corporation at
            #           <http://www.hackers.acme.com/>, the generator string should
            #           be "com.acme.hackers.foobar"
            #
            #         * tag - identifies one or more textual tags in the alert that
            #           describe the alert contents.  These are nothing more than
            #           free-form textual strings, with no spaces allowed.  Alert
            #           sources can also define a key=value structure within these
            #           tags, e.g. "color=blue", but this is optional.
            #
            #     For each attribute in a routing rule, you may specify one or more
            #     values to match that attribute with.  The syntax of these <value>
            #     definitions allows the wildcard characters ? and * to match any
            #     single character or any number of characters, respectively.
            #
            #     <channel> should be an alphanumeric name for a published alert
            #     channel.  Channels aloow alert subscribers to indicate the type of
            #     alert messages they would like to receive without needing to know
            #     any details about the attributes of the alerts themselves.  In
            #     this manner, snarfd can be used not only to route alerts, but to
            #     organize them into meaningful collections.

            - # route group "inbound" to "outbound"
                - from: inbound
                - to: outbound
                - rules:
                    - # route all alerts generated by the "foobar" software from
                      # Acme Corp. to the "foo" channel
                        - in:
                            - generator:
                                    - com.acme.hackers.foobar
                        - out:
                            - foo
                    - # route all alerts with the "evilhosts" tag to the "evil"
                      # channel
                        - in:
                            - tag:
                                    - evilhosts
                        - out:
                            - evil
                    - # route all alerts generated by Acme Corp. with the "urgent"
                      # or "critical" tags, as well as any tag beginning with "bad",
                      # to the "zomg" channel
                        - in:
                            - generator:
                                    - com.acme.*
                            - tag:
                                    - urgent
                                    - critical
                                    - bad*
                        - out:
                            - zomg

            - # route group "remote" to "outbound"
                - from: remote
                - to: outbound
                - rules:
                    - # route alerts from an upstream snarfd to the "feeds.events"
                      # channel
                        - in:
                            - generator:
                                - org.example.data
                            - tag:
                                - color=blue
                        - out:
                            - feeds.events

    # The "sink" section contains configuration for various alert destinations.
    # Each sub-section within the "sink" section denotes a single sink
    # configuration.  At a minimum, each "sink" sub-section must consist of an
    # identifier for the sink and a type: attribute that specifies the type of the
    # sink.  Currently-supported sink types are "json", "email", and "cef".
    sink:

        # A JSON (JavaScript Object Notation) sink.  JSON allows any snarf alert
        # data to be expressed in textual form using the same field structure that
        # snarf uses internally.
        json:
            type: json
            # JSON sinks support an "output_file" option for specifying the location
            # of the output.  If not specified, it defaults to standard output.
            # outut_file: foo.txt

        # An email sink, which sends alert data to a specified email address.
        email:
            type: email
            from: root          # the email address to send alerts from
            to: root            # the email address to send alerts from
            sms_format: false   # if true, alert format is shortened for SMS

        # A CEF (Common Event Format) sink.  Used for sending alerts to ArcSight.
        cef:
            type: cef

            # Configure syslog output for CEF alerts.
            syslog:
                enabled: true    # if true, send alerts to syslog (stdout otherwise)
                facility: local4 # syslog facility to use local1 .. local7 or user

            # Each entry in the "fields" sub-section maps a CEF output field to
            # a field in the snarf alert.  The format of each field mapping is:
            # - output_field:
            #     - field_type: input_field
            # where field_type is one of:
            #     flow (a flow field in the alert),
            #     field (a non-flow field in the alert)
            #     string (raw text to be included verbatim in the alert output)
            fields:
                - src:
                    - flow: sip
                - dst:
                    - flow: dip
                - spt:
                    - flow: sport
                - dpt:
                    - flow: dport
                - proto:
                    - flow: proto
                - start:
                    - flow: stime
                - end:
                    - flow: etime
                - cn1:
                    - flow: packets
                - cn1Label:
                    - string: Packets count
                - in:
                    - flow: bytes
                - cn2:
                    - flow: elapsed
                - cn2Label:
                    - string: duration of flow in msec
                - cs1:
                    - flow: sensor_name
                - cs1Label:
                    - string: sensor name
                - cs2:
                    - flow: flow_class
                - cs2Label:
                    - string: class of sensor
                - cs3:
                    - flow: flow_type
                - cs3Label:
                    - string: type of sensor
                - cs4:
                    - flow: icmp_type_code
                - cs4Label:
                    - string: ICMP type,code
                - cs5:
                    - flow: flags
                - cs5Label:
                    - string: TCP flags bitwise OR
                - app:
                    - flow: application_id
                - sourceGeoCountryCode:
                    - field: sip.cc
                - destinationGeoCountryCode:
                    - field: dip.cc

    # End snarfd configuration
