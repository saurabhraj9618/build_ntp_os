.. _source_api:

============
 Source API
============

To begin send ``snarf`` alerts, create a new alert source with:

   .. doxygenfunction:: snarf_source_init

By convention, source names should be in the form of the reverse
fully-qualified domain name of the software publisher, followed by the name
of the software -- e.g., if an alert detection program "foobar" is published
by the "hackers" division of Acme Corporation at
http://www.hackers.acme.com/ the generator string should be
"com.acme.hackers.foobar".

The ``dest`` argument is a *socket specifier*.

Once the alert has been constructed using the alert API, it can be sent with:

   .. doxygenfunction:: snarf_source_send_alert

When your application is done sending alerts, you should free the source with:

   .. doxygenfunction:: snarf_source_destroy






