#!/usr/bin/env python
#
# dstat plugin for displaying a count of snarf alerts per second
# ------------------------------------------------------------------------
# Copyright (C) 2012 Carnegie Mellon University. All Rights Reserved.
# ------------------------------------------------------------------------
# Authors: Tony Cebzanov <tonyc@cert.org>
# -----------------------------------------------------------------------------
# GNU Public License (GPL) Rights pursuant to Version 2, June 1991
# Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
# -----------------------------------------------------------------------------


class dstat_plugin(dstat):
    """
    Show snarf alert count per second
    """
    import os
    socket = os.environ.get('SNARF_ALERT_ORIGIN', "tcp://localhost:5556")
    channel = os.environ.get('SNARF_ALERT_CHANNEL', "")

    # Explicitly handle SIGINT and raise KeyboardInterrupt so that
    # it's not handled by another thread
    def sigint_handler(self, signum, frame):
        self.sink.shutdown()
        raise KeyboardInterrupt

    def __init__(self):
        import os
        import signal
        from snarf import Sink
        self.name = 'snarf'
        self.type = 'd'
        self.width = 5
        self.scale = 10
        self.vars = ('aps',)
        self.alert_count = 0
        signal.signal(signal.SIGINT, self.sigint_handler)
        try:
            self.sink = Sink(self.handle_sink, origin=self.socket, channel=self.channel)
        except KeyboardInterrupt:
            self.sink.shutdown()

    def handle_sink(self, alert):
        self.alert_count += 1

    def extract(self):
        for name in self.vars:
            self.val[name] = (self.set2[name] - self.set1[name]) * 1.0 / elapsed

        if step == op.delay:
            self.set1.update(self.set2)
        self.set2['aps'] = int(self.alert_count)
