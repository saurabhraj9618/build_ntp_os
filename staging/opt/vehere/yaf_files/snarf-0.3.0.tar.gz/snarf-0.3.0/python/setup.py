#!/usr/bin/env python
## ------------------------------------------------------------------------
## setup.py
## distutils setup script for ipa-python
## ------------------------------------------------------------------------
## Copyright (C) 2006-2013 Carnegie Mellon University. All Rights Reserved.
## ------------------------------------------------------------------------
## Authors: Tony Cebzanov <tonyc@cert.org>
## ------------------------------------------------------------------------
## GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
## Government Purpose License Rights (GPLR) pursuant to DFARS 252.227-7013
## ------------------------------------------------------------------------

from netsa import dist

dist.set_name("snarf")
dist.set_version("0.3.0")
dist.set_title("snarf")
dist.set_description("""
``snarf`` is a distributed alert reporting system.  Applications can use
``snarf``'s C and Python APIs to construct and send network alert messages,
which can then be routed to multiple destinations in a configurable manner.
                     """)

dist.set_maintainer("NetSA Group <netsa-help@cert.org>")
dist.set_url("http://tools.netsa.cert.org/ipa")
dist.set_license("GPL")

dist.add_package("snarf")

dist.add_version_file("src/snarf/VERSION")
dist.add_extra_files("bin/snarftest")
dist.add_extra_files("bin/snarf2cef.py")
dist.add_extra_files("bin/snarf2iodef.py")
dist.add_extra_files("utils/dstat_snarf.py")
dist.set_doc_dir("..")
dist.set_doc_conf_dir("../doc")

dist.execute()
