# ------------------------------------------------------------------------
# Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
# ------------------------------------------------------------------------
# Authors: Tony Cebzanov <tonyc@cert.org>
# ------------------------------------------------------------------------
# GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
# Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
# ------------------------------------------------------------------------

import zmq
import zmq.utils.jsonapi as jsonapi
import sys
import time
import random

from optparse import OptionParser
from source import Source
from sink import Sink
from alert import Alert, AlertFlow

import alert
import json
import sink

zmqctx = None

def init():
    global zmqctx
    zmqctx = zmq.Context()

init()

def main():

    global options
    global zmqctx
    global config
    zmqctx = zmq.zmqctx()
    parser = OptionParser()
    parser.add_option("-m", "--mode", dest="mode", help="mode")
    parser.add_option("-c", "--config", dest="config_file", help="configuration file")
    (options, args) = parser.parse_args()

    if not args:
        args = ("tcp://127.0.0.1:5555")

    if options.config_file:
        config = load_config(options.config_file)

    if options.mode:
        globals()[options.mode](args)


if __name__ == '__main__':
    main()

__all__ = """
Alert
AlertFlow
Source
Sink
""".split()
