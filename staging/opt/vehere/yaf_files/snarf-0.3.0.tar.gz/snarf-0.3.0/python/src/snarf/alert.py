# ------------------------------------------------------------------------
# Copyright (C) 2011-2014 Carnegie Mellon University. All Rights Reserved.
# ------------------------------------------------------------------------
# Authors: Tony Cebzanov <tonyc@cert.org>
# ------------------------------------------------------------------------
# GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
# Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
# ------------------------------------------------------------------------

"""
snarf.alert
-----------

The :mod:`snarf.alert` module provides classes to represent network alert
messages and various components of such messages, such as network flows.
"""
import datetime
import netsa.json
from netsa.data.times import make_datetime
from netsa.data.times import epoch_usec, make_datetime
import netsa_silk as ns
import base64
from alert_pb2 import SnarfEnvelope, SnarfAlertBody, SnarfField, SnarfValue, \
    Flow, IPAddress, Timestamp, TCPFlags, ElapsedTime, IPSet
import zmq
from json import pb2jd
import snarf



severityfield = SnarfEnvelope.DESCRIPTOR.fields_by_name['severity']

def datetime_from_timestamp(timestamp):
    return datetime.datetime(1970,1,1) + \
        datetime.timedelta(microseconds=timestamp)

def snarf_json_encoder(obj):
    if isinstance(obj, AlertFlow):
        return obj.__dict__
    if isinstance(obj, AlertSeverity):
        return int(obj)
    if isinstance(obj, datetime.datetime):
        return obj.isoformat() + "Z"
    if isinstance(obj, ns.IPv4Addr) or isinstance(obj, ns.IPv6Addr):
        return str(obj)
    if isinstance(obj, ns.TCPFlags):
        return str(obj)
    if isinstance(obj, AlertIPSet):
        return base64.b64encode(obj.data)
    raise TypeError(repr(obj) + " is not JSON serializable")

class AlertBlob(object):
    def __init__(self, data):
        self.data = data

class AlertIPSet(AlertBlob):
    def __init__(self, data):
        super(AlertIPSet, self).__init__(data)

    def to_protobuf(self, ipset):
        ipset.data = self.data


class AlertSeverity(object):
    """
    An object representing the perceived importance of an alert.
    """
    def __init__(self, severity):
        """
        The AlertSeverity object is built based on the structure of the
        AlertSeverity protobuf enum, so that if the enum changes in the
        protocol definition, no changes are necessary here.
        """
        if type(severity) == int:
            self._severity = severityfield.enum_type.values_by_number[severity]
        elif type(severity) == str:
            self._severity = severityfield.enum_type.values_by_name[severity]
        else:
            raise TypeError("invalid type for alert severity")

        self.severity = self._severity.number
        self.name = self._severity.name

    def __int__(self):
        return self.severity
    def __str__(self):
        return self.name
    def __repr__(self):
        return "<snarf.AlertSeverity %d: %s>" %(int(self), str(self))
    def __cmp__(self, other):
        return cmp(self.severity, other.severity)


class AlertFlow(object):
    """
    Representation of a network flow.
    """
    def __init__(self, stime, elapsed, sip, dip, sport, dport, proto,
                 packets, bytes, flags, flags_initial,
                 sensor_name, flow_class, flow_type, application_id):

        if type(stime) == datetime.datetime:
            self.stime = stime
        elif type(stime) == str:
            self.stime = make_datetime(stime)
        elif type(stime) == long:
            self.stime = datetime.datetime(1970,1,1) + \
                         datetime.timedelta(microseconds=stime)
        else:
            raise TypeError("stime must be a datetime, string, or long")

        self.elapsed = elapsed
        self.sip = ns.IPAddr(sip)
        self.dip = ns.IPAddr(dip)
        self.sport = sport
        self.dport = dport
        self.proto = proto
        self.packets = packets
        self.bytes = bytes
        self.flags = ns.TCPFlags(flags)
        self.flags_initial = ns.TCPFlags(flags_initial)
        self.sensor_name = sensor_name
        self.flow_class = flow_class
        self.flow_type = flow_type
        self.application_id = application_id

    def __repr__(self):
        return netsa.json.dumps(self.__dict__, default=snarf_json_encoder)

    @classmethod
    def from_message(cls, msg):
        """
        Build an :class:`AlertFlow` object from a protobuf message.
        """
        def copy_flags(msg):
            flags = ns.TCPFlags(0)
            for flag in TCPFlags.DESCRIPTOR.fields_by_name.keys():
                if getattr(msg, flag):
                    flags = flags | getattr(ns, "TCP_" + flag.upper())
            return flags

        if type(msg) != Flow:
            raise NotImplementedError(
                "Can't construct flow from %s" %(type(protobuf)))

        stime = datetime.datetime(1970,1,1) + \
            datetime.timedelta(microseconds=msg.stime.timestamp)
        elapsed = msg.elapsed.elapsed

        if msg.sip.type == IPAddress.IPV4:
            sip = ns.IPv4Addr(msg.sip.v4)
        elif msg.sip.type == IPAddress.IPV6:
            addr = (msg.sip.v6.hi << 64) + msg.sip.v6.lo
            sip = ns.IPv6Addr(addr)
        else:
            raise TypeError("Invalid IP address type: %d" %(msg.sip.type))

        if msg.dip.type == IPAddress.IPV4:
            dip = ns.IPv4Addr(msg.dip.v4)
        elif msg.dip.type == IPAddress.IPV6:
            addr = (msg.dip.v6.hi << 64) + msg.dip.v6.lo
            dip = ns.IPv6Addr(addr)
        else:
            raise TypeError("Invalid IP address type: %d" %(msg.dip.type))

        sport = msg.sport
        dport = msg.dport
        proto = msg.proto
        packets = msg.packets
        bytes = msg.bytes

        flags = ns.TCPFlags(copy_flags(msg.flags))
        flags_initial = ns.TCPFlags(copy_flags(msg.flags_initial))
        sensor_name = msg.sensor_name
        flow_class = msg.flow_class
        flow_type = msg.flow_type
        application_id = msg.application_id

        flags = copy_flags(msg.flags)
        flags_initial = copy_flags(msg.flags_initial)

        return cls(stime, elapsed, sip, dip, sport, dport, proto,
                   packets, bytes, flags, flags_initial,
                   sensor_name, flow_class, flow_type, application_id)

    def to_protobuf(self, msg):
        """
        Serialize an :class:`AlertFlow` object to a protobuf message.
        """

        msg.stime.timestamp = epoch_usec(self.stime)
        msg.elapsed.elapsed = self.elapsed

        def copy_flags(msgflags, flags):
            for flag in filter(lambda x: x.startswith('TCP_'),
                               ns.__dict__.keys()):
                flagattr = flag.lower()[4:]
                if getattr(flags, flagattr):
                    setattr(msgflags, flagattr, True)
                else:
                    setattr(msgflags, flagattr, False)
            return flags

        if type(self.sip) == ns.IPv4Addr:
            msg.sip.type = IPAddress.IPV4
            msg.sip.v4 = int(self.sip)
        elif type(self.sip) == ns.IPv6Addr:
            msg.sip.type = IPAddress.IPV6
            msg.sip.v6.hi = int(self.sip) & 0xFFFFFFFF00000000 >> 64
            msg.sip.v6.lo = int(self.sip) & 0x00000000FFFFFFFF
        else:
            raise TypeError("Invalid IP address type: %s" %(type(self.sip)))

        if type(self.dip) == ns.IPv4Addr:
            msg.dip.type = IPAddress.IPV4
            msg.dip.v4 = int(self.dip)
        elif type(self.dip) == ns.IPv6Addr:
            msg.dip.type = IPAddress.IPV6
            msg.dip.v6.hi = int(self.dip) & 0xFFFFFFFF00000000 >> 64
            msg.dip.v6.lo = int(self.dip) & 0x00000000FFFFFFFF
        else:
            raise TypeError("Invalid IP address type: %s" %(type(self.dip)))

        msg.sport = self.sport
        msg.dport = self.dport
        msg.proto = self.proto
        msg.packets = self.packets
        msg.bytes = self.bytes
        copy_flags(msg.flags, self.flags)
        copy_flags(msg.flags_initial, self.flags_initial)
        msg.sensor_name = self.sensor_name
        msg.flow_class = self.flow_class
        msg.flow_type = self.flow_type
        msg.application_id = self.application_id
        return msg

    def __repr__(self):
        return netsa.json.dumps(self.__dict__, default=snarf_json_encoder)


class Alert(object):
    """
    A class representing network alerts.  Each alert has a fixed set of
    required "envelope" fields and set of variable "alert body" fields.
    """

    def __init__(self, fields, generator=None, generator_version=None,
                 severity=SnarfEnvelope.VERYLOW,
                 timestamp=None,
                 analysis_tags=None):

        self.generator = generator
        self.generator_version = generator_version
        self.severity=severity
        self.timestamp = timestamp
        if analysis_tags:
            self.analysis_tags = analysis_tags
        else:
            self.analysis_tags = []

        if timestamp:
            self.timestamp = timestamp
        else:
            self.timestamp = datetime.datetime.now()

        if type(fields) == dict:
            self.fields = fields


    @classmethod
    def from_message(cls, envelopemsg, bodymsg):
        """
        Build an :class:`Alert` object from a protobuf message.
        """
        envelope = SnarfEnvelope()
        body = SnarfAlertBody()
        envelope.ParseFromString(envelopemsg)
        body.ParseFromString(bodymsg)
        fields = {}
        def fix_value(value):
            if type(value) == SnarfValue:
                typefield = SnarfValue.DESCRIPTOR.fields_by_name['type']
                typename = str(typefield.enum_type.values_by_number[value.type].name.lower())
                if value.type in [ SnarfValue.FLOW,
                                   SnarfValue.IPADDRESS,
                                   SnarfValue.IPSET]:
                    val = getattr(value, typename)
                    fix_value(val)
                else:
                    val = getattr(value, typename)
                    if type(val) == unicode:
                        val = str(val)
                    field_values.append(val)
            elif type(value) == Flow:
                flow = AlertFlow.from_message(value)
                field_values.append(flow)
            elif type(value) == IPSet:
                field_values.append(AlertIPSet(value.data))
            elif type(value) == IPAddress:
                if value.type == IPAddress.IPV4:
                    field_values.append(ns.IPv4Addr(value.v4))
                elif value.type == IPAddress.IPV6:
                    field_values.append(ns.IPv6Addr(value))
                else:
                    raise NotImplementedError("Unknown IP address type")

        for field in body.fields:
            field_values = []
            for value in field.value:
                fix_value(value)
            fields[field.name] = field_values

        generator = envelope.generator
        generator_version = envelope.generator_version
        severity = AlertSeverity(envelope.severity)
        timestamp = datetime_from_timestamp(envelope.timestamp.timestamp)
        analysis_tags = [ str(x) for x in envelope.analysis_tags ]
        return cls(fields, generator=generator,
                   generator_version=generator_version,
                   severity=severity,
                   timestamp=timestamp,
                   analysis_tags=analysis_tags)

    def to_message(self):
        """
        Serialize an :class:`Alert` object to a protobuf message.
        """
        envelope = SnarfEnvelope()
        body = SnarfAlertBody()
        self.to_protobuf(envelope, body)
        envelopemsg = envelope.SerializeToString()
        bodymsg = body.SerializeToString()
        return [envelopemsg, bodymsg]

    def to_protobuf(self, envelope, body):
        """
        Build a protobuf object from the alert.
        """
        envelope.generator = self.generator
        envelope.generator_version = self.generator_version
        envelope.severity = int(self.severity)
        envelope.timestamp.timestamp = epoch_usec(self.timestamp)
        for tag in self.analysis_tags:
            envelope.analysis_tags.append(tag)

        def build_value(msgvalue, value):
            if type(value) == str:
                msgvalue.type = SnarfValue.STRING
                msgvalue.string = value
            elif type(value) == int or type(value) == long:
                msgvalue.type = SnarfValue.INTEGER
                msgvalue.integer = value
            elif type(value) == float:
                msgvalue.type = SnarfValue.DOUBLE
                msgvalue.double = value
            elif type(value) == bool:
                msgvalue.boolean = SnarfValue.BOOLEAN
                msgvalue.integer = value
            elif type(value) == type(AlertBlob):
                # FIXME: bytes
                msgvalue.boolean = SnarfValue.BYTES
                msgvalue.bytes = value
            elif type(value) == AlertFlow:
                # FIXME: Flow
                msgvalue.type = SnarfValue.FLOW
                value.to_protobuf(msgvalue.flow)
            elif isinstance(value, ns.IPv4Addr):
                msgvalue.type = SnarfValue.IPADDRESS
                msgvalue.ipaddress.type = IPAddress.IPV4
                msgvalue.ipaddress.v4 = int(value)
            elif type(value) == AlertIPSet:
                msgvalue.type = SnarfValue.IPSET
                value.to_protobuf(msgvalue.ipset)
            else:
                raise TypeError("Unexpected type: %s" %(type(value)))

        def build_field(msgfield, fieldname):
            msgfield.name = fieldname
            if type(self.fields[fieldname]) == list:
                for value in self.fields[fieldname]:
                    build_value(msgfield.value.add(), value)
            else:
                build_value(msgfield.value.add(), self.fields[fieldname])

        for fieldname in self.fields.keys():
            build_field(body.fields.add(), fieldname)

    def get_generator(self):
        """
        Returns an identifier representing thed entity that generated
        the alert (e.g., "org.cert.netsa.pipeline".)
        """
        return self.generator

    def get_generator_version(self):
        """
        Returns a string representation of the version of the
        generator.
        """
        return self.generator_version

    def get_timestamp(self):
        """
        Returns a :class:`datetime.datetime` object representing the
        time at which the alert was generated.
        """
        return self.timestamp

    def get_severity(self):
        """
        Returns a :class:`PipelineSeverity` object representing the
        severity of this alert.
        """
        return self.severity

    def get_tags(self):
        """
        Returns a list of strings corresponding to tags associated
        with an alert. Different generators may impose additional
        semantics on tags; it is up to the user to apply those
        semantics appropriately.
        """
        return self.analysis_tags

    def get_fields(self):
        """
        Returns a dict of the alert fields.
        """
        return dict(self.fields)

    def get_fields_json(self):
        """
        Returns a dict of the alert fields in JSON format
        """
        return netsa.json.dumps(dict(self.fields), default=snarf_json_encoder)

    def add_tags(self, tags):
        """
        Tag an alert with one or more tags.
        """
        self.analysis_tags += tags

    def as_json(self):
        """
        Returns a string representation of the alert in JSON format.
        """

        envelope = {
            'generator': self.generator,
            'generator_version': self.generator_version,
            'severity': self.severity,
            'timestamp': self.timestamp,
            'analysis_tags': self.analysis_tags,
            }

        return netsa.json.dumps({'envelope': envelope, 'body': self.fields},
                                default=snarf_json_encoder)

    def as_json_raw(self):
        envelope = SnarfEnvelope()
        body = SnarfAlertBody()
        self.to_protobuf(envelope, body)
        return netsa.json.dumps({'envelope': pb2jd(envelope), 'body': pb2jd(body)})

class AlertSocket(zmq.Socket):
    """
    A specialized ZeroMQ socket that emits Snarf ``Alert`` objects.
    """

    def recv_multipart(self, flags=0, copy=False):
        messages = zmq.Socket.recv_multipart(self, flags=flags, copy=copy)
        envelopemsg = messages[0:-1][-1]
        bodymsg = messages[-1]
        alert = Alert.from_message(envelopemsg, bodymsg)
        return alert
__all__ = """
Alert
AlertFlow
AlertSeverity
""".split()
