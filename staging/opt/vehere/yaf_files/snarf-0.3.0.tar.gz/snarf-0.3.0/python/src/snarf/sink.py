# ------------------------------------------------------------------------
# Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
# ------------------------------------------------------------------------
# Authors: Tony Cebzanov <tonyc@cert.org>
# ------------------------------------------------------------------------
# GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
# Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
# ------------------------------------------------------------------------
"""
snarf.sink
-----------

The :mod:`snarf.sink` module provides an interface for applications to receive
network alerts.

Using a snarf sink is simply a matter of defining a callback function that takes
a :class:`snarf.alert.Alert` object as its only argument, and processes that
alert as needed.  Then, create a :class:`Sink` object, and pass the callback
into the :class:`Sink`'s constructor:

.. sourcecode:: python

    from snarf import *

    def process_alert(alert):
        print "[%s %s] %d %s" %(alert.get_generator(),
                            alert.get_generator_version(),
                            alert.get_severity(),
                            alert.get_timestamp())
    sink = Sink(process_alert,
                origin="tcp://localhost:5556",
                channel=channel)
    # process_alert now being called for each alert in the background

    # use the .stop() method when you're done
    sink.stop()

"""

import snarf
from snarf.alert import *

import zmq
import zmq.eventloop.ioloop as ioloop
import zmq.eventloop.zmqstream as zmqstream
import os
from snarf.utils import StoppableThread


class SinkThread(StoppableThread):

    def __init__(self, *args, **kwargs):
        super(SinkThread, self).__init__(*args, **kwargs)
        self.loop = self.get_loop()
        stopper = ioloop.PeriodicCallback(self.check_stop, 1000, self.loop)
        stopper.start()

    @classmethod
    def get_loop(cls):
        if not hasattr(cls, "_loop"):
            cls._loop = ioloop.IOLoop.instance()
        return cls._loop

    def check_stop(self):
        if self.is_stopped():
            self.get_loop().stop()

    def run(self):
        try:
            self.get_loop().start()
        except Exception, e:
            pass

class Sink(object):
    """
    A class representing a consumer of network alerts.  The given callback
    function will be called for each alert received on the given channel.
    """
    def __init__(self, callback, origin=None, channel=None):
        """
        Create a new snarf sink that will connect to the given origin,
        subscribe to the given channel, and process received alerts using the
        :func:callback function.
        """
        if origin:
            self.origin = origin
        else:
            if os.environ.has_key('SNARF_ALERT_ORIGIN'):
                self.origin = os.environ['SNARF_ALERT_ORIGIN']
            else:
                raise RuntimeError("SNARF_ALERT_ORIGIN not set")

        if channel:
            self.channel = channel
        else:
            self.channel = "" # subscribe to all

        self.sock = snarf.alert.AlertSocket(snarf.zmqctx, zmq.SUB)
        self.sock.setsockopt(zmq.SUBSCRIBE, self.channel)
        self.sock.setsockopt(zmq.LINGER, 0)
        self.sock.connect(self.origin)
        self.stream = zmqstream.ZMQStream(self.sock, self.get_thread().get_loop())
        self.stream.on_recv(callback)
        if not self.get_thread().is_alive():
            self.get_thread().start()

    @classmethod
    def get_thread(cls):
        if hasattr(cls, "_thread") and not cls._thread.is_alive():
            del cls._thread

        if not hasattr(cls, "_thread"):
            cls._thread = SinkThread()

        return cls._thread

    @classmethod
    def shutdown(cls):
        cls.get_thread().stop()
        #delattr(cls, "_thread")

    def stop(self):
        """
        Terminate a :ref:`Sink`'s background processing.
        """
        self.stream.stop_on_recv()
        self.stream.flush()
        self.stream.close()
        self.sock.close()

__all__ = """
Sink
""".split()
