# ------------------------------------------------------------------------
# Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
# ------------------------------------------------------------------------
# Authors: Tony Cebzanov <tonyc@cert.org>
# ------------------------------------------------------------------------
# GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
# Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
# ------------------------------------------------------------------------
"""
snarf.source
------------

The :mod:`snarf.source` module provides an interface for applications to send
alerts to snarf alert destinations.

In the following example, an alert object is created for each line of input
coming from the SiLK rwcut(1) tool:

.. sourcecode:: python

    from snarf import *
    import fileinput

    # create the source
    source = Source("org.cert.netsa.test", "0.0.1",
        destination="tcp://localhost:5555",
        default_tags=["type=Evaluation"])

    # generate input with:
    # rwcut --no-titles --no-columns \\
    #     --fields=sTime,duration,sIP,dIP,sPort, \\
    #     dPort, protocol,packets,bytes,flags,initialFlags,sensor, \\
    #     class,type,application
    for line in fileinput.input():

        (stime, elapsed, sip, dip, sport, dport, proto,
        packets, bytes, flags, flags_initial,
        sensor_name, flow_class, flow_type,
        application_id, dummy) = line.split('|')
        elapsed = int(float(elapsed) * 1000)
        sport = int(sport)
        dport = int(dport)
        proto = int(proto)
        packets = int(packets)
        bytes = int(bytes)
        application_id = int(application_id)
        f = AlertFlow(stime, elapsed, sip, dip, sport, dport, proto,
             packets, bytes, flags, flags_initial,
             sensor_name, flow_class, flow_type, application_id)
        a = Alert({'flow': f})
        source.send(a, tags=["foo=bar", "baz"])

"""

import snarf
from snarf.alert import *
import zmq
from time import sleep
import os

class Source(object):
    """
    A class representing a producer of network alerts.

    "name" and "version" should be the name and version of the program sending
    the alerts. "destination" is a socket specifier of the remote socket to send
    alerts to.  If desired, a list of tags can be added to all alerts sent by
    this source by supplying the default_tags argument.
    """
    def __init__(self, name, version, destination=None, default_tags=[]):
        """
        Create a new snarf source.
        """
        self.name = name
        self.version = version
        self.default_tags = default_tags
        if destination:
            self.destination = destination
        else:
            if os.environ.has_key('SNARF_ALERT_DESTINATION'):
                self.destination = os.environ['SNARF_ALERT_DESTINATION']
            else:
                raise RuntimeError("SNARF_ALERT_DESTINATION not set")

        self.sock = snarf.alert.AlertSocket(snarf.zmqctx, zmq.PUSH)
        self.sock.setsockopt(zmq.LINGER, 0)
        self.sock.connect(self.destination)

    def send(self, alert, tags=None):
        """
        Send an alert to the source's configured destination.
        """
        alert.generator = self.name
        alert.generator_version = self.version
        alert.generator_version = self.version
        alert.add_tags(self.default_tags)
        if tags:
            alert.add_tags(tags)

        (envelope, body) = alert.to_message()
        self.sock.send_multipart([envelope, body], copy=False)

    def stop(self):
        self.sock.close()
