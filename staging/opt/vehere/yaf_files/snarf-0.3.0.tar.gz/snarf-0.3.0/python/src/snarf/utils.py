import threading
import signal

class StoppableThread(threading.Thread):

    def __init__(self, *args, **kwargs):
        super(StoppableThread, self).__init__(*args, **kwargs)
        self._stop_event = threading.Event()

    def on_stop(self):
        pass

    def stop(self):
        self.on_stop()
        self._stop_event.set()

    def is_stopped(self):
        return self._stop_event.isSet()

class LoopThread(StoppableThread):

    def __init__(self, interval=1, *args, **kwargs):
        super(LoopThread, self).__init__(*args, **kwargs)
        self.interval = interval

    def run(self):
        while not self.is_stopped():
            self.loop()
            self._stop_event.wait(self.interval)

    def loop(self):
        """
        Override this with the callable to be looped
        """
        pass

