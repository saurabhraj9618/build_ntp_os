/*
 * alert.c
 * Structured Network Alert Reporting Library Implementation (alert)
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2014 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#include "alert_priv.h"
#define G_LOG_DOMAIN SNARF_ALERT_LOG_DOMAIN

#include <snarf/snarf.h>
#include <glib.h>
#include <glib/gstdio.h>


Timestamp *
snarf_alert_set_timestamp_field(
    uint64_t timestamp);

snarf_alert_t *
snarf_alert_new(
    snarf_alert_severity_t severity,
    uint64_t               timestamp)
{
    snarf_alert_t *alert        = g_new0(snarf_alert_t, 1);
    int            new_severity = (int) severity;

    alert->envelope = g_new0(SnarfEnvelope, 1);
    snarf_envelope__init(alert->envelope);
    alert->envelope->timestamp = snarf_alert_set_timestamp_field(timestamp);
    alert->envelope->severity  =
        (SnarfEnvelope__AlertSeverity) MAX(MIN(new_severity,
                                               ALERT_VERYHIGH),
                                           ALERT_VERYLOW);
    g_debug("new alert, timestamp: %" PRIu64 ",severity: %d",
            alert->envelope->timestamp->timestamp, alert->envelope->severity);

    alert->body = g_new0(SnarfAlertBody, 1);
    snarf_alert_body__init(alert->body);
    return alert;
} /* snarf_alert_new */

void
snarf_alert_free(snarf_alert_t *alert)
{
    int         i, j;
    SnarfField *field;

    if (!alert)
    {
        return;
    }

    for (i = 0; i < alert->body->n_fields; i++)
    {
        field = alert->body->fields[i];
        for (j = 0; j < field->n_value; j++)
        {
            switch (field->value[j]->type)
            {
                case SNARF_VALUE__TYPE__STRING:
                    g_free(field->value[j]->string);
                    break;
                case SNARF_VALUE__TYPE__FLOW:
                    g_free(field->value[j]->flow->stime);
                    g_free(field->value[j]->flow->elapsed);
                    g_free(field->value[j]->flow->sensor_name);
                    g_free(field->value[j]->flow->flow_class);
                    g_free(field->value[j]->flow->flow_type);
                    g_free(field->value[j]->flow->flags);
                    g_free(field->value[j]->flow->flags_initial);
                    if (field->value[j]->flow->sip->type ==
                        IPADDRESS__TYPE__IPV6)
                    {
                        g_free(field->value[j]->flow->sip->v6);
                    }
                    g_free(field->value[j]->flow->sip);
                    if (field->value[j]->flow->dip->type ==
                        IPADDRESS__TYPE__IPV6)
                    {
                        g_free(field->value[j]->flow->dip->v6);
                    }
                    g_free(field->value[j]->flow->dip);
                    g_free(field->value[j]->flow);
                    break;
                case SNARF_VALUE__TYPE__IPADDRESS:
                    if (field->value[j]->ipaddress->type ==
                        IPADDRESS__TYPE__IPV6)
                    {
                        g_free(field->value[j]->ipaddress->v6);
                    }
                    g_free(field->value[j]->ipaddress);
                  break;
                case SNARF_VALUE__TYPE__IPSET:
                    g_free(field->value[j]->ipset->data.data);
                    g_free(field->value[j]->ipset);
                    break;
                default:
                    break;
            } /* switch */
            g_free(field->value[j]);
        }

        g_free(field->value);
        g_free(field->name);
        g_free(field);
    }

    g_free(alert->body->fields);

    if (alert->envelope->generator)
    {
        g_free(alert->envelope->generator);
    }
    if (alert->envelope->generator_version)
    {
        g_free(alert->envelope->generator_version);
    }
    if (alert->envelope->timestamp)
    {
        g_free(alert->envelope->timestamp);
    }
    if (alert->envelope->n_analysis_tags)
    {
        int i;
        for (i = 0; i < alert->envelope->n_analysis_tags; i++)
        {
            g_free(alert->envelope->analysis_tags[i]);
        }

        g_free(alert->envelope->analysis_tags);
    }

    if (alert->envelope)
    {
        g_free(alert->envelope);
    }
    if (alert->body)
    {
        g_free(alert->body);
    }
    g_free(alert);

} /* snarf_alert_free */

void
snarf_alert_set_generator(snarf_alert_t *alert, char *name, char *version)
{
    alert->envelope->generator         = g_strdup(name);
    alert->envelope->generator_version = g_strdup(version);
} /* snarf_alert_set_generator */


void
snarf_alert_add_tags(snarf_alert_t *alert, char *tags)
{
    gchar **taglist  = NULL;
    char  **p        = NULL;
    int     tagcount = 0;
    char   *tag      = NULL;

    taglist = g_strsplit_set(tags, ", \t\n\v\f\r", 0);
    for (p = taglist, tagcount = 0; p && *p; p++)
    {
        tag = *p;
        if (!strlen(tag))
        {
            continue;
        }
        tagcount++;
        g_debug("tag: %s", tag);
        if (tagcount == 1)
        {
            g_debug("allocate: %d", tagcount);
            alert->envelope->analysis_tags = g_malloc(sizeof(char *));
        }
        else
        {
            g_debug("reallocate: %d", tagcount);
            alert->envelope->analysis_tags = g_realloc(
                alert->envelope->analysis_tags,
                (tagcount) * sizeof(char *));
        }
        alert->envelope->analysis_tags[tagcount-1] = g_strdup(tag);
        alert->envelope->n_analysis_tags           = tagcount;
    }

    /*    alert->envelope->analysis_tags = g_strdup(tags); */
    g_strfreev(taglist);

} /* snarf_alert_add_tags */


#define SNARF_ALERT_FIELD_VALUE_BY_INDEX(_field, _index) \
    (_field->value[_index])

int
snarf_alert_field_value_count(snarf_field_t *field)
{
    return field->n_value;
} /* snarf_alert_field_value_count */

int
snarf_alert_severity(
    snarf_alert_t *alert)
{
    return (int) alert->envelope->severity;
}

char *
snarf_alert_get_analysis_tag(
    snarf_alert_t *alert,
    const char    *prefix)

{
    int      i;
    char    *ret    = NULL;
    GString *keystr = g_string_new(prefix);

    g_string_append(keystr, ":");

    g_debug("snarf_alert_get_analysis_tag: %s", keystr->str);
    for (i = 0; i < alert->envelope->n_analysis_tags; i++)
    {
        if (g_str_has_prefix(alert->envelope->analysis_tags[i],
                             keystr->str))
        {
            g_debug("snarf_alert_get_analysis_tag: %s, %s", keystr->str,
                    alert->envelope->analysis_tags[i]);
            ret = alert->envelope->analysis_tags[i] + keystr->len;
            break;
        }
    }

    g_string_free(keystr, TRUE);
    return ret;
} /* snarf_alert_get_analysis_tag */


snarf_field_t *
snarf_alert_get_field(
    snarf_alert_t *alert,
    const char    *key)
{
    int         i;
    SnarfField *field = NULL;

    for (i = 0; i < alert->body->n_fields; i++)
    {
        field = alert->body->fields[i];
        char *fname = field->name;
        g_debug("get field: %s", fname);
        if (!strcmp(fname, key))
        {
            g_debug("returning field: %s", field->name);
            return field;
        }

    }

    return NULL;
} /* snarf_alert_get_field */


snarf_value_t *
snarf_alert_field_value(snarf_alert_t *alert, char *fieldname, int index)
{
    snarf_field_t *field = NULL;
    snarf_value_t *value = NULL;

    field = snarf_alert_get_field(alert, fieldname);
    if (!field)
    {
        return NULL;
    }
    value = SNARF_ALERT_FIELD_VALUE_BY_INDEX(field, index);
    if (!value)
    {
        return NULL;
    }
    return value;
} /* snarf_alert_field_value */


SnarfField *
snarf_alert_add_field(snarf_alert_t *alert, const char *name)
{
    SnarfField *field = NULL;
    int         count = alert->body->n_fields;

    if (count == 0)
    {
        g_debug("allocate: %d", count);
        alert->body->fields = g_malloc(sizeof(SnarfField *));
    }
    else
    {
        g_debug("reallocate: %d", count);
        alert->body->fields = g_realloc(alert->body->fields,
                                        (count+1) * sizeof(SnarfField *));
    }
    alert->body->fields[count] = g_malloc(sizeof(SnarfField));
    field                      = alert->body->fields[count];
    snarf_field__init(field);
    field->name = g_strdup(name);
    /*    g_debug("field: %s", alert->body->fields[count]->name); */
    alert->body->n_fields++;
    return field;
} /* snarf_alert_add_field */

void
snarf_alert_add_value(SnarfField *field, SnarfValue *value)
{
    int count = field->n_value;

    if (count == 0)
    {
        g_debug("value allocate: %d", count);
        field->value = g_malloc(sizeof(SnarfValue *));
    }
    else
    {
        g_debug("value reallocate: %d", count);
        field->value =
            g_realloc(field->value, (count+1) * sizeof(SnarfValue *));
    }

    field->value[count] = value;
    g_debug("add value type: %d", value->type);
    field->n_value++;
    /*
     * alert->body->fields[count] = field;
     * g_debug("count: %d, sizeof: %d", count, sizeof(SnarfField));
     */

} /* snarf_alert_add_value */

void
snarf_alert_add_text_field(snarf_alert_t *alert,
                           const char    *name,
                           const char    *value)
{
    SnarfField *field = NULL;
    SnarfValue *val   = NULL;

    val = g_new0(SnarfValue, 1);
    snarf_value__init(val);
    val->type   = SNARF_VALUE__TYPE__STRING;
    val->string = g_strdup(value);

    if (!(field = snarf_alert_get_field(alert, name)))
    {
        field = snarf_alert_add_field(alert, name);
    }
    snarf_alert_add_value(field, val);
} /* snarf_alert_add_text_field */

void
snarf_alert_add_int_field(snarf_alert_t *alert,
                          const char    *name,
                          int64_t        value)
{
    SnarfField *field = NULL;
    SnarfValue *val   = NULL;

    val = g_new0(SnarfValue, 1);
    snarf_value__init(val);
    val->type        = SNARF_VALUE__TYPE__INTEGER;
    val->has_integer = 1;
    val->integer     = value;

    if (!(field = snarf_alert_get_field(alert, name)))
    {
        field = snarf_alert_add_field(alert, name);
    }
    g_debug("add int field");
    snarf_alert_add_value(field, val);
} /* snarf_alert_add_int_field */

void
snarf_alert_add_double_field(snarf_alert_t *alert,
                             const char    *name,
                             double         value)
{
    SnarfField *field = NULL;
    SnarfValue *val   = NULL;

    val = g_new0(SnarfValue, 1);
    snarf_value__init(val);
    val->type        = SNARF_VALUE__TYPE__DOUBLE;
    val->has_double_ = 1;
    val->double_     = value;

    if (!(field = snarf_alert_get_field(alert, name)))
    {
        field = snarf_alert_add_field(alert, name);
    }
    g_debug("add double field");
    snarf_alert_add_value(field, val);
} /* snarf_alert_add_double_field */

void
snarf_alert_add_ip_field_v4(snarf_alert_t *alert,
                            const char    *name,
                            uint32_t       value)
{
    SnarfField *field = NULL;
    SnarfValue *val   = NULL;
    IPAddress  *ip    = NULL;

    ip = g_new0(IPAddress, 1);
    ipaddress__init(ip);
    ip->type   = IPADDRESS__TYPE__IPV4;
    ip->has_v4 = 1;
    ip->v4     = value;

    val = g_new0(SnarfValue, 1);
    snarf_value__init(val);
    val->type      = SNARF_VALUE__TYPE__IPADDRESS;
    val->ipaddress = ip;

    if (!(field = snarf_alert_get_field(alert, name)))
    {
        field = snarf_alert_add_field(alert, name);
    }
    g_debug("add ip field");
    snarf_alert_add_value(field, val);

} /* snarf_alert_add_ip_field_v4 */

void
snarf_alert_add_ip_field_v6(snarf_alert_t *alert,
                            const char    *name,
                            uint8_t        value[16])
{
    SnarfField             *field = NULL;
    SnarfValue             *val   = NULL;
    IPAddress              *ip    = NULL;
    guint64                 hi, lo;
    guint64                *p64;
    IPAddress__IPV6Address *v6addr = NULL;

    ip = g_new0(IPAddress, 1);
    ipaddress__init(ip);
    ip->type   = IPADDRESS__TYPE__IPV6;
    ip->has_v4 = 0;

    v6addr = g_new0(IPAddress__IPV6Address, 1);
    ipaddress__ipv6_address__init(v6addr);

    p64 = (guint64 *)value;
    hi  = *p64;
    p64++;
    lo = *p64;

    v6addr->hi = GUINT64_FROM_BE(hi);
    v6addr->lo = GUINT64_FROM_BE(lo);

    ip->v6 = v6addr;

    val = g_new0(SnarfValue, 1);
    snarf_value__init(val);
    val->type      = SNARF_VALUE__TYPE__IPADDRESS;
    val->ipaddress = ip;

    if (!(field = snarf_alert_get_field(alert, name)))
    {
        field = snarf_alert_add_field(alert, name);
    }
    g_debug("add ip field");
    snarf_alert_add_value(field, val);
} /* snarf_alert_add_ip_field_v6 */

IPSet *
snarf_alert_set_ipset_field(uint8_t *data, size_t len)
{
    IPSet *field = g_new0(IPSet, 1);

    ipset__init(field);
    field->data.data = g_memdup(data, len);
    field->data.len  = len;

    return field;
} /* snarf_alert_set_ipset_field */

void
snarf_alert_add_ipset_field(snarf_alert_t *alert,
                            const char    *name,
                            uint8_t       *data,
                            size_t         len)
{
    SnarfField *field = NULL;
    SnarfValue *val   = NULL;

    g_debug("ipset field");

    val = g_new0(SnarfValue, 1);
    snarf_value__init(val);
    val->type  = SNARF_VALUE__TYPE__IPSET;
    val->ipset = snarf_alert_set_ipset_field(data, len);

    if (!(field = snarf_alert_get_field(alert, name)))
    {
        field = snarf_alert_add_field(alert, name);
    }
    snarf_alert_add_value(field, val);
} /* snarf_alert_add_ipset_field */

Timestamp *
snarf_alert_set_timestamp_field(uint64_t timestamp)
{
    Timestamp *field = g_new0(Timestamp, 1);

    timestamp__init(field);
    field->timestamp = timestamp;
    return field;
}

ElapsedTime *
snarf_alert_set_elapsed_time_field(uint32_t elapsed)
{
    ElapsedTime *field = g_new0(ElapsedTime, 1);

    elapsed_time__init(field);
    field->elapsed = elapsed;
    return field;
}


TCPFlags *
snarf_alert_set_tcp_flags_field(uint8_t flags)
{
    TCPFlags *field = g_new0(TCPFlags, 1);

    tcpflags__init(field);

    if (flags & FIN_FLAG)
    {
        field->fin = TRUE;
    }
    if (flags & SYN_FLAG)
    {
        field->syn = TRUE;
    }
    if (flags & RST_FLAG)
    {
        field->rst = TRUE;
    }
    if (flags & PSH_FLAG)
    {
        field->psh = TRUE;
    }
    if (flags & ACK_FLAG)
    {
        field->ack = TRUE;
    }
    if (flags & URG_FLAG)
    {
        field->urg = TRUE;
    }
    if (flags & ECE_FLAG)
    {
        field->ece = TRUE;
    }
    if (flags & CWR_FLAG)
    {
        field->cwr = TRUE;
    }

    return field;
} /* snarf_alert_set_tcp_flags_field */

void
snarf_alert_add_flow_v4(snarf_alert_t *alert,
                        uint64_t stime, uint32_t elapsed,
                        uint32_t sip, uint32_t dip,
                        uint16_t sport, uint16_t dport,
                        uint8_t proto,
                        uint32_t packets, uint32_t bytes,
                        uint8_t flags, uint8_t flags_initial,
                        uint16_t application_id,
                        char *sensor_name,
                        char *flow_class, char *flow_type)
{

    /* TODO: handle multiple flows in a single alert */
    Flow       *alert_flow;
    IPAddress  *alert_flow_sip, *alert_flow_dip;
    SnarfValue *value;
    SnarfField *field;

    alert_flow = g_new0(Flow, 1);
    flow__init(alert_flow);

    g_debug("stime: %" PRIu64, stime);

    alert_flow->stime   = snarf_alert_set_timestamp_field(stime);
    alert_flow->elapsed = snarf_alert_set_elapsed_time_field(elapsed);

    alert_flow_sip = g_new0(IPAddress, 1);
    ipaddress__init(alert_flow_sip);
    alert_flow_sip->type   = IPADDRESS__TYPE__IPV4;
    alert_flow_sip->has_v4 = 1;
    alert_flow_sip->v4     = sip;

    alert_flow_dip = g_new0(IPAddress, 1);
    ipaddress__init(alert_flow_dip);
    alert_flow_dip->type   = IPADDRESS__TYPE__IPV4;
    alert_flow_dip->has_v4 = 1;
    alert_flow_dip->v4     = dip;

    alert_flow->sip = alert_flow_sip;
    alert_flow->dip = alert_flow_dip;

    alert_flow->proto = proto;

    alert_flow->packets = packets;
    alert_flow->bytes   = bytes;

    switch (proto)
    {
        case 1:
            alert_flow->icmp_type = (0xFF & (dport >> 8));
            alert_flow->icmp_code = (0xFF & dport >> 8);
            break;
        case 6:
            alert_flow->flags =
                snarf_alert_set_tcp_flags_field(flags);
            alert_flow->flags_initial = snarf_alert_set_tcp_flags_field(
                flags_initial);
        /* FALL-THROUGH */
        case 17:
            alert_flow->sport = sport;
            alert_flow->dport = dport;
            break;
        default:
            break;
    } /* switch */

    alert_flow->application_id = application_id;

    alert_flow->sensor_name = g_strdup(sensor_name);
    alert_flow->flow_class  = g_strdup(flow_class);
    alert_flow->flow_type   = g_strdup(flow_type);

    value = g_new0(SnarfValue, 1);
    snarf_value__init(value);
    value->type = SNARF_VALUE__TYPE__FLOW;
    value->flow = alert_flow;

    g_debug("sip type: %d", value->flow->sip->type);
    g_debug("sip type: %d", value->flow->dip->type);

    field = snarf_alert_add_field(alert, "flow");
    snarf_alert_add_value(field, value);

    /* alert->body->flow = alert_flow; */
} /* snarf_alert_add_flow_v4 */

void
snarf_alert_add_flow_v6(
    snarf_alert_t *alert,
    uint64_t stime, uint32_t elapsed,
    uint8_t sip[16], uint8_t dip[16],
    uint16_t sport, uint16_t dport,
    uint8_t proto,
    uint32_t packets, uint32_t bytes,
    uint8_t flags, uint8_t flags_initial,
    uint16_t application_id,
    char *sensor_name,
    char *flow_class, char *flow_type)
{
    /* TODO: handle multiple flows in a single alert */
    Flow                   *alert_flow;
    IPAddress              *alert_flow_sip, *alert_flow_dip;
    IPAddress__IPV6Address *sipv6addr, *dipv6addr;
    guint64                 hi, lo;
    guint64                *p64;

    SnarfValue *value;
    SnarfField *field;

    alert_flow = g_new0(Flow, 1);
    flow__init(alert_flow);

    alert_flow->stime   = snarf_alert_set_timestamp_field(stime);
    alert_flow->elapsed = snarf_alert_set_elapsed_time_field(elapsed);

    alert_flow_sip = g_new0(IPAddress, 1);
    ipaddress__init(alert_flow_sip);
    alert_flow_sip->type = IPADDRESS__TYPE__IPV6;
    alert_flow_sip->has_v4 = 0;
    sipv6addr            = g_new0(IPAddress__IPV6Address, 1);
    ipaddress__ipv6_address__init(sipv6addr);

    p64 = (guint64 *)sip;
    hi  = *p64;
    p64++;
    lo = *p64;

    sipv6addr->hi = GUINT64_FROM_BE(hi);
    sipv6addr->lo = GUINT64_FROM_BE(lo);

    alert_flow_sip->v6 = sipv6addr;

    alert_flow_dip = g_new0(IPAddress, 1);
    ipaddress__init(alert_flow_dip);
    alert_flow_dip->type = IPADDRESS__TYPE__IPV6;
    alert_flow_dip->has_v4 = 0;
    dipv6addr            = g_new0(IPAddress__IPV6Address, 1);
    ipaddress__ipv6_address__init(dipv6addr);

    p64 = (guint64 *)dip;
    hi  = *p64;
    p64++;
    lo = *p64;

    dipv6addr->hi = GUINT64_FROM_BE(hi);
    dipv6addr->lo = GUINT64_FROM_BE(lo);

    alert_flow_dip->v6 = dipv6addr;

    alert_flow->sip = alert_flow_sip;
    alert_flow->dip = alert_flow_dip;

    alert_flow->sport = sport;
    alert_flow->dport = dport;
    alert_flow->proto = proto;

    alert_flow->packets = packets;
    alert_flow->bytes   = bytes;

    alert_flow->flags         = snarf_alert_set_tcp_flags_field(flags);
    alert_flow->flags_initial =
        snarf_alert_set_tcp_flags_field(flags_initial);

    alert_flow->application_id = application_id;

    alert_flow->sensor_name = g_strdup(sensor_name);
    alert_flow->flow_class  = g_strdup(flow_class);
    alert_flow->flow_type   = g_strdup(flow_type);

    value = g_new0(SnarfValue, 1);
    snarf_value__init(value);
    value->type = SNARF_VALUE__TYPE__FLOW;
    value->flow = alert_flow;

    g_debug("sip type: %d", value->flow->sip->type);
    g_debug("sip type: %d", value->flow->dip->type);

    field = snarf_alert_add_field(alert, "flow");
    snarf_alert_add_value(field, value);

    /* alert->body->flow = alert_flow; */

} /* snarf_alert_add_flow_v6 */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
