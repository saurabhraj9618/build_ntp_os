/*
 * alert_print.c
 * Structured Network Alert Reporting Framework - alert printing helpers
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#include "alert_priv.h"
#define G_LOG_DOMAIN SNARF_ALERT_LOG_DOMAIN

#include <snarf/snarf.h>
#include <glib.h>
#include <glib/gstdio.h>



void
snarf_alert_print_timestr(
    snarf_output_buffer_t *outbuf,
    uint64_t               timestamp);

struct snarf_output_buffer
{
    GString                        *str;
    snarf_output_format_t           format;
    snarf_output_severity_format_t  severity_format;
    snarf_output_timestamp_format_t timestamp_format;
    snarf_output_elapsed_format_t   elapsed_format;
    snarf_output_tcp_flags_format_t tcp_flags_format;
    unsigned char                   delimiter;
};

snarf_output_buffer_t *
snarf_output_buffer_new(size_t len)
{
    snarf_output_buffer_t *outbuf = g_new0(snarf_output_buffer_t, 1);

    outbuf->str       = g_string_sized_new(len);
    outbuf->format    = SNARF_OUTPUT_BUFFER_RAW;
    outbuf->delimiter = '\0';
    return outbuf;
}

void
snarf_output_buffer_set_format(snarf_output_buffer_t *outbuf,
                               snarf_output_format_t  format)
{
    outbuf->format = format;
}


void
snarf_output_buffer_set_delimiter(snarf_output_buffer_t *outbuf, char delim)
{
    outbuf->delimiter = delim;
}

void
snarf_output_buffer_set_severity_format(
    snarf_output_buffer_t         *outbuf,
    snarf_output_severity_format_t format)
{
    outbuf->severity_format = format;
}

void
snarf_output_buffer_set_timestamp_format(
    snarf_output_buffer_t          *outbuf,
    snarf_output_timestamp_format_t format)
{
    outbuf->timestamp_format = format;
}

void
snarf_output_buffer_set_elapsed_format(
    snarf_output_buffer_t          *outbuf,
    snarf_output_elapsed_format_t format)
{
    outbuf->elapsed_format = format;
}

void
snarf_output_buffer_set_tcp_flags_format(
    snarf_output_buffer_t          *outbuf,
    snarf_output_tcp_flags_format_t format)
{
    outbuf->tcp_flags_format = format;
}

void
snarf_output_buffer_free(snarf_output_buffer_t *outbuf)
{
    g_string_free(outbuf->str, TRUE);
    g_free(outbuf);
}

char *
snarf_output_buffer_contents(snarf_output_buffer_t *outbuf)
{
    return (char *) outbuf->str->str;
}

size_t
snarf_output_buffer_length(snarf_output_buffer_t *outbuf)
{
    return (size_t) outbuf->str->len;
}



void
snarf_alert_print_generator(snarf_output_buffer_t *outbuf,
                            snarf_alert_t         *alert)
{
    g_string_append(outbuf->str, alert->envelope->generator);
}

void
snarf_alert_print_analysis_tags(snarf_output_buffer_t *outbuf,
                                snarf_alert_t         *alert)
{
    int i;

    if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
    {
        g_string_append_c(outbuf->str, '[');
    }

    for (i = 0; i < alert->envelope->n_analysis_tags; i++)
    {
        if (i > 0)
        {
            g_string_append(outbuf->str, ",");
        }
        if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
        {
            g_string_append_c(outbuf->str, '"');
        }
        snarf_alert_print_string_raw(outbuf, alert->envelope->analysis_tags[i]);
        if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
        {
            g_string_append_c(outbuf->str, '"');
        }
    }

    if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
    {
        g_string_append_c(outbuf->str, ']');
    }
    else
    if (outbuf->format == SNARF_OUTPUT_BUFFER_DELIMITED)
    {
        g_string_append_c(outbuf->str, outbuf->delimiter);
    }
} /* snarf_alert_print_analysis_tags */

void
snarf_alert_print_severity(snarf_output_buffer_t *outbuf,
                           const ProtobufCEnumDescriptor *desc,
                           void         *p)
{
    const ProtobufCEnumValue      *val;

    switch (outbuf->severity_format)
    {
      case SNARF_OUTPUT_SEVERITY_FORMAT_INT:
        g_string_append_printf(outbuf->str,
                               "%" PRIu32,
                               *(uint32_t *) p);
        break;
      case SNARF_OUTPUT_SEVERITY_FORMAT_NAME:
        {
            int                 index = *(int *) p;
            val = protobuf_c_enum_descriptor_get_value(
                desc,
                index);
            g_debug("enum: %s", val->name);
            if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
            {
                g_string_append_c(outbuf->str, '"');
            }
            g_string_append_printf(outbuf->str,
                                   "%s",
                                   val->name);
            if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
            {
                g_string_append_c(outbuf->str, '"');
            }
            break;
        }
      default:
        g_error("unknown severity format: %d",
                outbuf->severity_format);
        break;
    }                      /* switch */

}

#define SNARF_ALERT_SET_FLAG(_str_, _flag_, _set_, _unset_) \
    {                                                       \
        if (_flag_)                                         \
        {                                                   \
            g_string_append(_str_, _set_);                  \
        }                                                   \
        else                                                \
        {                                                   \
            g_string_append(_str_, _unset_);                \
        }                                                   \
    }

#define TCP_FLAGS_VERBOSE(outbuf) \
    (outbuf->tcp_flags_format ==  \
     SNARF_OUTPUT_TCP_FLAGS_FORMAT_VERBOSE)


void
snarf_alert_print_tcp_flags(snarf_output_buffer_t *outbuf,
                            TCPFlags              *flags)
{
    GString *str = g_string_sized_new(TCPFLAGS_STRLEN);


    if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
    {
        g_string_append_c(outbuf->str, '"');
    }

    if (flags)
    {
        SNARF_ALERT_SET_FLAG(str, flags->fin, "F",
                             TCP_FLAGS_VERBOSE(outbuf) ? " " : "");
        SNARF_ALERT_SET_FLAG(str, flags->syn, "S",
                             TCP_FLAGS_VERBOSE(outbuf) ? " " : "");
        SNARF_ALERT_SET_FLAG(str, flags->rst, "R",
                             TCP_FLAGS_VERBOSE(outbuf) ? " " : "");
        SNARF_ALERT_SET_FLAG(str, flags->psh, "P",
                             TCP_FLAGS_VERBOSE(outbuf) ? " " : "");
        SNARF_ALERT_SET_FLAG(str, flags->ack, "A",
                             TCP_FLAGS_VERBOSE(outbuf) ? " " : "");
        SNARF_ALERT_SET_FLAG(str, flags->urg, "U",
                             TCP_FLAGS_VERBOSE(outbuf) ? " " : "");
        SNARF_ALERT_SET_FLAG(str, flags->ece, "E",
                             TCP_FLAGS_VERBOSE(outbuf) ? " " : "");
        SNARF_ALERT_SET_FLAG(str, flags->cwr, "C",
                             TCP_FLAGS_VERBOSE(outbuf) ? " " : "");
        g_string_append(outbuf->str, str->str);
        g_string_free(str, TRUE);
    }

    if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
    {
        g_string_append_c(outbuf->str, '"');
    }
} /* snarf_alert_print_tcp_flags */

void
snarf_alert_print_tcp_flags2(snarf_output_buffer_t *outbuf,
                             TCPFlags              *flags)
{
    char tmpbuf[TCPFLAGS_STRLEN];

    g_assert(outbuf);


    tmpbuf[0] = (char)((flags->fin) ? 'F' : ' ');
    tmpbuf[1] = (char)((flags->syn) ? 'S' : ' ');
    tmpbuf[2] = (char)((flags->rst) ? 'R' : ' ');
    tmpbuf[3] = (char)((flags->psh) ? 'P' : ' ');
    tmpbuf[4] = (char)((flags->ack) ? 'A' : ' ');
    tmpbuf[5] = (char)((flags->urg) ? 'U' : ' ');
    tmpbuf[6] = (char)((flags->ece) ? 'E' : ' ');
    tmpbuf[7] = (char)((flags->cwr) ? 'C' : ' ');

    tmpbuf[TCPFLAGS_STRLEN-1] = '\0';
    g_string_append(outbuf->str, tmpbuf);
} /* snarf_alert_print_tcp_flags */


void
snarf_alert_print_timestamp(snarf_output_buffer_t *outbuf,
                            Timestamp             *timestamp)
{
    if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
    {
        g_string_append_c(outbuf->str, '"');
    }
    snarf_alert_print_timestr(outbuf, timestamp->timestamp);
    if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
    {
        g_string_append_c(outbuf->str, '"');
    }
} /* snarf_alert_print_timestamp */

void
snarf_alert_print_ip_address(snarf_output_buffer_t *outbuf,
                             IPAddress             *addr)
{
    char inbuf[16];
    char addrbuf[INET6_ADDRSTRLEN] = { 0, };

    g_assert(outbuf);
    switch (addr->type)
    {

        case IPADDRESS__TYPE__IPV4:
        {
            uint32_t tmpaddr = GUINT32_TO_BE(addr->v4);
            if (inet_ntop(AF_INET, (void *) &(tmpaddr), (char *)&addrbuf,
                          INET_ADDRSTRLEN))
            {
                g_string_append(outbuf->str, (char *)&addrbuf);
            }
            break;
        }
        case IPADDRESS__TYPE__IPV6:
        {
            uint64_t *p64;
            p64  = (uint64_t *)inbuf;
            *p64 = GUINT64_TO_BE(addr->v6->hi);
            p64++;
            *p64 = GUINT64_TO_BE(addr->v6->lo);
            if (inet_ntop(AF_INET6, &inbuf, (char *) &addrbuf,
                          INET6_ADDRSTRLEN))
            {
                g_string_append(outbuf->str, (char *) &addrbuf);
            }
            break;
        }
        default:
            g_critical("unknown IP address type: %d", addr->type);
    } /* switch */
} /* snarf_alert_print_ip_address */

void
snarf_alert_print_elapsed_time(
    snarf_output_buffer_t *outbuf,
    uint32_t               elapsed)
{
    switch (outbuf->elapsed_format)
    {
      case SNARF_OUTPUT_ELAPSED_FORMAT_SEC:
        g_string_append_printf(outbuf->str, "%" PRIu32 ".%03" PRIu32,
                               elapsed / 1000, elapsed % 1000);
        break;
      case SNARF_OUTPUT_ELAPSED_FORMAT_MSEC:
        g_string_append_printf(outbuf->str, "%" PRIu32, elapsed);
        break;
      default:
        g_critical("unknown elapsed format: %d", outbuf->elapsed_format);
    }

} /* snarf_alert_print_elapsed_time */

void
snarf_alert_print_timestr(snarf_output_buffer_t *outbuf,
                          uint64_t               timestamp)
{
    GTimeVal gtv;
    gchar   *timestr     = NULL;
    gchar    timebuf[64] = { 0, };

    gtv.tv_sec  = timestamp / (1000 * 1000);
    gtv.tv_usec = (timestamp % (1000 * 1000));
    switch (outbuf->timestamp_format)
    {
        case SNARF_OUTPUT_TIMESTAMP_FORMAT_ISO8601:
            timestr = g_time_val_to_iso8601(&gtv);
            /* GLib-- changed how g_time_val_to_iso8601() handles sub-second
             * time resolutions around version 2.12, and it's not clear
             * they've gotten it right yet, so we'll handle the microseconds
             * ourselves. */
            strncpy((char *)&timebuf, timestr, 19);
            g_free(timestr);
            sprintf(timebuf+19, ".%06luZ", gtv.tv_usec);
            g_string_append(outbuf->str, (char *)&timebuf);
            break;
        case SNARF_OUTPUT_TIMESTAMP_FORMAT_CEF:
            strftime(timebuf, 64, "%b %d %Y %H:%M:%S", localtime(&(gtv.tv_sec)));
            g_string_append(outbuf->str, (char *)&timebuf);
            break;
        case SNARF_OUTPUT_TIMESTAMP_FORMAT_EPOCHSEC:
            sprintf(timebuf, "%lu", gtv.tv_sec);
            g_string_append(outbuf->str, (char *)&timebuf);
          break;
        case SNARF_OUTPUT_TIMESTAMP_FORMAT_EPOCHMSEC:
            sprintf(timebuf, "%lu", gtv.tv_sec * 1000 + gtv.tv_usec / 1000);
            g_string_append(outbuf->str, (char *)&timebuf);
          break;
        default:
            g_critical("unknown timestamp format %d",
                       outbuf->timestamp_format);
    } /* switch */
} /* snarf_alert_print_timestr */

void
snarf_alert_print_string(snarf_output_buffer_t *outbuf,
                         char                  *str)
{
    if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
    {
        g_string_append_c(outbuf->str, '"');
    }
    g_string_append(outbuf->str, str);
    if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
    {
        g_string_append_c(outbuf->str, '"');
    }
    else if (outbuf->format == SNARF_OUTPUT_BUFFER_DELIMITED)
    {
        g_string_append_c(outbuf->str, outbuf->delimiter);
    }

} /* snarf_alert_print_string */

void
snarf_alert_print_string_raw(snarf_output_buffer_t *outbuf,
                             char                  *str)
{
    g_string_append(outbuf->str, str);
}

void
snarf_alert_print_envelope_field(
    snarf_output_buffer_t *outbuf,
    snarf_alert_t         *alert,
    const char            *fieldname)
{
    const ProtobufCFieldDescriptor *field = NULL;
    gpointer                  p;

    field = protobuf_c_message_descriptor_get_field_by_name
                (&snarf_envelope__descriptor,
                fieldname);

    if (!field)
    {
        g_warning("envelope field not found");
        return;
    }

    g_debug("envelope field: %s, %d",
            field->name,
            field->offset);
    p = (gpointer) alert->envelope + field->offset;
    switch (field->type)
    {
        case PROTOBUF_C_TYPE_STRING:
        {
            if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
            {
                g_string_append_c(outbuf->str, '"');
            }
            snarf_alert_print_string_raw(outbuf, *(char **) p);
            if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
            {
                g_string_append_c(outbuf->str, '"');
            }
            break;
        }
        case PROTOBUF_C_TYPE_MESSAGE:
        {
            const ProtobufCMessageDescriptor *desc = field->descriptor;
            g_debug("message: %s", desc->name);
            if (desc->message_init == (ProtobufCMessageInit)timestamp__init)
            {
                snarf_alert_print_timestamp(outbuf, *((Timestamp **) p));

            }
            else
            {
                g_warning("unknown message type");
                return;
            }
            break;
        }

        case PROTOBUF_C_TYPE_ENUM:
        {
            const ProtobufCEnumDescriptor *desc = field->descriptor;
            if (!strcmp(desc->name, "SnarfEnvelope.AlertSeverity"))
            {
                snarf_alert_print_severity(outbuf, desc, p);
            }
            else
            {
                g_error("unsupported envelope field: %s, %s",
                        fieldname,
                        desc->name);
            }
            break;
        }
        default:
            g_error("unsupported envelope field type: %d", field->type);
            break;
    }                                  /* switch */
#if 1
    if (outbuf->format == SNARF_OUTPUT_BUFFER_DELIMITED)
    {
        g_string_append_c(outbuf->str, outbuf->delimiter);
    }
#endif

} /* snarf_alert_print_envelope_field */


#define SNARF_ALERT_FLOW_FIELD_VALUE(_v, _f) \
    ( (gpointer) _v->flow + _f->offset )

const ProtobufCFieldDescriptor *
snarf_flow_get_field(
    snarf_value_t *value,
    const char    *fieldname)
{
    const ProtobufCFieldDescriptor *field = NULL;

    field = protobuf_c_message_descriptor_get_field_by_name
                (&flow__descriptor,
                fieldname);

    return field;
} /* snarf_flow_get_field */

void *
snarf_flow_get_field_value(
    snarf_value_t *value,
    const char    *fieldname)
{
    const ProtobufCFieldDescriptor *flowfield;

    flowfield = snarf_flow_get_field(value, fieldname);
    if (flowfield)
    {
        return (void *) value->flow + flowfield->offset;
    }
    else
    {
        return NULL;
    }
} /* snarf_flow_get_field_value */

void
snarf_print_protobuf_message(snarf_output_buffer_t      *outbuf,
                             gpointer                    value,
                             const ProtobufCMessageDescriptor *desc)
{
    int                       i;
    const ProtobufCFieldDescriptor *fielddesc = NULL;
    gpointer                  p;

    g_string_append_printf(outbuf->str, "{");
    for (i = 0; i < desc->n_fields; i++)
    {
        /* field = protobuf_c_message_descriptor_get_field(desc, i); */
        fielddesc = &(desc->fields[i]);
        p         = value + fielddesc->offset;

        if (i > 0)
        {
            g_string_append(outbuf->str, ", ");
        }

        g_string_append_printf(outbuf->str, "\"%s\": ", fielddesc->name);

        /*        g_debug("field: %s", fielddesc->name); */

        switch (fielddesc->type)
        {
            case PROTOBUF_C_TYPE_MESSAGE:
            {
                ProtobufCMessage *msg =
                    *(ProtobufCMessage **) p;
                const ProtobufCMessageDescriptor *msgdesc =
                    (ProtobufCMessageDescriptor *) fielddesc->descriptor;
#if 1
                if (msgdesc->message_init == (ProtobufCMessageInit)ipaddress__init)
                {
                    g_string_append_c(outbuf->str, '"');
                    snarf_alert_print_ip_address(outbuf, (IPAddress *)msg);
                    g_string_append_c(outbuf->str, '"');
                }
                else
                if (msgdesc->message_init == (ProtobufCMessageInit)timestamp__init)
                {
                    snarf_alert_print_timestamp(outbuf, *((Timestamp **) p));
                }
                else
                if (msgdesc->message_init == (ProtobufCMessageInit)elapsed_time__init)
                {
                    ElapsedTime *et = *((ElapsedTime **) p);
                    snarf_alert_print_elapsed_time(outbuf, et->elapsed);
                }
                else
                if (msgdesc->message_init == (ProtobufCMessageInit)tcpflags__init)
                {
                    snarf_alert_print_tcp_flags(outbuf, *((TCPFlags **) p));
                }
                else
                {
                    snarf_print_protobuf_message(outbuf,
                                                 msg,
                                                 fielddesc->descriptor);
                }
#else /* if 1 */
                snarf_print_protobuf_message(outbuf,
                                             msg,
                                             fielddesc->descriptor);
#endif /* if 1 */
                break;
            }
            case PROTOBUF_C_TYPE_ENUM:
            {
                const ProtobufCEnumValue *val;
                int                 index = *(int *) p;
                val = protobuf_c_enum_descriptor_get_value(
                    fielddesc->descriptor,
                    index);
                g_string_append_printf(outbuf->str, "\"%s\"", val->name);
                break;
            }
            case PROTOBUF_C_TYPE_UINT32:
            case PROTOBUF_C_TYPE_FIXED32:
                g_string_append_printf(outbuf->str,
                                       "%" PRIu32,
                                       *(uint32_t *) p);
                break;
            case PROTOBUF_C_TYPE_UINT64:
            {
                g_string_append_printf(outbuf->str,
                                       "%" PRIu64,
                                       *(uint64_t *) p);
                break;
            }
            case PROTOBUF_C_TYPE_STRING:
            {
                g_string_append_printf(outbuf->str, "\"%s\"", *(gchar **) p);
                break;
            }
            case PROTOBUF_C_TYPE_BOOL:
                g_string_append_printf(outbuf->str, "%s",
                                       ( ( *(protobuf_c_boolean *)p )  ?
                                         "true" : "false"));
                break;
            default:
                g_warning("unsupported protobuf field type: %d",
                          fielddesc->type);
                break;
        } /* switch */

    }

    g_string_append_printf(outbuf->str, "}");
} /* snarf_print_protobuf_message */

#define SNARF_BASE64_CHUNK_SIZE 256
#define SNARF_BASE64_DECODED_CHUNK_SIZE \
    ((((SNARF_BASE64_CHUNK_SIZE / 3) + 1) * 4) + 4)

void
snarf_print_base64(snarf_output_buffer_t *outbuf,
                   ProtobufCBinaryData   *data)
{
    const guchar *in;
    gchar         out[SNARF_BASE64_DECODED_CHUNK_SIZE];
    gint          state = 0;
    gint          save  = 0;
    gsize         len;
    gsize         bytes;
    gsize         c;

    in  = data->data;
    len = data->len;

    g_string_append_c(outbuf->str, '"');
    for (c = 0; c < len; )
    {
        gsize step = MIN(SNARF_BASE64_CHUNK_SIZE, len - c);
        bytes = g_base64_encode_step(in + c, step, FALSE, out, &state, &save);
        g_string_append_len(outbuf->str, out, bytes);
        c += step;
    }

    bytes = g_base64_encode_close(FALSE, out, &state, &save);
    g_string_append_len(outbuf->str, out, bytes);

    g_string_append_c(outbuf->str, '"');


} /* snarf_print_base64 */


void
snarf_alert_write_ipset(const char    *filename,
                        snarf_value_t *value)
{
    GError     *err = NULL;
    GIOStatus   status;
    GIOChannel *out          = NULL;
    gsize       byteswritten = 0;
    const gchar *data        = (gchar *)value->ipset->data.data;
    size_t      len          = value->ipset->data.len;

    out = g_io_channel_new_file(filename, "w", &err);
    g_io_channel_set_encoding(out, NULL, &err);
    g_io_channel_set_buffered(out, FALSE);

    if (err)
    {
        g_critical("can't open ip set file: %s", err->message);
        return;
    }
    status = g_io_channel_write_chars(out, data, len, &byteswritten, &err);
    if (status != G_IO_STATUS_NORMAL)
    {
        g_critical("write error: %d", status);
    }
    if (err)
    {
        g_critical("error writing data: %s", err->message);
        return;
    }
    g_io_channel_shutdown(out, TRUE, &err);
} /* snarf_alert_write_ipset */

void
snarf_alert_print_value(snarf_output_buffer_t *outbuf,
                        snarf_value_t         *value)
{
    g_assert(value);
    switch (value->type)
    {
        case SNARF_VALUE__TYPE__STRING:
            g_assert(value->string);
            if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
            {
                g_string_append_c(outbuf->str, '"');
            }
            g_string_append_printf(outbuf->str, "%s", value->string);
            if (outbuf->format == SNARF_OUTPUT_BUFFER_JSON)
            {
                g_string_append_c(outbuf->str, '"');
            }
            break;
        case SNARF_VALUE__TYPE__INTEGER:
            g_string_append_printf(outbuf->str, "%" PRIu64, value->integer);
            break;
        case SNARF_VALUE__TYPE__DOUBLE:
            g_string_append_printf(outbuf->str, "%lf", value->double_);
            break;
        case SNARF_VALUE__TYPE__BOOLEAN:
            g_string_append_printf(outbuf->str, "%s",
                                   (value->boolean ? "True" : "False"));
            break;
        case SNARF_VALUE__TYPE__FLOW:
            g_assert(value->flow);
            snarf_print_protobuf_message(outbuf,
                                         value->flow,
                                         value->flow->base.descriptor);
            break;
        case SNARF_VALUE__TYPE__IPADDRESS:
            snarf_alert_print_ip_address(outbuf, value->ipaddress);
            break;
        case SNARF_VALUE__TYPE__IPSET:
            g_assert(value->ipset);
            snarf_print_base64(outbuf, &(value->ipset->data));
            break;
        default:
          g_error("unknown field value type: %d", value->type);
    } /* switch */
    if (outbuf->format == SNARF_OUTPUT_BUFFER_DELIMITED)
    {
        g_string_append_c(outbuf->str, outbuf->delimiter);
    }

} /* snarf_alert_print_value */

void
snarf_print_field(snarf_output_buffer_t *outbuf,
                  snarf_field_t         *field)
{
    int i;

    g_string_append_printf(outbuf->str, "\"%s\": ", field->name);
    if (field->n_value == 0)
    {
        g_string_append(outbuf->str, "null");
    }
#if 0
    else
    if (field->n_value == 1)
    {
        snarf_alert_print_value(outbuf, field->value[0]);
    }
#endif /* if 0 */
    else
    {
        g_string_append(outbuf->str, "[");
        for (i = 0; i < field->n_value; i++)
        {
            if (i > 0)
            {
                g_string_append(outbuf->str, ", ");
            }
            snarf_alert_print_value(outbuf, field->value[i]);
        }

        g_string_append(outbuf->str, "]");
    }

} /* snarf_print_field */

void
snarf_print_envelope(snarf_output_buffer_t *outbuf,
                     snarf_alert_t         *alert)
{
    g_string_append(outbuf->str, "{\n");
    g_string_append(outbuf->str, "        \"generator\": ");
    snarf_alert_print_envelope_field(outbuf, alert, "generator");
    g_string_append(outbuf->str, ",\n");
    g_string_append(outbuf->str, "        \"generator_version\": ");
    snarf_alert_print_envelope_field(outbuf, alert, "generator_version");
    g_string_append(outbuf->str, ",\n");
    g_string_append(outbuf->str, "        \"severity\": ");
    snarf_alert_print_envelope_field(outbuf, alert, "severity");
    g_string_append(outbuf->str, ",\n");
    g_string_append(outbuf->str, "        \"timestamp\": ");
    snarf_alert_print_envelope_field(outbuf, alert, "timestamp");
    g_string_append(outbuf->str, ",\n");
    g_string_append(outbuf->str, "        \"analysis_tags\": ");
    snarf_alert_print_analysis_tags(outbuf, alert);
    g_string_append(outbuf->str, "\n}");
} /* snarf_print_envelope */

void
snarf_print_alert_body(snarf_output_buffer_t *outbuf,
                       snarf_alert_t         *alert)
{
    SnarfAlertBody *body = alert->body;
    int             i;
    snarf_field_t  *field;

    g_string_append(outbuf->str, "{\n");
    for (i = 0; i < body->n_fields; i++)
    {
        if (i > 0)
        {
            g_string_append(outbuf->str, ",\n         ");
        }
        field = alert->body->fields[i];
        snarf_print_field(outbuf, field);
    }

    g_string_append(outbuf->str, "}\n");

} /* snarf_print_alert_body */

void
snarf_alert_print(snarf_output_buffer_t *outbuf,
                  snarf_alert_t         *alert)
{
    g_string_append(outbuf->str, "{\n");
    g_string_append_printf(outbuf->str, "    \"envelope\": ");
    snarf_print_envelope(outbuf, alert);
    g_string_append(outbuf->str, ",\n");
    g_string_append_printf(outbuf->str, "    \"body\": ");
    snarf_print_alert_body(outbuf, alert);
    g_string_append(outbuf->str, "}\n");
}

void
snarf_alert_print_flow(
    snarf_output_buffer_t *outbuf,
    snarf_value_t         *value,
    const char            *fieldname)
{
    g_string_append(outbuf->str, "{\n");
    snarf_alert_print_flow_field(outbuf, value, "sip");
    g_string_append(outbuf->str, "}\n");
}

void
snarf_alert_print_flow_field(
    snarf_output_buffer_t *outbuf,
    snarf_value_t         *value,
    const char            *fieldname)
{
    const ProtobufCFieldDescriptor *field = NULL;
    gpointer                  p;

    g_assert(value);

    field = protobuf_c_message_descriptor_get_field_by_name
                (&flow__descriptor,
                fieldname);

    if (field)
    {
        p = snarf_flow_get_field_value(value, fieldname);
        switch (field->type)
        {
            case PROTOBUF_C_TYPE_MESSAGE:
            {
                const ProtobufCMessageDescriptor *desc = field->descriptor;
                if (desc->message_init == (ProtobufCMessageInit)ipaddress__init)
                {
                    snarf_alert_print_ip_address(outbuf, *((IPAddress **) p));
                }
                else
                if (desc->message_init == (ProtobufCMessageInit)tcpflags__init)
                {
                    snarf_alert_print_tcp_flags(outbuf, *((TCPFlags **) p));
                }
                else
                if (desc->message_init == (ProtobufCMessageInit)timestamp__init)
                {
                    snarf_alert_print_timestamp(outbuf, *((Timestamp **) p));
                }
                else
                if (desc->message_init == (ProtobufCMessageInit)elapsed_time__init)
                {
                    ElapsedTime *ep      = *((struct _ElapsedTime **) p);
                    uint32_t     elapsed = ep->elapsed;
                    snarf_alert_print_elapsed_time(outbuf, elapsed);
                }
                else
                {
                    g_error("unknown message type");
                    return;
                }
                break;
            }
            case PROTOBUF_C_TYPE_UINT32:
                g_string_append_printf(outbuf->str,
                                       "%" PRIu32,
                                       *(uint32_t *) p);
                break;
            case PROTOBUF_C_TYPE_UINT64:
            {
                g_string_append_printf(outbuf->str,
                                       "%" PRIu64,
                                       *(uint64_t *) p);
                break;
            }
            case PROTOBUF_C_TYPE_STRING:
            {
                g_string_append_printf(outbuf->str,
                                       "%s",
                                       *(gchar **) p);
                break;
            }
            default:
                g_error("unsupported flow field type: %d", field->type);
                break;
        } /* switch */
    }
    else
    {
        /* special handling for computed field "etime" */
        if (!strcmp(fieldname, "etime"))
        {
            Timestamp   *stime = NULL;
            Timestamp    etime;
            ElapsedTime *elapsed = NULL;
            stime = *(Timestamp **)
                    snarf_flow_get_field_value(value, "stime");
            elapsed = *(ElapsedTime **)
                      snarf_flow_get_field_value(value, "elapsed");
            etime.timestamp = stime->timestamp + 1000 * elapsed->elapsed;
            snarf_alert_print_timestamp(outbuf, &etime);
        }
        else
        {
            g_error("unknown flow field name: %s", fieldname);
        }

    }

    if (outbuf->format == SNARF_OUTPUT_BUFFER_DELIMITED)
    {
        g_string_append_c(outbuf->str, outbuf->delimiter);
    }
} /* snarf_alert_print_flow_field */


/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
