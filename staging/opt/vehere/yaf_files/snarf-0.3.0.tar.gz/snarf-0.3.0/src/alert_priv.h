/*
 * alert_priv.h
 * Structured Network Alert Reporting Library - Private Alert Interface
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#ifndef _SNARF_ALERT_PRIV_H_
#define _SNARF_ALERT_PRIV_H_

#define SNARF_ALERT_LOG_DOMAIN "snarf.alert"

#include <snarf/alert.h>
#include "proto/alert.pb-c.h"


#ifndef TCPFLAGS_STRLEN
#    define TCPFLAGS_STRLEN 9

/* Shamelessly stolen from sku-string.c */
#    define CWR_FLAG (1 << 7)          /* 128 */
#    define ECE_FLAG (1 << 6)          /*  64 */
#    define URG_FLAG (1 << 5)          /*  32 */
#    define ACK_FLAG (1 << 4)          /*  16 */
#    define PSH_FLAG (1 << 3)          /*   8 */
#    define RST_FLAG (1 << 2)          /*   4 */
#    define SYN_FLAG (1 << 1)          /*   2 */
#    define FIN_FLAG (1)               /*   1 */
#endif /* ifndef TCPFLAGS_STRLEN */

struct snarf_alert
{
    SnarfEnvelope  *envelope;
    SnarfAlertBody *body;
};

void
snarf_alert_set_generator(
    snarf_alert_t *alert,
    char          *name,
    char          *version);

void
snarf_alert_print_tcp_flags(
    snarf_output_buffer_t *outbuf,
    TCPFlags              *flags);

void
snarf_alert_print_timestr(
    snarf_output_buffer_t *outbuf,
    uint64_t               timestamp);

void
snarf_alert_print(snarf_output_buffer_t *outbuf,
                  snarf_alert_t         *alert);

#endif /* ifndef _SNARF_ALERT_PRIV_H_ */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
