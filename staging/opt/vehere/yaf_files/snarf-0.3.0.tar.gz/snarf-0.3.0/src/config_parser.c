/*
 * config_parser.c
 * Structured Network Alert Reporting Framework Config File Parsing Routines
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2014 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#include "snarf.h"
#define G_LOG_DOMAIN SNARF_LOG_DOMAIN

#include <snarf/snarf.h>
#include <glib.h>
#include <glib/gstdio.h>
#include <yaml.h>

enum storage_flags { VAR, VAL, SEQ }; /* "Store as" switch */

void
process_config_layer(yaml_parser_t *parser, GNode *data) {
    GNode       *last_leaf = data;
    yaml_event_t event;
    int          storage = VAR; /* mapping cannot start with VAL definition
                                 * w/o VAR key */

    while (1)
    {
        yaml_parser_parse(parser, &event);
        g_debug("event: %d", event.type);

        /*
         * Parse value either as a new leaf in the mapping
         *  or as a leaf value (one of them, in case it's a sequence)
         */
        if (event.type == YAML_SCALAR_EVENT)
        {
            g_debug("scalar: %s", event.data.scalar.value);
            if (storage)
            {
                g_node_append_data(last_leaf,
                                   g_strdup((gchar *) event.data.scalar.value));
            }
            else
            {
                last_leaf =
                    g_node_append(data,
                                  g_node_new(g_strdup((gchar *) event.data.
                                                      scalar.value)));
            }
            storage ^= VAL; /* Flip VAR/VAL switch for the next event */
        }

        /* Sequence - all the following scalars will be appended to the
         * last_leaf */
#if 1
        else
        if (event.type == YAML_SEQUENCE_START_EVENT)
        {
            storage   = SEQ;
            last_leaf = g_node_append_data(last_leaf, "null");
        }
#else /* if 1 */
        else
        if (event.type == YAML_SEQUENCE_START_EVENT)
        {
            storage = SEQ;
        }
#endif /* if 1 */
#if 1
        else
        if (event.type == YAML_SEQUENCE_END_EVENT)
        {
            storage   = VAR;
            last_leaf = last_leaf->parent;
        }
#else /* if 1 */
        else
        if (event.type == YAML_SEQUENCE_END_EVENT)
        {
            storage = VAR;
        }
#endif /* if 1 */

        /* depth += 1 */
        else
        if (event.type == YAML_MAPPING_START_EVENT)
        {
            process_config_layer(parser, last_leaf);
            storage ^= VAL;                     /* Flip VAR/VAL, w/o touching
                                                 *SEQ */
        }

        /* depth -= 1 */
        else
        if (
            ( event.type == YAML_MAPPING_END_EVENT)
            || (event.type == YAML_STREAM_END_EVENT)
            )
        {
            break;
        }
        yaml_event_delete(&event);
    }
} /* process_config_layer */


snarf_config_t *
snarf_find_config_key(snarf_config_t *root, const char *key)
{
    GNode *rootnode = (GNode *) root;
    GNode *node     = rootnode->children;

    while (node)
    {
        if (!strcmp(key, node->data))
        {
            return node;
        }
        node = node->next;
    }
    return NULL;
} /* snarf_find_config_key */

void *
snarf_get_config_value(snarf_config_t *root, char *key)
{
    GNode *keynode  = NULL, *valnode = NULL;
    GNode *rootnode = (GNode *) root;

    keynode = snarf_find_config_key(rootnode, key);
    if (!keynode)
    {
        return NULL;
    }
    valnode = g_node_first_child(keynode);
    if (!valnode)
    {
        return NULL;
    }
    return valnode->data;
} /* snarf_get_config_value */



gboolean
snarf_dump_config(GNode *node, gpointer data)
{
    int i = g_node_depth(node);

    /* while (--i) g_debug("    "); */
    g_debug("%*s", i*4, (char *) node->data);
    return FALSE;
}

char *find_config_file(char *cfgfile)
{
    if (!cfgfile)
    {
        if (getenv(SNARF_CONFIG_FILE_ENV))
        {
            cfgfile = getenv(SNARF_CONFIG_FILE_ENV);
        }
        else
        {
            cfgfile = "/etc/snarf.conf";
        }
    }
    return cfgfile;
}

int
snarf_check_config(char *cfgfile, time_t *mtime)
{

    GStatBuf buf;
    char *cfg = NULL;

    g_assert(mtime);

    cfg = find_config_file(cfgfile);

    if (! g_stat(cfg, &buf))
    {
        *mtime = buf.st_mtime;
        return TRUE;
    }
    return FALSE;
}



snarf_config_t *
snarf_load_config(char *cfgfile, char *section)
{
    GNode        *config_root    = NULL;
    GNode        *config_section = NULL;
    yaml_parser_t parser;


    cfgfile = find_config_file(cfgfile);

    FILE *source = fopen(cfgfile, "rb");

    if (!source)
    {
        g_debug("couldn't open config file: %s", cfgfile);
        return NULL;
    }

    config_root = g_node_new("snarf");

    yaml_parser_initialize(&parser);
    yaml_parser_set_input_file(&parser, source);
    process_config_layer(&parser, config_root);
    yaml_parser_delete(&parser);
    fclose(source);
    g_node_traverse(config_root,
                    G_PRE_ORDER,
                    G_TRAVERSE_ALL,
                    -1,
                    snarf_dump_config,
                    NULL);

    if (!section)
    {
        return config_root;
    }
    config_section = snarf_find_config_key(config_root, section);
    g_node_traverse(config_section,
                    G_PRE_ORDER,
                    G_TRAVERSE_ALL,
                    -1,
                    snarf_dump_config,
                    NULL);
    return config_section;
} /* snarf_load_config */

gboolean snarf_free_config_node (GNode *node, void * data)
{
    if (node && node->data)
        g_free(node->data);
    return TRUE;
}

void snarf_free_config(snarf_config_t *root)
{
    if (!root) return;
    g_node_traverse((GNode *)root,
                    G_PRE_ORDER,
                    G_TRAVERSE_ALL,
                    -1,
                    snarf_free_config_node,
                    NULL);
    g_node_destroy(root);
}

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
