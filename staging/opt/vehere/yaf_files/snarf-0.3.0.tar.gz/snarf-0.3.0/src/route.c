/*
 * route.c
 * Structured Network Alert Reporting Framework Alert Routing Routines
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#include "snarf.h"
#define G_LOG_DOMAIN SNARF_LOG_DOMAIN

#include "alert_priv.h"

#include <snarf/snarf.h>
#include <snarf/route.h>

void
snarf_dump_envelope(zmq_msg_t *envelope_msg)
{
    SnarfEnvelope *envelope;

    envelope = snarf_envelope__unpack(
        NULL, zmq_msg_size(envelope_msg), zmq_msg_data(envelope_msg));


}

int
snarf_match_route(zmq_msg_t *envelope_msg,
                  void *generators,
                  void *tags)
{
    SnarfEnvelope *envelope;
    int            i, j;
    gboolean       generator_match = FALSE, tags_match = FALSE;

    GPtrArray *pgenerators = (GPtrArray *) generators;
    GPtrArray *ptags = (GPtrArray *) tags;

    envelope = snarf_envelope__unpack(
        NULL, zmq_msg_size(envelope_msg), zmq_msg_data(envelope_msg));

    if (pgenerators)
    {
        for (i = 0; i < pgenerators->len; i++)
        {
            if (g_pattern_match(g_ptr_array_index(pgenerators, i),
                                strlen(envelope->generator),
                                envelope->generator,
                                NULL))
            {
                g_debug("generator match: %s", envelope->generator);
                generator_match = TRUE;
                break;
            }

        }
    }
    else
    {
        generator_match = TRUE;
    }
    if (ptags)
    {
        for (i = 0; i < ptags->len; i++)
        {
            for (j = 0; j < envelope->n_analysis_tags; j++)
            {
                g_debug("testing tag %s", envelope->analysis_tags[j]);
                if (g_pattern_match(g_ptr_array_index(ptags, i),
                                    strlen(envelope->analysis_tags[j]),
                                    envelope->analysis_tags[j],
                                    NULL))
                {
                    g_debug("tags match: %s", envelope->analysis_tags[j]);
                    tags_match = TRUE;
                    break;
                }
            }

        }
    }
    else
    {
        tags_match = TRUE;
    }
    if (envelope) {
        snarf_envelope__free_unpacked(envelope, NULL);
    }
    return (int) (generator_match && tags_match);
} /* snarf_match_route */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
