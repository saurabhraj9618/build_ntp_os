/*
 * sink.c
 * Structured Network Alert Reporting Library - Sink Implementation
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2014 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */


#include "sink.h"
/* #define G_LOG_DOMAIN SNARF_SINK_LOG_DOMAIN */

#include <snarf/snarf.h>
#include <glib.h>
#include <glib/gstdio.h>

#include "alert_priv.h"

/* Poll timeout for sink socket, in microseconds */
#define SNARF_SINK_POLL_TIMEOUT ( 1000 )

extern void *zmq_ctx;

typedef struct snarf_sink_type_map_st {
    char *label;
    snarf_sink_callbacks_t callbacks;
} snarf_sink_type_map_t;

static struct snarf_sink_type_map_st snarf_sink_type_map[] = {
    { "json", { snarf_sink_json_init,
                snarf_sink_json_process,
                snarf_sink_json_destroy } },
    { "cef", { snarf_sink_cef_init,
               snarf_sink_cef_process,
               snarf_sink_cef_destroy } },
    { "email", { snarf_sink_email_init,
                 snarf_sink_email_process,
                 snarf_sink_email_destroy } },
    { NULL, 0}
};

snarf_sink_callbacks_t sink_types[] = {
    { snarf_sink_json_init,
      snarf_sink_json_process,
      snarf_sink_json_destroy },
    { snarf_sink_cef_init,
      snarf_sink_cef_process,
      snarf_sink_cef_destroy },
    { snarf_sink_email_init,
      snarf_sink_email_process,
      snarf_sink_email_destroy },
    { NULL,
      NULL,
      NULL },
};



struct snarf_sink
{
    void                   *socket;
    char                   *channel;
    GThread                *thread;
    gboolean                terminate;
    snarf_sink_callbacks_t *callbacks;
    void                   *sinkctx;
};


snarf_sink_t *
snarf_sink_init(
    char *origin)

{
    int rc;
    int socket_linger_timeout = 1000;

    struct snarf_sink *sink = g_new0(struct snarf_sink, 1);

    origin = (origin ? origin : getenv(SNARF_ALERT_ORIGIN_ENV));

    if (getenv(SNARF_SINK_LINGER_ENV))
    {
        socket_linger_timeout = atoi(getenv(SNARF_SINK_LINGER_ENV));
    }

    if (!origin)
        g_error("no alert source socket specified");

    sink->socket = zmq_socket(zmq_ctx, ZMQ_SUB);
    if (!sink->socket)
    {
        g_error("Couldn't create ZMQ socket");
    }
    rc = zmq_setsockopt(sink->socket, ZMQ_LINGER, &socket_linger_timeout,
                   sizeof (socket_linger_timeout));
    g_assert(!rc);
    g_debug("sink connect");
    rc = zmq_connect(sink->socket, origin);
    if (rc)
    {
        g_error("Couldn't open socket %s (%d)", origin, errno);
    }
    sink->terminate = FALSE;
    return sink;
} /* snarf_sink_init */

int
snarf_sink_configure(
    snarf_sink_t     *sink,
    const char       *sink_id)
{
    int i;
    snarf_sink_callbacks_t *callbacks = NULL;
    GNode *config = NULL;
    const char *type = NULL;

    config = snarf_load_config(NULL, "sink");
    if (config)
    {
        g_debug("loading sink config");
        g_assert(config);
        config = snarf_find_config_key(config, sink_id);
        if (!config)
        {
            g_critical("sink %s not found in snarf config file", sink_id);
            return 0;
        }
        type = (char *)snarf_get_config_value(config, "type");

    }
    else
    {
        /* interpret sink_id as a type */
        g_debug("sink type: %s", sink_id);
        type = sink_id;
    }
    g_debug("sink_type: %s", type);
    for (i=0; snarf_sink_type_map[i].label != NULL; i++)
    {
        if (!g_ascii_strncasecmp(type,
                                 snarf_sink_type_map[i].label, strlen(type)))
        {
            callbacks = &snarf_sink_type_map[i].callbacks;
            break;
        }
    }

    /* FIXME */
    g_assert(callbacks);

    sink->callbacks = g_new0(snarf_sink_callbacks_t, 1);
    memcpy(sink->callbacks, callbacks,
           sizeof(snarf_sink_callbacks_t));
    return ! sink->callbacks->init_fn(&(sink->sinkctx), config);
}

int
snarf_sink_configure_full(
    snarf_sink_t           *sink,
    snarf_sink_init_fn_t    init_fn,
    snarf_sink_alert_fn_t   process_fn,
    snarf_sink_destroy_fn_t destroy_fn,
    snarf_config_t         *config)
{
    g_debug("sink_type: custom");
    sink->callbacks             = g_new0(snarf_sink_callbacks_t, 1);
    sink->callbacks->init_fn    = init_fn;
    sink->callbacks->process_fn = process_fn;
    sink->callbacks->destroy_fn = destroy_fn;
    return ! sink->callbacks->init_fn(&(sink->sinkctx), config);
}

int
snarf_sink_subscribe(
    snarf_sink_t *sink,
    const char   *channel)
{
    int rc;

    g_debug("subscribing to channel %s", channel);
    rc = zmq_setsockopt(sink->socket, ZMQ_SUBSCRIBE, channel, strlen(channel));
    if (rc)
    {
        g_error("Couldn't subscribe to channel %s", channel);
        return 1;
    }
    return 0;

} /* snarf_sink_subscribe */

snarf_sink_callback_status_t
snarf_sink_process_message(
    snarf_sink_t *sink)
{
    int             rc;
    int64_t         more      = 0;     /*  Multipart detection */
    size_t          more_size = sizeof (more);
    SnarfEnvelope  *envelope  = NULL;
    zmq_msg_t      *envelopemsg;
    SnarfAlertBody *alertbody = NULL;
    zmq_msg_t      *alertbodymsg;
    snarf_alert_t  *alert = NULL;
    int             msg_count = 0;
    snarf_sink_callback_status_t status = SNARF_SINK_CALLBACK_OK;
    int i=0;

    GArray *messages = g_array_new(FALSE, FALSE, sizeof(zmq_msg_t));

    g_debug("process_message");

    do
    {
        zmq_msg_t message;
        rc = zmq_msg_init(&message);
        g_assert(!rc);
        rc = zmq_recvmsg(sink->socket, &message, 0);
        if (rc == -1)
        {
            if (errno == EINTR)
            {
                return FALSE;
            }
            g_critical("errno %d: %s", errno, strerror(errno));
        }
        g_array_append_val(messages, message);
        rc = zmq_getsockopt(sink->socket, ZMQ_RCVMORE, &more, &more_size);
        g_assert(!rc);
        g_debug("part");
    } while (more);

    msg_count = messages->len;

    /* We count from the end to get the right message part whether snarfd has
     *  added a subscription key or not */
    envelopemsg = &g_array_index(messages, zmq_msg_t, msg_count - 2);
    g_assert(envelopemsg);
    envelope = snarf_envelope__unpack(NULL, zmq_msg_size(envelopemsg),
                                      zmq_msg_data(envelopemsg));
    g_debug("sink envelope generator: %s", envelope->generator);
    alertbodymsg = &g_array_index(messages, zmq_msg_t, msg_count - 1);
    g_assert(alertbodymsg);
    alertbody = snarf_alert_body__unpack(NULL, zmq_msg_size(alertbodymsg),
                                         zmq_msg_data(alertbodymsg));

    alert           = g_new0(snarf_alert_t, 1);
    alert->envelope = envelope;
    alert->body     = alertbody;
    g_debug("process: %d", (int) alert->envelope->severity);
    status = sink->callbacks->process_fn(sink->sinkctx, alert);
    snarf_envelope__free_unpacked(envelope, NULL);
    snarf_alert_body__free_unpacked(alertbody, NULL);
    g_free(alert);
    for ( i=0; i < messages->len; i++)
    {
        zmq_msg_t *msg;
        msg = &g_array_index(messages, zmq_msg_t, i);
        zmq_msg_close(msg);
    }
    g_array_free(messages, TRUE);
    return status;
} /* snarf_sink_process_message */

gpointer
snarf_sink_poll(
    void *data)
{
    snarf_sink_t *sink = (snarf_sink_t *) data;
    gboolean       rc;
    zmq_pollitem_t poll_item = { sink->socket, -1, ZMQ_POLLIN, 0 };

    g_debug("snarf_sink_poll");

    do
    {
        g_debug("+poll");
        rc = zmq_poll(&poll_item, 1, SNARF_SINK_POLL_TIMEOUT);
        g_debug("-poll");
        if (rc)
        {
            if (rc == -1)
            {
                g_debug("zmq_poll -1, errno: %d", errno);
            }
            if (poll_item.revents & ZMQ_POLLIN)
            {
                if (snarf_sink_process_message(sink))
                {
                    g_critical("error processing alert message");
                }
            }
        }
    } while (! sink->terminate);

    return NULL;

} /* snarf_sink_poll */


int
snarf_sink_process(
    snarf_sink_t *sink)
{
    GError *err = NULL;

    sink->thread = g_thread_try_new("snarf_sink_poll", (GThreadFunc) snarf_sink_poll, (void *) sink, &err);

    if (err)
    {
        g_error("%s", err->message);
        return 1;
    }
    return 0;
} /* snarf_sink_process */


void
snarf_sink_destroy(snarf_sink_t *sink)
{

    g_debug("snarf_sink_destroy");

    sink->terminate = 1;
    g_thread_join(sink->thread);


    if (sink->callbacks)
    {
        if (sink->callbacks->destroy_fn)
        {
            sink->callbacks->destroy_fn(&(sink->sinkctx));
        }
        g_free(sink->callbacks);
    }

    g_debug("closing socket");
    if (sink->socket)
    {
        zmq_close(sink->socket);
    }
    g_debug("socket closed");

    g_free(sink);

    g_debug("sink destroyed");

} /* snarf_sink_destroy */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
