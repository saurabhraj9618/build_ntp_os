/*
 * sink.h
 * Structured Network Alert Reporting Framework Alert Sink Implementation
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

//#include <zmq.h>
#include "snarf.h"
#include "sink_json.h"
#include "sink_cef.h"
#include "sink_email.h"

#define SNARF_SINK_LOG_DOMAIN "snarf.sink"

extern void *zmq_ctx;

struct snarf_sink_callbacks_st
{
    snarf_sink_init_fn_t    init_fn;
    snarf_sink_alert_fn_t   process_fn;
    snarf_sink_destroy_fn_t destroy_fn;
};

typedef struct snarf_sink_callbacks_st snarf_sink_callbacks_t;


/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
