/*
 * sink_cef.c
 * Structured Network Alert Reporting Framework Common Event Format (CEF)
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2012-2014 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#include "sink.h"
/* #define G_LOG_DOMAIN SNARF_SINK_LOG_DOMAIN */

#include <snarf/snarf.h>
#include <glib.h>
#include <syslog.h>

#include "sink_cef.h"


#define CEF_OUTPUT_BUFFER_LEN 1024

#define DEFAULT_SYSLOG_IDENT "snarf"
#define DEFAULT_SYSLOG_FACILITY LOG_USER
#define DEFAULT_SYSLOG_PRIORITY LOG_WARNING

typedef struct cef_context_st
{
    GNode *config;
    int   use_syslog;
    char *syslog_ident;
    int   syslog_facility;
    int   syslog_priority;
    int   syslog_pid;
    GPtrArray *fields;
    void *sig_id_field;
    void *name_field;
} cef_context_t;

typedef struct cef_syslog_facility_map_st {
    char *label;
    int id;
} cef_syslog_facility_map_t;

static cef_syslog_facility_map_t syslog_facility_map[] = {
    { "user", LOG_USER },
    { "local0", LOG_LOCAL0 },
    { "local1", LOG_LOCAL1 },
    { "local2", LOG_LOCAL2 },
    { "local3", LOG_LOCAL3 },
    { "local4", LOG_LOCAL4 },
    { "local5", LOG_LOCAL5 },
    { "local6", LOG_LOCAL6 },
    { "local7", LOG_LOCAL7 },
    { NULL, 0}
};


static int default_priority_map[] = {
    LOG_NOTICE,
    LOG_WARNING,
    LOG_ERR,
    LOG_CRIT,
    LOG_ALERT
};

void add_field(
    GNode   *node,
    gpointer data)
{
    GNode *typenode, *valnode;
    GPtrArray *fields = (GPtrArray *) data;

    g_assert(node && g_node_first_child(node));
    typenode = g_node_first_child(g_node_first_child(node));
    g_assert(typenode);
    valnode = g_node_first_child(typenode);
    g_assert(valnode);
    g_debug("field: [%s] => [%s] [%s]", (char *)node->data, (char *)typenode->data,  (char *)valnode->data);
    g_ptr_array_add(fields, node);

}

void load_fields(GNode *root, cef_context_t *ctx)
{
    ctx->fields = g_ptr_array_new();

    if (! (root && g_node_first_child(root))) return;

    g_node_children_foreach(root,
                            G_TRAVERSE_ALL,
                            add_field,
                            ctx->fields);
}

void load_syslog(GNode *root, cef_context_t *ctx)
{
    char *val;

    val = (char *)snarf_get_config_value(root, "enabled");
    if (val && !g_ascii_strncasecmp(val, "true", strlen(val)))
    {
        ctx->use_syslog = TRUE;
    }

    val = (char *)snarf_get_config_value(root, "facility");
    if (val)
    {
        int i;
        for (i=0; syslog_facility_map[i].label != NULL; i++)
        {
            if (!g_ascii_strncasecmp(val,
                                     syslog_facility_map[i].label, strlen(val)))
            {
                ctx->syslog_facility = syslog_facility_map[i].id;
                break;
            }
        }
    }
}

char *get_envelope_field(GNode *root, char *key)
{
    GNode *node, *namenode, *valnode;
    char *ret = NULL;
    node = snarf_find_config_key(root, key);
    if (node)
    {
        g_assert(node && g_node_first_child(node));
        namenode = g_node_first_child(g_node_first_child(node));
        g_assert(namenode);
        valnode = g_node_first_child(namenode);
        g_assert(valnode);
        g_debug("envelope field: [%s] = [%s]",(char *)namenode->data,
                (char *)valnode->data);
        ret = (char *)valnode->data;
    }
    return ret;
}

void load_envelope(GNode *root, cef_context_t *ctx)
{
    char *val;

    ctx->sig_id_field = get_envelope_field(root, "sig_id_field");
    ctx->name_field = get_envelope_field(root, "name_field");
}



snarf_sink_callback_status_t
snarf_sink_cef_init(void **sinkctx, void *config)
{
    GNode *cfg = (GNode *) config;
    cef_context_t *ctx = g_new0(cef_context_t, 1);
    GNode *node = NULL;

    g_debug("snarf_sink_cef_init");

    ctx->config = config;

    ctx->syslog_ident = DEFAULT_SYSLOG_IDENT;
    ctx->syslog_facility = DEFAULT_SYSLOG_FACILITY;
    ctx->syslog_priority = DEFAULT_SYSLOG_PRIORITY;
    ctx->use_syslog = FALSE;

    if (!config)
    {
        g_critical("couldn't load CEF sink configuration from config file");
        return SNARF_SINK_CALLBACK_ERROR;
    }

    node = snarf_find_config_key(config, "fields");
    if (node && g_node_first_child(node))
        load_fields(g_node_first_child(node), ctx);
    node = snarf_find_config_key(config, "syslog");
    if (node && g_node_first_child(node))
        load_syslog(node, ctx);
    node = snarf_find_config_key(config, "envelope");
    if (node && g_node_first_child(node))
        load_envelope(g_node_first_child(node), ctx);
    g_debug("syslog: ident=%s, %d, %d", ctx->syslog_ident,
            ctx->syslog_priority,
            ctx->syslog_facility);

    openlog(ctx->syslog_ident, 1, ctx->syslog_facility);
    *sinkctx = (void *) ctx;

    return SNARF_SINK_CALLBACK_OK;

} /* snarf_sink_cef_init */

snarf_sink_callback_status_t
snarf_sink_cef_destroy(void **sinkctx)
{
    cef_context_t *ctx = (cef_context_t *) *sinkctx;

    g_debug("snarf_sink_cef_destroy");
    closelog();
    g_free(ctx);
    return SNARF_SINK_CALLBACK_OK;
} /* snarf_sink_cef_destroy */


void print_tagval(snarf_alert_t *alert,
                  char *tagname,
                  snarf_output_buffer_t *outbuf)
{
    char *tagval = NULL;
    if (tagname)
    {
        tagval = snarf_alert_get_analysis_tag(alert, tagname);
    }

    if (tagval)
    {
        snarf_alert_print_string(outbuf, tagval);
    }
    else
    {
        snarf_alert_print_analysis_tags(outbuf, alert);
    }
}

snarf_sink_callback_status_t
snarf_sink_cef_process(void *sinkctx, snarf_alert_t *alert)
{
    snarf_value_t         *value;
    cef_context_t         *ctx = (cef_context_t *) sinkctx;
    snarf_output_buffer_t *outbuf;
    int field_num = 0;
    GNode *fieldnode, *typenode, *valnode;

    outbuf = snarf_output_buffer_new(CEF_OUTPUT_BUFFER_LEN);
    snarf_output_buffer_set_format(outbuf, SNARF_OUTPUT_BUFFER_DELIMITED);
    snarf_output_buffer_set_severity_format(outbuf,
                                            SNARF_OUTPUT_SEVERITY_FORMAT_INT);
    snarf_output_buffer_set_timestamp_format(
        outbuf,
        SNARF_OUTPUT_TIMESTAMP_FORMAT_EPOCHMSEC);

    snarf_output_buffer_set_elapsed_format(
        outbuf,
        SNARF_OUTPUT_ELAPSED_FORMAT_MSEC);

    snarf_output_buffer_set_delimiter(outbuf, '|');
    /* header */
    snarf_alert_print_string(outbuf, "CEF:0");
    /* vendor  -- hard-coding this for now */
    snarf_alert_print_string(outbuf, "org.cert.netsa");
    /* product */
    snarf_alert_print_envelope_field(outbuf, alert, "generator");
    /* version */
    snarf_alert_print_envelope_field(outbuf, alert, "generator_version");
    /* "signature ID" */

    print_tagval(alert, ctx->sig_id_field, outbuf);
    print_tagval(alert, ctx->name_field, outbuf);

    /* severity */
    snarf_alert_print_envelope_field(outbuf, alert, "severity");
    snarf_output_buffer_set_delimiter(outbuf, ' ');


    for (field_num=0; field_num < ctx->fields->len; field_num++)
    {
        GNode *fieldnode = g_ptr_array_index(ctx->fields, field_num);
        char *field, *type, *val;
        field = (char *)fieldnode->data;
        g_assert(fieldnode && g_node_first_child(fieldnode));
        typenode = g_node_first_child(g_node_first_child(fieldnode));
        g_assert(typenode);
        type = (char *)typenode->data;
        valnode = g_node_first_child(typenode);
        g_assert(valnode);
        val = (char *)valnode->data;
        g_debug("field: [%s] => [%s] [%s]", field, type,  val);
        if (!strcmp(type, "field"))
        {
            value = snarf_alert_field_value(alert, val, 0);
            if (!value) continue;
            snarf_alert_print_string_raw(outbuf, field);
            snarf_alert_print_string_raw(outbuf, "=");
            snarf_alert_print_value(outbuf, value);
        }
        else if (!strcmp(type, "flow"))
        {
            value = snarf_alert_field_value(alert, "flow", 0);
            if (!value) continue;
            snarf_alert_print_string_raw(outbuf, field);
            snarf_alert_print_string_raw(outbuf, "=");
            /* ugly hack for ICMP type and code mashed together */
            if ( !strcmp(val, "icmp_type_code"))
            {
                snarf_output_buffer_set_format(outbuf, SNARF_OUTPUT_BUFFER_RAW);
                snarf_alert_print_flow_field(outbuf, value, "icmp_type");
                snarf_alert_print_string_raw(outbuf, ",");
                snarf_output_buffer_set_format(outbuf,
                                               SNARF_OUTPUT_BUFFER_DELIMITED);
                snarf_alert_print_flow_field(outbuf, value, "icmp_code");
            }
            else
            {
                snarf_alert_print_flow_field(outbuf, value, val);
            }
        }
        else if (!strcmp(type, "string"))
        {
            snarf_alert_print_string_raw(outbuf, field);
            snarf_alert_print_string_raw(outbuf, "=");
            snarf_alert_print_string(outbuf, val);
        }
        else
        {
            g_critical("unknown field type: %s", type);
        }
    }

    if (ctx->use_syslog)
    {
        int priority;
        if (ctx->syslog_priority)
        {
            priority = ctx->syslog_priority;
        }
        else
        {
            priority = default_priority_map[snarf_alert_severity(alert)-1];
            g_debug("alert priority: %d, syslog priority: %d", snarf_alert_severity(alert), priority);
        }
        syslog(priority, "%s", snarf_output_buffer_contents(outbuf));

    }
    else
    {
        snarf_alert_print_string_raw(outbuf, "\n");
        g_print("%s", snarf_output_buffer_contents(outbuf));
    }
    snarf_output_buffer_free(outbuf);

    return SNARF_SINK_CALLBACK_OK;
} /* snarf_sink_cef_process */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
