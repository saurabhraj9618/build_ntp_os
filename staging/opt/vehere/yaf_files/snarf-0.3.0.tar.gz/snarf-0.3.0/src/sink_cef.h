/*
 * sink_cef.h
 * Structured Network Alert Reporting Framework Common Event Format (CEF)
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#ifndef _SNARF_SINK_CEF_H_
#define _SNARF_SINK_CEF_H_

#include <snarf/snarf.h>
#include <syslog.h>


#define SNARF_SINK_CEF_SIP_LABEL            "src"
#define SNARF_SINK_CEF_DIP_LABEL            "dst"
#define SNARF_SINK_CEF_SPORT_LABEL          "spt"
#define SNARF_SINK_CEF_DPORT_LABEL          "dpt"
#define SNARF_SINK_CEF_PROTO_LABEL          "proto"
#define SNARF_SINK_CEF_PACKETS_LABEL        "fsize" /* "file size", for some
                                                     *reason */
#define SNARF_SINK_CEF_BYTES_LABEL          "in" /* "bytes in" */
#define SNARF_SINK_CEF_FLAGS_LABEL          "filePermission" /* ??? */
#define SNARF_SINK_CEF_STIME_LABEL          "start"
#define SNARF_SINK_CEF_ETIME_LABEL          "end"
#define SNARF_SINK_CEF_ELAPSED_LABEL        "cn1" /* "deviceCustomNumber1" */
#define SNARF_SINK_CEF_SENSOR_NAME_LABEL    "deviceHostname"
#define SNARF_SINK_CEF_FLOW_CLASS_LABEL     "deviceDomain"
#define SNARF_SINK_CEF_FLOW_TYPE_LABEL      "deviceDirection"
#define SNARF_SINK_CEF_FLAGS_INITIAL_LABEL  "fileName"  /* ??? */
#define SNARF_SINK_CEF_APPLICATION_ID_LABEL "applicationProtocol"

snarf_sink_callback_status_t
snarf_sink_cef_init(
    void **sinkconfig,
    void  *config);

snarf_sink_callback_status_t
snarf_sink_cef_process(
    void          *sinkconfig,
    snarf_alert_t *alert);

snarf_sink_callback_status_t
snarf_sink_cef_destroy(
    void **sinkconfig);


#endif /* ifndef SINK_CEF */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
