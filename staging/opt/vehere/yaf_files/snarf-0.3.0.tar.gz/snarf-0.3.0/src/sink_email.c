/*
 * sink_email.c
 * Structured Network Alert Reporting Framework Common Event Format (email)
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#include <snarf/snarf.h>
#include <glib.h>

#include "sink_email.h"
#include "alert_priv.h"

#define DEFAULT_FROM "snarf"
#define DEFAULT_TO "root"
#define DEFAULT_SUBJECT_PREFIX "Network Alert"

typedef struct email_context_st
{
    GNode *config;
    char *from;
    char *to;
    char *subject_prefix;
    gboolean sms_format;
} email_context_t;

static gboolean
send_email(const char *from,
           const char *to,
           const char *subject,
           const char *body)
{
    gchar      *mailcmd[3];
    GPid        pid;
    GIOChannel *sendmail_input;
    GIOStatus   status;

    GError *err = NULL;
    GString *msg = g_string_new("");
    gint fd=0;
    gsize written=0;

    mailcmd[0] = SENDMAIL_PATH;
    mailcmd[1] = g_strdup(to);
    mailcmd[2] = NULL;

    //    g_debug("send_email: %s", body);
    if (!g_spawn_async_with_pipes(NULL, mailcmd, NULL,
                                  G_SPAWN_DO_NOT_REAP_CHILD,
                                  NULL, NULL,
                                  &pid, &fd,
                                  NULL, NULL, &err))
    {
        g_critical("Could not start sendmail: %s", err->message);
        g_error_free(err);
        return FALSE;
    }

    sendmail_input = g_io_channel_unix_new (fd);
    g_io_channel_set_encoding(sendmail_input, NULL, &err);
    g_io_channel_set_buffered(sendmail_input, FALSE);

    g_string_append_printf(msg,
                           "From: %s\n"
                           "To: %s\n"
                           "Subject: %s\n"
                           "\n\n"
                           "%s"
                           "\n",
                           from,
                           to,
                           subject,
                           body);
    //    g_debug("message: %s", msg->str);
    status = g_io_channel_write_chars (sendmail_input, msg->str, msg->len,
                                       &written, &err);
    if (status != G_IO_STATUS_NORMAL)
    {
        g_critical("write error: %d", status);
    }
    if (err)
    {
        g_critical("error writing data: %s", err->message);
        return FALSE;
    }

    g_io_channel_shutdown(sendmail_input, TRUE, &err);
    waitpid(pid, NULL, 0);
    g_spawn_close_pid(pid);
    return TRUE;
} /* send_email */

snarf_sink_callback_status_t
snarf_sink_email_init(void **sinkctx, void *config)
{
    GNode          *cfg         = (GNode *) config;
    email_context_t *ctx = g_new0(email_context_t, 1);
    char *value = NULL;

    ctx->config = config;

    g_debug("snarf_sink_email_init");
    if (config)
    {
        value = (char *)snarf_get_config_value(config, "from");
        if (value)
        {
            ctx->from = g_strdup(value);
        }
        else
        {
            ctx->from = g_strdup(DEFAULT_FROM);
        }

        value = (char *)snarf_get_config_value(config, "to");
        if (value)
        {
            ctx->to = g_strdup(value);
        }
        else
        {
            ctx->to = g_strdup(DEFAULT_TO);
        }

        value = (char *)snarf_get_config_value(config, "subject_prefix");
        if (value)
        {
            ctx->subject_prefix = g_strdup(value);
        }
        else
        {
            ctx->subject_prefix = g_strdup(DEFAULT_SUBJECT_PREFIX);
        }

        value = (char *)snarf_get_config_value(config, "sms_format");
        if (value && !g_ascii_strncasecmp(value, "true", strlen(value)))
            ctx->sms_format = TRUE;
        else
            ctx->sms_format = FALSE;
    }
    else
    {
        ctx->sms_format = FALSE;
        ctx->from = g_strdup(DEFAULT_FROM);
        ctx->to = g_strdup(DEFAULT_TO);
        ctx->subject_prefix = g_strdup(DEFAULT_SUBJECT_PREFIX);
    }

    *sinkctx    = (void *) ctx;
    return SNARF_SINK_CALLBACK_OK;
} /* snarf_sink_email_init */

snarf_sink_callback_status_t
snarf_sink_email_destroy(void **sinkctx)
{
    email_context_t *ctx = (email_context_t *) *sinkctx;

    g_debug("snarf_sink_email_destroy");
    if (ctx->from)
    {
        g_free(ctx->from);
    }
    if (ctx->to)
    {
        g_free(ctx->to);
    }
    if (ctx->subject_prefix)
    {
        g_free(ctx->subject_prefix);
    }

    g_free(ctx);
    return SNARF_SINK_CALLBACK_OK;
} /* snarf_sink_email_destroy */


#define EMAIL_OUTPUT_BUFFER_LEN 1024

snarf_sink_callback_status_t
snarf_sink_email_process(void *sinkctx, snarf_alert_t *alert)
{
    email_context_t *ctx = (email_context_t *) sinkctx;
    snarf_output_buffer_t *outbuf, *subjbuf;

    g_debug("snarf_sink_email_process");

    outbuf = snarf_output_buffer_new(EMAIL_OUTPUT_BUFFER_LEN);
    subjbuf = snarf_output_buffer_new(EMAIL_OUTPUT_BUFFER_LEN);

    snarf_output_buffer_set_format(outbuf, SNARF_OUTPUT_BUFFER_JSON);
    snarf_output_buffer_set_format(subjbuf, SNARF_OUTPUT_BUFFER_RAW);
    snarf_output_buffer_set_severity_format(subjbuf,
                                            SNARF_OUTPUT_SEVERITY_FORMAT_NAME);

    snarf_alert_print_string_raw(subjbuf, ctx->subject_prefix);
    snarf_alert_print_string_raw(subjbuf, ": [");
    snarf_alert_print_envelope_field(subjbuf, alert, "timestamp");
    snarf_alert_print_string_raw(subjbuf, " ");
    snarf_alert_print_envelope_field(subjbuf, alert, "severity");
    snarf_alert_print_string_raw(subjbuf, "] ");
    snarf_alert_print_analysis_tags(subjbuf, alert);

    snarf_alert_print(outbuf, alert);

    if (ctx->sms_format)
    {
        send_email(ctx->from, ctx->to,
                   snarf_output_buffer_contents(subjbuf),
                   snarf_output_buffer_contents(subjbuf));
    }
    else
    {
        send_email(ctx->from, ctx->to,
                   snarf_output_buffer_contents(subjbuf),
                   snarf_output_buffer_contents(outbuf));
    }
    snarf_output_buffer_free(outbuf);
    snarf_output_buffer_free(subjbuf);

    return SNARF_SINK_CALLBACK_OK;
} /* snarf_sink_email_process */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
