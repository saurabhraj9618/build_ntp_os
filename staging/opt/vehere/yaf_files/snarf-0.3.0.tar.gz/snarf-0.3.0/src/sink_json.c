/*
 * sink_json.c
 * Structured Network Alert Reporting Framework JSON Sink
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#include <snarf/snarf.h>
#include <glib.h>

#include "sink_json.h"
#include "alert_priv.h"

#define JSON_OUTPUT_BUFFER_LEN 1024

typedef struct json_context_st
{
    GNode      *config;
    char       *output_file;
    GIOChannel *output_channel;
} json_context_t;

snarf_sink_callback_status_t
snarf_sink_json_init(void **sinkctx, void *config)
{
    GError         *err         = NULL;
    GNode          *cfg         = (GNode *) config;
    json_context_t *ctx         = g_new0(json_context_t, 1);
    char           *output_file = NULL;

    ctx->config = config;

    if (config)
    {
        output_file = (char *)snarf_get_config_value(config, "output_file");
    }

    if (output_file)
    {
        ctx->output_file = g_strdup(output_file);
        ctx->output_channel = g_io_channel_new_file(ctx->output_file,
                                                    "a", &err);
    }
    else
    {
        ctx->output_channel = g_io_channel_unix_new(fileno(stdout));
    }

    *sinkctx = (void *) ctx;
    return SNARF_SINK_CALLBACK_OK;
} /* snarf_sink_json_init */

snarf_sink_callback_status_t
snarf_sink_json_destroy(void **sinkctx)
{
    GError         *err = NULL;
    json_context_t *ctx = (json_context_t *) *sinkctx;

    if (g_io_channel_get_buffered(ctx->output_channel))
    {
        g_io_channel_flush(ctx->output_channel, &err);
        g_assert(!err);
    }
    if (ctx->output_file)
        g_free(ctx->output_file);

    g_io_channel_shutdown(ctx->output_channel, TRUE, &err);
    g_assert(!err);
    g_free(ctx);
    return SNARF_SINK_CALLBACK_OK;
} /* snarf_sink_json_destroy */


snarf_sink_callback_status_t
snarf_sink_json_process(void *sinkctx, snarf_alert_t *alert)
{
    json_context_t        *ctx = (json_context_t *) sinkctx;
    GError                *err = NULL;
    GIOStatus              status;
    gsize                  bytes_written;
    snarf_output_buffer_t *outbuf;

    outbuf = snarf_output_buffer_new(JSON_OUTPUT_BUFFER_LEN);
    snarf_output_buffer_set_format(outbuf, SNARF_OUTPUT_BUFFER_JSON);
    snarf_output_buffer_set_elapsed_format(
        outbuf,
        SNARF_OUTPUT_ELAPSED_FORMAT_MSEC);

    snarf_alert_print(outbuf, alert);
    status = g_io_channel_write_chars(ctx->output_channel,
                                      snarf_output_buffer_contents(outbuf),
                                      snarf_output_buffer_length(outbuf),
                                      &bytes_written,
                                      &err);
    snarf_output_buffer_free(outbuf);
    return SNARF_SINK_CALLBACK_OK;

} /* snarf_sink_json_process */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
