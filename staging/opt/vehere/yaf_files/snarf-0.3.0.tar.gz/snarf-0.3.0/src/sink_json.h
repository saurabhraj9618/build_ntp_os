/*
 * sink_json.c
 * Structured Network Alert Reporting Framework JSON Sink
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#ifndef _SNARF_SINK_JSON_H_
#define _SNARF_SINK_JSON_H_

#include <snarf/snarf.h>

snarf_sink_callback_status_t
snarf_sink_json_init(
    void **sinkconfig,
    void  *config);

snarf_sink_callback_status_t
snarf_sink_json_process(
    void          *sinkconfig,
    snarf_alert_t *alert);

snarf_sink_callback_status_t
snarf_sink_json_destroy(
    void **sinkconfig);


#endif /* ifndef _SNARF_SINK_JSON_H_ */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
