/*
** snarf.c
** Structured Network Alert Reporting Library Implementation
**
** ------------------------------------------------------------------------
** Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov <tonyc@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
** ------------------------------------------------------------------------
*/

#include "snarf.h"
#include "source.h"
#include "sink.h"
#include "alert_priv.h"

#include <snarf/snarf.h>
#include <glib.h>
//#include "alert_priv.h"

/* The ZeroMQ context. */
void *zmq_ctx = NULL;

static GLogLevelFlags log_levels = G_LOG_FLAG_RECURSION | G_LOG_FLAG_FATAL
    | G_LOG_LEVEL_ERROR | G_LOG_LEVEL_CRITICAL | G_LOG_LEVEL_WARNING
    | G_LOG_LEVEL_MESSAGE;
static GLogLevelFlags no_log_levels = G_LOG_LEVEL_INFO | G_LOG_LEVEL_DEBUG;

void
snarf_init()
{
    char *debug = NULL;
    zmq_ctx = zmq_init(SNARF_ZMQ_THREADS);

    debug = getenv("SNARF_DEBUG");
    if (debug)
    {
        char domains[1024];

        log_levels |= G_LOG_LEVEL_INFO | G_LOG_LEVEL_DEBUG;
        no_log_levels &= G_LOG_LEVEL_INFO | G_LOG_LEVEL_DEBUG;

        /* g_snprintf(domains, 1024, "%s %s %s %s", SNARF_LOG_DOMAIN, */
        /*            SNARF_SOURCE_LOG_DOMAIN, */
        /*            SNARF_SINK_LOG_DOMAIN, */
        /*            SNARF_ALERT_LOG_DOMAIN); */
        g_setenv ("G_MESSAGES_DEBUG", "all", TRUE);
        g_debug("snarf debugging enabled");
    }

    g_log_set_handler(SNARF_LOG_DOMAIN, no_log_levels,
                      null_logger, NULL);
    g_log_set_handler(SNARF_LOG_DOMAIN, log_levels,
                      g_log_default_handler, NULL);

    g_log_set_handler(SNARF_SOURCE_LOG_DOMAIN, no_log_levels,
                      null_logger, NULL);
    g_log_set_handler(SNARF_SOURCE_LOG_DOMAIN, log_levels,
                      g_log_default_handler, NULL);

    g_log_set_handler(SNARF_SINK_LOG_DOMAIN, no_log_levels,
                      null_logger, NULL);
    g_log_set_handler(SNARF_SINK_LOG_DOMAIN, log_levels,
                      g_log_default_handler, NULL);

    g_log_set_handler(SNARF_ALERT_LOG_DOMAIN, no_log_levels,
                      null_logger, NULL);
    g_log_set_handler(SNARF_ALERT_LOG_DOMAIN, log_levels,
                      g_log_default_handler, NULL);

} /* snarf_init */

void *snarf_context()
{
    return zmq_ctx;
}

void
snarf_term()
{
    g_debug("snarf_term");
    if (zmq_term(zmq_ctx))
    {
        g_debug("zmq_term errno: %d", errno);
    }
} /* snarf_term */

uint64_t
snarf_get_current_timestamp()
{
    GTimeVal gtv;
    uint64_t res;

    g_get_current_time(&gtv);
    res = (1000 * 1000 * (uint64_t) gtv.tv_sec) + gtv.tv_usec;
    g_debug("get_current_timestamp: %" PRIu64, res);
    return res;
}

char *get_canonical_hostname()
{
    int gai_result;
    char hostname[1024];
    struct addrinfo hints, *info;
    char *canonical_hostname = NULL;
    gethostname(hostname, 1023);
    hostname[1023] = '\0';

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC; /*either IPV4 or IPV6*/
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_CANONNAME;

    if ( ((gai_result = getaddrinfo(hostname, NULL, &hints, &info)) != 0) || (info == NULL)) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(gai_result));
        canonical_hostname = g_strdup("unknown");
    }
    else
    {
        canonical_hostname = g_strdup(info->ai_canonname);
        freeaddrinfo(info);
    }
    return canonical_hostname;
}

void
null_logger(
    const char    *domain,
    GLogLevelFlags log_level,
    const char    *message,
    gpointer       user_data)
{
}

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
