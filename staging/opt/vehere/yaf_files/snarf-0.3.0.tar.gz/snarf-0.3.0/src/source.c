/*
 * source.c
 * Structured Network Alert Reporting Framework Implementation (source)
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2014 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

/* #define G_LOG_DOMAIN SNARF_SOURCE_LOG_DOMAIN */

#include <snarf/snarf.h>
#include "source.h"
#include "alert_priv.h"

#include <glib.h>
#include <glib/gstdio.h>


snarf_source_t *
snarf_source_init(char *source_name,
                  char *source_version,
                  char *destination)
{
    int                  rc;
    int             hwm = SNARF_HWM;
    int socket_linger_timeout = 1000;
    struct snarf_source *ctx = g_new0(struct snarf_source, 1);

    ctx->source_name    = g_strdup(source_name);
    ctx->source_version = g_strdup(source_version);

    destination = (destination ?
                   destination :
                   getenv(SNARF_ALERT_DESTINATION_ENV));

    if (getenv(SNARF_SOURCE_LINGER_ENV))
    {
        socket_linger_timeout = atoi(getenv(SNARF_SOURCE_LINGER_ENV));
    }
    if (destination)
    {
        g_debug("alerting remotely");
        ctx->dispatch_fn    = snarf_source_send_alert_remote;
        ctx->dest_socket    = zmq_socket(zmq_ctx, ZMQ_PUSH);
        if (!ctx->dest_socket)
        {
            g_error("Couldn't create ZMQ socket");
        }
        rc = zmq_setsockopt(ctx->dest_socket, ZMQ_RCVHWM, &hwm, sizeof (hwm));
        if (rc)
        {
            g_error("Couldn't set HWM");
        }
        rc = zmq_setsockopt(ctx->dest_socket,
                            ZMQ_LINGER,&socket_linger_timeout,
                            sizeof (socket_linger_timeout));
        if (rc)
        {
            g_error("Couldn't set ZMQ_LINGER");
        }
        /* zmq_setsockopt (source, ZMQ_IDENTITY, identity, strlen(identity));
        **/
        g_debug("connecting to %s", destination);
        rc = zmq_connect(ctx->dest_socket, destination);
        if (rc)
        {
            g_error("Couldn't connect to %s", destination);
        }
    }
    else
    {
        g_debug("alerting locally");
        ctx->dispatch_fn = snarf_source_send_alert_local;
    }
    return ctx;
} /* snarf_source_init */


#define PIPELINE_OUTPUT_BUFFER_LEN 1024

int
snarf_source_send_alert_local(
    snarf_source_t *source,
    char           *tags,
    snarf_alert_t  *alert)
{
    snarf_output_buffer_t *outbuf;
    g_debug("local alert, severity: %d", alert->envelope->severity);

    outbuf = snarf_output_buffer_new(PIPELINE_OUTPUT_BUFFER_LEN);
    snarf_output_buffer_set_format(outbuf, SNARF_OUTPUT_BUFFER_JSON);

    snarf_alert_set_generator(alert,
                              source->source_name,
                              source->source_version);
    snarf_alert_add_tags(alert, tags);
    snarf_alert_print(outbuf, alert);
    g_print("%s", snarf_output_buffer_contents(outbuf));
    snarf_output_buffer_free(outbuf);
    return 0;
}

int
snarf_source_send_alert_remote(
    snarf_source_t *source,
    char           *tags,
    snarf_alert_t  *alert)
{
    unsigned  len;
    void     *buf;
    zmq_msg_t msg;
    int       rc;

    /* Alert *ap = ((Alert *) alert); */

    snarf_alert_set_generator(alert,
                              source->source_name,
                              source->source_version);
    snarf_alert_add_tags(alert, tags);

    /* FIXME:  Look into using ProtobufCBuffer here */
    len = snarf_envelope__get_packed_size(alert->envelope);
    buf = g_malloc(len);
    snarf_envelope__pack(alert->envelope, buf);

    rc = zmq_msg_init_data(&msg,
                           buf,
                           len,
                           (void *)g_free,
                           NULL);
    if (rc)
    {
        g_critical("couldn't initialize envelope");
        return rc;
    }
    g_debug("sending envelope");
    rc = zmq_sendmsg(source->dest_socket, &msg, ZMQ_SNDMORE);
    if (rc == -1)
    {
        g_critical("couldn't send envelope message: %d", errno);
        return rc;
    }
    zmq_msg_close(&msg);

    len = snarf_alert_body__get_packed_size(alert->body);
    buf = g_malloc(len);
    snarf_alert_body__pack(alert->body, buf);


    rc = zmq_msg_init_data(&msg, buf, len, (void *)g_free, NULL);
    if (rc)
    {
        return rc;
    }

    g_debug("sending body");
    rc = zmq_sendmsg(source->dest_socket, &msg, 0);
    if (rc == -1)
    {
        g_critical("couldn't send body message: %d", errno);
        return rc;
    }

    zmq_msg_close(&msg);

    return 0;
} /* snarf_source_send_alert */



int snarf_source_send_alert(
    snarf_source_t *source,
    char           *tags,
    snarf_alert_t  *alert)
{
    int rc = 0;
    g_assert(source);
    g_debug("send");
    rc = source->dispatch_fn(source, tags, alert);
    snarf_alert_free(alert);
    return rc;
}

void
snarf_source_destroy(snarf_source_t *source)
{
    zmq_close(source->dest_socket);
    g_free(source->source_name);
    g_free(source->source_version);
    g_free(source);

} /* snarf_source_destroy */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
