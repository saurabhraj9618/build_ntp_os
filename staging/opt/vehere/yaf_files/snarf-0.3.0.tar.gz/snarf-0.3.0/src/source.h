/*
 * source.h
 *
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#ifndef _SOURCE_H_
#define _SOURCE_H_

#define SNARF_HWM          1024
#define SNARF_ENVELOPE_LEN 1024

#define SNARF_SOURCE_LOG_DOMAIN "snarf.source"

//#include <zmq.h>
#include "snarf.h"

extern void *zmq_ctx;
int
snarf_source_send_alert_remote(
    snarf_source_t *source,
    char           *tags,
    snarf_alert_t  *alert);

int
snarf_source_send_alert_local(
    snarf_source_t *source,
    char           *tags,
    snarf_alert_t  *alert);


typedef int (*snarf_source_alert_dispatch_fn_t)(snarf_source_t *source,
                                                char           *tags,
                                                snarf_alert_t  *alert);

struct snarf_source
{
    snarf_source_alert_dispatch_fn_t dispatch_fn;
    char *source_name;
    char *source_version;
    void *dest_socket;
    snarf_config_t *config;
    int debug;
};

#endif /* ifndef _SOURCE_H_ */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
