#!/usr/bin/env python

import unittest
import sys
import os
import signal
import time
import re
import subprocess
from threading import Thread, Lock, Timer, Event
import netsa_silk as ns

from snarf import *
from snarf.utils import *

SOCK1="ipc:///tmp/snarf_test_1"
SOCK2="ipc:///tmp/snarf_test_2"
SOCK3="ipc:///tmp/snarf_test_3"
SOCK4="ipc:///tmp/snarf_test_4"

if 'srcdir' in os.environ:
    confpath= "%s/tests" %(os.getenv('srcdir'))
else:
    confpath = "%s/tests" %(os.curdir)

class SnarfCProgram(object):
    def __init__(self, program, *args, **kwargs):
        self.args = [program]
        self.stopped = True
        self.name = kwargs.pop('name', type(self).__name__)
        self.env = os.environ
        self.env.update(kwargs.pop('env', {}))
        if 'srcdir' in os.environ:
            os.environ['PATH'] = "%s/utils:" %(os.getenv('srcdir')) + os.environ['PATH']
        self.args.extend(args)
        for arg in kwargs.keys():
            self.args.extend(["--%s" %(arg), kwargs[arg]])


    def start(self):
        args = self.args
        print "Starting: %s [%s]" % (self.name, self.args)
        self.process = subprocess.Popen(args, stdout=subprocess.PIPE, env=self.env)
        self.stopped = False
        print "Started"
        return self.process

    def wait(self):
        self.process.wait()

    def read_output(self):
        #(out, err) = self.process.communicate()
        out = ''.join(self.process.stdout.readlines())
        return out

    def kill(self):
        print "Killing", self.name
        if self.process and self.process.returncode is None:
            try:
                print "Sending SIGKILL to %s" %(self.name)
                os.kill(self.process.pid, signal.SIGKILL)
            except OSError:
                pass

    def stop(self):

        if self.stopped or self.process is None:
            return None
        print "Stopping %s" %(self.name)
        if self.process.returncode is None:
            try:
                print "Process is still running: Sending SIGTERM to pid %d" %(
                    self.process.pid)
                os.kill(self.process.pid, signal.SIGTERM)
                timer = Timer(10, self.kill)
                timer.start()
                (pid, status) = os.waitpid(self.process.pid, 0)
                print "Stopped: status = %d" %(status)
                timer.cancel()
            except OSError:
                pass
        else:
            print "Process is dead with a return status of %d" \
                %(self.process.returncode)
        self.stopped = True
        return self.process.returncode

class SnarfFoo(SnarfCProgram):

    def __init__(self, *args, **kwargs):
        super(SnarfFoo, self).__init__("foo", *args, **kwargs)

class Snarfd(SnarfCProgram):

    def __init__(self, *args, **kwargs):
        super(Snarfd, self).__init__("snarfd", *args, **kwargs)

class Snarfc(SnarfCProgram):

    def __init__(self, *args, **kwargs):
        source = kwargs.pop('source', None)
        sink = kwargs.pop('sink', None)

        super(Snarfc, self).__init__("snarfc", *args, **kwargs)

        if source:
            self.args.extend(['--source', source])
        if sink:
            self.args.extend(['--sink', sink])

class SourceTester(LoopThread):

    def __init__(self, destination, *args, **kwargs):
        super(SourceTester, self).__init__(*args, **kwargs)
        self.source = Source("org.cert.netsa.snarftest", "0.0.1",
                             destination=destination,
                             default_tags=["type=Evaluation"])

    def loop (self):
        a = Alert({'foo': 1})
        self.source.send(a, tags=["foo=bar"])


class SnarfTests(unittest.TestCase):
    progs = []

    def add_prog(self, prog):
        self.progs.append(prog)
        prog.start()

    def tearDown(self):
        for prog in reversed(self.progs):
            print "stopping %s" %(prog)
            prog.stop()
            time.sleep(1)

class SimpleLibsnarfTests(SnarfTests):
    def setUp(self):
        global confpath
        self.add_prog(Snarfd("-n",
                             env={'SNARF_CONFIG_FILE':
                                      "%s/snarfd1.conf" %(confpath)}))

    def test_basic(self):
        self.sink = Snarfc("--no-daemon", sink=SOCK2, sinkid="json",
                           env={'SNARF_CONFIG_FILE':
                                      "%s/snarfd1.conf" %(confpath)})
        #self.sink = SnarfFoo()
        self.source = Snarfc("--no-daemon", source=SOCK1, count="3",
                             env={'SNARF_CONFIG_FILE':
                                      "%s/snarfd1.conf" %(confpath)})
        self.sink.start()
        self.source.start()
        Timer(5, self.source.stop).start()
        Timer(5, self.sink.stop).start()
        out = self.sink.read_output()
        print out

class CompoundLibsnarfTests(SnarfTests):

    def setUp(self):
        global confpath
        self.add_prog(Snarfd("-n",
                             env={'SNARF_CONFIG_FILE':
                                      "%s/snarfd1.conf" %(confpath)}))

        self.add_prog(Snarfd("-n",
                             env={'SNARF_CONFIG_FILE':
                                      "%s/snarfd2.conf" %(confpath)}))

        time.sleep(1)

    def test_python_source_to_python_sink(self):
        def handle_sink(alert):
            print "[%s %s] %d %s\n%s\n" %(alert.get_generator(),
                                          alert.get_generator_version(),
                                          alert.get_severity(),
                                          alert.get_timestamp(),
                                          alert.get_fields_json())
            self.assertTrue(alert.get_fields()["foo"][0] == 1)

        self.sink = Sink(handle_sink, origin=SOCK4)
        self.sourcethread = SourceTester(SOCK1)
        self.sourcethread.start()
        time.sleep(5)
        self.sourcethread.stop()
        self.sink.stop()

    def test_snarfc_source_to_python_sink(self):
        def handle_sink(alert):
            print "[%s %s] %d %s\n%s\n" %(alert.get_generator(),
                                          alert.get_generator_version(),
                                          alert.get_severity(),
                                          alert.get_timestamp(),
                                          alert.get_fields_json())
            self.assertTrue('flow' in  alert.get_fields())
            print alert.get_fields()['flow']
            sip = alert.get_fields()['flow'][0].sip
            if type(sip) == ns.IPv4Addr:
                self.assertTrue(sip == ns.IPv4Addr("222.173.190.239"))
            elif type(sip) == ns.IPv6Addr:
                self.assertTrue(
                    sip == ns.IPv6Addr(
                        "dead:beef:cede:face:bead:deaf:fade:aced"))

        self.sink = Sink(handle_sink, origin=SOCK4)
        self.source = Snarfc(source=SOCK1)
        time.sleep(5)
        self.source.stop()
        self.sink.stop()



if __name__ == '__main__':
    unittest.main()

