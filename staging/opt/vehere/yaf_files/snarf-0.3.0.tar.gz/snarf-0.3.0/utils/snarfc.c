/*
 * snarfc.c
 * Snarf client for source / sink testing
 *
 * ------------------------------------------------------------------------
 * Copyright (C) 2011-2014 Carnegie Mellon University. All Rights Reserved.
 * ------------------------------------------------------------------------
 * Authors: Tony Cebzanov <tonyc@cert.org>
 * ------------------------------------------------------------------------
 * GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 * Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 * ------------------------------------------------------------------------
 */

#define G_LOG_DOMAIN "snarfc"

#include <snarf/snarf.h>
#include <glib.h>
#include <glib/gstdio.h>
#include <syslog.h>
#include "utils.h"

static GMainLoop *main_loop = NULL;
void             *context;

/* static char *config_file = NULL; */

static gboolean do_source     = FALSE;
static char    *source_socket = NULL;
static gboolean source_from_input = FALSE;

static gboolean do_sink     = FALSE;
static char    *sink_socket = NULL;

static char    *sink_id = "json";
static char    *sink_channel = "";
static int alert_count = 0;
static int source_interval = 2000;
static gboolean random_data = FALSE;
static char *pid_file = NULL;
static gboolean no_daemon = FALSE;

GScannerConfig scancfg;

static void snarfc_scanner_msg(
    GScanner *scanner,
    char     *message,
    gboolean  error)
{
    if (error) {
        g_critical("Error at line %u, position %u in expression: %s.",
                   scanner->line, scanner->position, message);
    } else {
        g_warning("Warning at line %u, position %u in expression: %s.",
                  scanner->line, scanner->position, message);
    }
} /* ipaquery_msg */

GScanner *snarfc_initialize_scanner()
{
    GScanner *scanner = NULL;

    /* configure scanner */
    scancfg.cset_skip_characters  = " \t\r\n";
    scancfg.cset_identifier_first = G_CSET_a_2_z
        G_CSET_A_2_Z
        G_CSET_LATINS
        G_CSET_LATINC
        "_=^";

    scancfg.cset_identifier_nth = G_CSET_a_2_z
        G_CSET_A_2_Z
        G_CSET_LATINS
        G_CSET_LATINC
        G_CSET_DIGITS
        "=_.,|^$*[]+\\";
    scancfg.cpair_comment_single  = "#\n";
    scancfg.case_sensitive        = 0;
    scancfg.skip_comment_multi    = 1;
    scancfg.skip_comment_single   = 1;
    scancfg.scan_comment_multi    = 0;
    scancfg.scan_identifier       = 1;
    scancfg.scan_identifier_1char = 0;
    scancfg.scan_identifier_NULL  = 0;
    scancfg.scan_symbols          = 1;
    scancfg.scan_binary           = 0;
    scancfg.scan_octal            = 0;
    scancfg.scan_float            = 0;
    scancfg.scan_hex              = 1;
    scancfg.scan_hex_dollar       = 0;
    scancfg.scan_string_sq        = 1;
    scancfg.scan_string_dq        = 1;
    scancfg.numbers_2_int         = 0;
    scancfg.int_2_float           = 0;
    scancfg.identifier_2_string   = 1;
    scancfg.char_2_token          = 1;
    scancfg.symbol_2_token        = 1;
    scancfg.scope_0_fallback      = 0;
    scancfg.store_int64           = 1;

    scanner = g_scanner_new(&scancfg);
    return scanner;
}



static gboolean
option_parse(const char *option_name,
             const char *value,
             gpointer    data,
             GError    **error)
{

    option_name += 2;

    if (!strcmp(option_name, "source"))
    {
        do_source     = TRUE;
        source_socket = g_strdup(value);
    }
    else if (!strcmp(option_name, "sink"))
    {
        do_sink     = TRUE;
        sink_socket = g_strdup(value);
    }
    else if (!strcmp(option_name, "sinkid"))
    {
        sink_id = g_strdup(value);
    }
    return TRUE;
} /* option_parse */

static GOptionEntry snarfc_optentries[] = {
    { "source",
      0,
      G_OPTION_FLAG_OPTIONAL_ARG, G_OPTION_ARG_CALLBACK,
      option_parse,
      "source socket", "socket" },
    { "source-interval",    0,
      0, G_OPTION_ARG_INT,
      &source_interval,
      "delay between alerts", "milliseconds"},
    { "source-from-input",    0,
      0, G_OPTION_ARG_NONE,
      &source_from_input,
      "emit alerts from input data", NULL},
    { "sink",
      0,
      G_OPTION_FLAG_OPTIONAL_ARG, G_OPTION_ARG_CALLBACK,
      option_parse,
      "sink socket", "socket" },
    { "sinkid",            0,
      0, G_OPTION_ARG_STRING,
      &sink_id,
      "sink identifier", "id" },
    { "channel",            0,
      0, G_OPTION_ARG_STRING,
      &sink_channel,
      "channel to subscribe to", "channel" },
    { "count",    'c',
      0, G_OPTION_ARG_INT,
      &alert_count,
      "send this many alerts", "count"},
    { "random-data",    'r',
      0, G_OPTION_ARG_NONE,
      &random_data,
      "randomize some data values", NULL},
    { "pidfile", 'p', 0,
      G_OPTION_ARG_STRING,
      &pid_file,
      "Write PID to FILE", "FILE" },
    { "no-daemon", 'n', 0,
      G_OPTION_ARG_NONE,
      &no_daemon,
      "Do not daemonize", NULL },
    { NULL }
};

static gboolean
snarfc_opt_parse(
    int   *argc,
    char **argv[])
{
    GOptionContext *octx = NULL;
    GError         *oerr = NULL;
    gboolean        rv   = FALSE;

    octx = g_option_context_new("snarfc");

    g_option_context_add_main_entries(octx, snarfc_optentries, NULL);

    g_option_context_parse(octx, argc, argv, &oerr);

    if (oerr)
    {
        g_critical("Couldn't parse command line: %s\nUse --help for usage.",
                   oerr->message);
    }
    g_option_context_free(octx);
    return rv;
} /* snarfc_opt_parse */


static void
signal_handler(int signo)
{
    if ((signo == SIGINT) || (signo == SIGTERM))
    {
        g_debug("Caught signal %d, shutting down...", signo);
        if (main_loop)
        {
            g_main_loop_quit(main_loop);
        }
    }
} /* signal_handler */

static void
setup_signals(void)
{
    struct sigaction action;
    sigset_t         mask;

    sigemptyset(&action.sa_mask);
    action.sa_handler = SIG_IGN;
    action.sa_flags   = 0;
    sigaction(SIGPIPE, &action, NULL);

    sigemptyset(&mask);
    action.sa_handler = signal_handler;
    action.sa_mask    = mask;
    action.sa_flags   = 0;
    sigaction(SIGTERM, &action, NULL);
    sigaction(SIGINT, &action, NULL);
} /* setup_signals */

guint64
get_current_timestamp()
{
    GTimeVal gtv;
    gchar   *str;

    g_get_current_time(&gtv);
    str = g_time_val_to_iso8601(&gtv);
    /* g_debug("time: %s", str); */
    g_free(str);
    return (1000 * 1000 * gtv.tv_sec) + gtv.tv_usec;
} /* get_current_timestamp */



gboolean
source_send_alert(gpointer data)
{
    snarf_source_t *source = (snarf_source_t *)data;
    static int alerts_sent = 0;
    uint16_t       sport=5555, dport=443, application_id=80;
    uint8_t        proto=6, flags=0x0F, flags_initial=0xF0;
    uint32_t       elapsed=8192, packets=12345, bytes=9876543;
    snarf_alert_severity_t severity = ALERT_HIGH;

    snarf_alert_t *alert;

    if (random_data)
    {
        severity = g_random_int_range (0, 10) - 4;

        elapsed = g_random_int ();

        sport = g_random_int_range(0, G_MAXUINT16);
        dport = g_random_int_range(0, G_MAXUINT16);

        proto = g_random_int_range(0, G_MAXUINT8);
        flags = g_random_int_range(0, G_MAXUINT8);
        flags_initial = g_random_int_range(0, G_MAXUINT8);

        packets = g_random_int ();
        bytes = g_random_int ();

    }

    /* g_debug("source_send_alert"); */

    alert = snarf_alert_new(severity,
                            snarf_get_current_timestamp());


    snarf_alert_add_text_field(alert,
                               "foo.bar",
                               "us");

    snarf_alert_add_text_field(alert,
                               "foo.bar",
                               "us");


    snarf_alert_add_text_field(alert,
                               "sip.cc",
                               "us");

    snarf_alert_add_text_field(alert,
                               "dip.cc",
                               "ca");

    {
        uint8_t *setdata;
        int      i = 0, j = 0;

        setdata = g_malloc(1024);
        for (i = 0; i < 1024; i++)
        {
            setdata[i] = (uint8_t) (j++ % 256);
        }

        snarf_alert_add_ipset_field(alert,
                                    "test.ipset",
                                    setdata, 1024);
        g_free(setdata);
    }

    /*    snarf_alert_add_int_field(alert, "test.int", -987654321); */

    /* g_debug("adding flow"); */


    if (g_random_int_range(0, 2))
    {
        struct sockaddr_in sipaddr, dipaddr;

        inet_pton(AF_INET, "10.1.1.1", &(sipaddr.sin_addr));
        inet_pton(AF_INET, "255.128.64.1", &(dipaddr.sin_addr));

        if (random_data)
        {
            uint32_t sip16, dip16;
            sip16 = g_random_int_range(0, G_MAXUINT16);
            dip16 = g_random_int_range(0, G_MAXUINT16);
            sipaddr.sin_addr.s_addr &= (G_MAXUINT16 << 16) | sip16;
            dipaddr.sin_addr.s_addr &= (G_MAXUINT16 << 16) | dip16;
        }

        snarf_alert_add_ip_field_v4(alert,
                                    "test.sip",
                                    GUINT32_FROM_BE(sipaddr.sin_addr.s_addr));

        snarf_alert_add_ip_field_v4(alert,
                                    "test.dip",
                                    GUINT32_FROM_BE(dipaddr.sin_addr.s_addr));

        snarf_alert_add_flow_v4(alert,
                                get_current_timestamp(), elapsed,
                                GUINT32_FROM_BE(sipaddr.sin_addr.s_addr),
                                GUINT32_FROM_BE(dipaddr.sin_addr.s_addr),
                                sport, dport,
                                proto,
                                packets, bytes,
                                flags, flags_initial,
                                application_id,
                                "sensor1",
                                "lan", "in");

        snarf_source_send_alert(source, "type:Evaluation, analysis:beacon", alert);
    }
    else
    {
        struct sockaddr_in6 sipaddr, dipaddr;

        inet_pton(AF_INET6, "dead:beef:cede:face:bead:deaf:fade:aced", &(sipaddr.sin6_addr));
        inet_pton(AF_INET6, "dead:beef:cede:face:bead:deaf:fade:aced", &(dipaddr.sin6_addr));

        if (random_data)
        {
            int i;

            for (i = 8; i < 15; i++) {
                sipaddr.sin6_addr.s6_addr[i] = g_random_int_range(0, G_MAXUINT8);
            }
            for (i = 8; i < 15; i++) {
                dipaddr.sin6_addr.s6_addr[i] = g_random_int_range(0, G_MAXUINT8);
            }
        }

        snarf_alert_add_ip_field_v6(alert,
                                    "test.sip",
                                    (uint8_t *)&(sipaddr.sin6_addr));

        snarf_alert_add_ip_field_v6(alert,
                                    "test.dip",
                                    (uint8_t *)&(dipaddr.sin6_addr));

        snarf_alert_add_flow_v6(alert, get_current_timestamp(), elapsed,
                                (uint8_t *)&(sipaddr.sin6_addr),
                                (uint8_t *) &(dipaddr.sin6_addr),
                                sport, dport,
                                proto,
                                packets, bytes,
                                flags, flags_initial,
                                application_id,
                                "sensor2",
                                "wan", "out");

        snarf_source_send_alert(source, "type:Evaluation, analysis:beacon", alert);
    }
    alerts_sent++;
    if (!alert_count || alerts_sent < alert_count)
    {
        return TRUE;
    }
    else
    {
        g_main_loop_quit(main_loop);
    }
    return TRUE;
} /* source_send_alert */


int
zmq_source(char *sock, char *identity)
{
    int i = 0;

    snarf_source_t *source;

    source = snarf_source_init("org.cert.netsa.pipeline", "0.0.1", sock);
    for (i=0; (!alert_count) || i < alert_count; i++)
    {
        source_send_alert(source);
        sleep(5);
    }
    printf("source end\n");
    snarf_source_destroy(source);
    return 0;
} /* zmq_source */


#define PIPELINE_OUTPUT_BUFFER_LEN 1024


typedef struct snarfc_config_st
{
    char       *alert_file;
} snarfc_config_t;

typedef struct snarfc_context_st
{
    snarfc_config_t *config;
    GIOChannel      *alert_channel;
} snarfc_context_t;

snarf_sink_callback_status_t
snarfc_sink_init(void **sinkctx, void *config)
{
    GError          *err = NULL;
    snarfc_config_t *cfg =
        (snarfc_config_t *) config;
    snarfc_context_t *ctx = g_new0(snarfc_context_t, 1);

    g_debug("snarfc_sink_init");

    ctx->config                 = g_new0(snarfc_config_t, 1);
    ctx->config->alert_file = g_strdup(cfg->alert_file);
    g_debug("opening %s", ctx->config->alert_file);
    ctx->alert_channel = g_io_channel_new_file(ctx->config->alert_file, "a", &err);

    *sinkctx = (void *) ctx;
    return SNARF_SINK_CALLBACK_OK;
} /* snarf_sink_pipeline_init */

snarf_sink_callback_status_t
snarfc_sink_destroy(void **sinkctx)
{
    GError          *err = NULL;
    snarfc_context_t *ctx = (snarfc_context_t *) *sinkctx;

    g_debug("snarfc_sink_destroy");
    g_debug("closing %s", ctx->config->alert_file);
    g_io_channel_shutdown(ctx->alert_channel, TRUE, &err);
    g_free(ctx->config);
    g_free(ctx);
    return SNARF_SINK_CALLBACK_OK;

} /* snarf_sink_pipeline_destroy */


snarf_sink_callback_status_t
snarfc_sink_process(void *sinkctx, snarf_alert_t *alert)
{
    snarf_value_t         *value;
    snarfc_context_t *ctx = (snarfc_context_t *) sinkctx;
    GError                *err = NULL;
    GIOStatus              status;
    gsize                  bytes_written;
    snarf_output_buffer_t *outbuf, *outbuf2;

    g_debug("snarfc_sink_process");

    outbuf = snarf_output_buffer_new(PIPELINE_OUTPUT_BUFFER_LEN);
    snarf_output_buffer_set_format(outbuf, SNARF_OUTPUT_BUFFER_DELIMITED);
    snarf_output_buffer_set_delimiter(outbuf, '|');
    snarf_output_buffer_set_tcp_flags_format(outbuf, SNARF_OUTPUT_TCP_FLAGS_FORMAT_VERBOSE);

    outbuf2 = snarf_output_buffer_new(PIPELINE_OUTPUT_BUFFER_LEN);
    snarf_output_buffer_set_format(outbuf2, SNARF_OUTPUT_BUFFER_DELIMITED);
    snarf_output_buffer_set_delimiter(outbuf2, '|');

    snarf_alert_print_envelope_field(outbuf, alert, "timestamp");

    snarf_alert_print_envelope_field(outbuf, alert, "severity");

    value = snarf_alert_field_value(alert, "flow", 0);
    if (value)
    {
        snarf_alert_print_flow_field(outbuf, value, "sip");
        snarf_alert_print_flow_field(outbuf, value, "dip");
        snarf_alert_print_flow_field(outbuf, value, "sport");
        snarf_alert_print_flow_field(outbuf, value, "dport");
        snarf_alert_print_flow_field(outbuf, value, "proto");
        snarf_alert_print_flow_field(outbuf, value, "packets");
        snarf_alert_print_flow_field(outbuf, value, "bytes");
        snarf_alert_print_flow_field(outbuf, value, "flags");
        snarf_alert_print_flow_field(outbuf, value, "stime");
        snarf_alert_print_flow_field(outbuf, value, "etime");
        snarf_alert_print_flow_field(outbuf, value, "elapsed");
        snarf_alert_print_flow_field(outbuf, value, "sensor_name");
        snarf_alert_print_flow_field(outbuf, value, "flow_class");
        snarf_alert_print_flow_field(outbuf, value, "flow_type");
        snarf_alert_print_flow_field(outbuf, value, "flags_initial");
        snarf_alert_print_flow_field(outbuf, value, "application_id");
    }

    value = snarf_alert_field_value(alert, "sip.cc", 0);
    if(value)
        snarf_alert_print_value(outbuf, value);

    value = snarf_alert_field_value(alert, "dip.cc", 0);
    if(value)
        snarf_alert_print_value(outbuf, value);

    value = snarf_alert_field_value(alert, "pipeline.list.SIP", 0);
    if (value)
        snarf_alert_write_ipset("foo.set", value);

    value = snarf_alert_field_value(alert, "test.ipset", 0);
    if (value)
        snarf_alert_write_ipset("bar.set", value);

    snarf_alert_print_string_raw(outbuf, "\n");

    status = g_io_channel_write_chars(ctx->alert_channel,
                                      snarf_output_buffer_contents(outbuf),
                                      snarf_output_buffer_length(outbuf),
                                      &bytes_written,
                                      &err);
    if (status != G_IO_STATUS_NORMAL)
    {
        g_critical("write failed (%d): %lu bytes written",
                   status,
                   bytes_written);
    }
    snarf_output_buffer_free(outbuf);
    return SNARF_SINK_CALLBACK_OK;
}

static gboolean
snarfc_process_input(GIOChannel *in,
                     GIOCondition condition,
                     gpointer data)
{
    gboolean rv = TRUE;
    GIOStatus status;
    gchar *input = NULL;
    GError *err = NULL;
    GScanner *scanner = NULL;

    switch (condition)
    {
      case G_IO_IN:
        break;
      case G_IO_ERR:
        g_critical("I/O error reading input");
        return FALSE;
      default:
        g_critical("unknown IO status: %d", status);
        return FALSE;
    }

    status = g_io_channel_read_line(in, &input, NULL, NULL, &err);
    switch (status)
    {
      case G_IO_STATUS_NORMAL:
        break;
      case G_IO_STATUS_EOF:
        g_debug("eof");
        rv = FALSE;
        g_main_loop_quit(main_loop);
        goto done;
      case G_IO_STATUS_ERROR:
      default:
        g_critical("I/O error reading input");
        return FALSE;
    }
    if (input == NULL)
    {
        rv = FALSE;
        goto done;
    }
    scanner = snarfc_initialize_scanner();
    g_scanner_input_text(scanner, input, strlen(input));
    do {
        switch (g_scanner_get_next_token(scanner)) {
          default:
          {
              g_critical("unknown token: %d\n", scanner->token);
              g_scanner_unexp_token(scanner, G_TOKEN_STRING, NULL, NULL,
                                    NULL, "unknown token in find",
                                    FALSE);
              break;
          }
        } /* switch g_scanner_get_next_token(scanner) */
        g_scanner_peek_next_token(scanner);
    } while (scanner->next_token != G_TOKEN_EOF
             && scanner->next_token != G_TOKEN_ERROR) ;


    g_print("%s", input);
  done:
    g_free(input);
    return rv;
}

int
main(int argc, char *argv[]) {

    snarf_source_t *source = NULL;
    snarf_sink_t   *sink = NULL;

    setup_signals();
    srandom((unsigned) time(NULL));

    snarfc_opt_parse(&argc, &argv);

    if (! no_daemon)
        daemonize(pid_file);

    snarf_init();

    /* config = snarf_load_config(config_file, "snarfc"); */

    main_loop = g_main_loop_new(NULL, FALSE);

    if (do_sink)
    {
        gchar **chanlist  = NULL;
        char   *chan      = NULL;
        gchar  **p        = NULL;

        sink = snarf_sink_init(sink_socket);

        if (!strcmp(sink_id, "custom"))
        {
            snarfc_config_t cfg;
            cfg.alert_file = "snarfc_alert.txt";
            g_return_val_if_fail(
                snarf_sink_configure_full(sink,
                                          snarfc_sink_init,
                                          snarfc_sink_process,
                                          snarfc_sink_destroy,
                                          &cfg),
                1);

        }
        else
        {
            g_return_val_if_fail(
                snarf_sink_configure(sink, sink_id), 1);
        }

        chanlist = g_strsplit_set(sink_channel, ",", 0);

        for (p = chanlist; p && *p; p++)
        {
            chan = *p;
            if (!strlen(chan))
            {
                continue;
            }
            snarf_sink_subscribe(sink, chan);
        }

        snarf_sink_process(sink);
    }

    if (do_source)
    {
        source = snarf_source_init("org.cert.netsa.snarfc",
                                   "0.0.1",
                                   source_socket);
        if (source_from_input)
        {
            GIOChannel *in = g_io_channel_unix_new (fileno(stdout));
            g_io_add_watch(in, G_IO_IN | G_IO_ERR, snarfc_process_input, NULL);

        }
        else
        {
            g_timeout_add(source_interval, source_send_alert, source);
        }
    }

    g_main_loop_run(main_loop);

    g_debug("sink: %x", sink);
    if (sink)
    {
        g_debug("destroy sink");
        snarf_sink_destroy(sink);
    }

    g_debug("source: %x", sink);
    if (source)
    {
        g_debug("destroy source");
        snarf_source_destroy(source);
    }

    g_debug("sink_socket: %x", sink_socket);
    if (sink_socket)
    {
        g_debug("free sink socket");
        g_free(sink_socket);
    }
    snarf_term();
    return 0;
} /* main */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
