/*
** snarfd.c
** Structured Network Alert Reporting Framework daemon
**
** ------------------------------------------------------------------------
** Copyright (C) 2011-2014 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov <tonyc@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
** ------------------------------------------------------------------------
*/

#define SNARFD_LOG_DOMAIN "snarfd"
#define G_LOG_DOMAIN SNARFD_LOG_DOMAIN

#include <snarf/snarf.h>
#include <snarf/route.h>
#include "utils.h"

static GLogLevelFlags log_levels = G_LOG_FLAG_RECURSION | G_LOG_FLAG_FATAL
    | G_LOG_LEVEL_ERROR | G_LOG_LEVEL_CRITICAL | G_LOG_LEVEL_WARNING
    | G_LOG_LEVEL_MESSAGE;
static GLogLevelFlags no_log_levels = G_LOG_LEVEL_INFO | G_LOG_LEVEL_DEBUG;

gboolean load_config(char *cfgfile);

typedef struct socket_def {
    char *name;
    void *handle;
    int type;
    char *endpoint;
    char *identity;
    char *channel;
    int hwm;
} socket_def_t;

typedef struct socket_info {
    GHashTable *sockets;
    GArray *poll_items;
} socket_info_t;

typedef struct route_def {
    void *insock;
    void *outsock;
    GPtrArray *generators;
    GPtrArray *tags;
    char *outchan;
} route_def_t;

static GMainLoop *main_loop = NULL;

void *context;

GNode *app_config = NULL;
static char *config_file = NULL;
static char *pid_file = NULL;
static gboolean no_daemon = FALSE;
//GList *routes;
GPtrArray *routes;

time_t last_cfg_mtime = 0;
int cfg_timer_source = 0;
socket_info_t socket_info;

static GHashTable *channel_stats = NULL;
static snarf_source_t *stats_source = NULL;
static char *stats_socket = NULL;
static int stats_interval;
static guint stats_source_id = 0;

static void
signal_handler(int signo)
{
    if ((signo == SIGINT) || (signo == SIGTERM))
    {
        g_debug("Caught signal %d, shutting down...", signo);
        g_idle_remove_by_data("poll_loop");
        g_main_loop_quit(main_loop);
    }
} /* signal_handler */

static void
setup_signals(void)
{
    struct sigaction action;
    sigset_t         mask;

    sigemptyset(&action.sa_mask);
    action.sa_handler = SIG_IGN;
    action.sa_flags   = 0;
    sigaction(SIGPIPE, &action, NULL);

    sigemptyset(&mask);
    action.sa_handler = signal_handler;
    action.sa_mask    = mask;
    action.sa_flags   = 0;
    sigaction(SIGTERM, &action, NULL);
    sigaction(SIGINT, &action, NULL);
} /* setup_signals */


static GOptionEntry option_entries[] =
    {
        { "config", 'c', 0,
          G_OPTION_ARG_STRING,
          &config_file,
          "Read options from config file FILE", "FILE" },
        { "pidfile", 'p', 0,
          G_OPTION_ARG_STRING,
          &pid_file,
          "Write PID to FILE", "FILE" },
        { "no-daemon", 'n', 0,
          G_OPTION_ARG_NONE,
          &no_daemon,
          "Do not daemonize", NULL },
        { NULL }
    };

static gboolean
snarfd_opt_parse(
    int   *argc,
    char **argv[])
{
    GOptionContext *octx = NULL;
    GError         *oerr = NULL;
    gboolean        rv   = FALSE;

    octx = g_option_context_new("snarfd");

    g_option_context_add_main_entries(octx, option_entries, NULL);

    g_option_context_parse(octx, argc, argv, &oerr);

    if (oerr)
    {
        g_critical("Couldn't parse command line: %s\nUse --help for usage.",
                   oerr->message);
    }
    g_option_context_free(octx);
    return rv;
} /* option_entries_opt_parse */



void print_config_node(
    GNode   *node,
    gpointer data)
{
    g_debug("node: %s", (char *)node->data);
}

void free_socket_def(gpointer data)
{
    socket_def_t *sock = (socket_def_t *) data;
    if (!sock) return;
    if (sock->endpoint) g_free(sock->endpoint);
    if (sock->identity) g_free(sock->identity);
    if (sock->channel) g_free(sock->channel);
    g_free(sock);
}

#define DEFAULT_HWM 1024

void add_socket(
    GNode   *node,
    gpointer data)
{
    GNode *attrnode, *valnode;
    GHashTable *ht = (GHashTable *) data;

    socket_def_t *socket = NULL;

    socket = g_new0(socket_def_t, 1);

    g_debug("socket name: [%s]", (char *)node->data);
    socket->name = g_strdup(node->data);

    g_node_children_foreach(node, G_TRAVERSE_ALL, print_config_node, NULL);

    attrnode = snarf_find_config_key(node, "type");
    if (!attrnode)
    {
        g_critical("Socket type not specified.");
        return;
    }
    valnode = g_node_first_child(attrnode);
    if (!g_ascii_strncasecmp(valnode->data, "pull", strlen(valnode->data))){
        socket->type = ZMQ_PULL;
    } else if (!g_ascii_strncasecmp(valnode->data, "pub", strlen(valnode->data))) {
        socket->type = ZMQ_PUB;
    } else if (!g_ascii_strncasecmp(valnode->data, "sub", strlen(valnode->data))) {
        socket->type = ZMQ_SUB;
    } else {
        g_critical("Invalid socket type: %s", (char *)attrnode->data);
    }

    attrnode = snarf_find_config_key(node, "endpoint");
    if (!attrnode)
    {
        g_critical("Socket endpoint not specified.");
        return;
    }
    valnode = g_node_first_child(attrnode);
    socket->endpoint = g_strdup(valnode->data);

    attrnode = snarf_find_config_key(node, "identity");
    if (attrnode)
    {
        valnode = g_node_first_child(attrnode);
        socket->identity = g_strdup(valnode->data);
    }

    attrnode = snarf_find_config_key(node, "channel");
    if (attrnode)
    {
        valnode = g_node_first_child(attrnode);
        socket->channel = g_strdup(valnode->data);
    }

    attrnode = snarf_find_config_key(node, "hwm");
    if (attrnode)
    {
        valnode = g_node_first_child(attrnode);
        socket->hwm = atoi(valnode->data);
    }
    else
    {
        socket->hwm = DEFAULT_HWM;
    }

    g_hash_table_insert(ht, node->data, socket);
}

void open_socket(gpointer key, gpointer value, gpointer data)
{
    socket_def_t *sock = (socket_def_t *) value;
    void *handle = zmq_socket(context, sock->type);
    GArray *poll_items = (GArray *) data;
    int rc;
    int linger = 0;
    GString *identity = g_string_new("");
    if (sock->identity)
    {
        identity = g_string_append(identity, sock->identity);
    }
    else
    {
        char *canonical_hostname = NULL;
        canonical_hostname = get_canonical_hostname();
        if (canonical_hostname)
        {
            g_string_append_printf(identity, "%s/",
                                              canonical_hostname);
            g_free(canonical_hostname);
        }
        g_string_append_printf(identity, "%s",sock->name);
    }
    sock->identity = g_strdup(identity->str);
    g_debug("setting %s identity to %s", sock->endpoint, sock->identity);
    rc = zmq_setsockopt (handle, ZMQ_IDENTITY, sock->identity, strlen(sock->identity));
    g_assert(!rc);
    g_string_free(identity, TRUE);
    if (sock->hwm)
    {
        unsigned int hwmtype = ZMQ_RCVHWM;
        if (sock->type == ZMQ_PULL)
        {
            hwmtype = ZMQ_SNDHWM;
        }
        g_debug("setting %s sndhwm to %llu", sock->endpoint, sock->hwm);
        rc = zmq_setsockopt (handle, ZMQ_SNDHWM, &(sock->hwm), sizeof(int));
        if (rc)
            g_critical("rc: %d, errno: %d", rc, errno);
        g_debug("setting %s rcvhwm to %llu", sock->endpoint, sock->hwm);
        rc = zmq_setsockopt (handle, ZMQ_RCVHWM, &(sock->hwm), sizeof(int));
        if (rc)
            g_critical("rc: %d, errno: %d", rc, errno);
    }
    rc = zmq_setsockopt (handle, ZMQ_LINGER, &linger, sizeof(linger));
    g_assert(!rc);

    switch(sock->type)
    {
      case ZMQ_SUB:
        {
            zmq_pollitem_t poll_item = {handle, -1, ZMQ_POLLIN, 0};
            if (sock->channel)
            {
                rc = zmq_setsockopt (handle, ZMQ_SUBSCRIBE, sock->channel, strlen(sock->channel));
                g_debug("subscribing %s to %s", sock->endpoint, sock->channel);
                g_assert(!rc);
            }
            g_debug("polling %s", sock->endpoint);
            g_array_append_val(poll_items, poll_item);
            g_debug("connecting to subscribe socket %s", sock->endpoint);
            rc = zmq_connect (handle, sock->endpoint);
            if (rc)
            g_critical("couldn't connect to subscribe socket %s (%s)",
                       sock->endpoint, strerror(errno));
        }
        break;
      case ZMQ_PULL:
        {
            zmq_pollitem_t poll_item = {handle, -1, ZMQ_POLLIN, 0};
            g_debug("polling pull socket %s", sock->endpoint);
            g_array_append_val(poll_items, poll_item);
        }
        /* fall-through */
      case ZMQ_PUB:
        g_debug("binding to publish socket %s", sock->endpoint);
        rc = zmq_bind (handle, sock->endpoint);
        if (rc)
            g_critical("couldn't bind to publish socket %s (%s)",
                       sock->endpoint, strerror(errno));
        break;
      default:
        g_critical("invalid socket type: %d", sock->type);
    }

    sock->handle = handle;
}

void dump_socket(gpointer key, gpointer value, gpointer data)
{
    socket_def_t *sock = (socket_def_t *) value;
    g_debug("socket %s: %d, %s", (char *)key, sock->type, (char *)sock->endpoint);
}

void close_socket(gpointer key, gpointer value, gpointer data)
{
    socket_def_t *sock = (socket_def_t *) value;
    zmq_close(sock->handle);
}

void close_sockets()
{
   g_hash_table_foreach(socket_info.sockets, close_socket, NULL);
}

void load_sockets(GNode *root)
{
    socket_info.sockets = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, free_socket_def);

    socket_info.poll_items = g_array_new(FALSE, TRUE, sizeof(zmq_pollitem_t));

    if (! (root && g_node_first_child(root))) return;

    g_node_children_foreach(root,
                            G_TRAVERSE_ALL,
                            add_socket,
                            socket_info.sockets);

    g_hash_table_foreach(socket_info.sockets, dump_socket, NULL);
    g_hash_table_foreach(socket_info.sockets, open_socket, socket_info.poll_items);
}

GPtrArray *build_rule_list(GNode *root, char *key)
{
    GNode *node = NULL, *anode = NULL;
    GPtrArray *list = NULL;
    GPatternSpec *pattern;

    node = snarf_find_config_key(root, key);
    if (!node)
    {
        g_debug("no %s rule", key);
        return NULL;
    }

    node = g_node_first_child(node);

    list = g_ptr_array_new();
    g_ptr_array_set_free_func(list, (GDestroyNotify) g_pattern_spec_free);
    for (anode = g_node_first_child(node); anode; anode = g_node_next_sibling(anode))
    {
        g_debug("anode: %s", (char *)anode->data);
        pattern = g_pattern_spec_new(anode->data);
        g_ptr_array_add (list, pattern);
    }
    return list;

}

void add_route(GNode *root, gpointer data)
{
    GPtrArray *routes = (GPtrArray *)data;
    GNode *node, *rnode, *anode;
    socket_def_t *insockdef, *outsockdef;
    char *insockspec, *outsockspec;
    void *insock, *outsock;
    GPtrArray *generators;
    GPtrArray *tags;
    char *outchan;
    route_def_t *route;


    node = snarf_find_config_key(root, "from");
    if (! (node = g_node_first_child(node)))
    {
        g_critical("empty input socket in route definition");
    }
    insockspec = node->data;
    g_debug("insock: %s", insockspec);

    insockdef = g_hash_table_lookup(socket_info.sockets, node->data);
    if (!insockdef)
        g_error("input socket not found");
    insock = insockdef->handle;

    node = snarf_find_config_key(root, "to");
    if (! (node = g_node_first_child(node)))
    {
        g_critical("empty output socket in route definition");
    }
    outsockspec = node->data;
    g_debug("outsock: %s", outsockspec);

    outsockdef = g_hash_table_lookup(socket_info.sockets, node->data);
    if (!outsockdef)
        g_error("input socket not found");
    outsock = outsockdef->handle;

    rnode = snarf_find_config_key(root, "rules");
    rnode = g_node_first_child(rnode);
    rnode = g_node_first_child(rnode);

    if (! rnode)
    {
        g_critical("route definition must contain rules entry");
    }

    for (anode = rnode; anode; anode = g_node_next_sibling(anode))
    {
        g_debug("rule node: %s", (char *)anode->data);
#if 1
        node = snarf_find_config_key(anode, "in");
        node = g_node_first_child(node);

        generators = build_rule_list(node, "generator");
        tags = build_rule_list(node, "tag");

        if (! (generators || tags))
        {
            g_critical("missing rule");
        }

        node = g_node_first_child(rnode);
        node = g_node_first_child(node);
        node = snarf_find_config_key(anode, "out");
        node = g_node_first_child(node);
        node = g_node_first_child(node);
        if (! node)
        {
            g_critical("missing output channel");
        }
        outchan = g_strdup(node->data);

        route = g_new0(route_def_t, 1);

        g_debug("route: %s, %s, %s", insockdef->endpoint, outsockdef->endpoint, outchan);
        route->insock = insock;
        route->generators = generators;
        route->tags = tags;
        route->outsock = outsock;
        route->outchan = outchan;
        g_ptr_array_add(routes, route);
#endif
    }
}

void dump_route(gpointer data, gpointer user_data)
{
    route_def_t *route = (route_def_t *)data;
    g_debug("route: %p,%p %p,%p", route->insock, route->insock,
            route->generators, route->tags);
}


void free_route(gpointer data)
{
    route_def_t *route = (route_def_t *) data;
    if (route->generators)
        g_ptr_array_free(route->generators, TRUE);

    if (route->tags)
        g_ptr_array_free(route->tags, TRUE);

}

void load_routes(GNode *root)
{

    if (routes)
        g_ptr_array_free(routes, TRUE);

    routes = g_ptr_array_new();
    g_ptr_array_set_free_func(routes, free_route);

    if (! (root && g_node_first_child(root))) return;

    g_node_children_foreach(g_node_first_child(root),
                            G_TRAVERSE_ALL,
                            add_route,
                            routes);

    g_ptr_array_foreach(routes, dump_route, NULL);
}


void dump_message(zmq_msg_t *message)
{
    //  Dump the message as text or binary
    char *data = zmq_msg_data(message);
    int size = zmq_msg_size(message);
    int is_text = 1;
    int char_nbr;
    for (char_nbr = 0; char_nbr < size; char_nbr++)
        if ((unsigned char) data [char_nbr] < 32
            ||  (unsigned char) data [char_nbr] > 127)
            is_text = 0;

    printf ("[%03d] ", size);
    for (char_nbr = 0; char_nbr < size; char_nbr++) {
        if (is_text)
            printf ("%c", data [char_nbr]);
        else
            printf ("%02X ", (unsigned char) data [char_nbr]);
    }
    printf ("\n");
}

#define SNARFD_POLL_TIMEOUT 1000 * 1000
gboolean poll_loop(void *data)
{
    zmq_pollitem_t *items = (zmq_pollitem_t *) socket_info.poll_items->data;
    /* g_debug("polling %d sockets", socket_info.poll_items->len); */
    int rc;
    int i;

    rc = zmq_poll(items, socket_info.poll_items->len, SNARFD_POLL_TIMEOUT);

    if (rc > 0)
    {
        for (i=0; i < socket_info.poll_items->len; i++)
        {
            if (items[i].events & ZMQ_POLLERR || items[i].revents & ZMQ_POLLERR)
            {
                g_warning("poll error");
            }
            if (items[i].revents & ZMQ_POLLIN)
            {
                int64_t more = 0;           //  Multipart detection
                size_t more_size = sizeof (more);
                GArray *messages = g_array_new(FALSE, FALSE, sizeof(zmq_msg_t));
                int route_num;
                int socket_type;
                size_t socket_type_size = sizeof(socket_type);

                g_debug("poll in");
                rc = zmq_getsockopt (items[i].socket, ZMQ_TYPE, &socket_type,
                                     &socket_type_size);
                g_assert(!rc);

                do {
                    zmq_msg_t message;
                    rc = zmq_msg_init (&message);
                    g_assert(rc != -1);
                    rc = zmq_recvmsg (items[i].socket, &message, 0);
                    g_assert(rc != -1);
                    g_array_append_val(messages, message);
                    rc = zmq_getsockopt (items[i].socket, ZMQ_RCVMORE, &more,
                                         &more_size);
                    g_assert(!rc);
                } while (more);

                for (route_num=0; route_num < routes->len; route_num++)
                {
                    int part_num;
                    route_def_t *route = g_ptr_array_index(routes, route_num);
                    zmq_msg_t *src_envelope = &g_array_index (messages,
                                                              zmq_msg_t,
                                                              messages->len - 2);
                    if (items[i].socket != route->insock)
                    {
                        g_debug("skipping route %d", route_num);
                        continue;
                    }

                    g_debug("testing route %d", route_num);

                    if (snarf_match_route(src_envelope,
                                          (void *)route->generators,
                                          (void *)route->tags))
                    {
                        zmq_msg_t dst_envelope, orig_envelope;
                        zmq_msg_t *src_msg = NULL;
                        zmq_msg_t dst_msg;
                        int rc;
                        int chancount = 0;

                        g_debug("routing to %s", route->outchan);
                        if (stats_socket)
                        {
                            chancount = GPOINTER_TO_INT(
                                g_hash_table_lookup(channel_stats, route->outchan));

                            if (! chancount)
                            {
                                g_hash_table_replace(channel_stats,
                                                     route->outchan,
                                                     GINT_TO_POINTER(1));
                            }
                            else
                            {
                                g_hash_table_replace(channel_stats,
                                                     route->outchan,
                                                     GINT_TO_POINTER(chancount+1));
                            }
                        }
                        /* Send an envelope with the destination subscription */
                        rc = zmq_msg_init_data (&dst_envelope, route->outchan,
                                                strlen(route->outchan), NULL, NULL);
                        g_assert(!rc);
                        /* dump_message(&dst_envelope); */
                        rc = zmq_sendmsg (route->outsock, &dst_envelope, ZMQ_SNDMORE);
                        g_assert(rc != -1);
                        zmq_msg_close (&dst_envelope);

                        if (socket_type == ZMQ_PULL)
                        {
                            /* For PULL sockets only (connections from
                               alert sources) we send a copy of the
                               original envelope */
                            zmq_msg_init (&orig_envelope);
                            zmq_msg_copy(&orig_envelope, src_envelope);
                            /* snarf_dump_envelope(&orig_envelope); */
                            rc = zmq_sendmsg (route->outsock, &orig_envelope, ZMQ_SNDMORE);
                            g_assert(rc != -1);
                            zmq_msg_close(&orig_envelope);
                        }

                        for(part_num=1; part_num < messages->len; part_num++)
                        {
                            src_msg = &g_array_index (messages, zmq_msg_t, part_num);
                            /* dump_message(src_msg); */
                            zmq_msg_init (&dst_msg);
                            g_debug("sending part %d", part_num);
                            zmq_msg_copy(&dst_msg, src_msg);
                            rc = zmq_sendmsg (route->outsock, &dst_msg,
                                           (part_num == messages->len - 1) ? 0 : ZMQ_SNDMORE);
                            g_assert(rc != -1);
                            zmq_msg_close(&dst_msg);
                        }
                    }
                }
                for (i=0; i < messages->len; i++)
                {
                    zmq_msg_t *msg;
                    msg = &g_array_index (messages, zmq_msg_t, i);
                    zmq_msg_close(msg);
                }
                g_array_free(messages, TRUE);
            }
        }
    }
    else if (rc < 0)
    {
        close_sockets();
        return FALSE;
    }
    return TRUE;
}

void dump_channel_stats(gpointer key, gpointer value, gpointer data)
{
    char *channel = (char *) key;
    int count = GPOINTER_TO_INT(value);
    snarf_alert_t *alert;
    GString *str = g_string_new("channel_");
    alert = (snarf_alert_t *) data;
    g_string_append(str, channel);
    g_debug("channel %s: %d\n", str->str, count);
    snarf_alert_add_int_field(alert,
                              str->str,
                              count);
    g_string_free(str, TRUE);

}

gboolean flush_stats(void *data)
{
    snarf_alert_t *alert;

    g_debug("flush_stats");

    alert = snarf_alert_new(ALERT_VERYLOW,
                            snarf_get_current_timestamp());

    snarf_alert_add_int_field(alert,
                              "stats_interval",
                              stats_interval);

    g_hash_table_foreach (channel_stats, dump_channel_stats, alert);

    snarf_source_send_alert(stats_source, "type=stats", alert);
    g_hash_table_remove_all(channel_stats);

    return TRUE;
}

gboolean check_config(gpointer data)
{
    char *file = (char *) data;
    time_t cfg_mtime;


    if (!snarf_check_config(file, &cfg_mtime))
    {
        g_critical("Could not load config file %s", file);
        return FALSE;
    }

    if (cfg_mtime > last_cfg_mtime)
    {
        g_debug("loading config");
        load_config(config_file);
    }
    last_cfg_mtime = cfg_mtime;
    return TRUE;
}

gboolean load_config(char *cfgfile)
{
    GNode *node = NULL;
    char *val = NULL;
    int update = (int) last_cfg_mtime;
    char *stats_sock_name = NULL;

    g_debug("load_config");

    app_config = snarf_load_config(cfgfile, "snarfd");

    if (!app_config)
    {
        g_critical("couldn't load snarf config, use -c option or "
                   "SNARF_CONFIG_FILE environment variable");
        exit(1);
    }

    if (!update)
    {
        node = snarf_find_config_key(app_config, "sockets");
        g_assert(node);
        load_sockets(node);
    }

    node = snarf_find_config_key(app_config, "routes");
    g_assert(node);
    load_routes(node);

    node = snarf_find_config_key(app_config, "stats");
    if (node)
    {
        val = (char *)snarf_get_config_value(node, "enabled");

        if (!val || !g_ascii_strncasecmp(val, "false", strlen(val)))
        {
            g_debug("stats disabled");
            if (stats_source_id)
            {
                g_source_remove (stats_source_id);
                stats_source_id = 0;
                stats_socket = NULL;
            }
        }
        else
        {
            g_debug("stats enabled");

            stats_sock_name = (char *)snarf_get_config_value(node, "socket");
            if (stats_sock_name)
            {
                socket_def_t *sockdef = g_hash_table_lookup(socket_info.sockets,
                                                            stats_sock_name);
                if (sockdef)
                {
                    stats_socket = sockdef->endpoint;
                }
                g_debug("stats socket: %s", stats_sock_name);
            }
            if (snarf_get_config_value(node, "interval"))
            {
                stats_interval = atoi(snarf_get_config_value(node, "interval"));
                g_debug("stats interval: %d", stats_interval);
            }
        }
        if (stats_socket)
        {
            int stats_event_id;
            stats_source = snarf_source_init("org.cert.netsa.snarfd",
                                             PACKAGE_VERSION,
                                             stats_socket);
            channel_stats = g_hash_table_new(g_str_hash, g_str_equal);
            stats_source_id = g_timeout_add(stats_interval * 1000, flush_stats,
                                           NULL);
        }

    }

    val = (char *)snarf_get_config_value(app_config, "reload");
    if (val && !g_ascii_strncasecmp(val, "true", strlen(val)))
    {
        g_debug("reload");
        if (!cfg_timer_source)
            cfg_timer_source = g_timeout_add(5000, check_config,
                                             (gpointer) cfgfile);
    }
    else
    {
        g_debug("no reload");
        if (cfg_timer_source)
            g_source_remove(cfg_timer_source);
    }
    return TRUE;
}



int main(int argc, char *argv[]) {

    char *debug = NULL;

    snarfd_opt_parse(&argc, &argv);

    if (! no_daemon)
        daemonize(pid_file);

    debug = getenv("SNARF_DEBUG");

    if (debug)
    {
        log_levels |= G_LOG_LEVEL_INFO | G_LOG_LEVEL_DEBUG;
        no_log_levels &= G_LOG_LEVEL_INFO | G_LOG_LEVEL_DEBUG;
    }

    main_loop = g_main_loop_new(NULL, FALSE);

    g_log_set_handler(SNARFD_LOG_DOMAIN, no_log_levels,
                      null_logger, NULL);
    g_log_set_handler(SNARFD_LOG_DOMAIN, log_levels,
                      g_log_default_handler, NULL);

    g_setenv ("G_MESSAGES_DEBUG", SNARFD_LOG_DOMAIN, TRUE);
    g_debug("snarfd starting up");

    setup_signals();

    snarf_init();
    context = snarf_context();

    if (! check_config(config_file))
    {
        goto exit;
    }

    g_idle_add(poll_loop, "poll_loop");

    g_main_loop_run(main_loop);

  exit:
    g_debug("terminating");

    if (stats_source)
    {
        snarf_source_destroy(stats_source);
    }

    /* snarf_free_config(app_config); */
    snarf_term();
    return 0;
}

