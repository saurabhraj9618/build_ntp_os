/*
** utils.c
** Structured Network Alert Reporting Framework common utility functions
**
** ------------------------------------------------------------------------
** Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov <tonyc@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
** ------------------------------------------------------------------------
*/

#include "utils.h"

void
null_logger(
    const char    *domain,
    GLogLevelFlags log_level,
    const char    *message,
    gpointer       user_data)
{
}

gboolean
daemonize(const char *pid_file)
{
    pid_t pid = 0;
    int   rv  = 0;

    if (chdir("/") == -1)
    {
        rv = errno;
        g_critical("Cannot change directory: %s", strerror(rv));
        return FALSE;
    }

    /* fork */
    if (fork())
    {
        exit(0);
    }

    /* dissociate from controlling terminal */
    if (setsid() < 0)
    {
        g_critical("setsid() failed: %s", strerror(errno));
        return FALSE;
    }

    /* redirect stdio */
    freopen("/dev/null", "r", stdin);
    freopen("/dev/null", "w", stdout);
    freopen("/dev/null", "w", stderr);

    pid = getpid();
    if (pid_file)
    {
        FILE *pf = fopen(pid_file, "w");
        if (!pf)
        {
            g_critical("could not write pidfile");
            return FALSE;
        }
        fprintf(pf, "%d\n", pid);
        fclose(pf);
    }
    return TRUE;
} /* daemonize */

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
