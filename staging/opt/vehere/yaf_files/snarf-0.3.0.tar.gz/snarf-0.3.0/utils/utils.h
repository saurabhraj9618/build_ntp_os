/*
** utils.h
** Structured Network Alert Reporting Framework common utility functions
**
** ------------------------------------------------------------------------
** Copyright (C) 2011-2013 Carnegie Mellon University. All Rights Reserved.
** ------------------------------------------------------------------------
** Authors: Tony Cebzanov <tonyc@cert.org>
** ------------------------------------------------------------------------
** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
** ------------------------------------------------------------------------
*/

#include <snarf/snarf.h>
#include <glib.h>
#include <glib/gstdio.h>

void
null_logger(
    const char    *domain,
    GLogLevelFlags log_level,
    const char    *message,
    gpointer       user_data);

gboolean
daemonize(
    const char *pid_file);

/*
 * Local Variables:
 * mode:c
 * indent-tabs-mode:nil
 * c-basic-offset:4
 * End:
 */
